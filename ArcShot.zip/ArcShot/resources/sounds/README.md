# Sound effects (optional)

Drop short `.wav` files here (16-bit PCM works everywhere). Missing files are skipped silently.

| File | Plays on |
|---|---|
| swish.wav | any made basket |
| dunk.wav | dunks |
| block.wav | blocks |
| steal.wav | steals |
| ability.wav | Q / E abilities |
| ultimate.wav | ultimates |
| win.wav | winning a match |
| achievement.wav | achievement unlocked |

The mapping is in `core/SoundManager.onEvent`. Check the license of any sound you download.
