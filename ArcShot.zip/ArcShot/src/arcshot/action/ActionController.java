package arcshot.action;

import arcshot.anim.AnimationTable;
import arcshot.court.Match;
import arcshot.player.Player;

/**
 * Owns exactly ONE current action per player. Input, AI and abilities REQUEST actions; the controller accepts or
 * rejects them using the priority / interruptible rules in {@link ActionType}. When no action runs, the player is
 * in a locomotion state (idle, walk, sprint, dribble, defensive stance) derived from movement.
 * <p>
 * This is the "single source of truth" for what a player is doing, so actions can never overlap.
 * OOP pillars: <b>ENCAPSULATION</b> (the current action is private and changes only through
 * {@link #request}/{@link #force}) and <b>POLYMORPHISM</b> (it updates any {@link Action} subclass).
 */
public final class ActionController {
    private final Player owner;
    private Action current;
    private ActionType locomotion = ActionType.IDLE;
    private double locomotionTime;
    private int rejected;

    public ActionController(Player owner) {
        this.owner = owner;
    }

    /** Asks to start an action. Returns false (and changes nothing) if the current action may not be replaced. */
    public boolean request(Action next, Match m) {
        if (current != null && !current.isFinished() && !current.getType().canBeReplacedBy(next.getType())) {
            rejected++;
            return false;
        }
        replace(next, m);
        return true;
    }

    /** Starts an action no matter what (fouls, resets, scripted finishes). */
    public void force(Action next, Match m) {
        replace(next, m);
    }

    private void replace(Action next, Match m) {
        if (current != null && !current.isFinished()) {
            current.cancel(owner, m);
        }
        current = next;
        next.start(owner, m);
    }

    /** Ends whatever is running (e.g. at check ball). */
    public void clear(Match m) {
        if (current != null && !current.isFinished()) {
            current.cancel(owner, m);
        }
        current = null;
    }

    /** Advances the current action (fires its frame events). */
    public void update(double dt, Match m) {
        locomotionTime += dt;
        if (current != null) {
            current.update(dt, owner, m);
            if (current != null && current.isFinished()) {
                current = null;
            }
        }
    }

    /** Set every frame by the match from movement / ball / defense state. */
    public void setLocomotion(ActionType type) {
        if (type.isLocomotion() && type != locomotion) {
            locomotion = type;
            locomotionTime = 0;
        }
    }

    // ---- queries --------------------------------------------------------------------------------------------

    public Action getCurrent() { return current; }

    public boolean isBusy() { return current != null; }

    public ActionType getType() { return current != null ? current.getType() : locomotion; }

    public boolean is(ActionType t) { return getType() == t; }

    public boolean locksMovement() { return current != null && current.getType().locksMovement(); }

    public boolean locksShooting() { return current != null && current.getType().locksShooting(); }

    public boolean locksPassing() { return current != null && current.getType().locksPassing(); }

    public boolean hasRootMotion() { return current != null && current.getType().hasRootMotion(); }

    public boolean isIntangible() { return current != null && current.isIntangible(); }

    /** Height above the floor, never negative. */
    public double getZ() { return current == null ? 0 : Math.max(0, current.getZ()); }

    public boolean isAirborne() { return getZ() > 0.5; }

    /** Times a request was refused (shown in the debug overlay). */
    public int getRejected() { return rejected; }

    /** Animation name for the renderer. */
    public String getAnimation() {
        if (current != null) {
            return current.getAnimation();
        }
        switch (locomotion) {
            case WALK:
            case SPRINT: return "run";
            case DRIBBLE_IDLE: return "dribble";
            case DRIBBLE_MOVE: return "dribble_run";
            case DEFENSIVE_STANCE: return "stance";
            default: return "idle";
        }
    }

    /** Animation frame for the renderer. Locomotion runs faster when sprinting. */
    public int getFrame() {
        if (current != null) {
            return current.getFrame();
        }
        double speedUp = locomotion == ActionType.SPRINT ? 1.35 : 1.0;
        return AnimationTable.get(owner.getPlayerClass().key(), getAnimation()).frameAt(locomotionTime * speedUp);
    }

    /** Seconds the dribble cycle has run (the ball bounce is synced to it). */
    public double getLocomotionTime() { return locomotionTime; }
}
