package arcshot.rules;

import arcshot.player.Player;

/**
 * Charge / illegal contact by the offense: turnover, counts as a team foul, never free throws.
 * OOP pillars: <b>INHERITANCE</b> + <b>POLYMORPHISM</b> (turns the team-foul penalty off).
 */
public class OffensiveFoul extends Foul {
    public OffensiveFoul(Player offender, Player victim) {
        super(offender, victim);
    }

    @Override
    public String getName() { return "OFFENSIVE FOUL"; }

    @Override
    public String getSignal() { return "signal_out"; }

    @Override
    public int teamFoulsAdded() { return RulesConfig.offensiveFoulCountsAsTeamFoul() ? 1 : 0; }

    @Override
    protected boolean usesTeamFoulPenalty() { return false; }

    @Override
    protected int baseFreeThrows(FoulContext ctx) { return 0; }

    @Override
    protected boolean isTurnover() { return true; }
}
