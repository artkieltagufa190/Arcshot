# Sprites

`tools/SpriteSheetGenerator.java` makes every sprite in this folder from code: a small 3D "puppet rig" that is
posed for each frame, projected and pixel-shaded. You can regenerate everything with

```
./build.sh sprites        (Windows: build.bat sprites)
```

and the game picks the new files up the next time it starts. You can also paint over the PNGs by hand.

```
sprites/
  guard/   sheet_a.png  sheet_b.png  manifest.properties     (a / b = two hair styles)
  forward/ ...
  big/     ...
  ref/     sheet_a.png  manifest.properties
  preview.png           (every animation of every class side by side, for checking)
```

## Sheet layout

- Frame size: 48 x 64 px. The feet sit at pixel (24, 61) of every frame. That point is the player's position
  on the court, and the shadow is drawn there.
- Rows: `animationIndex * 3 + facing`. Facing 0 = BACK (toward the hoop, away from the camera),
  1 = FRONT (toward the camera), 2 = SIDE (facing right). Facing left is the SIDE row mirrored in code.
- Columns: frames, left to right.
- **Three angles plus mirroring** is the smallest set that reads well from the broadcast camera. Players face
  the hoop (BACK) or the camera (FRONT) most of the time, and SIDE covers running across the court.
  `Facing.choose()` uses hysteresis, so the sprite does not flicker between angles.

## Colors (mask convention)

Team-dependent parts are painted in fixed **mask colors**, 3 tones each (light, base, dark). In-game,
`SpriteLoader` recolors them with a `Palette` (team color, skin tone, hair color) and caches the result. One
sheet therefore serves every jersey, shoe and skin choice, including the Customize screen colors.

| Part | Light | Base | Dark |
|---|---|---|---|
| Jersey | `#FF66FF` | `#FF00FF` | `#B000B0` |
| Shorts | `#66FF66` | `#00FF00` | `#00B000` |
| Shoes | `#99FFFF` | `#00FFFF` | `#00B0B0` |
| Skin | `#FFB060` | `#FF8000` | `#B05000` |
| Hair | `#A06020` | `#804000` | `#502000` |
| Trim / wristbands | `#FFFF80` | `#FFFF00` | `#B0B000` |
| Outline | `#141018` (not recolored) | | |

If you paint by hand, use **exactly** these colors for the parts that should change color. Any other color is
kept as it is.

## Manifest (`manifest.properties`)

For every animation the manifest stores:

```properties
shoot.frames=7
shoot.fps=14
shoot.loop=false
shoot.events=2:takeoff,4:ball_release,6:foot_land     # frame:event
shoot.row=15
shoot.hand.back=...      # per frame "x,y" offset from the feet: where the ball is drawn
shoot.number.back=...    # where the jersey number is drawn
shoot.head.back=...      # name tag / status icons
```

**Frame events drive gameplay.**
- `ball_release`: the shot or pass leaves the hand.
- `takeoff`: the foul check on the shooter.
- `contact_start` / `contact_end`: the block window.
- `rim_touch`: the dunk scores.
- `grab`: the rebound.
- `contact`: steals.
- `foot_land`: the action ends.

To re-time an animation, edit `fps` or move an event to another frame here. No code change is needed, as long
as the frame count stays the same. (When the count changes, `AnimationTable` keeps its built-in timing.)

## Art tweak section (what to change in `tools/SpriteSheetGenerator.java`)

All of these constants are at the top of the file:

| Want to change | Constant |
|---|---|
| Class body shapes (Guard slim, Forward athletic, Big bulky) | `GUARD`, `FORWARD`, `BIG`, `REF` = `new Body(key, thigh, shin, torso, headR, shoulderW, hipW, upperArm, foreArm, limbR, torsoW, torsoD)`. Units are sprite pixels. Make `torsoW` / `limbR` bigger for bulkier players and `thigh` / `shin` / `torso` longer for taller ones (the frame is 64 px high, so keep the total under about 58). |
| How much forward/back motion shows | `FORESHORTEN` |
| Mask colors | `JERSEY`, `SHORTS`, `SHOE`, `SKIN`, `HAIR`, `TRIM`. These must stay equal to `arcshot.render.sprite.Palette`. |
| Referee shirt stripes / pants | `REF_SHIRT_W`, `REF_SHIRT_B`, `REF_PANTS`, `REF_SHOE` |
| A pose | `pose(anim, frame, frames)`. Each case sets joint angles in degrees (`armA` shoulder pitch, `armE` elbow, `hipA`, `knee`, `crouch`, `lean`). |
| Referee signals | `refPose(...)` |
| Frame counts / fps / events | `AnimationTable` (code defaults) or this manifest |

## Honest quality notes (what to improve by hand)

- **Hands and faces** are only 2 to 4 px. Eyes are one dark pixel. Hand-painted faces, ears and hair
  silhouettes would add the most character.
- **Side view** limbs overlap in the run cycle and can look stiff. A hand-drawn 6-frame side run would look
  better.
- **Dunk and windmill** poses come from joint angles rather than hand-authored key poses. The windmill arm
  sweep reads, but the rim-hang frame could be more dramatic.
- **Shading** is 3 hard tones with a fixed light from the upper left. There is no dithering on the body.
  Adding a 1 px dither band between tones on the jersey would match the reference more closely.
- **The referee** uses the same rig as the players, so the signals are simple arm poses.
- **Licensing:** everything here was generated by the tool. If you replace art with sprites you did not
  draw, check the license and credit it in the main README.
