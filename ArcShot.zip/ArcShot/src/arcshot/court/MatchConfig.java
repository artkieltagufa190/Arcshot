package arcshot.court;

import arcshot.ai.Difficulty;
import arcshot.player.PlayerClass;
import arcshot.save.Loadout;
import java.awt.Color;
import java.util.EnumMap;
import java.util.Map;

/**
 * Everything chosen before a match (class, loadouts, perks, difficulty, colors). Built by the Class Select screen.
 * OOP pillar: <b>ENCAPSULATION</b> - a simple data holder with getters/setters and safe defaults.
 */
public final class MatchConfig {
    private PlayerClass mainClass = PlayerClass.GUARD;
    private Difficulty difficulty = Difficulty.NORMAL;
    private boolean practice;
    private final Map<PlayerClass, Loadout> loadouts = new EnumMap<>(PlayerClass.class);
    private String perk1 = "";
    private String perk2 = "";
    private String playerName = "Player";
    private int jerseyNumber = 7;
    private Color homeColor = new Color(0xFF7A1A);
    private Color awayColor = new Color(0x3A7BFF);
    private boolean autoSwitch = true;
    private double gameSeconds = arcshot.core.Balance.d("rules.gameSeconds", 360);
    private arcshot.rules.FoulFrequency foulFrequency = arcshot.rules.FoulFrequency.NORMAL;
    private boolean strictRefs;
    private long seed = System.nanoTime();

    public PlayerClass getMainClass() { return mainClass; }

    public void setMainClass(PlayerClass mainClass) { this.mainClass = mainClass; }

    public Difficulty getDifficulty() { return difficulty; }

    public void setDifficulty(Difficulty difficulty) { this.difficulty = difficulty; }

    public boolean isPractice() { return practice; }

    public void setPractice(boolean practice) { this.practice = practice; }

    public Loadout getLoadout(PlayerClass pc) { return loadouts.get(pc); }

    public void setLoadout(Loadout l) { loadouts.put(l.getPlayerClass(), l.copy()); }

    public String getPerk1() { return perk1; }

    public String getPerk2() { return perk2; }

    public void setPerks(String p1, String p2) {
        perk1 = p1 == null ? "" : p1;
        perk2 = p2 == null ? "" : p2;
    }

    public String getPlayerName() { return playerName; }

    public void setPlayerName(String playerName) { this.playerName = playerName; }

    public int getJerseyNumber() { return jerseyNumber; }

    public void setJerseyNumber(int jerseyNumber) { this.jerseyNumber = jerseyNumber; }

    public Color getHomeColor() { return homeColor; }

    public void setHomeColor(Color homeColor) { this.homeColor = homeColor; }

    public Color getAwayColor() { return awayColor; }

    public void setAwayColor(Color awayColor) { this.awayColor = awayColor; }

    /** Switch control to whoever on your team gets the ball. */
    public boolean isAutoSwitch() { return autoSwitch; }

    public void setAutoSwitch(boolean autoSwitch) { this.autoSwitch = autoSwitch; }

    /** Regulation length in seconds (Settings: 4 / 6 / 8 / 10 minutes). */
    public double getGameSeconds() { return gameSeconds; }

    public void setGameSeconds(double gameSeconds) { this.gameSeconds = Math.max(30, gameSeconds); }

    public arcshot.rules.FoulFrequency getFoulFrequency() { return foulFrequency; }

    public void setFoulFrequency(arcshot.rules.FoulFrequency f) { this.foulFrequency = f; }

    public boolean isStrictRefs() { return strictRefs; }

    public void setStrictRefs(boolean strictRefs) { this.strictRefs = strictRefs; }

    /** Random seed for fouls and rolls (set it to replay the same match in tests). */
    public long getSeed() { return seed; }

    public void setSeed(long seed) { this.seed = seed; }
}
