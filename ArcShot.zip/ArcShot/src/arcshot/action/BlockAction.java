package arcshot.action;

import arcshot.core.Balance;
import arcshot.court.Interaction;
import arcshot.court.Match;
import arcshot.player.Player;

/**
 * Block jump (or rebound jump). The block can only touch the ball between the {@code contact_start} and
 * {@code contact_end} frame events; a rebound jump tries to grab the ball on the {@code grab} event.
 * OOP pillars: <b>INHERITANCE</b> + <b>POLYMORPHISM</b>.
 */
public class BlockAction extends Action {
    private final boolean rebound;
    private boolean contact;

    public BlockAction(boolean rebound) {
        super(rebound ? ActionType.REBOUND_JUMP : ActionType.BLOCK, rebound ? "rebound" : "block");
        this.rebound = rebound;
    }

    public boolean isRebound() { return rebound; }

    /** True while the hands can touch the ball. */
    public boolean isContactActive() { return contact || getZ() > 12; }

    @Override
    protected void onEvent(String event, Player p, Match m) {
        if ("contact_start".equals(event)) {
            contact = true;
        } else if ("contact_end".equals(event)) {
            contact = false;
        } else if ("grab".equals(event)) {
            m.queue(Interaction.Kind.REBOUND, p, this);
        }
    }

    @Override
    public double getZ() {
        String start = rebound ? "takeoff" : "contact_start";
        return arc(getTime(), def().timeOf(start), def().timeOf("foot_land"),
                Balance.d(rebound ? "anim.reboundHeight" : "anim.blockHeight", rebound ? 40 : 46));
    }
}
