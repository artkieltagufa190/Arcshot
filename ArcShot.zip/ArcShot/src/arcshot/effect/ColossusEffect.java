package arcshot.effect;

/**
 * Colossus Rebound: every missed shot goes to this player; blocks become possession.
 * OOP pillars: <b>INHERITANCE</b> (extends StatusEffect) and <b>POLYMORPHISM</b> (overrides only the modifiers it changes).
 */
public class ColossusEffect extends StatusEffect {
    public ColossusEffect(double duration) {
        super("colossus", duration, false);
    }

    @Override
    public boolean guaranteesRebounds() { return true; }

    @Override
    public boolean isHeavy() { return true; }
}
