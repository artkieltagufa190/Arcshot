package arcshot.messenger;

import arcshot.ui.Theme;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

/**
 * Lets the original Messenger game run inside the resizable window WITHOUT changing its game logic.
 * The game still thinks it is a 480x720 panel: this subclass paints it into an image, scales that image to fit
 * (letterboxing with themed side panels), and converts mouse coordinates back to game coordinates.
 * <p>
 * OOP pillars: <b>INHERITANCE</b> (extends the original {@link GamePanel}) and <b>POLYMORPHISM</b>
 * (overrides {@code paint} and the mouse-event hooks) - a clean way to extend code you must not break.
 */
public class ScaledMessengerPanel extends GamePanel {
    private final BufferedImage buffer = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
    private double scale = 1;
    private double offsetX;
    private double offsetY;

    public ScaledMessengerPanel(Player player, Runnable onExit) {
        super(player, onExit);
        setPreferredSize(new java.awt.Dimension(Theme.LOGICAL_W, Theme.LOGICAL_H));
        setDoubleBuffered(false);
    }

    private void computeTransform() {
        scale = Math.min(getWidth() / (double) WIDTH, getHeight() / (double) HEIGHT);
        scale = Math.max(0.1, scale);
        offsetX = (getWidth() - WIDTH * scale) / 2;
        offsetY = (getHeight() - HEIGHT * scale) / 2;
    }

    @Override
    public void paint(Graphics g0) {
        computeTransform();
        Graphics2D bg = buffer.createGraphics();
        super.paint(bg); // the original GamePanel draws itself at 480x720
        bg.dispose();
        Graphics2D g = (Graphics2D) g0.create();
        Theme.quality(g);
        Theme.paintBackground(g, getWidth(), getHeight());
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        int w = (int) Math.round(WIDTH * scale);
        int h = (int) Math.round(HEIGHT * scale);
        g.setColor(new Color(0, 0, 0, 90));
        g.fillRoundRect((int) offsetX - 6, (int) offsetY + 6, w + 12, h, 24, 24);
        g.drawImage(buffer, (int) offsetX, (int) offsetY, w, h, null);
        paintSides(g, w);
        g.dispose();
    }

    private void paintSides(Graphics2D g, int gameW) {
        int side = (int) offsetX;
        if (side < 220) {
            return;
        }
        int cx = side / 2;
        g.setColor(Theme.ACCENT);
        g.setFont(Theme.display(44));
        Theme.drawCentered(g, "CLASSIC", cx, getHeight() / 2 - 70);
        Theme.drawCentered(g, "SHOOTOUT", cx, getHeight() / 2 - 20);
        g.setFont(Theme.body(16));
        g.setColor(Theme.TEXT_MUTED);
        Theme.drawCentered(g, "Drag the ball back, release to shoot", cx, getHeight() / 2 + 30);
        Theme.drawCentered(g, "Swish = 3 points, rim = 2", cx, getHeight() / 2 + 54);
        int rx = (int) (offsetX + gameW) + side / 2;
        g.setFont(Theme.semi(16));
        g.setColor(Theme.TEXT_MUTED);
        Theme.drawCentered(g, "Esc - back to menu", rx, getHeight() / 2);
        Theme.drawCentered(g, "The hoop starts moving at 6 points", rx, getHeight() / 2 + 28);
        Theme.drawCentered(g, "A defender joins at 14", rx, getHeight() / 2 + 52);
    }

    private MouseEvent toGame(MouseEvent e) {
        int x = (int) Math.round((e.getX() - offsetX) / scale);
        int y = (int) Math.round((e.getY() - offsetY) / scale);
        return new MouseEvent(this, e.getID(), e.getWhen(), e.getModifiersEx(), x, y, e.getXOnScreen(),
                e.getYOnScreen(), e.getClickCount(), e.isPopupTrigger(), e.getButton());
    }

    @Override
    protected void processMouseEvent(MouseEvent e) {
        super.processMouseEvent(toGame(e));
    }

    @Override
    protected void processMouseMotionEvent(MouseEvent e) {
        super.processMouseMotionEvent(toGame(e));
    }
}
