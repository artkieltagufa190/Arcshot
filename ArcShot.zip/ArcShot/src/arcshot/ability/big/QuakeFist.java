package arcshot.ability.big;

import arcshot.ability.AbilitySlot;
import arcshot.ability.ActiveAbility;
import arcshot.court.Match;
import arcshot.effect.SlowEffect;
import arcshot.player.Player;

/**
 * Big E (default): close-range knockback plus a 2 s slow.
 * OOP pillars: <b>INHERITANCE</b> (extends ActiveAbility / Ultimate) and <b>POLYMORPHISM</b> (overrides perform() and the optional hooks).
 */
public class QuakeFist extends ActiveAbility {
    public QuakeFist() {
        super("big.quake_fist", AbilitySlot.E, 15);
    }

    @Override
    protected void perform(Player owner, Match match) {
        double radius = param("radius", 100);
        for (Player o : opponentsNear(owner, match, radius)) {
            double dx = o.getX() - owner.getX();
            double dy = o.getY() - owner.getY();
            double len = Math.max(1, Math.hypot(dx, dy));
            o.applyKnockback(dx / len * param("knockback", 280), dy / len * param("knockback", 280));
            o.applyEffect(new SlowEffect(param("slowTime", 2), param("slow", 0.55)));
        }
        match.shake(5);
        match.fx().ring("quake", owner.getX(), owner.getY(), radius, 0.45);
        match.fx().burst("quake", owner.getX(), owner.getY(), 14, 160);
    }

    @Override
    public boolean aiShouldUse(Player owner, Match match) {
        // only as a defensive play: swinging it while holding the ball draws offensive fouls in the upgrade's rules
        Player near = match.nearestOpponent(owner, 80);
        return near != null && hasBall(near, match);
    }
}
