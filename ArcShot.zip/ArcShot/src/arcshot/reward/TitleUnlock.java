package arcshot.reward;

import arcshot.save.Profile;
import arcshot.ui.ThemeSkin;

/**
 * Unlocks a player title shown on the main menu. The newest title is equipped automatically.
 * OOP pillar: <b>POLYMORPHISM</b> - implements Reward; the manager just calls grant().
 */
public final class TitleUnlock implements Reward {
    private final String title;

    public TitleUnlock(String title) {
        this.title = title;
    }

    @Override
    public void grant(Profile profile) {
        profile.unlock(Profile.TITLE + title);
        profile.setTitle(title);
    }

    @Override
    public String describe(ThemeSkin skin) {
        return "Title: \"" + title + "\"";
    }

    @Override
    public boolean provides(String unlockKey) {
        return (Profile.TITLE + title).equals(unlockKey);
    }
}
