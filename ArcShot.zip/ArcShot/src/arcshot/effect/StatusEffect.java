package arcshot.effect;

/**
 * Base class of every temporary effect on a player (slow, freeze, boosts, barrier, ...).
 * <p>
 * OOP pillars:
 * <ul>
 *   <li><b>ABSTRACTION</b> - a player only sees "an effect that may change my speed / shooting / reach";
 *       it never needs to know which ability caused it.</li>
 *   <li><b>INHERITANCE</b> - subclasses such as {@link SlowEffect} and {@link FreezeEffect} reuse the timer logic.</li>
 *   <li><b>POLYMORPHISM</b> - every modifier method has a neutral default; a subclass overrides only what it changes,
 *       e.g. {@code SlowEffect} overrides only {@link #speedMultiplier()}.</li>
 *   <li><b>ENCAPSULATION</b> - the remaining time is private and only changes through {@link #update},
 *       {@link #refresh} and {@link #scaleDuration}.</li>
 * </ul>
 */
public abstract class StatusEffect {
    private final String id;
    private final boolean debuff;
    private double duration;
    private double remaining;

    protected StatusEffect(String id, double duration, boolean debuff) {
        this.id = id;
        this.debuff = debuff;
        this.duration = Math.max(0.01, duration);
        this.remaining = this.duration;
    }

    /** Effects with the same id replace each other instead of stacking. Also used as the visual key. */
    public final String getId() { return id; }

    /** True for harmful effects (Ironclad perk shortens these). */
    public final boolean isDebuff() { return debuff; }

    public final double getRemaining() { return remaining; }

    public final double getDuration() { return duration; }

    /** 1.0 when just applied, 0.0 when about to expire. */
    public final double getFractionLeft() { return Math.max(0, remaining / duration); }

    public final boolean isExpired() { return remaining <= 0; }

    /** Counts the effect down. Final so every subclass expires the same way. */
    public final void update(double dt) {
        remaining -= dt;
    }

    /** Ends the effect immediately (e.g. a one-shot effect that was consumed). */
    public final void expire() {
        remaining = 0;
    }

    /** Used when the same effect is applied again: keeps the longer of the two timers. */
    public final void refresh(double newDuration) {
        if (newDuration > remaining) {
            remaining = newDuration;
            duration = Math.max(duration, newDuration);
        }
    }

    /** Multiplies the length (e.g. 0.65 for Ironclad). */
    public final void scaleDuration(double factor) {
        duration *= factor;
        remaining *= factor;
    }

    /** Short text shown in the HUD / colorblind cues. */
    public String getLabel() { return id.toUpperCase(); }

    // ---- modifiers: neutral by default, overridden by subclasses ----------------------------------------------

    public double speedMultiplier() { return 1.0; }

    /** Added to the make chance (0.10 = +10%). */
    public double shootingBonus(boolean outsideArc) { return 0.0; }

    /** Added to the defense rating (steal / block / contest power). */
    public double defenseBonus() { return 0.0; }

    public double reachMultiplier(Reach reach) { return 1.0; }

    public boolean preventsMovement() { return false; }

    public boolean preventsActions() { return false; }

    public boolean preventsShooting() { return false; }

    public boolean isUnblockable() { return false; }

    public boolean isIntangible() { return false; }

    public boolean isStealResistant() { return false; }

    public boolean guaranteesGreen() { return false; }

    public boolean guaranteesRebounds() { return false; }

    public boolean autoContestsPaint() { return false; }

    /** Heavy players cannot be pushed around by collisions or knockback. */
    public boolean isHeavy() { return false; }

    /** True if the effect is used up by the next shot (e.g. Deadeye Mark). */
    public boolean consumedOnShot() { return false; }
}
