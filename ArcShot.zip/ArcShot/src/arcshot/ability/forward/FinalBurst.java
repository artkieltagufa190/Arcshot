package arcshot.ability.forward;

import arcshot.ability.Ultimate;
import arcshot.core.Balance;
import arcshot.court.Court;
import arcshot.court.Match;
import arcshot.effect.StunEffect;
import arcshot.effect.UnblockableEffect;
import arcshot.player.Player;

/**
 * Forward R (default): rocket to the rim for an unblockable forced dunk that knocks defenders back.
 * OOP pillars: <b>INHERITANCE</b> (extends ActiveAbility / Ultimate) and <b>POLYMORPHISM</b> (overrides perform() and the optional hooks).
 */
public class FinalBurst extends Ultimate {
    private double dashTime;

    public FinalBurst() {
        super("forward.final_burst");
    }

    @Override
    protected boolean meetsRequirements(Player owner, Match match) {
        return hasBall(owner, match) && !match.needsClear()
                && match.getCourt().distanceToHoop(owner.getX(), owner.getY()) <= param("range", 360);
    }

    @Override
    protected void perform(Player owner, Match match) {
        Court c = match.getCourt();
        double dist = c.distanceToHoop(owner.getX(), owner.getY());
        dashTime = Math.max(0.12, dist / param("speed", 900));
        owner.applyEffect(new UnblockableEffect("final_burst", dashTime + 0.5, true));
        owner.startDash(c.getHoopX() - owner.getX(), c.getHoopY() - owner.getY(), Math.max(0, dist - 24), dashTime, true);
        match.flash("final_burst", 0.2);
    }

    @Override
    protected double activeDuration() {
        return dashTime;
    }

    @Override
    protected void whileActive(double dt, Player owner, Match match) {
        match.fx().afterimage(owner, "final_burst");
    }

    @Override
    protected void onEnd(Player owner, Match match) {
        match.forceDunk(owner, (int) param("points", Balance.i("rules.insidePoints", 1)));
        for (Player o : opponentsNear(owner, match, param("radius", 140))) {
            double dx = o.getX() - owner.getX();
            double dy = o.getY() - owner.getY();
            double len = Math.max(1, Math.hypot(dx, dy));
            o.applyKnockback(dx / len * 380, dy / len * 380);
            o.applyEffect(new StunEffect(param("stun", 0.8)));
        }
        match.shake(12);
        match.hitStop(0.12);
        match.flash("final_burst", 0.35);
        match.fx().ring("final_burst", owner.getX(), owner.getY(), 160, 0.5);
        match.fx().text("FINAL BURST!", "final_burst", owner.getX(), owner.getY() - 90);
    }

    @Override
    public boolean aiShouldUse(Player owner, Match match) {
        return meetsRequirements(owner, match);
    }
}
