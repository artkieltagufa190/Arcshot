package arcshot.save;

import arcshot.player.PlayerClass;

/**
 * The chosen Q, E and R ability ids for one class.
 * OOP pillar: <b>ENCAPSULATION</b> - ids are private and never null.
 */
public final class Loadout {
    private final PlayerClass playerClass;
    private String q;
    private String e;
    private String r;

    public Loadout(PlayerClass playerClass, String q, String e, String r) {
        this.playerClass = playerClass;
        setQ(q);
        setE(e);
        setR(r);
    }

    public PlayerClass getPlayerClass() { return playerClass; }

    public String getQ() { return q; }

    public String getE() { return e; }

    public String getR() { return r; }

    public void setQ(String q) { this.q = q == null ? "" : q; }

    public void setE(String e) { this.e = e == null ? "" : e; }

    public void setR(String r) { this.r = r == null ? "" : r; }

    public Loadout copy() {
        return new Loadout(playerClass, q, e, r);
    }
}
