package arcshot.ui.screens;

import arcshot.app.AppContext;
import arcshot.messenger.Player;
import arcshot.messenger.ScaledMessengerPanel;
import arcshot.ui.Screen;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.KeyStroke;

/**
 * Hosts the original Messenger shootout (unchanged logic) inside the new app. Esc returns to the menu.
 * OOP pillars: <b>INHERITANCE</b> (extends Screen) and <b>POLYMORPHISM</b> (the ScreenManager calls its lifecycle hooks).
 */
public class MessengerScreen extends Screen {
    private ScaledMessengerPanel game;

    public MessengerScreen(AppContext app) {
        super(app);
        setBorder(BorderFactory.createEmptyBorder());
    }

    @Override
    public void onEnter() {
        Player player = new Player(app.profile().getName());
        game = new ScaledMessengerPanel(player, this::exit);
        add(game, BorderLayout.CENTER);
        getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), "back");
        getActionMap().put("back", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exit();
            }
        });
        revalidate();
    }

    private void exit() {
        if (game != null) {
            game.stop();
        }
        app.back();
    }

    @Override
    public void onExit() {
        if (game != null) {
            game.stop();
        }
    }
}
