#!/bin/sh
# Compile and run ArcShot. Usage: ./build.sh          (compile + run)
#                                 ./build.sh compile  (compile only)
#                                 ./build.sh jar      (compile + build ArcShot.jar)
#                                 ./build.sh test     (compile + run the self-tests)
#                                 ./build.sh sprites  (regenerate resources/sprites with the generator tool)
set -e
cd "$(dirname "$0")"
if [ "$1" = "sprites" ]; then
  rm -rf out-tools && mkdir -p out-tools
  javac -encoding UTF-8 --release 10 -sourcepath src -d out-tools tools/SpriteSheetGenerator.java
  java -cp out-tools SpriteSheetGenerator resources/sprites
  exit 0
fi
rm -rf out
mkdir -p out
find src -name "*.java" > out/sources.txt
javac -encoding UTF-8 --release 10 -d out @out/sources.txt
cp -R resources/* out/
rm out/sources.txt
if [ "$1" = "compile" ]; then exit 0; fi
if [ "$1" = "test" ]; then java -cp out arcshot.test.SelfTests "${2:-4}"; exit $?; fi
if [ "$1" = "jar" ]; then
  jar cfe ArcShot.jar arcshot.App -C out .
  echo "Built ArcShot.jar - run with: java -jar ArcShot.jar"
  exit 0
fi
java -cp out arcshot.App
