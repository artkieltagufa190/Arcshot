package arcshot.reward;

import arcshot.perk.Perk;
import arcshot.perk.PerkRegistry;
import arcshot.save.Profile;
import arcshot.ui.ThemeSkin;

/**
 * Unlocks a passive perk.
 * OOP pillar: <b>POLYMORPHISM</b> - implements Reward; the manager just calls grant().
 */
public final class PerkUnlock implements Reward {
    private final String perkId;

    public PerkUnlock(String perkId) {
        this.perkId = perkId;
    }

    @Override
    public void grant(Profile profile) {
        profile.unlock(Profile.PERK + perkId);
    }

    @Override
    public String describe(ThemeSkin skin) {
        Perk perk = PerkRegistry.create(perkId);
        return "Perk: " + (perk == null ? perkId : perk.getName());
    }

    @Override
    public boolean provides(String unlockKey) {
        return (Profile.PERK + perkId).equals(unlockKey);
    }
}
