package arcshot.action;

import arcshot.core.Balance;
import arcshot.court.Interaction;
import arcshot.court.Match;
import arcshot.player.Player;

/**
 * Dunk: gather, takeoff, rise to the rim (root motion + z arc), slam on the {@code rim_touch} frame event, hang on
 * the rim, drop and land. Variants by animation: "dunk" (one hand), "dunk2" (two hands), "windmill" (Final Burst).
 * The ball stays in the dunker's hands until {@code rim_touch}, so a block during the rise knocks it loose.
 * OOP pillars: <b>INHERITANCE</b> + <b>POLYMORPHISM</b>.
 */
public class DunkAction extends Action {
    private final double rimX;
    private final double rimY;
    private final boolean forced;
    private final int points;
    private double startX;
    private double startY;
    private boolean slammed;

    /** @param forced true for ultimates: cannot be blocked, always counts */
    public DunkAction(String variant, double rimX, double rimY, boolean forced, int points) {
        super(ActionType.DUNK, variant);
        this.rimX = rimX;
        this.rimY = rimY;
        this.forced = forced;
        this.points = points;
    }

    public boolean isForced() { return forced; }

    public int getPoints() { return points; }

    public boolean hasSlammed() { return slammed; }

    /** True between takeoff and the slam: the window in which a dunk can be blocked or fouled. */
    public boolean isRising() {
        return !slammed && getTime() >= def().timeOf("takeoff");
    }

    @Override
    protected void onStart(Player p, Match m) {
        startX = p.getX();
        startY = p.getY();
        p.face(rimX - startX, rimY - startY);
    }

    @Override
    protected void onUpdate(double dt, Player p, Match m) {
        double tRim = def().timeOf("rim_touch");
        double u = Math.min(1, getTime() / tRim);
        double ease = u * u * (3 - 2 * u);
        if (!slammed) {
            p.setPosition(startX + (rimX - startX) * ease, startY + (rimY - startY) * ease);
        }
    }

    @Override
    protected void onEvent(String event, Player p, Match m) {
        if ("takeoff".equals(event) && !forced) {
            m.queue(Interaction.Kind.FOUL_CHECK, p, "dunk");
        } else if ("rim_touch".equals(event)) {
            slammed = true;
            m.queue(Interaction.Kind.SCORE, p, this);
        }
    }

    @Override
    public boolean isIntangible() {
        return forced; // ultimates fly through defenders
    }

    @Override
    public double getZ() {
        double t = getTime();
        double t0 = def().timeOf("takeoff");
        double tr = def().timeOf("rim_touch");
        double tl = def().timeOf("foot_land");
        double peak = Balance.d("anim.dunkHeight", 50) + (p() ? 10 : 0);
        if (t < t0) {
            return 0;
        }
        if (t < tr) {
            double u = (t - t0) / (tr - t0);
            return peak * (1 - (1 - u) * (1 - u));
        }
        double hang = 1.0 / def().getFps();
        if (t < tr + hang) {
            return peak - 4;
        }
        double u = Math.min(1, (t - tr - hang) / Math.max(0.01, tl - tr - hang));
        return Math.max(0, (peak - 4) * (1 - u * u));
    }

    private boolean p() {
        return "windmill".equals(getAnimation());
    }
}
