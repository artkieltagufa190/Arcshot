package arcshot.rules;

/** Settings option: how often referees call contact. */
public enum FoulFrequency {
    OFF("Off", 0), LOW("Low", 0.5), NORMAL("Normal", 1.0), HIGH("High", 1.7);

    private final String label;
    private final double multiplier;

    FoulFrequency(String label, double multiplier) {
        this.label = label;
        this.multiplier = multiplier;
    }

    public String getLabel() { return label; }

    public double getMultiplier() { return multiplier; }

    public static FoulFrequency fromName(String name) {
        for (FoulFrequency f : values()) {
            if (f.name().equalsIgnoreCase(name)) {
                return f;
            }
        }
        return NORMAL;
    }
}
