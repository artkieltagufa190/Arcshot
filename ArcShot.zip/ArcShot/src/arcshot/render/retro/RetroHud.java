package arcshot.render.retro;

import arcshot.ability.Ability;
import arcshot.ability.AbilitySlot;
import arcshot.achievement.Achievement;
import arcshot.action.Action;
import arcshot.action.JumpShotAction;
import arcshot.control.InputAction;
import arcshot.core.GameEvent;
import arcshot.core.GameEventListener;
import arcshot.core.GameEventType;
import arcshot.court.Ball;
import arcshot.court.CourtGeometry;
import arcshot.court.FreeThrowAim;
import arcshot.court.Match;
import arcshot.court.Team;
import arcshot.player.Player;
import arcshot.player.TeamSide;
import arcshot.render.RenderContext;
import arcshot.rules.FreeThrowSequence;
import arcshot.rules.RulesConfig;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * The retro HUD, drawn in the same 640x360 pixel buffer as the court:
 * broadcast scoreboard bottom-right (clock, shot clock, team-foul pips, BONUS light), controlled-player card with
 * Q/E/R icons bottom-left, the vertical shot meter for jump shots, the <b>arc-arrow aim for free throws</b>,
 * banners, hints, achievement toasts, a commentary ticker and the F3 debug readout.
 * It listens to the event bus for toasts and commentary (it never changes gameplay).
 * OOP pillars: <b>POLYMORPHISM</b> (a {@link GameEventListener}) and <b>ENCAPSULATION</b>.
 */
public final class RetroHud implements GameEventListener {
    static final Color PANEL = new Color(0x0B0F1E);
    static final Color PANEL_2 = new Color(0x1A2140);
    static final Color EDGE = new Color(0x4A4F66);
    static final Color WHITE = new Color(0xF4F4F0);
    static final Color MUTED = new Color(0x9AA0B4);
    static final Color GOLD = new Color(0xF4CC3A);
    static final Color GREEN = new Color(0x2ECC40);
    static final Color RED = new Color(0xD8462A);
    static final Color CYAN = new Color(0x5FD3F0);
    static final Color OUTLINE = RetroCourtRenderer.OUTLINE;

    private static final double TOAST_TIME = 4.0;
    private static final double LINE_TIME = 4.5;

    /** A toast or a commentary line. */
    private static final class Msg {
        final String title;
        final String sub;
        double age;

        Msg(String title, String sub) {
            this.title = title;
            this.sub = sub;
        }
    }

    private final RenderContext ctx;
    private Projection pr;
    private final ConcurrentLinkedQueue<Msg> incomingToasts = new ConcurrentLinkedQueue<>();
    private final ConcurrentLinkedQueue<String> incomingLines = new ConcurrentLinkedQueue<>();
    private final List<Msg> toasts = new ArrayList<>();
    private Msg line;
    private final RetroAbilityIcons icons = new RetroAbilityIcons();

    public RetroHud(RenderContext ctx, Projection pr) {
        this.ctx = ctx;
        this.pr = pr;
    }

    /** The projection is created on the first frame (it needs the court). */
    void setProjection(Projection pr) {
        this.pr = pr;
    }

    // =========================================================================================================
    // events -> toasts and commentary
    // =========================================================================================================

    @Override
    public void onEvent(GameEvent e) {
        GameEventType t = e.getType();
        if (t == GameEventType.ACHIEVEMENT_UNLOCKED && e.getPayload() instanceof Achievement) {
            Achievement a = (Achievement) e.getPayload();
            incomingToasts.add(new Msg(a.getName(), a.getTier().getDisplayName() + " UNLOCKED"));
            return;
        }
        Player p = e.getSource();
        String who = p == null ? "" : p.getName();
        switch (t) {
            case DUNK: incomingLines.add(pick(who + " THROWS IT DOWN!", "SLAM! " + who + " WITH AUTHORITY", who + " RATTLES THE RIM!")); break;
            case LAYUP: incomingLines.add(pick(who + " LAYS IT IN", "SMOOTH FINISH BY " + who, who + " OFF THE GLASS")); break;
            case THREE_MADE: incomingLines.add(pick(who + " FROM DOWNTOWN!", "BANG! " + who + " FOR TWO", who + " - NOTHING BUT NET")); break;
            case BLOCK: incomingLines.add(pick("REJECTED BY " + who + "!", who + " SAYS NO!", "GET THAT OUTTA HERE!")); break;
            case STEAL: incomingLines.add(pick(who + " PICKS HIS POCKET", "STOLEN BY " + who, who + " JUMPS THE LANE")); break;
            case AND_ONE: incomingLines.add("AND ONE! " + who + " TO THE LINE"); break;
            case FOUL_COMMITTED: incomingLines.add("WHISTLE - FOUL ON " + who); break;
            case FREE_THROW_MADE: incomingLines.add(who + " HITS THE FREE THROW"); break;
            case FREE_THROW_MISSED: incomingLines.add(who + " MISSES AT THE LINE"); break;
            case TURNOVER: incomingLines.add(pick("TURNOVER " + (who.isEmpty() ? "" : "BY " + who), "COUGHED IT UP")); break;
            case ULTIMATE_USED: incomingLines.add(who + " GOES ULTIMATE!"); break;
            default: break;
        }
    }

    private String pick(String... options) {
        return options[(int) (System.nanoTime() / 1000 % options.length)].trim();
    }

    public void update(double dt) {
        Msg m;
        while ((m = incomingToasts.poll()) != null) {
            toasts.add(m);
        }
        String s;
        while ((s = incomingLines.poll()) != null) {
            line = new Msg(s, "");
        }
        Iterator<Msg> it = toasts.iterator();
        while (it.hasNext()) {
            Msg t = it.next();
            t.age += dt;
            if (t.age > TOAST_TIME) {
                it.remove();
            }
        }
        if (line != null) {
            line.age += dt;
            if (line.age > LINE_TIME) {
                line = null;
            }
        }
    }

    // =========================================================================================================
    // draw
    // =========================================================================================================

    public void draw(Graphics2D g, Match m) {
        Player c = m.getControlled();
        if (pr == null) {
            return;
        }
        if (m.isFreeThrow()) {
            drawFreeThrowAim(g, m);
        } else if (c != null) {
            drawShotMeter(g, m, c);
        }
        drawScoreboard(g, m);
        if (c != null) {
            drawPlayerCard(g, m, c);
        }
        drawTicker(g, m);
        drawChips(g, m);
        drawBanner(g, m);
        drawToasts(g);
        if (ctx.isShowFps() || ctx.isDebug()) {
            PixelFont.drawOutlined(g, ctx.getFps() + " FPS", 4, 14, MUTED, OUTLINE, 1);
        }
        if (ctx.isDebug()) {
            drawDebug(g, m);
        }
    }

    // ---- scoreboard (bottom-right, like the classic broadcast bug) ------------------------------------------

    private void drawScoreboard(Graphics2D g, Match m) {
        int w = 128;
        int h = 46;
        int x = Projection.W - w - 6;
        int y = Projection.H - h - 6;
        box(g, x, y, w, h);
        // header: period + game clock, shot clock box
        String period = m.isPractice() ? "PRAC" : (m.isOvertime() ? "OT" : "1ST");
        PixelFont.draw(g, period, x + 4, y + 4, GOLD, 1);
        String clock = m.isPractice() ? "--:--" : (m.isOvertime() ? "FIRST TO " + RulesConfig.overtimePoints() : m.getClockText());
        PixelFont.draw(g, clock, x + 30, y + 4, WHITE, 1);
        if (!m.isPractice()) {
            int sc = (int) Math.ceil(m.getShotClock());
            g.setColor(OUTLINE);
            g.fillRect(x + w - 20, y + 2, 17, 11);
            g.setColor(sc <= 4 ? RED : new Color(0x2A2D3A));
            g.fillRect(x + w - 19, y + 3, 15, 9);
            PixelFont.draw(g, String.valueOf(sc), x + w - 11 - PixelFont.width(String.valueOf(sc), 1) / 2, y + 4,
                    sc <= 4 ? WHITE : GOLD, 1);
        }
        g.setColor(EDGE);
        g.fillRect(x + 2, y + 15, w - 4, 1);
        teamRow(g, m, m.getHome(), x, y + 18, w);
        teamRow(g, m, m.getAway(), x, y + 31, w);
    }

    private void teamRow(Graphics2D g, Match m, Team t, int x, int y, int w) {
        boolean ball = m.getOffense() == t.getSide() && !m.isFinished();
        g.setColor(t.getColor());
        g.fillRect(x + 3, y, 4, 11);
        PixelFont.draw(g, abbreviation(t.getName()), x + 10, y + 2, WHITE, 1);
        if (ball) {
            g.setColor(new Color(0xE8742A));
            g.fillRect(x + 32, y + 4, 3, 3);
        }
        // team-foul pips (6 = one away from the bonus), then BONUS light
        int fouls = m.getRules().getTeamFouls(t.getSide());
        int bonusFrom = RulesConfig.bonusFrom();
        for (int i = 0; i < bonusFrom - 1; i++) {
            g.setColor(i < fouls ? GOLD : new Color(0x2A2D3A));
            g.fillRect(x + 39 + i * 4, y + 4, 3, 3);
        }
        boolean bonus = m.getRules().isInPenalty(t.getSide());
        if (bonus) {
            g.setColor(RED);
            g.fillRect(x + 64, y + 1, 31, 9);
            PixelFont.draw(g, "BONUS", x + 66, y + 2, WHITE, 1);
        } else if (fouls > 0) {
            PixelFont.draw(g, "F" + fouls, x + 66, y + 2, MUTED, 1);
        }
        String score = String.valueOf(t.getScore());
        g.setColor(OUTLINE);
        g.fillRect(x + w - 27, y, 24, 11);
        PixelFont.draw(g, score, x + w - 4 - PixelFont.width(score, 1) - 2, y + 2, WHITE, 1);
    }

    private static String abbreviation(String name) {
        String clean = name.toUpperCase().replaceAll("[^A-Z ]", "").trim();
        String[] parts = clean.split(" +");
        if (parts.length >= 2) {
            return parts[parts.length - 1].length() >= 3 ? parts[parts.length - 1].substring(0, 3) : (parts[0].charAt(0) + parts[1]).substring(0, Math.min(3, parts[1].length() + 1));
        }
        return clean.length() >= 3 ? clean.substring(0, 3) : clean;
    }

    // ---- player card (bottom-left) --------------------------------------------------------------------------

    private void drawPlayerCard(Graphics2D g, Match m, Player p) {
        int x = 6;
        int y = Projection.H - 52;
        int w = 166;
        box(g, x, y, w, 46);
        g.setColor(m.teamOf(p.getSide()).getColor());
        g.fillRect(x + 3, y + 3, 14, 14);
        PixelFont.drawTinyNumber(g, String.valueOf(p.getNumber()), x + 10, y + 7, WHITE);
        String name = p.getName().toUpperCase();
        if (name.length() > 12) {
            name = name.substring(0, 12);
        }
        PixelFont.draw(g, name, x + 21, y + 4, WHITE, 1);
        PixelFont.draw(g, p.getPlayerClass().getDisplayName(), x + 21, y + 12, MUTED, 1);
        if (p.getConsecutiveMakes() >= arcshot.core.Balance.i("heat.streak", 3)) {
            boolean on = ((int) (m.getElapsed() * 6)) % 2 == 0;
            PixelFont.draw(g, "HOT", x + w - 22, y + 4, on ? RED : GOLD, 1);
        }
        // stamina + ultimate
        bar(g, x + 3, y + 22, 64, 3, p.getStamina() / 100.0, GREEN);
        Color ult = p.isUltimateReady() && ((int) (m.getElapsed() * 6)) % 2 == 0 ? WHITE : GOLD;
        bar(g, x + 3, y + 28, 64, 3, p.getUltimateCharge() / 100.0, ult);
        PixelFont.draw(g, "STA", x + 3, y + 34, MUTED, 1);
        PixelFont.draw(g, "ULT", x + 27, y + 34, MUTED, 1);
        // Q / E / R
        InputAction[] keys = {InputAction.ABILITY_Q, InputAction.ABILITY_E, InputAction.ULTIMATE};
        AbilitySlot[] slots = AbilitySlot.values();
        for (int i = 0; i < 3; i++) {
            Ability a = p.getAbility(slots[i]);
            if (a != null) {
                icons.draw(g, m, p, a, x + 72 + i * 31, y + 19, shortKey(ctx.getKeys().shortName(keys[i])), ctx.getSkin());
            }
        }
    }

    private static String shortKey(String k) {
        return k.length() > 2 ? k.substring(0, 1) : k;
    }

    // ---- jump shot meter (vertical, beside the shooter) -----------------------------------------------------

    private void drawShotMeter(Graphics2D g, Match m, Player p) {
        Action a = p.getActions().getCurrent();
        if (!(a instanceof JumpShotAction) || !((JumpShotAction) a).isCharging() || p.getShotHold() < 0) {
            return;
        }
        double t = p.getShotHold() / m.getMeterTime(p);
        int h = 30;
        int x = pr.ix(p.getX(), p.getY()) + 14;
        int y = pr.iy(p.getX(), p.getY(), 0) - 52;
        g.setColor(OUTLINE);
        g.fillRect(x - 2, y - 2, 9, h + 4);
        g.setColor(new Color(0x2A2D3A));
        g.fillRect(x - 1, y - 1, 7, h + 2);
        int gy0 = y + h - (int) Math.round(h * m.getGreenEnd());
        int gy1 = y + h - (int) Math.round(h * m.getGreenStart());
        g.setColor(new Color(0x1E7A2A));
        g.fillRect(x, gy0, 5, gy1 - gy0);
        boolean inGreen = t >= m.getGreenStart() && t <= m.getGreenEnd() || p.hasGuaranteedGreen();
        Color fill = inGreen ? WHITE : (t > m.getGreenEnd() ? RED : new Color(0xE8742A));
        int fh = (int) Math.round(h * Math.min(1, t));
        // chunky 2-px steps
        for (int i = 0; i < fh; i += 2) {
            g.setColor(fill);
            g.fillRect(x + 1, y + h - i - 2, 3, 2);
        }
        if (inGreen) {
            g.setColor(GREEN);
            g.drawRect(x - 2, y - 2, 8, h + 3);
        }
        if (p.hasGuaranteedGreen()) {
            PixelFont.drawCentered(g, "LOCK", x + 2, y - 10, GREEN, OUTLINE, 1);
        }
    }

    // ---- free throws: the 2K-style arc arrow (see FreeThrowAim) ---------------------------------------------

    private void drawFreeThrowAim(Graphics2D g, Match m) {
        FreeThrowSequence seq = m.getFreeThrows();
        Ball ball = m.getBall();
        Player s = ball.getState() == Ball.State.HELD ? ball.getHolder() : null;
        if (seq != null) {
            String label = "FREE THROW " + Math.min(seq.getTotal(), seq.getTaken() + 1) + " OF " + seq.getTotal();
            PixelFont.drawCentered(g, label, Projection.W / 2, 6, WHITE, OUTLINE, 1);
        }
        if (s == null) {
            return;
        }
        FreeThrowAim aim = m.getFreeThrowAim();
        boolean human = s.isHumanControlled();
        if (!aim.isAiming()) {
            if (human && ((int) (m.getElapsed() * 3)) % 2 == 0) {
                PixelFont.drawCentered(g, "HOLD " + ctx.getKeys().shortName(InputAction.SHOOT), pr.ix(s.getX(), s.getY()),
                        pr.iy(s.getX(), s.getY(), 0) + 6, GOLD, OUTLINE, 1);
            }
            if (!human) {
                return;
            }
        }
        CourtGeometry c = m.getCourt();
        double sx = pr.x(s.getX(), s.getY());
        double sy = pr.y(s.getX(), s.getY(), 75);
        double rimX = pr.x(c.getHoopX(), c.getHoopY());
        double rimY = pr.y(c.getHoopX(), c.getHoopY(), c.getRimHeight());
        double power = aim.isAiming() ? Math.min(1.45, aim.getPower()) : 0.0;
        double tipTargetX = rimX + aim.getSway() * 26;
        double e = aim.error(human ? 1.0 : 0.35);
        Color col = !aim.isAiming() ? MUTED : (e <= 1 ? GREEN : (e <= 2 ? GOLD : RED));
        // The path is a hook like the classic 2K free-throw arrow: a cubic curve that rises from the shooter's hands,
        // bends out to the right above the backboard and comes down onto the rim (t = 1). Holding SHOOT reveals more
        // of it; past t = 1 it keeps falling along its last direction (too long).
        double reach = Math.max(0.06, power);
        int steps = Math.max(6, (int) (reach * 48));
        double[] xs = new double[steps + 1];
        double[] ys = new double[steps + 1];
        double p1x = sx + 28;
        double p1y = rimY - 22;
        double p2x = tipTargetX + 56;
        double p2y = rimY - 78;
        double p3x = tipTargetX;
        double p3y = rimY - 3;
        for (int i = 0; i <= steps; i++) {
            double u = reach * i / steps;
            double t = Math.min(1, u);
            double a = (1 - t) * (1 - t) * (1 - t);
            double b = 3 * (1 - t) * (1 - t) * t;
            double c2 = 3 * (1 - t) * t * t;
            double d = t * t * t;
            xs[i] = a * sx + b * p1x + c2 * p2x + d * p3x;
            ys[i] = a * sy + b * p1y + c2 * p2y + d * p3y;
            if (u > 1) {
                // continue along the final tangent (P2 -> P3), i.e. down and to the left of the rim
                double ex = p3x - p2x;
                double ey = p3y - p2y;
                double el = Math.hypot(ex, ey);
                xs[i] += ex / el * (u - 1) * 80;
                ys[i] += ey / el * (u - 1) * 80;
            }
        }
        // shaft: a solid ribbon, 3 px at the hands widening to 6 px, with a 1 px outline
        for (int pass = 0; pass < 2; pass++) {
            for (int i = 0; i < steps; i++) {
                double dx = xs[i + 1] - xs[i];
                double dy = ys[i + 1] - ys[i];
                double len = Math.max(0.001, Math.hypot(dx, dy));
                double nx = -dy / len;
                double ny = dx / len;
                double half = (1.5 + 1.5 * i / (double) steps) + (pass == 0 ? 1 : 0);
                Polygon seg = new Polygon();
                seg.addPoint((int) Math.round(xs[i] + nx * half), (int) Math.round(ys[i] + ny * half));
                seg.addPoint((int) Math.round(xs[i + 1] + nx * half), (int) Math.round(ys[i + 1] + ny * half));
                seg.addPoint((int) Math.round(xs[i + 1] - nx * half), (int) Math.round(ys[i + 1] - ny * half));
                seg.addPoint((int) Math.round(xs[i] - nx * half), (int) Math.round(ys[i] - ny * half));
                g.setColor(pass == 0 ? OUTLINE : (i > steps * 0.7 ? RetroCourtRenderer.shade(col, 1.2) : col));
                g.fillPolygon(seg);
            }
        }
        // arrowhead aligned with the last segment
        double dx = xs[steps] - xs[steps - 1];
        double dy = ys[steps] - ys[steps - 1];
        double len = Math.max(0.001, Math.hypot(dx, dy));
        dx /= len;
        dy /= len;
        double tx = xs[steps] + dx * 9;
        double ty = ys[steps] + dy * 9;
        Polygon head = new Polygon();
        head.addPoint((int) Math.round(tx), (int) Math.round(ty));
        head.addPoint((int) Math.round(xs[steps] - dy * 7), (int) Math.round(ys[steps] + dx * 7));
        head.addPoint((int) Math.round(xs[steps] + dy * 7), (int) Math.round(ys[steps] - dx * 7));
        g.setColor(OUTLINE);
        g.fillPolygon(head);
        g.drawPolygon(head);
        Polygon inner = new Polygon();
        inner.addPoint((int) Math.round(tx - dx * 2), (int) Math.round(ty - dy * 2));
        inner.addPoint((int) Math.round(xs[steps] - dy * 5 + dx), (int) Math.round(ys[steps] + dx * 5 + dy));
        inner.addPoint((int) Math.round(xs[steps] + dy * 5 + dx), (int) Math.round(ys[steps] - dx * 5 + dy));
        g.setColor(col);
        g.fillPolygon(inner);
        // target bracket on the rim
        int rx = (int) Math.round(rimX);
        int ry = (int) Math.round(rimY);
        g.setColor(((int) (m.getElapsed() * 4)) % 2 == 0 ? WHITE : GOLD);
        g.fillRect(rx - 12, ry - 1, 3, 1);
        g.fillRect(rx + 10, ry - 1, 3, 1);
        if (aim.isAiming() && e <= 1) {
        }
    }

    // ---- ticker, chips, banners, toasts ---------------------------------------------------------------------

    private void drawTicker(Graphics2D g, Match m) {
        if (line == null) {
            return;
        }
        int w = PixelFont.width(line.title, 1) + 12;
        double slide = Math.min(1, line.age * 5) * Math.min(1, (LINE_TIME - line.age) * 4);
        int x = Projection.W - 6 - (int) (w * slide);
        int y = Projection.H - 66;
        g.setColor(OUTLINE);
        g.fillRect(x - 1, y - 1, w + 2, 12);
        g.setColor(PANEL_2);
        g.fillRect(x, y, w, 10);
        g.setColor(GOLD);
        g.fillRect(x, y, 2, 10);
        PixelFont.draw(g, line.title, x + 6, y + 2, WHITE, 1);
    }

    private void drawChips(Graphics2D g, Match m) {
        String chip = "";
        Color col = GOLD;
        if (m.needsClear() && m.isLive()) {
            chip = m.getOffense() == TeamSide.HOME ? "CLEAR THE BALL - TAKE IT BEHIND THE ARC" : "OPPONENT MUST CLEAR";
        } else if (!m.getHint().isEmpty()) {
            chip = m.getHint();
            col = WHITE;
        }
        if (chip.isEmpty()) {
            return;
        }
        int w = PixelFont.width(chip, 1) + 10;
        int x = Projection.W / 2 - w / 2;
        int y = 4;
        g.setColor(OUTLINE);
        g.fillRect(x - 1, y - 1, w + 2, 13);
        g.setColor(PANEL);
        g.fillRect(x, y, w, 11);
        PixelFont.draw(g, chip, x + 5, y + 2, col, 1);
    }

    private void drawBanner(Graphics2D g, Match m) {
        String b = m.getBanner();
        if (b.isEmpty() || (m.isFreeThrow() && b.startsWith("FREE THROW"))) {
            return; // the free-throw label at the top already says this; keep the shooter and arrow visible
        }
        String sub = m.getBannerSub();
        if ("ULTIMATE".equals(b)) {
            b = ctx.getSkin().abilityName(sub).toUpperCase();
            sub = "";
        }
        double t = m.getBannerTime();
        int scale = PixelFont.width(b, 3) > Projection.W - 40 ? 2 : 3;
        int y = 168;
        int bandH = sub.isEmpty() ? 34 : 46;
        // band slides in from the sides (stepped, no alpha)
        int reveal = (int) (Projection.W * Math.min(1, t * 4));
        int x0 = Projection.W / 2 - reveal / 2;
        g.setColor(OUTLINE);
        g.fillRect(x0, y - 6, reveal, bandH + 2);
        g.setColor(PANEL_2);
        g.fillRect(x0, y - 5, reveal, bandH);
        g.setColor(GOLD);
        g.fillRect(x0, y - 5, reveal, 1);
        g.fillRect(x0, y - 6 + bandH, reveal, 1);
        if (reveal < Projection.W / 2) {
            return;
        }
        Color main = "DEFEAT".equals(b) ? RED : ("FOUL".equals(b) || b.startsWith("FOUL") ? GOLD : WHITE);
        PixelFont.drawCentered(g, b, Projection.W / 2, y + 2, main, OUTLINE, scale);
        if (!sub.isEmpty()) {
            PixelFont.drawCentered(g, sub, Projection.W / 2, y + 28, MUTED, OUTLINE, 1);
        }
    }

    private void drawToasts(Graphics2D g) {
        int y = 46;
        for (Msg t : toasts) {
            double slide = Math.min(1, t.age * 4) * Math.min(1, (TOAST_TIME - t.age) * 3);
            int w = Math.max(PixelFont.width(t.title, 1), PixelFont.width(t.sub, 1)) + 14;
            int x = Projection.W - (int) ((w + 6) * slide);
            box(g, x, y, w, 24);
            g.setColor(GOLD);
            g.fillRect(x + 2, y + 2, 2, 20);
            PixelFont.draw(g, t.title, x + 8, y + 4, WHITE, 1);
            PixelFont.draw(g, t.sub, x + 8, y + 13, GOLD, 1);
            y += 28;
        }
    }

    // ---- F3 debug ---------------------------------------------------------------------------------------------

    private void drawDebug(Graphics2D g, Match m) {
        Player c = m.getControlled();
        Ball b = m.getBall();
        List<String> lines = new ArrayList<>();
        lines.add("DEBUG F3  F6-F11 SCENARIOS");
        lines.add("PHASE " + m.getPhase() + "  ANOM " + m.getAnomalies());
        lines.add("BALL " + b.getState() + (b.getHolder() != null ? " " + b.getHolder().getName() : "")
                + String.format(" Z%.0f", b.getZ()));
        lines.add("OWNER CHG " + b.getOwnerChanges() + " " + b.getLastReason());
        lines.add("FOULS H" + m.getRules().getTeamFouls(TeamSide.HOME) + " A" + m.getRules().getTeamFouls(TeamSide.AWAY));
        if (c != null) {
            lines.add("ACT " + c.getActions().getType() + " " + c.getActions().getAnimation() + " F" + c.getActions().getFrame());
            lines.add(String.format("Z%.0f  SPD%.0f  REJ %d", c.getZ(), c.getEffectiveSpeed(), c.getActions().getRejected()));
            lines.add(String.format("MAKE %.0f%%", m.estimateMakeChance(c) * 100));
        }
        if (m.isFreeThrow()) {
            FreeThrowAim a = m.getFreeThrowAim();
            lines.add(String.format("FT POW %.2f SWAY %.2f ERR %.1f", a.getPower(), a.getSway(), a.error(1)));
        }
        int y = 24;
        int w = 0;
        for (String s : lines) {
            w = Math.max(w, PixelFont.width(s, 1));
        }
        g.setColor(new Color(0, 0, 0, 170));
        g.fillRect(2, y - 2, w + 6, lines.size() * 9 + 3);
        for (String s : lines) {
            PixelFont.draw(g, s, 5, y, s.startsWith("DEBUG") ? GOLD : WHITE, 1);
            y += 9;
        }
    }

    // ---- helpers ----------------------------------------------------------------------------------------------

    static void box(Graphics2D g, int x, int y, int w, int h) {
        g.setColor(OUTLINE);
        g.fillRect(x - 1, y - 1, w + 2, h + 2);
        g.setColor(EDGE);
        g.fillRect(x, y, w, h);
        g.setColor(PANEL);
        g.fillRect(x + 1, y + 1, w - 2, h - 2);
        g.setColor(PANEL_2);
        g.fillRect(x + 1, y + 1, w - 2, 1);
    }

    static void bar(Graphics2D g, int x, int y, int w, int h, double frac, Color c) {
        g.setColor(OUTLINE);
        g.fillRect(x - 1, y - 1, w + 2, h + 2);
        g.setColor(new Color(0x2A2D3A));
        g.fillRect(x, y, w, h);
        g.setColor(c);
        int fw = (int) (w * Math.max(0, Math.min(1, frac)));
        fw -= fw % 2;
        g.fillRect(x, y, fw, h);
    }
}
