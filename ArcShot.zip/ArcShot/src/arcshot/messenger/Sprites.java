package arcshot.messenger;

import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/**
 * Loads optional artwork from the images folder. Returns null if a file is missing, so the game still runs.
 * OOP pillar: <b>ENCAPSULATION</b> - a static helper that hides how files are found and loaded.
 */
public final class Sprites {
    private Sprites() { }

    public static BufferedImage load(String fileName) {
        try {
            File file = new File("images", fileName);
            if (file.exists()) {
                return ImageIO.read(file);
            }
            java.io.InputStream in = Sprites.class.getResourceAsStream("/images/" + fileName);
            return in == null ? null : ImageIO.read(in);
        } catch (Exception ex) {
            return null; // bad or unreadable image: fall back to the drawn shapes
        }
    }
}
