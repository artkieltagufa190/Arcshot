package arcshot.court;

/**
 * Anything standing on the court with a floor position and a height: players and referees. The renderer depth-sorts
 * by {@link #getY()} and lifts by {@link #getZ()}.
 * OOP pillar: <b>ABSTRACTION</b> + <b>POLYMORPHISM</b> - Player and Referee are drawn through this one interface.
 */
public interface CourtBody {
    double getX();

    double getY();

    /** Height above the floor (0 = standing). Never negative. */
    double getZ();
}
