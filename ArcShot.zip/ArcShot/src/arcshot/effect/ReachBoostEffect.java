package arcshot.effect;

import java.util.EnumSet;
import java.util.Set;

/**
 * Enlarges one or more reach radii (Sky Rend, Pickpocket Reflex, Rebound Surge).
 * OOP pillars: <b>INHERITANCE</b> (extends StatusEffect) and <b>POLYMORPHISM</b> (overrides only the modifiers it changes).
 */
public class ReachBoostEffect extends StatusEffect {
    private final double multiplier;
    private final Set<Reach> reaches;

    public ReachBoostEffect(String id, double duration, double multiplier, Reach first, Reach... more) {
        super(id, duration, false);
        this.multiplier = multiplier;
        this.reaches = EnumSet.of(first, more);
    }

    @Override
    public double reachMultiplier(Reach reach) {
        return reaches.contains(reach) ? multiplier : 1.0;
    }
}
