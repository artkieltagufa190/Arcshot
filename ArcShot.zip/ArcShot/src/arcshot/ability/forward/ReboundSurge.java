package arcshot.ability.forward;

import arcshot.ability.AbilitySlot;
import arcshot.ability.ActiveAbility;
import arcshot.court.Ball;
import arcshot.court.Match;
import arcshot.effect.Reach;
import arcshot.effect.ReachBoostEffect;
import arcshot.player.Player;

/**
 * Forward E (alternate): 3 s boosted jump and rebound priority.
 * OOP pillars: <b>INHERITANCE</b> (extends ActiveAbility / Ultimate) and <b>POLYMORPHISM</b> (overrides perform() and the optional hooks).
 */
public class ReboundSurge extends ActiveAbility {
    public ReboundSurge() {
        super("forward.rebound_surge", AbilitySlot.E, 12);
    }

    @Override
    protected void perform(Player owner, Match match) {
        owner.applyEffect(new ReachBoostEffect("rebound_surge", param("duration", 3), param("multiplier", 1.8), Reach.REBOUND));
        match.fx().ring("rebound_surge", owner.getX(), owner.getY(), 60, 0.4);
    }

    @Override
    public boolean aiShouldUse(Player owner, Match match) {
        return match.getBall().getState() == Ball.State.SHOT;
    }
}
