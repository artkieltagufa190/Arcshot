package arcshot.messenger;

import java.awt.Color;
import java.awt.Graphics2D;

/**
 * A moving blocker that appears at higher scores. Bounces the ball away.
 * OOP pillars: <b>INHERITANCE</b> (extends GameObject) and <b>POLYMORPHISM</b> (implements Collidable).
 */
public class Defender extends GameObject implements Collidable {
    private static final double WIDTH = 90;
    private static final double HEIGHT = 18;
    private static final double MIN_X = 60;

    private final double maxX;
    private final double speed = 2.5;
    private int direction = 1;
    private boolean active;

    public Defender(double x, double y, double courtWidth) {
        super(x, y);
        this.maxX = courtWidth - 60;
    }

    public void setActive(boolean active) { this.active = active; }
    public boolean isActive() { return active; }

    @Override
    public boolean resolveCollision(Ball ball) {
        if (!active) {
            return false;
        }
        double left = getX() - WIDTH / 2;
        double right = getX() + WIDTH / 2;
        double top = getY() - HEIGHT / 2;
        double bottom = getY() + HEIGHT / 2;
        double closestX = Math.max(left, Math.min(ball.getX(), right));
        double closestY = Math.max(top, Math.min(ball.getY(), bottom));
        double dx = ball.getX() - closestX;
        double dy = ball.getY() - closestY;
        double dist = Math.hypot(dx, dy);
        if (dist >= ball.getRadius()) {
            return false;
        }
        if (dist == 0) {
            ball.deflect(0, -1, ball.getRadius());
        } else {
            ball.deflect(dx / dist, dy / dist, ball.getRadius() - dist);
        }
        return true;
    }

    @Override
    public void update() {
        if (!active) {
            return;
        }
        setX(getX() + speed * direction);
        if (getX() > maxX) {
            setX(maxX);
            direction = -1;
        } else if (getX() < MIN_X) {
            setX(MIN_X);
            direction = 1;
        }
    }

    @Override
    public void draw(Graphics2D g) {
        if (!active) {
            return;
        }
        g.setColor(new Color(40, 90, 200));
        g.fillRoundRect((int) (getX() - WIDTH / 2), (int) (getY() - HEIGHT / 2), (int) WIDTH, (int) HEIGHT, 10, 10);
        g.setColor(Color.WHITE);
        g.drawString("DEFENDER", (int) getX() - 30, (int) getY() + 4);
    }
}
