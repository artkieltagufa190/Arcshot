package arcshot.rules;

import arcshot.player.Player;

/**
 * Technical foul: 1 free throw (+ possession by default, see {@code rules.technicalPossession}).
 * The 7-9 / 10+ team-foul penalties never apply to technicals.
 * OOP pillars: <b>INHERITANCE</b> + <b>POLYMORPHISM</b>.
 */
public class TechnicalFoul extends Foul {
    public TechnicalFoul(Player offender, Player victim) {
        super(offender, victim);
    }

    @Override
    public String getName() { return "TECHNICAL"; }

    @Override
    public int teamFoulsAdded() { return RulesConfig.technicalTeamFouls(); }

    @Override
    protected boolean usesTeamFoulPenalty() { return false; }

    @Override
    protected int baseFreeThrows(FoulContext ctx) { return RulesConfig.technicalFreeThrows(); }

    @Override
    protected boolean basePossession(FoulContext ctx) { return RulesConfig.technicalPossession(); }
}
