package arcshot.ability.forward;

import arcshot.ability.AbilitySlot;
import arcshot.ability.ActiveAbility;
import arcshot.court.Match;
import arcshot.effect.StunEffect;
import arcshot.player.Player;
import java.util.HashSet;
import java.util.Set;

/**
 * Forward Q (alternate): shoulder through defenders; anyone you hit staggers for 1.5 s.
 * OOP pillars: <b>INHERITANCE</b> (extends ActiveAbility / Ultimate) and <b>POLYMORPHISM</b> (overrides perform() and the optional hooks).
 */
public class BullRush extends ActiveAbility {
    private final Set<Player> hit = new HashSet<>();

    public BullRush() {
        super("forward.bull_rush", AbilitySlot.Q, 12);
    }

    @Override
    protected boolean meetsRequirements(Player owner, Match match) {
        return owner.canMove();
    }

    @Override
    protected void perform(Player owner, Match match) {
        hit.clear();
        double dx = owner.getInput().getMoveX();
        double dy = owner.getInput().getMoveY();
        if (Math.hypot(dx, dy) < 0.2) {
            dx = owner.getFacingX();
            dy = owner.getFacingY();
        }
        owner.startDash(dx, dy, param("distance", 110), param("dashTime", 0.25), false);
    }

    @Override
    protected double activeDuration() {
        return param("dashTime", 0.25);
    }

    @Override
    protected void whileActive(double dt, Player owner, Match match) {
        match.fx().trail("bull", owner.getX(), owner.getY() - 10, 12);
        for (Player o : opponentsNear(owner, match, 36)) {
            if (hit.add(o)) {
                o.applyEffect(new StunEffect(param("stun", 1.5)));
                o.applyKnockback(owner.getFacingX() * 320, owner.getFacingY() * 320);
                match.fx().burst("bull", o.getX(), o.getY() - 20, 10, 180);
                match.shake(4);
            }
        }
    }

    @Override
    public boolean aiShouldUse(Player owner, Match match) {
        return hasBall(owner, match) && match.nearestOpponent(owner, 55) != null;
    }
}
