package arcshot.cosmetic;

import arcshot.save.Profile;
import java.awt.Color;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Every jersey color, aura color, player style and court theme. Locked items are unlocked by achievements
 * ({@code CosmeticUnlock} rewards). OOP pillar: <b>ABSTRACTION</b> - screens ask for items by type or id.
 */
public final class CosmeticRegistry {
    private static final Map<String, Cosmetic> ALL = new LinkedHashMap<>();

    static {
        jersey("jersey.orange", "Blaze Orange", true, 0xFF7A1A);
        jersey("jersey.red", "Crimson", true, 0xE23B4A);
        jersey("jersey.white", "Home White", true, 0xE9ECF4);
        jersey("jersey.teal", "Street Teal", false, 0x18B7A6);
        jersey("jersey.purple", "Night Purple", false, 0x8B5CF6);
        jersey("jersey.black", "Blackout", false, 0x2A2F3D);
        jersey("jersey.gold", "Champion Gold", false, 0xF5B82E);
        jersey("jersey.green", "Jade", false, 0x2FBF5B);
        jersey("jersey.pink", "Sakura", false, 0xF472B6);

        aura("aura.default", "Team Color", true, 0xFFFFFF);
        aura("aura.fire", "Inferno", false, 0xFF5A1F);
        aura("aura.ice", "Glacier", false, 0x6FD3FF);
        aura("aura.toxic", "Venom", false, 0x9BE15D);
        aura("aura.legend", "Legend Prism", false, 0xFFD54A);

        style("style.classic", "Classic", true, 0x222222);
        style("style.headband", "Headband", true, 0xFFFFFF);
        style("style.gold", "Gold Trim (MVP)", false, 0xF5C542);
        style("style.legend", "Legend Crown", false, 0xFFE27A);

        court("court.classic", "Classic Hardwood", true, 0xC98B4E, 0xFFF6E8, 0xA3592C, 0x2B3046);
        court("court.night", "Night Court", false, 0x1E2A4A, 0x7FE7FF, 0x283B6B, 0x0B1020);
        court("court.sunset", "Sunset Park", false, 0xE08A4F, 0xFFF0D8, 0xC0503A, 0x4A2B3D);
        court("court.street", "Street Asphalt", false, 0x4A4F5A, 0xF2F2F2, 0x2F6FD6, 0x2A2D33);
        court("court.legend", "Legend Arena", false, 0x2B1F3A, 0xFFD54A, 0x5B2A86, 0x140C1F);
    }

    private CosmeticRegistry() { }

    private static void add(Cosmetic c) { ALL.put(c.getId(), c); }

    private static void jersey(String id, String name, boolean def, int rgb) {
        add(new Cosmetic(id, CosmeticType.JERSEY, name, def, new Color(rgb)));
    }

    private static void aura(String id, String name, boolean def, int rgb) {
        add(new Cosmetic(id, CosmeticType.AURA, name, def, new Color(rgb)));
    }

    private static void style(String id, String name, boolean def, int rgb) {
        add(new Cosmetic(id, CosmeticType.STYLE, name, def, new Color(rgb)));
    }

    private static void court(String id, String name, boolean def, int floor, int lines, int paint, int outside) {
        add(new Cosmetic(id, CosmeticType.COURT, name, def, new Color(floor), new Color(lines), new Color(paint), new Color(outside)));
    }

    public static Cosmetic get(String id) { return ALL.get(id); }

    /** Item by id, or the first default of that type. */
    public static Cosmetic getOrDefault(String id, CosmeticType type) {
        Cosmetic c = ALL.get(id);
        if (c != null && c.getType() == type) {
            return c;
        }
        return byType(type).get(0);
    }

    public static List<Cosmetic> byType(CosmeticType type) {
        List<Cosmetic> list = new ArrayList<>();
        for (Cosmetic c : ALL.values()) {
            if (c.getType() == type) {
                list.add(c);
            }
        }
        return list;
    }

    public static List<String> allIds() { return new ArrayList<>(ALL.keySet()); }

    public static boolean isAvailable(Cosmetic c, Profile profile) {
        return c.isDefaultUnlocked() || profile.hasUnlock(Profile.COSMETIC + c.getId());
    }
}
