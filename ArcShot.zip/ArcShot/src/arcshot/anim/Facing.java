package arcshot.anim;

/**
 * Which way a sprite is drawn. BACK = facing the hoop (away from the camera), FRONT = toward the camera,
 * SIDE = facing right (left is the same frames mirrored).
 * OOP pillar: <b>ABSTRACTION</b> - a fixed set of named values.
 */
public enum Facing {
    BACK, FRONT, SIDE;

    /**
     * Chooses a facing from a direction, with hysteresis so the sprite does not flicker when the direction is
     * near a diagonal: the current facing is kept unless the new one is clearly better.
     */
    public static Facing choose(double fx, double fy, Facing current) {
        double ax = Math.abs(fx);
        double ay = Math.abs(fy);
        Facing wanted = ay > ax ? (fy < 0 ? BACK : FRONT) : SIDE;
        if (current == null || wanted == current) {
            return wanted;
        }
        double margin = 0.25;
        if (current == SIDE && ay < ax + margin) {
            return SIDE;
        }
        if (current != SIDE && ax < ay + margin && Math.signum(fy) == (current == BACK ? -1 : 1)) {
            return current;
        }
        return wanted;
    }
}
