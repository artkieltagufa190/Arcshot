package arcshot.messenger;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

/**
 * The hoop and backboard. getX() is the hoop's center. It starts moving once the player scores enough.
 * OOP pillars: <b>INHERITANCE</b> (extends GameObject) and <b>POLYMORPHISM</b> (implements Collidable).
 */
public class Hoop extends GameObject implements Collidable {
    /** The hoop is far away, so it is drawn smaller than the ball starts out. */
    private static final double HOOP_SCALE = 0.65;
    private static final double RIM_HALF_WIDTH = 50 * HOOP_SCALE;
    private static final double RIM_RADIUS = 5 * HOOP_SCALE;
    private static final double MIN_X = 90;

    private final double maxX;
    private final double floorY;
    private double speed;
    private int direction = 1;
    private int flashFrames;
    private final java.awt.image.BufferedImage rimBack = Sprites.load("rim_back.png");
    private final java.awt.image.BufferedImage rimFront = Sprites.load("rim_front.png");
    private final java.awt.image.BufferedImage rimBackHit = Sprites.load("rim_back_hit.png");
    private final java.awt.image.BufferedImage rimFrontHit = Sprites.load("rim_front_hit.png");
    private final java.awt.image.BufferedImage backboard = Sprites.load("backboard.png");

    public Hoop(double centerX, double rimY, double courtWidth, double floorY) {
        super(centerX, rimY);
        this.floorY = floorY;
        this.maxX = courtWidth - 90;
    }

    /** ENCAPSULATION: speed is validated and can never be negative. */
    public void setSpeed(double speed) {
        if (speed < 0) {
            throw new IllegalArgumentException("Speed cannot be negative.");
        }
        this.speed = speed;
    }

    public static double getScale() { return HOOP_SCALE; }

    public double getRimLeft() { return getX() - RIM_HALF_WIDTH; }
    public double getRimRight() { return getX() + RIM_HALF_WIDTH; }

    /** True when the ball center crosses the rim line going down, inside the rim. */
    public boolean isScoredBy(Ball ball) {
        return !ball.isScored()
                && ball.getVy() > 0
                && ball.getPrevY() < getY()
                && ball.getY() >= getY()
                && ball.getX() > getRimLeft()
                && ball.getX() < getRimRight();
    }

    @Override
    public boolean resolveCollision(Ball ball) {
        if (ball.getVy() < 0) {
            return false; // rising: the ball passes through the rim; only a falling ball can hit it
        }
        boolean hit = false;
        double[] rimPoints = { getRimLeft(), getRimRight() };
        for (double px : rimPoints) {
            double dx = ball.getX() - px;
            double dy = ball.getY() - getY();
            double dist = Math.hypot(dx, dy);
            double minDist = ball.getRadius() + RIM_RADIUS;
            if (dist > 0 && dist < minDist) {
                ball.deflect(dx / dist, dy / dist, minDist - dist);
                hit = true;
            }
        }
        return hit;
    }

    @Override
    public void update() {
        if (flashFrames > 0) {
            flashFrames--;
        }
        if (speed == 0) {
            return;
        }
        setX(getX() + speed * direction);
        if (getX() > maxX) {
            setX(maxX);
            direction = -1;
        } else if (getX() < MIN_X) {
            setX(MIN_X);
            direction = 1;
        }
    }

    /** Makes the rim flash green for a moment after a basket. */
    public void flash() {
        flashFrames = 25;
    }

    /** The stand: a pole with an arm that holds the backboard. Drawn first, behind the glass. */
    private void drawStand(Graphics2D g) {
        int px = (int) getX() - 58;          // pole centre
        int armY = (int) getY() - 42;
        int boardLeft = (int) getX() - 42;
        int floor = (int) floorY;
        Color dark = new Color(52, 44, 68);
        Color mid = new Color(74, 64, 94);
        Color light = new Color(104, 92, 128);
        // arm out to the backboard
        g.setColor(dark);
        g.fillRect(px - 7, armY, boardLeft - px + 9, 12);
        g.setColor(light);
        g.fillRect(px - 7, armY, boardLeft - px + 9, 3);
        // pole
        g.setColor(dark);
        g.fillRect(px - 7, armY, 14, floor - armY);
        g.setColor(mid);
        g.fillRect(px - 7, armY, 5, floor - armY);
        g.setColor(light);
        g.fillRect(px - 7, armY, 2, floor - armY);
        // foot
        g.setColor(dark);
        g.fillRect(px - 13, floor - 8, 26, 8);
        g.setColor(mid);
        g.fillRect(px - 13, floor - 8, 26, 3);
    }

    /** Back layer: backboard and the back of the rim. Drawn BEFORE the ball. */
    @Override
    public void draw(Graphics2D g) {
        drawStand(g);
        AffineTransform old = g.getTransform();
        g.translate(getX(), getY());
        g.scale(HOOP_SCALE, HOOP_SCALE);
        if (backboard != null) {
            g.drawImage(backboard, -65, -105, 130, 95, null);
        } else {
            g.setColor(Color.WHITE);
            g.fillRect(-65, -105, 130, 95);
            g.setColor(new Color(200, 40, 40));
            g.setStroke(new BasicStroke(4f));
            g.drawRect(-65, -105, 130, 95);
            g.drawRect(-25, -50, 50, 40);
        }
        g.setStroke(new BasicStroke(4f));
        if (rimBack != null) {
            // pixel-art rim, back half: 25x4 pixels drawn 4x bigger
            g.drawImage(flashFrames > 0 && rimBackHit != null ? rimBackHit : rimBack, -50, -14, 100, 16, null);
        } else {
            g.setColor(new Color(150, 60, 20));
            g.drawLine(-50, -3, 50, -3);
        }
        g.setTransform(old);
    }

    /** Front layer: net, front rim and rim ends. Drawn AFTER the ball so you can see it go in or hit. */
    public void drawFront(Graphics2D g) {
        AffineTransform old = g.getTransform();
        g.translate(getX(), getY());
        g.scale(HOOP_SCALE, HOOP_SCALE);
        if (rimFront != null) {
            // pixel-art rim front + net: 25x14 pixels drawn 4x bigger, over the ball
            g.drawImage(flashFrames > 0 && rimFrontHit != null ? rimFrontHit : rimFront, -50, 2, 100, 56, null);
            g.setTransform(old);
            return;
        }
        int left = -50;
        int right = 50;
        g.setColor(new Color(255, 255, 255, 220));
        g.setStroke(new BasicStroke(1.5f));
        for (int i = 0; i <= 6; i++) {
            int topX = left + i * (right - left) / 6;
            int botX = left + 15 + i * (right - left - 30) / 6;
            g.drawLine(topX, 0, botX, 45);
        }
        g.drawLine(left + 8, 20, right - 8, 20);
        g.drawLine(left + 15, 45, right - 15, 45);

        g.setColor(flashFrames > 0 ? new Color(60, 220, 90) : new Color(235, 90, 20));
        g.setStroke(new BasicStroke(6f));
        g.drawLine(left, 0, right, 0);
        int r = 7;
        g.fillOval(left - r, -r, r * 2, r * 2);
        g.fillOval(right - r, -r, r * 2, r * 2);
        g.setColor(Color.WHITE);
        g.setStroke(new BasicStroke(1.5f));
        g.drawOval(left - r, -r, r * 2, r * 2);
        g.drawOval(right - r, -r, r * 2, r * 2);
        g.setTransform(old);
    }
}
