package arcshot.court;

import arcshot.player.Player;
import arcshot.rules.Foul;

/**
 * Data about one shot in the air. The result (make or miss) is rolled at release; the flight is the visual arc.
 * v3 adds the shot {@link Kind}, bank shots off the backboard, and a pending shooting foul (resolved when the
 * shot lands, so a fouled make becomes an "and one").
 * OOP pillar: <b>ENCAPSULATION</b> - immutable except for the flight timer and the pending foul.
 */
public final class ShotAttempt {
    /** How well the shot meter was timed. */
    public enum Timing { GREEN, GOOD, EARLY, LATE }

    /** What kind of shot it is. */
    public enum Kind { JUMP_SHOT, LAYUP, DUNK, FREE_THROW }

    private final Player shooter;
    private final double startX;
    private final double startY;
    private final double startZ;
    private final double duration;
    private final double peak;
    private final boolean made;
    private final int points;
    private final boolean outside;
    private final Kind kind;
    private final boolean bank;
    private final Timing timing;
    private final double chance;
    private double elapsed;
    private Foul pendingFoul;

    public ShotAttempt(Player shooter, double startZ, double duration, double peak, boolean made, int points,
                       boolean outside, Kind kind, boolean bank, Timing timing, double chance) {
        this.shooter = shooter;
        this.startX = shooter.getX();
        this.startY = shooter.getY();
        this.startZ = startZ;
        this.duration = duration;
        this.peak = peak;
        this.made = made;
        this.points = points;
        this.outside = outside;
        this.kind = kind;
        this.bank = bank;
        this.timing = timing;
        this.chance = chance;
    }

    public void advance(double dt) { elapsed += dt; }

    public double getProgress() { return Math.min(1, elapsed / duration); }

    public double getElapsed() { return elapsed; }

    public boolean isFinished() { return elapsed >= duration; }

    public Player getShooter() { return shooter; }

    public double getStartX() { return startX; }

    public double getStartY() { return startY; }

    public double getStartZ() { return startZ; }

    public double getPeak() { return peak; }

    public boolean isMade() { return made; }

    public int getPoints() { return points; }

    public boolean isOutside() { return outside; }

    public Kind getKind() { return kind; }

    public boolean isDunk() { return kind == Kind.DUNK; }

    public boolean isFreeThrow() { return kind == Kind.FREE_THROW; }

    public boolean isBank() { return bank; }

    public Timing getTiming() { return timing; }

    public double getChance() { return chance; }

    /** A shooting foul called on this shot, decided when the shot lands. */
    public Foul getPendingFoul() { return pendingFoul; }

    public void setPendingFoul(Foul foul) { this.pendingFoul = foul; }
}
