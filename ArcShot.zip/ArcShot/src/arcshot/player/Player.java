package arcshot.player;

import arcshot.ability.Ability;
import arcshot.ability.AbilitySlot;
import arcshot.ability.ActiveAbility;
import arcshot.ability.Ultimate;
import arcshot.action.ActionController;
import arcshot.action.ActionType;
import arcshot.action.BlockAction;
import arcshot.action.DashAction;
import arcshot.anim.Facing;
import arcshot.control.PlayerController;
import arcshot.control.PlayerInput;
import arcshot.core.Balance;
import arcshot.court.CourtBody;
import arcshot.court.Match;
import arcshot.effect.Reach;
import arcshot.effect.StatusEffect;
import arcshot.perk.Perk;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * A basketball player on the 3x3 court. Concrete classes: {@link Guard}, {@link Forward}, {@link Big}.
 * <p>
 * v3 (retro pass): what the player is DOING (shooting, dunking, dashing, blocking ...) is owned by its
 * {@link ActionController}; this class keeps stats, effects, stamina, the ultimate meter and floor movement.
 * Height above the floor ({@link #getZ()}) comes from the current action's jump arc.
 * <p>
 * OOP pillars:
 * <ul>
 *   <li><b>ABSTRACTION</b> - abstract methods ({@link #getPlayerClass()}, {@link #rangeModifier}, {@link #getMass()},
 *       {@link #classReachFactor}, ...) say <i>what</i> every class must define, not how.</li>
 *   <li><b>INHERITANCE</b> - movement, stamina, effects and abilities are written once here and shared by all classes.</li>
 *   <li><b>POLYMORPHISM</b> - the match calls {@code player.rangeModifier(...)} and gets the Guard's, Forward's or
 *       Big's own answer; it is also drawn through the {@link CourtBody} interface like a referee.</li>
 *   <li><b>ENCAPSULATION</b> - stats are private with getters. Effects change them only through controlled methods
 *       ({@link #applyEffect}, {@link #getEffectiveSpeed}), never by writing fields directly.</li>
 * </ul>
 */
public abstract class Player implements CourtBody {
    public static final double RADIUS = 15;

    private final String name;
    private final int number;
    private final TeamSide side;
    private final boolean userTeam;

    // base ratings (never changed after creation)
    private final double baseSpeed;
    private final double shooting;
    private final double defense;
    private final double rebound;

    private double x;
    private double y;
    private double vx;
    private double vy;
    private double facingX;
    private double facingY = -1;
    private double wantFacingX;
    private double wantFacingY = -1;
    private boolean facingLocked;
    private Facing spriteFacing = Facing.BACK;

    private double stamina = 100;
    private double ultimate;
    private boolean sprinting;

    private final List<StatusEffect> effects = new ArrayList<>();
    private final List<Perk> perks = new ArrayList<>();
    private ActiveAbility abilityQ;
    private ActiveAbility abilityE;
    private Ultimate abilityR;

    private PlayerController controller;
    private final PlayerInput input = new PlayerInput();
    private final PlayerStats stats = new PlayerStats();
    private final ActionController actions = new ActionController(this);
    private Match match;

    private double knockVx;
    private double knockVy;
    private double jumpCooldown;
    private double stealCooldown;
    private double shotHold = -1;
    private int consecutiveMakes;
    private double animTime;
    private int appearance;

    /**
     * @param key class key used for balance values, e.g. "guard" reads guard.speed, guard.shooting ...
     */
    protected Player(String name, int number, TeamSide side, boolean userTeam, String key,
                     double defSpeed, double defShooting, double defDefense, double defRebound) {
        this.name = name;
        this.number = number;
        this.side = side;
        this.userTeam = userTeam;
        this.baseSpeed = Balance.d(key + ".speed", defSpeed);
        this.shooting = Balance.d(key + ".shooting", defShooting);
        this.defense = Balance.d(key + ".defense", defDefense);
        this.rebound = Balance.d(key + ".rebound", defRebound);
    }

    // ---- abstract: every class answers these differently -----------------------------------------------------

    public abstract PlayerClass getPlayerClass();

    /** Class-specific shooting bonus or penalty for a shot from this distance. */
    public abstract double rangeModifier(double distanceToHoop, boolean outsideArc);

    /** Heavier players push lighter ones in collisions. */
    public abstract double getMass();

    /** How high (in pixels of ball height) this player can grab a rebound. */
    public abstract double getGrabHeight();

    /** Within this distance of the hoop a shot becomes a dunk/layup. */
    public abstract double getDunkRange();

    /** Multiplier on the base block / steal / rebound / contest radius. */
    protected abstract double classReachFactor(Reach reach);

    // ---- per-frame update -----------------------------------------------------------------------------------

    /** Links the player to its match (needed when abilities start dashes). Called once by the match. */
    public void attach(Match m) {
        this.match = m;
    }

    /** Step 3 of the tick: effects, cooldowns and stamina. */
    public void updateTimers(double dt, Match m) {
        animTime += dt;
        updateEffects(dt);
        jumpCooldown = Math.max(0, jumpCooldown - dt);
        stealCooldown = Math.max(0, stealCooldown - dt);
        for (AbilitySlot slot : AbilitySlot.values()) {
            Ability a = getAbility(slot);
            if (a != null) {
                a.update(dt, this, m);
            }
        }
        updateStamina(dt);
    }

    /** Step 5 of the tick: floor movement (root-motion actions move the player themselves). */
    public void updateMovement(double dt) {
        if (actions.hasRootMotion()) {
            vx = 0;
            vy = 0;
        } else {
            boolean free = canMove() && !actions.locksMovement();
            double speed = free ? getEffectiveSpeed() : 0;
            double tx = input.getMoveX() * speed;
            double ty = input.getMoveY() * speed;
            boolean accelerating = tx * vx + ty * vy > 0 && Math.hypot(tx, ty) > Math.hypot(vx, vy);
            double rate = accelerating ? Balance.d("player.acceleration", 8) : Balance.d("player.deceleration", 12);
            double k = Math.min(1, rate * dt);
            vx += (tx - vx) * k;
            vy += (ty - vy) * k;
            x += vx * dt;
            y += vy * dt;
        }
        x += knockVx * dt;
        y += knockVy * dt;
        double decay = Math.exp(-7 * dt);
        knockVx *= decay;
        knockVy *= decay;
        updateFacing(dt);
    }

    /** Kept for compatibility: timers + movement in one call. */
    public void update(double dt, Match match) {
        updateTimers(dt, match);
        updateMovement(dt);
    }

    private void updateFacing(double dt) {
        double len = Math.hypot(input.getMoveX(), input.getMoveY());
        if (!facingLocked && len > 0.2 && !actions.hasRootMotion() && !actions.locksMovement()) {
            wantFacingX = input.getMoveX() / len;
            wantFacingY = input.getMoveY() / len;
        }
        facingLocked = false;
        double k = Math.min(1, Balance.d("player.turnRate", 14) * dt);
        double fx = facingX + (wantFacingX - facingX) * k;
        double fy = facingY + (wantFacingY - facingY) * k;
        double fl = Math.hypot(fx, fy);
        if (fl > 0.001) {
            facingX = fx / fl;
            facingY = fy / fl;
        }
        spriteFacing = Facing.choose(facingX, facingY, spriteFacing);
    }

    private void updateEffects(double dt) {
        Iterator<StatusEffect> it = effects.iterator();
        while (it.hasNext()) {
            StatusEffect e = it.next();
            e.update(dt);
            if (e.isExpired()) {
                it.remove();
            }
        }
    }

    private void updateStamina(double dt) {
        boolean moving = Math.hypot(input.getMoveX(), input.getMoveY()) > 0.1;
        sprinting = input.isSprint() && moving && stamina > 1 && canMove() && !actions.locksMovement();
        if (sprinting) {
            stamina = Math.max(0, stamina - Balance.d("stamina.drainPerSecond", 22) * dt);
        } else {
            double regen = Balance.d("stamina.regenPerSecond", 12);
            for (Perk p : perks) {
                regen *= p.staminaRegenMultiplier();
            }
            stamina = Math.min(100, stamina + regen * dt);
        }
    }

    // ---- effects (controlled access) ------------------------------------------------------------------------

    /**
     * Applies an effect. Same-id effects refresh instead of stacking, and the Ironclad perk shortens debuffs.
     * The player never needs to know which ability created the effect.
     */
    public void applyEffect(StatusEffect effect) {
        if (effect.isDebuff()) {
            double mult = 1;
            for (Perk p : perks) {
                mult *= p.debuffDurationMultiplier();
            }
            if (mult != 1) {
                effect.scaleDuration(mult);
            }
            shotHold = -1; // getting hit cancels a shot in progress
        }
        for (StatusEffect existing : effects) {
            if (existing.getId().equals(effect.getId())) {
                existing.refresh(effect.getRemaining());
                return;
            }
        }
        effects.add(effect);
    }

    public boolean hasEffect(String id) {
        for (StatusEffect e : effects) {
            if (e.getId().equals(id)) {
                return true;
            }
        }
        return false;
    }

    /** Removes effects that are used up by a shot (Deadeye Mark). */
    public void consumeShotEffects() {
        for (StatusEffect e : effects) {
            if (e.consumedOnShot()) {
                e.expire();
            }
        }
    }

    public List<StatusEffect> getEffects() {
        return Collections.unmodifiableList(effects);
    }

    public boolean canMove() {
        for (StatusEffect e : effects) {
            if (e.preventsMovement()) {
                return false;
            }
        }
        return true;
    }

    public boolean canAct() {
        for (StatusEffect e : effects) {
            if (e.preventsActions()) {
                return false;
            }
        }
        return true;
    }

    public boolean canShoot() {
        if (!canAct()) {
            return false;
        }
        for (StatusEffect e : effects) {
            if (e.preventsShooting()) {
                return false;
            }
        }
        return true;
    }

    public boolean isUnblockable() {
        for (StatusEffect e : effects) {
            if (e.isUnblockable()) {
                return true;
            }
        }
        return false;
    }

    public boolean isIntangible() {
        if (actions.isIntangible()) {
            return true;
        }
        for (StatusEffect e : effects) {
            if (e.isIntangible()) {
                return true;
            }
        }
        return false;
    }

    public boolean isStealResistant() {
        for (StatusEffect e : effects) {
            if (e.isStealResistant()) {
                return true;
            }
        }
        return false;
    }

    public boolean hasGuaranteedGreen() {
        for (StatusEffect e : effects) {
            if (e.guaranteesGreen()) {
                return true;
            }
        }
        return false;
    }

    public boolean guaranteesRebounds() {
        for (StatusEffect e : effects) {
            if (e.guaranteesRebounds()) {
                return true;
            }
        }
        return false;
    }

    public boolean autoContestsPaint() {
        for (StatusEffect e : effects) {
            if (e.autoContestsPaint()) {
                return true;
            }
        }
        return false;
    }

    public boolean isHeavy() {
        for (StatusEffect e : effects) {
            if (e.isHeavy()) {
                return true;
            }
        }
        return false;
    }

    // ---- ratings with effects applied -----------------------------------------------------------------------

    /** Base speed x effects x sprint x defensive slide. */
    public double getEffectiveSpeed() {
        double s = baseSpeed;
        for (StatusEffect e : effects) {
            s *= e.speedMultiplier();
        }
        if (sprinting) {
            s *= Balance.d("stamina.sprintMultiplier", 1.35);
        }
        if (actions.getType() == ActionType.DEFENSIVE_STANCE) {
            s *= Balance.d("player.slideMultiplier", 0.92);
        }
        return s;
    }

    public double getBaseSpeed() { return baseSpeed; }

    /** Shooting rating 0..100 (base, without effects). */
    public double getShooting() { return shooting; }

    /** Make-chance bonus from effects and perks (e.g. 0.12 = +12%). */
    public double getShootingBonus(boolean outsideArc, Match match) {
        double bonus = 0;
        for (StatusEffect e : effects) {
            bonus += e.shootingBonus(outsideArc);
        }
        for (Perk p : perks) {
            bonus += p.shootingBonus(this, match);
        }
        return bonus;
    }

    /** Defense rating with effects. */
    public double getDefense() {
        double d = defense;
        for (StatusEffect e : effects) {
            d += e.defenseBonus();
        }
        return Math.max(0, d);
    }

    public double getRebound() { return rebound; }

    /** A reach radius in pixels: base (balance file) x class factor x effects. */
    public double getReach(Reach reach) {
        double base;
        switch (reach) {
            case BLOCK: base = Balance.d("reach.block", 48); break;
            case STEAL: base = Balance.d("reach.steal", 46); break;
            case REBOUND: base = Balance.d("reach.rebound", 40); break;
            default: base = Balance.d("reach.contest", 95); break;
        }
        double r = base * classReachFactor(reach);
        for (StatusEffect e : effects) {
            r *= e.reachMultiplier(reach);
        }
        return r;
    }

    /** Grab height including rebound effects and the current jump. */
    public double getEffectiveGrabHeight() {
        double h = getGrabHeight();
        for (StatusEffect e : effects) {
            h *= Math.sqrt(e.reachMultiplier(Reach.REBOUND));
        }
        return h + getZ();
    }

    // ---- stamina / ultimate ---------------------------------------------------------------------------------

    public double getStamina() { return stamina; }

    public boolean isSprinting() { return sprinting; }

    public double getUltimateCharge() { return ultimate; }

    /** Adds meter (perks such as Quick Charge multiply it). Never goes above 100. */
    public void addUltimateCharge(double amount) {
        if (amount <= 0) {
            return;
        }
        double mult = 1;
        for (Perk p : perks) {
            mult *= p.ultimateGainMultiplier();
        }
        ultimate = Math.min(100, ultimate + amount * mult);
    }

    public boolean isUltimateReady() { return ultimate >= 100; }

    public void consumeUltimate() { ultimate = 0; }

    /** Practice helper. */
    public void fillUltimate() { ultimate = 100; }

    // ---- movement helpers used by the match and by abilities ------------------------------------------------

    /**
     * Starts a dash. Since v3 this REQUESTS a {@link DashAction} from the action controller, so a dash can never
     * overlap a dunk, a shot or another dash. (Abilities did not change.)
     */
    public void startDash(double dirX, double dirY, double distance, double duration, boolean intangible) {
        if (Math.hypot(dirX, dirY) < 0.01) {
            dirX = facingX;
            dirY = facingY;
        }
        if (match != null) {
            boolean crossover = match.getBall().getHolder() == this;
            actions.request(new DashAction(dirX, dirY, distance, duration, intangible, crossover), match);
        }
    }

    public boolean isDashing() { return actions.getType() == ActionType.DASH || actions.getType() == ActionType.CROSSOVER; }

    public void cancelDash() {
        if (isDashing() && match != null) {
            actions.clear(match);
        }
    }

    /** Pushes the player (ignored while heavy, e.g. Iron Wall). */
    public void applyKnockback(double kx, double ky) {
        if (!isHeavy()) {
            knockVx += kx;
            knockVy += ky;
        }
    }

    /** Leftover speed at the end of a dash (momentum). */
    public void carryMomentum(double mvx, double mvy) {
        vx = mvx;
        vy = mvy;
    }

    public void setPosition(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public void stop() {
        vx = 0;
        vy = 0;
        knockVx = 0;
        knockVy = 0;
        if (match != null) {
            actions.clear(match);
        }
    }

    /** Turns toward a direction (smoothly, over the next frames). */
    public void face(double dx, double dy) {
        double len = Math.hypot(dx, dy);
        if (len > 0.01) {
            wantFacingX = dx / len;
            wantFacingY = dy / len;
        }
    }

    /** Faces a point this frame regardless of movement (defensive slide, shooting). */
    public void lockFacing(double tx, double ty) {
        face(tx - x, ty - y);
        facingLocked = true;
    }

    /** Snaps the facing immediately (resets). */
    public void snapFacing(double dx, double dy) {
        face(dx, dy);
        facingX = wantFacingX;
        facingY = wantFacingY;
        spriteFacing = Facing.choose(facingX, facingY, null);
    }

    // ---- defensive actions ----------------------------------------------------------------------------------

    /** Jump to block (requests a {@link BlockAction}). Returns false while cooling down or busy. */
    public boolean startJump() {
        if (jumpCooldown > 0 || !canAct() || match == null) {
            return false;
        }
        if (actions.request(new BlockAction(false), match)) {
            jumpCooldown = Balance.d("block.jumpCooldown", 1.0);
            return true;
        }
        return false;
    }

    /** Jump for a loose ball (requests a rebound {@link BlockAction}). */
    public boolean startRebound() {
        if (jumpCooldown > 0 || !canAct() || match == null) {
            return false;
        }
        if (actions.request(new BlockAction(true), match)) {
            jumpCooldown = Balance.d("block.jumpCooldown", 1.0);
            return true;
        }
        return false;
    }

    /** True while airborne in a block or rebound jump. */
    public boolean isJumping() {
        ActionType t = actions.getType();
        return (t == ActionType.BLOCK || t == ActionType.REBOUND_JUMP) && actions.isAirborne();
    }

    /** True while the block's hands can touch the ball (contact frames of the animation). */
    public boolean isBlockContactActive() {
        return actions.getCurrent() instanceof BlockAction && ((BlockAction) actions.getCurrent()).isContactActive();
    }

    /** 0..1 jump height (used by the smooth renderer). */
    public double getJumpHeight() {
        return Math.min(1, getZ() / 46.0);
    }

    public boolean canAttemptSteal() { return stealCooldown <= 0 && canAct(); }

    public void startStealCooldown(double seconds) { stealCooldown = seconds; }

    // ---- shooting meter -------------------------------------------------------------------------------------

    /** Seconds Space has been held for the current shot, or -1 if not charging. */
    public double getShotHold() { return shotHold; }

    public void setShotHold(double seconds) { shotHold = seconds; }

    public boolean isChargingShot() { return shotHold >= 0; }

    public void recordShotResult(boolean made) {
        consecutiveMakes = made ? consecutiveMakes + 1 : 0;
    }

    public int getConsecutiveMakes() { return consecutiveMakes; }

    // ---- abilities / perks / controller ---------------------------------------------------------------------

    public void setAbilities(ActiveAbility q, ActiveAbility e, Ultimate r) {
        this.abilityQ = q;
        this.abilityE = e;
        this.abilityR = r;
    }

    public Ability getAbility(AbilitySlot slot) {
        switch (slot) {
            case Q: return abilityQ;
            case E: return abilityE;
            default: return abilityR;
        }
    }

    public void addPerk(Perk perk) {
        if (perk != null) {
            perks.add(perk);
        }
    }

    public List<Perk> getPerks() { return Collections.unmodifiableList(perks); }

    public PlayerController getController() { return controller; }

    public void setController(PlayerController controller) { this.controller = controller; }

    public boolean isHumanControlled() { return controller != null && controller.isHuman(); }

    public PlayerInput getInput() { return input; }

    public PlayerStats getStats() { return stats; }

    /** The single owner of "what is this player doing". */
    public ActionController getActions() { return actions; }

    // ---- simple getters -------------------------------------------------------------------------------------

    public String getName() { return name; }

    public int getNumber() { return number; }

    public TeamSide getSide() { return side; }

    public boolean isUserTeam() { return userTeam; }

    @Override
    public double getX() { return x; }

    @Override
    public double getY() { return y; }

    /** Height above the floor from the current action's jump arc (never negative). */
    @Override
    public double getZ() { return actions.getZ(); }

    public double getVx() { return vx; }

    public double getVy() { return vy; }

    public double getFacingX() { return facingX; }

    public double getFacingY() { return facingY; }

    /** Which sprite view to draw (with anti-flicker hysteresis). */
    public Facing getSpriteFacing() { return spriteFacing; }

    public double getAnimTime() { return animTime; }

    /** Skin / hair look index chosen by the match. */
    public int getAppearance() { return appearance; }

    public void setAppearance(int appearance) { this.appearance = appearance; }

    public double distanceTo(double px, double py) { return Math.hypot(px - x, py - y); }

    public double distanceTo(Player other) { return distanceTo(other.x, other.y); }

    @Override
    public String toString() {
        return name + " (" + getPlayerClass().getDisplayName() + ")";
    }
}
