package arcshot.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * The "balance sheet": every tunable gameplay number (cooldowns, durations, radii, meter gains,
 * rules, unlock thresholds) is read from {@code config/balance.properties}.
 * <p>
 * OOP pillar: <b>ENCAPSULATION</b>. The raw {@link Properties} object is private. The rest of the game can only
 * ask for typed values through {@link #d}, {@link #i} and {@link #b}, and must always pass a safe default,
 * so a missing or mistyped key can never crash the game.
 * <p>
 * Live tweaking: if {@code resources/config/balance.properties} exists in the working folder it is preferred,
 * and {@link #reload()} (F5 in a match) re-reads it without restarting.
 */
public final class Balance {
    private static final String CLASSPATH_FILE = "/config/balance.properties";
    private static final File DEV_FILE = new File("resources/config/balance.properties");

    private static volatile Properties props = new Properties();
    private static volatile String loadedFrom = "built-in defaults";

    static {
        reload();
    }

    private Balance() { }

    /** Re-reads the balance file. Safe to call at any time; on error the built-in defaults are used. */
    public static synchronized void reload() {
        Properties fresh = new Properties();
        String from = "built-in defaults";
        try {
            if (DEV_FILE.isFile()) {
                try (InputStream in = new FileInputStream(DEV_FILE)) {
                    fresh.load(in);
                    from = DEV_FILE.getPath();
                }
            } else {
                InputStream in = Balance.class.getResourceAsStream(CLASSPATH_FILE);
                if (in != null) {
                    try (InputStream stream = in) {
                        fresh.load(stream);
                        from = "classpath " + CLASSPATH_FILE;
                    }
                }
            }
        } catch (IOException | IllegalArgumentException ex) {
            fresh = new Properties();
            from = "built-in defaults (balance file unreadable)";
        }
        props = fresh;
        loadedFrom = from;
    }

    /** A decimal value, or {@code def} if the key is missing or not a number. */
    public static double d(String key, double def) {
        String value = props.getProperty(key);
        if (value == null) {
            return def;
        }
        try {
            return Double.parseDouble(value.trim());
        } catch (NumberFormatException ex) {
            return def;
        }
    }

    /** A whole-number value, or {@code def}. */
    public static int i(String key, int def) {
        return (int) Math.round(d(key, def));
    }

    /** A true/false value, or {@code def}. */
    public static boolean b(String key, boolean def) {
        String value = props.getProperty(key);
        return value == null ? def : Boolean.parseBoolean(value.trim());
    }

    /** A text value, or {@code def}. */
    public static String s(String key, String def) {
        String value = props.getProperty(key);
        return value == null ? def : value.trim();
    }

    /** Where the current values came from (shown in the debug overlay). */
    public static String loadedFrom() {
        return loadedFrom;
    }
}
