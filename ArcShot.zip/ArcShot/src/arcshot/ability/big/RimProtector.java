package arcshot.ability.big;

import arcshot.ability.AbilitySlot;
import arcshot.ability.ActiveAbility;
import arcshot.court.Match;
import arcshot.effect.RimProtectorEffect;
import arcshot.player.Player;

/**
 * Big Q (alternate): for 3 s every opponent shot in the paint is automatically contested.
 * OOP pillars: <b>INHERITANCE</b> (extends ActiveAbility / Ultimate) and <b>POLYMORPHISM</b> (overrides perform() and the optional hooks).
 */
public class RimProtector extends ActiveAbility {
    public RimProtector() {
        super("big.rim_protector", AbilitySlot.Q, 11);
    }

    @Override
    protected void perform(Player owner, Match match) {
        owner.applyEffect(new RimProtectorEffect(param("duration", 3)));
        match.fx().ring("rim_protector", match.getCourt().getHoopX(), match.getCourt().getHoopY() + 60, 130, 0.5);
    }

    @Override
    public boolean aiShouldUse(Player owner, Match match) {
        return opponentHasBall(owner, match) && match.getCourt().distanceToHoop(
                match.getBall().getHolder().getX(), match.getBall().getHolder().getY()) < 200;
    }
}
