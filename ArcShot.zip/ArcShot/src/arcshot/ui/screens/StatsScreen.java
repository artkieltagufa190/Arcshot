package arcshot.ui.screens;

import arcshot.app.AppContext;
import arcshot.save.Profile;
import arcshot.ui.Screen;
import arcshot.ui.Theme;
import arcshot.ui.UIFactory;
import arcshot.ui.components.RoundedPanel;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JComponent;
import javax.swing.JPanel;

/**
 * Lifetime stats (3x3 mode only; Practice is not counted).
 * OOP pillars: <b>INHERITANCE</b> (extends Screen) and <b>POLYMORPHISM</b> (the ScreenManager calls its lifecycle hooks).
 */
public class StatsScreen extends Screen {
    public StatsScreen(AppContext app) {
        super(app);
        add(UIFactory.header("Lifetime stats", "Every 3x3 match you have finished", e -> app.back()), BorderLayout.NORTH);
        Profile p = app.profile();
        int matches = p.getStat("matches");
        int wins = p.getStat("wins");
        JPanel grid = UIFactory.clear(new GridLayout(0, 5, Theme.S4, Theme.S4));
        grid.add(tile("Matches", matches));
        grid.add(tile("Wins", wins));
        grid.add(tile("Losses", p.getStat("losses")));
        grid.add(tile("Win %", matches == 0 ? "-" : Math.round(100.0 * wins / matches) + "%"));
        grid.add(tile("Time played", (p.getStat("seconds") / 60) + " min"));
        grid.add(tile("Points", p.getStat("points")));
        grid.add(tile("Baskets", p.getStat("baskets")));
        grid.add(tile("Outside makes", p.getStat("outside")));
        grid.add(tile("Dunks", p.getStat("dunks")));
        grid.add(tile("Best score", p.getStat("best.score")));
        grid.add(tile("Rebounds", p.getStat("rebounds")));
        grid.add(tile("Assists", p.getStat("assists")));
        grid.add(tile("Steals", p.getStat("steals")));
        grid.add(tile("Blocks", p.getStat("blocks")));
        grid.add(tile("Best margin", p.getStat("best.margin")));
        grid.add(tile("Abilities used", p.getStat("abilities")));
        grid.add(tile("Ultimates used", p.getStat("ultimates")));
        grid.add(tile("Wins as Guard", p.getStat("wins.guard")));
        grid.add(tile("Wins as Forward", p.getStat("wins.forward")));
        grid.add(tile("Wins as Big", p.getStat("wins.big")));
        JPanel wrap = UIFactory.clear(new BorderLayout());
        wrap.add(grid, BorderLayout.NORTH);
        add(UIFactory.scroll(wrap), BorderLayout.CENTER);
    }

    private JComponent tile(String label, Object value) {
        RoundedPanel card = UIFactory.card(new BorderLayout());
        card.add(UIFactory.label(String.valueOf(value), Theme.display(36), Theme.TEXT), BorderLayout.CENTER);
        card.add(UIFactory.label(label.toUpperCase(), Theme.bold(12), Theme.TEXT_MUTED), BorderLayout.SOUTH);
        return card;
    }
}
