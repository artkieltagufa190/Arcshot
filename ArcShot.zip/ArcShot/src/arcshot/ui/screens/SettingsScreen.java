package arcshot.ui.screens;

import arcshot.ai.Difficulty;
import arcshot.app.AppContext;
import arcshot.control.InputAction;
import arcshot.control.KeyBindings;
import arcshot.core.Balance;
import arcshot.save.Settings;
import arcshot.ui.Screen;
import arcshot.ui.Theme;
import arcshot.ui.ThemeSkin;
import arcshot.ui.UIFactory;
import arcshot.ui.components.RoundedPanel;
import arcshot.ui.components.ThemedButton;
import arcshot.ui.components.ThemedSlider;
import arcshot.ui.components.ToggleSwitch;
import arcshot.ui.components.ValueStepper;
import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.EnumMap;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * Settings: profile name, audio, skin, gameplay, accessibility, key rebinding, and hidden developer / demo options
 * (click the version label 5 times): Unlock All (Demo Mode) and Reset Progress.
 * OOP pillars: <b>INHERITANCE</b> (extends Screen) and <b>POLYMORPHISM</b> (the ScreenManager calls its lifecycle hooks).
 */
public class SettingsScreen extends Screen {
    private final Settings s;
    private final Map<InputAction, ThemedButton> keyButtons = new EnumMap<>(InputAction.class);
    private InputAction waitingFor;
    private final JPanel devPanel = UIFactory.column();
    private int versionClicks;

    public SettingsScreen(AppContext app) {
        super(app);
        this.s = app.profile().getSettings();
        add(UIFactory.header("Settings", "Changes are saved automatically", e -> {
            app.save();
            app.back();
        }), BorderLayout.NORTH);
        JPanel cols = UIFactory.clear(new GridLayout(1, 2, Theme.S5, 0));
        JPanel left = UIFactory.column();
        left.add(section("Profile", profileRows()));
        left.add(UIFactory.vgap(Theme.S4));
        left.add(section("Audio & display", audioRows()));
        left.add(UIFactory.vgap(Theme.S4));
        left.add(section("Gameplay & accessibility", gameplayRows()));
        JPanel right = UIFactory.column();
        right.add(section("Controls (click, then press a key)", keyRows()));
        right.add(UIFactory.vgap(Theme.S4));
        devPanel.setVisible(s.isDeveloperOptions());
        buildDevPanel();
        right.add(devPanel);
        right.add(UIFactory.vgap(Theme.S3));
        JLabel version = UIFactory.muted("ArcShot v2.0  -  save file: " + app.saves().getFile().getPath());
        version.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
        version.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (++versionClicks >= 5) {
                    s.setDeveloperOptions(true);
                    devPanel.setVisible(true);
                    app.save();
                    revalidate();
                }
            }
        });
        right.add(version);
        cols.add(top(left));
        cols.add(top(right));
        add(UIFactory.scroll(cols), BorderLayout.CENTER);
        setFocusable(true);
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                captureKey(e);
            }
        });
    }

    private static JComponent top(JComponent c) {
        JPanel wrap = UIFactory.clear(new BorderLayout());
        wrap.add(c, BorderLayout.NORTH);
        return wrap;
    }

    private JComponent section(String title, JComponent... rows) {
        RoundedPanel card = UIFactory.card(null);
        card.setLayout(new javax.swing.BoxLayout(card, javax.swing.BoxLayout.Y_AXIS));
        JLabel h = UIFactory.heading(title);
        h.setAlignmentX(LEFT_ALIGNMENT);
        card.add(h);
        for (JComponent r : rows) {
            r.setAlignmentX(LEFT_ALIGNMENT);
            card.add(r);
        }
        card.setAlignmentX(LEFT_ALIGNMENT);
        return card;
    }

    private JComponent[] profileRows() {
        JTextField name = new JTextField(app.profile().getName(), 12);
        name.setFont(Theme.semi(16));
        name.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Theme.BORDER),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)));
        name.setPreferredSize(new Dimension(170, 38));
        JLabel feedback = UIFactory.muted(" ");
        ThemedButton save = UIFactory.secondary("Save", e -> {
            try {
                app.profile().setName(name.getText());
                app.save();
                feedback.setForeground(Theme.SUCCESS);
                feedback.setText("Saved");
            } catch (IllegalArgumentException ex) {
                feedback.setForeground(Theme.DANGER);
                feedback.setText(ex.getMessage());
            }
        });
        JPanel ctrl = UIFactory.clear(new FlowLayout(FlowLayout.RIGHT, Theme.S2, 0));
        ctrl.add(name);
        ctrl.add(save);
        return new JComponent[] {UIFactory.formRow("Player name", "1-12 characters (also used in Classic Shootout)", ctrl), feedback};
    }

    private JComponent[] audioRows() {
        ThemedSlider volume = new ThemedSlider(s.getVolume());
        volume.setOnChange(v -> {
            s.setVolume(v);
            app.applyAudio();
        });
        ToggleSwitch mute = toggle(s.isMuted(), v -> {
            s.setMuted(v);
            app.applyAudio();
        });
        ValueStepper<String> skin = new ValueStepper<>();
        skin.addOption(ThemeSkin.ANIME, "Anime (default)");
        skin.addOption(ThemeSkin.STREET, "Street / PBA");
        skin.setSelected(s.getSkin());
        skin.setOnChange(id -> {
            s.setSkin(id);
            app.reloadSkin();
            app.save();
        });
        ToggleSwitch fps = toggle(s.isShowFps(), s::setShowFps);
        ValueStepper<String> style = new ValueStepper<>();
        style.addOption("retro", "Retro pixel (default)");
        style.addOption("smooth", "Smooth HD (classic v2)");
        style.setSelected(s.getGraphicsStyle());
        style.setOnChange(id -> {
            s.setGraphicsStyle(id);
            app.save();
        });
        return new JComponent[] {
            UIFactory.formRow("Volume", "Sound files go in resources/sounds (optional)", volume),
            UIFactory.formRow("Mute", null, mute),
            UIFactory.formRow("Theme skin", "Ability names, effect colors and particles", skin),
            UIFactory.formRow("Match graphics", "Retro = 640x360 pixel art, angled court", style),
            UIFactory.formRow("CRT scanlines", "Retro style only", toggle(s.isCrt(), s::setCrt)),
            UIFactory.formRow("Show FPS counter", "F1 in a match; F3 = debug overlay", fps)
        };
    }

    private JComponent[] gameplayRows() {
        ValueStepper<String> diff = new ValueStepper<>();
        for (Difficulty d : Difficulty.values()) {
            diff.addOption(d.name(), d.getLabel());
        }
        diff.setSelected(s.getDifficulty());
        diff.setOnChange(id -> {
            s.setDifficulty(id);
            app.save();
        });
        ValueStepper<String> fouls = new ValueStepper<>();
        fouls.addOption("OFF", "Off");
        fouls.addOption("LOW", "Low");
        fouls.addOption("NORMAL", "Normal");
        fouls.addOption("HIGH", "High");
        fouls.setSelected(s.getFoulFrequency());
        fouls.setOnChange(id -> {
            s.setFoulFrequency(id);
            app.save();
        });
        ValueStepper<Integer> minutes = new ValueStepper<>();
        for (int m : new int[] {4, 6, 8, 10}) {
            minutes.addOption(m, m + " minutes" + (m == 10 ? " (official 3x3)" : (m == 6 ? " (default)" : "")));
        }
        minutes.setSelected(s.getGameMinutes());
        minutes.setOnChange(m -> {
            s.setGameMinutes(m);
            app.save();
        });
        return new JComponent[] {
            UIFactory.formRow("Default AI difficulty", null, diff),
            UIFactory.formRow("Game length", "Or first to 21 points", minutes),
            UIFactory.formRow("Foul frequency", "How often contact is called", fouls),
            UIFactory.formRow("Strict refs", "Technicals for abilities on frozen players, more calls", toggle(s.isStrictRefs(), s::setStrictRefs)),
            UIFactory.formRow("Auto-switch to ball handler", "Control whoever on your team gets the ball",
                    toggle(s.isAutoSwitch(), s::setAutoSwitch)),
            UIFactory.formRow("Colorblind-friendly cues", "Text labels on effects, striped away jerseys",
                    toggle(s.isColorblind(), s::setColorblind)),
            UIFactory.formRow("Screen shake", null, toggle(s.isScreenShake(), s::setScreenShake))
        };
    }

    private ToggleSwitch toggle(boolean initial, java.util.function.Consumer<Boolean> onChange) {
        ToggleSwitch t = new ToggleSwitch(initial);
        t.setOnChange(v -> {
            onChange.accept(v);
            app.save();
        });
        return t;
    }

    private JComponent[] keyRows() {
        KeyBindings keys = s.getKeys();
        JComponent[] rows = new JComponent[InputAction.values().length + 1];
        int i = 0;
        for (InputAction a : InputAction.values()) {
            ThemedButton b = UIFactory.secondary(keys.keyName(a), e -> startCapture(a));
            b.setPreferredSize(new Dimension(150, 40));
            keyButtons.put(a, b);
            JPanel row = UIFactory.clear(new BorderLayout());
            row.add(UIFactory.label(a.getLabel(), Theme.semi(15), Theme.TEXT), BorderLayout.CENTER);
            row.add(b, BorderLayout.EAST);
            row.setBorder(BorderFactory.createEmptyBorder(3, 0, 3, 0));
            rows[i++] = row;
        }
        JPanel reset = UIFactory.clear(new FlowLayout(FlowLayout.RIGHT, 0, Theme.S2));
        reset.add(UIFactory.button("Reset to defaults", ThemedButton.Style.GHOST, e -> {
            keys.resetToDefaults();
            refreshKeys();
            app.save();
        }));
        rows[i] = reset;
        return rows;
    }

    private void startCapture(InputAction a) {
        waitingFor = a;
        keyButtons.get(a).setText("Press a key...");
        requestFocusInWindow();
    }

    private void captureKey(KeyEvent e) {
        if (waitingFor == null) {
            return;
        }
        s.getKeys().bind(waitingFor, e.getKeyCode());
        waitingFor = null;
        refreshKeys();
        app.save();
    }

    private void refreshKeys() {
        for (Map.Entry<InputAction, ThemedButton> en : keyButtons.entrySet()) {
            en.getValue().setText(s.getKeys().keyName(en.getKey()));
        }
    }

    private void buildDevPanel() {
        RoundedPanel card = UIFactory.card(null);
        card.setLayout(new javax.swing.BoxLayout(card, javax.swing.BoxLayout.Y_AXIS));
        JLabel h = UIFactory.label("Developer / Demo options", Theme.bold(20), Theme.GOLD);
        h.setAlignmentX(LEFT_ALIGNMENT);
        card.add(h);
        JComponent unlock = UIFactory.formRow("Unlock All (Demo Mode)", "Every ability, perk and cosmetic becomes available",
                toggle(s.isUnlockAllDemo(), v -> {
                    s.setUnlockAllDemo(v);
                    app.achievements().checkUnlocks();
                }));
        unlock.setAlignmentX(LEFT_ALIGNMENT);
        card.add(unlock);
        JPanel buttons = UIFactory.clear(new FlowLayout(FlowLayout.LEFT, 0, Theme.S2));
        buttons.setAlignmentX(LEFT_ALIGNMENT);
        buttons.add(UIFactory.secondary("Reload balance.properties", e -> {
            Balance.reload();
            JOptionPane.showMessageDialog(this, "Loaded from " + Balance.loadedFrom(), "Balance", JOptionPane.INFORMATION_MESSAGE);
        }));
        buttons.add(UIFactory.hgap(Theme.S3));
        buttons.add(UIFactory.button("Reset Progress", ThemedButton.Style.DANGER, e -> confirmReset()));
        card.add(buttons);
        card.setAlignmentX(LEFT_ALIGNMENT);
        devPanel.add(card);
    }

    private void confirmReset() {
        int r = JOptionPane.showConfirmDialog(this, "Erase all stats, achievements, unlocks and loadouts?\n"
                + "Your name and settings are kept.", "Reset progress", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (r == JOptionPane.YES_OPTION) {
            app.profile().resetProgress();
            app.save();
            JOptionPane.showMessageDialog(this, "Progress reset.", "Reset progress", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
