package arcshot.render;

import arcshot.court.Court;
import arcshot.cosmetic.Cosmetic;
import arcshot.ui.Theme;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.RadialGradientPaint;
import java.awt.geom.Arc2D;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;

/**
 * Paints the half court (floor, paint, arc, lines) once into a cached image, and the hoop every frame.
 * The court theme cosmetic supplies the colors, so a new court theme needs no new art.
 * OOP pillar: <b>ABSTRACTION</b> - drawing details are hidden behind draw methods; gameplay never draws.
 */
public final class CourtRenderer {
    /** How much height (z) lifts things up on screen in our angled top-down view. */
    public static final double LIFT = 0.35;

    private final Court court;
    private final Cosmetic theme;
    private BufferedImage cache;

    public CourtRenderer(Court court, Cosmetic theme) {
        this.court = court;
        this.theme = theme;
    }

    public void drawFloor(Graphics2D g, int w, int h) {
        if (cache == null) {
            cache = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
            Graphics2D cg = cache.createGraphics();
            Theme.quality(cg);
            paintStatic(cg, w, h);
            cg.dispose();
        }
        g.drawImage(cache, 0, 0, null);
    }

    private void paintStatic(Graphics2D g, int w, int h) {
        Color floor = theme.color(0);
        Color lines = theme.color(1);
        Color paint = theme.color(2);
        Color outside = theme.color(3);
        g.setPaint(new GradientPaint(0, 0, Theme.mix(outside, Color.BLACK, 0.25), 0, h, outside));
        g.fillRect(0, 0, w, h);
        int l = (int) court.getLeft();
        int t = (int) court.getTop();
        int cw = (int) court.getWidth();
        int ch = (int) court.getHeight();
        // apron + shadow
        g.setColor(new Color(0, 0, 0, 90));
        g.fillRoundRect(l - 14, t - 10, cw + 28, ch + 26, 18, 18);
        g.setColor(Theme.mix(floor, Color.BLACK, 0.18));
        g.fillRect(l - 10, t - 10, cw + 20, ch + 20);
        // floor planks
        g.setColor(floor);
        g.fillRect(l, t, cw, ch);
        for (int x = l, i = 0; x < l + cw; x += 25, i++) {
            g.setColor(i % 2 == 0 ? Theme.alpha(Color.WHITE, 10) : Theme.alpha(Color.BLACK, 12));
            g.fillRect(x, t, 25, ch);
        }
        // paint
        int px = (int) (court.getHoopX() - court.getPaintHalfWidth());
        int pw = (int) (court.getPaintHalfWidth() * 2);
        int pd = (int) court.getPaintDepth();
        g.setColor(Theme.alpha(paint, 210));
        g.fillRect(px, t, pw, pd);
        // inside-the-arc tint
        g.setColor(Theme.alpha(Color.WHITE, 12));
        double r = court.getArcRadius();
        g.fill(new Arc2D.Double(court.getHoopX() - r, court.getHoopY() - r, r * 2, r * 2, 180, 180, Arc2D.CHORD));
        // lines
        g.setColor(lines);
        g.setStroke(new BasicStroke(3f));
        g.drawRect(l, t, cw, ch);
        g.drawRect(px, t, pw, pd);
        double ft = 1.8 * Court.PX_PER_M;
        g.draw(new Arc2D.Double(court.getHoopX() - ft, t + pd - ft, ft * 2, ft * 2, 180, 180, Arc2D.OPEN));
        g.setStroke(new BasicStroke(2f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10, new float[] {10, 8}, 0));
        g.draw(new Arc2D.Double(court.getHoopX() - ft, t + pd - ft, ft * 2, ft * 2, 0, 180, Arc2D.OPEN));
        g.setStroke(new BasicStroke(3f));
        double nc = 1.25 * Court.PX_PER_M;
        g.draw(new Arc2D.Double(court.getHoopX() - nc, court.getHoopY() - nc, nc * 2, nc * 2, 180, 180, Arc2D.OPEN));
        drawArc(g);
        // top of the key circle at the bottom edge (half-court style)
        g.draw(new Arc2D.Double(court.getHoopX() - 90, t + ch - 90, 180, 180, 0, 180, Arc2D.OPEN));
        // check-ball mark
        g.setColor(Theme.alpha(lines, 140));
        g.fillOval((int) court.checkX() - 5, (int) court.checkY() - 3, 10, 6);
        // watermark
        g.setFont(Theme.display(54));
        g.setColor(Theme.alpha(lines, 22));
        Theme.drawCentered(g, "ARCSHOT 3x3", (int) court.getHoopX(), t + ch - 32);
        // vignette
        g.setPaint(new RadialGradientPaint(new Point2D.Double(w / 2.0, h / 2.0), w * 0.7f,
                new float[] {0.55f, 1f}, new Color[] {new Color(0, 0, 0, 0), new Color(0, 0, 0, 120)}));
        g.fillRect(0, 0, w, h);
    }

    private void drawArc(Graphics2D g) {
        double r = court.getArcRadius();
        double cx = court.getHoopX();
        double cy = court.getHoopY();
        double corner = court.getCornerX();
        double yMeet = cy + Math.sqrt(Math.max(0, r * r - corner * corner));
        g.drawLine((int) (cx - corner), (int) court.getTop(), (int) (cx - corner), (int) yMeet);
        g.drawLine((int) (cx + corner), (int) court.getTop(), (int) (cx + corner), (int) yMeet);
        double startAngle = Math.toDegrees(Math.atan2(yMeet - cy, corner));
        g.draw(new Arc2D.Double(cx - r, cy - r, r * 2, r * 2, -startAngle, -(180 - 2 * startAngle), Arc2D.OPEN));
    }

    /** Backboard, stanchion and rim (drawn before players). */
    public void drawHoopBack(Graphics2D g, double netSwing, boolean flash) {
        double cx = court.getHoopX();
        double rimY = court.getHoopY() - court.getRimHeight() * LIFT;
        double boardY = court.getTop() + 1.2 * Court.PX_PER_M - 3.4 * Court.PX_PER_M * LIFT;
        // stanchion arm
        g.setColor(new Color(40, 44, 58));
        g.fillRect((int) cx - 5, (int) court.getTop() - 40, 10, (int) (boardY - court.getTop() + 44));
        g.fillRoundRect((int) cx - 30, (int) court.getTop() - 46, 60, 12, 6, 6);
        // shadow of the hoop on the floor
        g.setColor(new Color(0, 0, 0, 60));
        g.fillOval((int) cx - 20, (int) court.getHoopY() - 7, 40, 14);
        // backboard
        g.setColor(new Color(235, 240, 250, 225));
        g.fillRoundRect((int) cx - 46, (int) boardY - 12, 92, 24, 4, 4);
        g.setColor(new Color(220, 60, 50));
        g.setStroke(new BasicStroke(2f));
        g.drawRoundRect((int) cx - 46, (int) boardY - 12, 92, 24, 4, 4);
        g.drawRect((int) cx - 14, (int) boardY - 6, 28, 13);
        // rim back half
        g.setColor(flash ? new Color(60, 220, 100) : new Color(235, 90, 20));
        g.setStroke(new BasicStroke(3.5f));
        g.draw(new Arc2D.Double(cx - 16, rimY - 7, 32, 14, 0, 180, Arc2D.OPEN));
    }

    /** Net and front rim (drawn after players so the ball looks like it goes in). */
    public void drawHoopFront(Graphics2D g, double netSwing, boolean flash) {
        double cx = court.getHoopX();
        double rimY = court.getHoopY() - court.getRimHeight() * LIFT;
        double sway = Math.sin(netSwing * 18) * 4 * netSwing;
        double stretch = 1 + netSwing * 0.35;
        g.setColor(new Color(255, 255, 255, 210));
        g.setStroke(new BasicStroke(1.3f));
        for (int i = 0; i <= 6; i++) {
            double topX = cx - 16 + i * 32 / 6.0;
            double botX = cx - 9 + i * 18 / 6.0 + sway;
            g.drawLine((int) topX, (int) rimY, (int) botX, (int) (rimY + 22 * stretch));
        }
        g.drawLine((int) (cx - 12 + sway / 2), (int) (rimY + 10 * stretch), (int) (cx + 12 + sway / 2), (int) (rimY + 10 * stretch));
        g.drawLine((int) (cx - 9 + sway), (int) (rimY + 22 * stretch), (int) (cx + 9 + sway), (int) (rimY + 22 * stretch));
        g.setColor(flash ? new Color(60, 220, 100) : new Color(255, 110, 30));
        g.setStroke(new BasicStroke(3.5f));
        g.draw(new Arc2D.Double(cx - 16, rimY - 7, 32, 14, 180, 180, Arc2D.OPEN));
    }
}
