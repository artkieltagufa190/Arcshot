package arcshot.court;

import arcshot.core.Balance;

/**
 * The free-throw aim, in the style of classic 2K free throws: an arc arrow from the shooter to the basket.
 * <ul>
 *   <li><b>Power</b> - while SHOOT is held the arrow grows from the shooter toward (and past) the rim. 1.0 = the tip
 *       lands exactly on the rim.</li>
 *   <li><b>Sway</b> - the tip swings left and right on its own. 0 = dead centre.</li>
 * </ul>
 * Release when the tip sits on the rim: the closer to (power 1, sway 0), the better the timing grade.
 * This is a different control from the jump-shot meter on purpose (the brief's reference image).
 * Gameplay owns the numbers; renderers only read {@link #getPower()}, {@link #getSway()} and {@link #isAiming()}.
 * OOP pillar: <b>ENCAPSULATION</b> - the grading formula lives here only.
 */
public final class FreeThrowAim {
    private double time;
    private double sway;
    private double power;
    private boolean aiming;
    private double swaySpeed = 2.6;

    /** Called when a new free throw is set up; slower sway for better free-throw shooters. */
    public void reset(double freeThrowPercent) {
        time = 0;
        sway = 0;
        power = 0;
        aiming = false;
        swaySpeed = Balance.d("ft.swaySpeed", 2.8) * (1.25 - freeThrowPercent * 0.5);
    }

    /** One tick while the shooter is holding SHOOT. */
    public void update(double dt, double hold, double meterTime) {
        aiming = true;
        time += dt;
        sway = Math.sin(time * swaySpeed) * (0.75 + 0.25 * Math.sin(time * swaySpeed * 0.37 + 1.1));
        power = hold / meterTime;
    }

    /** Ends aiming (shot released or cancelled). The last power/sway stay readable for the HUD. */
    public void stop() {
        aiming = false;
    }

    public boolean isAiming() { return aiming; }

    /** 0 = at the shooter, 1 = on the rim, above 1 = long. */
    public double getPower() { return power; }

    /** -1 = far left, 0 = centre, +1 = far right. */
    public double getSway() { return sway; }

    /**
     * Distance from a perfect release in "window units": 1.0 = edge of the green window.
     * {@code swayWeight} lets AI shooters (who do not watch the sway) be graded mostly on power.
     */
    public double error(double swayWeight) {
        double pw = Balance.d("ft.powerWindow", 0.09);
        double sw = Balance.d("ft.swayWindow", 0.28);
        double dp = (power - 1.0) / pw;
        double ds = sway / sw * swayWeight;
        return Math.sqrt(dp * dp + ds * ds);
    }

    public ShotAttempt.Timing grade(double swayWeight) {
        double e = error(swayWeight);
        if (e <= 1.0) {
            return ShotAttempt.Timing.GREEN;
        }
        if (e <= 2.0) {
            return ShotAttempt.Timing.GOOD;
        }
        return power < 1.0 ? ShotAttempt.Timing.EARLY : ShotAttempt.Timing.LATE;
    }

    /** Make-chance change for this release (added to the class free-throw percentage). */
    public double bonus(double swayWeight) {
        double e = error(swayWeight);
        if (e <= 1.0) {
            return Balance.d("ft.greenBonus", 0.16);
        }
        if (e <= 2.0) {
            return Balance.d("ft.goodBonus", 0.02);
        }
        return -Math.min(0.45, 0.08 + (e - 2.0) * 0.07);
    }
}
