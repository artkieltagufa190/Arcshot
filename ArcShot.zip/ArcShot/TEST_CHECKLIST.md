# Manual test checklist

Run `./build.sh` (or `build.bat`). Tick each box. For a clean start, delete `~/.arcshot/profile.properties`.

## Startup and menu
- [ ] The splash screen animates, and any key or click goes to the main menu.
- [ ] The main menu shows 3 mode buttons plus Achievements, Customize, Settings, How to Play, Stats and Quit.
- [ ] Hovering a button highlights it. Tab/Enter keyboard navigation works.
- [ ] Resize the window (and maximise): menus re-layout, nothing overlaps, and the game is letterboxed.
- [ ] Quit (and the window X) saves and exits.

## Classic Shootout (Messenger mode, original logic)
- [ ] Drag-and-release shoots, swish = 3 and rim = 2, and the hoop moves at 6+ points.
- [ ] The defender appears at 14+. The timer counts down from 100.
- [ ] The game-over card shows score, accuracy and streak. Play Again restarts and Back to Menu returns.
- [ ] Esc returns to the menu at any time. Mouse aim is still correct after resizing the window.

## 3x3 match: core
- [ ] Class select: clicking a card selects it, Q/E/R steppers show only unlocked abilities, and locked ones list their achievement.
- [ ] The match starts with CHECK BALL, then players move with WASD, and Shift sprints while draining stamina.
- [ ] Outside the paint, holding Space fills the vertical meter beside the shooter. Releasing in green shows "GREEN" and gives a high make chance.
- [ ] Inside the arc = 1 point, outside = 2.
- [ ] F passes in the WASD direction. F with an AI teammate holding the ball makes them pass to you.
- [ ] Defense: Space jumps (blocks) and F steals when close.
- [ ] After a steal or defensive rebound, the "CLEAR THE BALL" chip appears and shooting is blocked until you go behind the arc.
- [ ] The shot clock counts 12 and resets on a rim hit. Running out of shot clock is a turnover.
- [ ] Tab switches the controlled player, and the "YOU" marker follows.
- [ ] The match ends at 21, or when the clock runs out with a leader. A tie goes to OVERTIME: the first team to score 2 points wins.
- [ ] Results shows the box score, achievements earned and ultimate highlights. Play Again and Main Menu work.

## 3x3 match: upgrade pass (v3)
- [ ] **Retro look** (default): the match is pixel art at 640x360, crisp when the window is resized (integer scaling, black bars), with the angled broadcast court, crowd, sponsor boards and the scoreboard bottom-right.
- [ ] Settings → Match graphics = Smooth HD brings back the v2 view. CRT scanlines toggle works in retro.
- [ ] Players face the hoop / camera / sideways without flickering; jersey numbers are visible; the ball bounces in the dribbler's hand.
- [ ] Driving fast at the rim and pressing Space: **dunk** (net swings, rim dips, "DUNK" sound hook). Slower or contested: **layup** (bank shot when coming from the side).
- [ ] A defender can **block** a layup or a normal dunk during the rise (not after the rim touch).
- [ ] Shooting fouls: the whistle, "FOUL" banner, a referee signal, then free throws: 1 inside / 2 outside / 1 after a made basket ("AND ONE!").
- [ ] Scoreboard foul pips fill; at 6 team fouls the **BONUS** light turns on; the 7th foul gives 2 FT even without a shot; from foul 10 the fouled team also keeps the ball.
- [ ] Charge into a set defender with a dash: **offensive foul**, turnover, no FT.
- [ ] **Free throws**: players line up, "FREE THROW 1 OF 2" at the top; holding Space grows an arrow from the shooter that hooks onto the rim and swings side to side; release when the tip is on the rim (green). Abilities are greyed out.
- [ ] After a made last free throw the defense clears from under the basket; after a miss the rebound is live.
- [ ] Settings → Foul frequency Off: no fouls at all. High: clearly more calls. Strict refs on: Quake Fist on a frozen player can be a technical.
- [ ] Settings → Game length 4/6/8/10 changes the clock of the next match.
- [ ] Two referees: one on the baseline, one on the sideline; they never block players and play whistle/signal animations on calls.
- [ ] Three straight makes: flames above the head and "HOT" on the player card. A miss removes it.
- [ ] Commentary ticker lines appear above the scoreboard for dunks, blocks, steals and fouls.
- [ ] F3 overlay shows phase, ball state/owner, team fouls, action + frame + z of your player, FT aim values, and hitboxes. With F3 on: F6 shooting foul, F7 dunk, F8 block, F9 out of bounds, F10 seventh team foul, F11 free throws.
- [ ] Practice: tips rotate at the top; 4 = free-throw drill, 5 = dunk drill.
- [ ] Results: box score shows DNK, PF, FG and FT columns.
- [ ] New achievements: Layup Line, High Flyer, Charity Stripe, Contact Artist, And One! unlock from the matching plays.
- [ ] `./build.sh test` (or `build.bat test`) prints `PASSED ... FAILED 0`.

## Abilities and effects
- [ ] Q/E icons show a radial cooldown sweep and seconds left. The ultimate icon glows when the meter is full.
- [ ] Practice: C refills, 1/2/3 switch class. Try every default ability (they all work in Practice).
- [ ] Guard: Shadow Step dashes through, Focus Aura shows a yellow aura, Time Stop freezes opponents with a gray-blue tint and you can't shoot.
- [ ] Forward: Rising Fang drive is unblockable, Sky Rend shows a ring, Final Burst dunks and knocks defenders back.
- [ ] Big: Iron Wall barrier, Quake Fist knockback + slow, Titan Seal field slows opponents near the hoop.
- [ ] Demo Mode on: try every alternate (Crossover Snap, Slipstream, Deadeye Mark, Pickpocket, Phantom Squad, Tiger Claw, Bull Rush, Rebound Surge, Blazing Screen, Meteor Crash, Bulwark Screen, Rim Protector, Boulder Toss, Tremor Stomp, Colossus Rebound).
- [ ] Colorblind cues on: effects show text labels and away jerseys are striped.

## Achievements, saves, customization
- [ ] Score once in a match: the "First Bucket" toast appears in the HUD, and Customize then has 3 new jerseys.
- [ ] Achievement tree: nodes show locked / in progress (bar) / unlocked, lines show prerequisites, and hover shows details plus a hint.
- [ ] Close and reopen the game: progress, unlocks, loadouts, cosmetics and settings are kept.
- [ ] Corrupt the save file (type garbage into it): the game still starts, and `profile.corrupt` is created.
- [ ] Settings: click the version line 5 times, and Developer / Demo options appear.
- [ ] Unlock All makes everything selectable. Reset Progress (with confirmation) wipes progress.
- [ ] Customize: locked items can be previewed but not equipped, and the label names the achievement.
- [ ] The chosen jersey, number, aura, style and court theme appear in the next match.

## Settings
- [ ] Rebinding a key works in the next match. Reset to defaults works.
- [ ] Skin = Street: ability names change in the class select, HUD and How to Play, and effects are toned down.
- [ ] Screen shake and FPS toggles work in a match. F3 debug overlay, F5 reload balance.
- [ ] Pause → Settings → Back returns to the paused match.

## Stability
- [ ] Play 3 matches in a row: no slowdown, no freeze, no flicker.
- [ ] Alt-tab during a match: keys don't get "stuck".

---

## What was cut or left for later
| Item | Status |
|---|---|
| Sprite sheets | **Done in v3** (generated by `tools/SpriteSheetGenerator.java`, mask-recolored in code). The smooth renderer still draws code players. |
| Instant replay of the last basket | Not built (COULD, cut in v3 too). |
| "3 seconds with back to the basket" violation | Cut in v3: the AI and controls never post up, so it would never trigger. |
| Punch-in camera zoom on dunks | Cut in v3: at 640x360 any zoom breaks the integer pixel grid; a screen shake + flash is used instead. |
| Score flip animation on the scoreboard | Cut in v3 (small polish item). |
| Local multiplayer | Not built (COULD). Ready by design: add a second `KeyboardController` with other `KeyBindings` and give it an AWAY player. `Match` already treats every controller the same way. |
| Sound files | Hooks are done (`SoundManager` + `SOUND` events: swish, rim, backboard, dunk, block, whistle, crowd, dribble, sneaker, bounce). No `.wav` files are bundled, so the game is silent until you add them. |
| "25+ points in one match" achievement | Impossible in a game to 21, so it became "Deep Range: 10+ points from outside the arc in one match". |
| "First defender can't block" (Rising Fang) | Simplified to "your shot is unblockable during the drive". |
