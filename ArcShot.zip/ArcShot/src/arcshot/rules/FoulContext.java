package arcshot.rules;

/**
 * Facts about the play needed to decide a foul's penalty.
 * {@code shotMade} is null for non-shooting fouls.
 */
public final class FoulContext {
    private final Boolean shotMade;
    private final boolean shotOutside;

    public FoulContext(Boolean shotMade, boolean shotOutside) {
        this.shotMade = shotMade;
        this.shotOutside = shotOutside;
    }

    public static FoulContext nonShooting() { return new FoulContext(null, false); }

    public Boolean getShotMade() { return shotMade; }

    public boolean isShotOutside() { return shotOutside; }
}
