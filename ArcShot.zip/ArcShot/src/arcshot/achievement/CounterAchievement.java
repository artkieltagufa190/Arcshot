package arcshot.achievement;

import arcshot.core.GameEvent;

/**
 * Career total: counts matching events across all matches (e.g. 5 career steals).
 * OOP pillars: <b>INHERITANCE</b> (extends Achievement) and <b>POLYMORPHISM</b> (overrides handle() / progress).
 */
public class CounterAchievement extends Achievement {
    private final EventFilter filter;
    private final int target;

    public CounterAchievement(String id, String name, String description, String hint,
                              AchievementTier tier, AchievementBranch branch, EventFilter filter, int target) {
        super(id, name, description, hint, tier, branch);
        this.filter = filter;
        this.target = Math.max(1, target);
    }

    @Override
    public int getTarget() { return target; }

    @Override
    public void handle(GameEvent event, AchievementContext ctx) {
        if (filter.matches(event)) {
            ctx.setProgress(getId(), ctx.getProgress(getId()) + 1);
        }
    }
}
