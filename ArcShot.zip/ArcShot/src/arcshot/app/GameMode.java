package arcshot.app;

/**
 * A playable mode shown on the main menu (kept from the original project).
 * OOP pillars: <b>ABSTRACTION</b> (the menu only knows this interface) and <b>POLYMORPHISM</b>
 * (the menu builds one button per mode and calls {@link #launch} without knowing which mode it is).
 */
public interface GameMode {
    String getTitle();

    String getDescription();

    /** Opens the mode (its first screen). */
    void launch(AppContext app);
}
