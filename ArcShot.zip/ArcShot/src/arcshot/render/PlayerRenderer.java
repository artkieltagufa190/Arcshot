package arcshot.render;

import arcshot.court.CourtEntity;
import arcshot.player.Player;
import arcshot.player.PlayerClass;
import arcshot.player.TeamSide;
import arcshot.ui.Theme;
import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Composite;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Polygon;

/**
 * Draws players procedurally (code-drawn placeholder figures in an angled top-down view) in their team / jersey color.
 * When sprite sheets are added, only this class needs to change - gameplay is untouched.
 * OOP pillar: <b>ABSTRACTION</b> - drawing details are hidden behind draw methods; gameplay never draws.
 */
public final class PlayerRenderer {
    private static final Color[] SKIN = {
        new Color(0xF1C7A0), new Color(0xC68E5E), new Color(0x8D5A3B), new Color(0xE0AC7E), new Color(0x6B4430), new Color(0xD9A27A)
    };

    private final EffectRenderer effects;

    public PlayerRenderer(EffectRenderer effects) {
        this.effects = effects;
    }

    public void drawShadow(Graphics2D g, Player p) {
        double lift = p.getJumpHeight();
        int w = (int) (34 - lift * 8);
        g.setColor(new Color(0, 0, 0, (int) (90 - lift * 30)));
        g.fillOval((int) p.getX() - w / 2, (int) p.getY() - 6, w, 12);
    }

    /**
     * @param jersey   team / jersey color
     * @param aura     aura color shown when the ultimate is ready (null = jersey)
     * @param style    cosmetic style id (headband, gold trim, crown)
     */
    public void draw(Graphics2D g, Player p, Color jersey, Color aura, String style, boolean controlled,
                     boolean hasBall, double time, int index) {
        double x = p.getX();
        double lift = p.getJumpHeight() * 20;
        double y = p.getY() - lift;
        double bob = Math.abs(Math.sin(p.getAnimTime() * 9)) * Math.min(1, Math.hypot(p.getVx(), p.getVy()) / 200) * 2.5;
        y -= bob;
        effects.drawUnder(g, p, time);
        if (controlled) {
            drawControlRing(g, p, time);
        }
        if (p.isUltimateReady()) {
            effects.glow(g, x, y - 26, 40 + Math.sin(time * 6) * 4, aura == null ? jersey : aura, 120);
        }
        Color shorts = Theme.mix(jersey, Color.BLACK, 0.45);
        Color skin = SKIN[Math.abs(index) % SKIN.length];
        int size = p.getPlayerClass() == PlayerClass.BIG ? 3 : (p.getPlayerClass() == PlayerClass.GUARD ? -2 : 0);
        // legs
        g.setColor(Theme.mix(skin, Color.BLACK, 0.15));
        double stride = Math.sin(p.getAnimTime() * 14) * Math.min(1, Math.hypot(p.getVx(), p.getVy()) / 150) * 4;
        g.fillRoundRect((int) (x - 8), (int) (y - 16 + stride), 6, 16, 4, 4);
        g.fillRoundRect((int) (x + 2), (int) (y - 16 - stride), 6, 16, 4, 4);
        // shorts
        g.setColor(shorts);
        g.fillRoundRect((int) (x - 11 - size / 2), (int) (y - 24), 22 + size, 12, 6, 6);
        // torso / jersey
        int tw = 26 + size;
        int th = 26 + size;
        int tx = (int) (x - tw / 2.0);
        int ty = (int) (y - 22 - th);
        g.setPaint(new GradientPaint(tx, ty, Theme.mix(jersey, Color.WHITE, 0.15), tx, ty + th, Theme.mix(jersey, Color.BLACK, 0.15)));
        g.fillRoundRect(tx, ty, tw, th, 12, 12);
        if (effects.isColorblind() && p.getSide() == TeamSide.AWAY) {
            g.setColor(Theme.alpha(Color.WHITE, 120));
            for (int sx = tx + 4; sx < tx + tw - 2; sx += 6) {
                g.fillRect(sx, ty + 2, 2, th - 4);
            }
        }
        if ("style.gold".equals(style) && p.isUserTeam()) {
            g.setColor(new Color(0xF5C542));
            g.setStroke(new BasicStroke(2f));
            g.drawRoundRect(tx, ty, tw, th, 12, 12);
        }
        // arms
        g.setColor(skin);
        double armSwing = hasBall ? 0 : stride;
        g.fillOval(tx - 5, (int) (ty + 6 + armSwing), 8, 14);
        g.fillOval(tx + tw - 3, (int) (ty + 6 - armSwing), 8, 14);
        // number
        double lum = (0.299 * jersey.getRed() + 0.587 * jersey.getGreen() + 0.114 * jersey.getBlue()) / 255.0;
        g.setColor(lum > 0.72 ? new Color(30, 30, 40) : Color.WHITE);
        g.setFont(Theme.bold(13));
        Theme.drawCentered(g, String.valueOf(p.getNumber()), (int) x, ty + th / 2 + 1);
        // head
        double hx = x + p.getFacingX() * 2;
        double hy = ty - 8;
        g.setColor(skin);
        g.fillOval((int) (hx - 9), (int) (hy - 9), 18, 18);
        g.setColor(new Color(30, 22, 18));
        g.fillArc((int) (hx - 9), (int) (hy - 10), 18, 14, 0, 180);
        if (p.isUserTeam() && ("style.headband".equals(style) || "style.legend".equals(style))) {
            g.setColor("style.legend".equals(style) ? new Color(0xFFE27A) : Color.WHITE);
            g.fillRect((int) (hx - 9), (int) (hy - 4), 18, 4);
        }
        if (p.isUserTeam() && "style.legend".equals(style)) {
            drawCrown(g, hx, hy - 12);
        }
        effects.drawOver(g, p, time, hy);
        drawTag(g, p, x, hy - 16, jersey, controlled);
        if (p.isChargingShot()) {
            g.setColor(Theme.alpha(Color.WHITE, 120));
            g.setStroke(new BasicStroke(2f));
            g.drawOval((int) x - 20, (int) y - 66, 40, 40);
        }
    }

    private void drawCrown(Graphics2D g, double x, double y) {
        Polygon crown = new Polygon();
        crown.addPoint((int) x - 8, (int) y + 4);
        crown.addPoint((int) x - 8, (int) y - 3);
        crown.addPoint((int) x - 4, (int) y + 1);
        crown.addPoint((int) x, (int) y - 5);
        crown.addPoint((int) x + 4, (int) y + 1);
        crown.addPoint((int) x + 8, (int) y - 3);
        crown.addPoint((int) x + 8, (int) y + 4);
        g.setColor(new Color(0xFFD54A));
        g.fillPolygon(crown);
    }

    private void drawControlRing(Graphics2D g, Player p, double time) {
        double pulse = 0.5 + 0.5 * Math.sin(time * 5);
        effects.floorRing(g, p.getX(), p.getY(), 24 + pulse * 3, Theme.ACCENT_2, 3f, 230);
        double fx = p.getFacingX();
        double fy = p.getFacingY();
        Polygon arrow = new Polygon();
        double ax = p.getX() + fx * 34;
        double ay = p.getY() + fy * 34 * 0.55;
        arrow.addPoint((int) (ax + fx * 8), (int) (ay + fy * 8 * 0.55));
        arrow.addPoint((int) (ax - fy * 6), (int) (ay + fx * 6 * 0.55));
        arrow.addPoint((int) (ax + fy * 6), (int) (ay - fx * 6 * 0.55));
        g.setColor(Theme.alpha(Theme.ACCENT_2, 220));
        g.fillPolygon(arrow);
    }

    private void drawTag(Graphics2D g, Player p, double x, double y, Color jersey, boolean controlled) {
        String cls = p.getPlayerClass().getDisplayName().substring(0, 1);
        String text = controlled ? "YOU" : cls;
        g.setFont(Theme.bold(11));
        int w = g.getFontMetrics().stringWidth(text) + 10;
        int ty = (int) y - 14;
        g.setColor(controlled ? Theme.ACCENT_2 : new Color(0, 0, 0, 150));
        g.fillRoundRect((int) x - w / 2, ty, w, 14, 7, 7);
        if (controlled) {
            Polygon tri = new Polygon();
            tri.addPoint((int) x - 4, ty + 14);
            tri.addPoint((int) x + 4, ty + 14);
            tri.addPoint((int) x, ty + 19);
            g.fillPolygon(tri);
        }
        g.setColor(controlled ? new Color(10, 20, 40) : (p.getSide() == TeamSide.HOME ? Theme.mix(jersey, Color.WHITE, 0.5) : Color.WHITE));
        g.drawString(text, (int) x - w / 2 + 5, ty + 11);
    }

    /** Phantom Squad decoys: translucent copies of their owner. */
    public void drawDecoy(Graphics2D g, CourtEntity decoy, Color jersey, double time) {
        Composite old = g.getComposite();
        float a = (float) (0.45 * Math.min(1, decoy.getFractionLeft() * 3));
        g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, a));
        double x = decoy.getX();
        double y = decoy.getY();
        g.setColor(effects.colorFor("decoy"));
        g.fillOval((int) x - 16, (int) y - 6, 32, 12);
        g.setColor(jersey);
        g.fillRoundRect((int) x - 13, (int) y - 48, 26, 26, 12, 12);
        g.fillOval((int) x - 9, (int) y - 64, 18, 18);
        g.setComposite(old);
    }
}
