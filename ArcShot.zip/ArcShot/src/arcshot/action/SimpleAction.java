package arcshot.action;

/**
 * A timed action that only plays an animation: FOULED (stumble), CELEBRATE, ABILITY_CAST.
 * OOP pillar: <b>INHERITANCE</b> - reuses all timing from {@link Action}; only the duration differs.
 */
public class SimpleAction extends Action {
    private final double seconds;

    public SimpleAction(ActionType type, String animation, double seconds) {
        super(type, animation);
        this.seconds = seconds;
    }

    public static SimpleAction fouled() { return new SimpleAction(ActionType.FOULED, "fouled", 0.45); }

    public static SimpleAction celebrate() { return new SimpleAction(ActionType.CELEBRATE, "celebrate", 1.3); }

    /** Cast pose for an ability family ("cast" or "cast_strike"). */
    public static SimpleAction cast(String animation) { return new SimpleAction(ActionType.ABILITY_CAST, animation, 0.3); }

    @Override
    public double duration() { return seconds; }
}
