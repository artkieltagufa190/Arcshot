package arcshot.render.sprite;

import java.awt.Color;
import java.util.HashMap;
import java.util.Map;

/**
 * The colors a character sheet is recolored with (indexed-color / mask convention). The sprite generator paints
 * team-dependent parts in fixed MASK colors (magenta jersey, green shorts, cyan shoes, orange skin, brown hair,
 * yellow trim, each in 3 tones); {@link #map()} turns each mask tone into the matching tone of the real color.
 * <b>Keep the MASK constants in sync with tools/SpriteSheetGenerator.</b>
 * OOP pillar: <b>ENCAPSULATION</b> (immutable value object with a cache key).
 */
public final class Palette {
    static final int[] JERSEY = {0xFF66FF, 0xFF00FF, 0xB000B0};
    static final int[] SHORTS = {0x66FF66, 0x00FF00, 0x00B000};
    static final int[] SHOE = {0x99FFFF, 0x00FFFF, 0x00B0B0};
    static final int[] SKIN = {0xFFB060, 0xFF8000, 0xB05000};
    static final int[] HAIR = {0xA06020, 0x804000, 0x502000};
    static final int[] TRIM = {0xFFFF80, 0xFFFF00, 0xB0B000};

    /** Skin tones (retro palette). */
    public static final int[] SKIN_TONES = {0x5C3A26, 0x8A5A3C, 0xC68A5E, 0xE8B890, 0x6E4630};
    public static final int[] HAIR_TONES = {0x1E1410, 0x2A1A10, 0x3A2414, 0x14100C};

    private final int jersey;
    private final int shorts;
    private final int shoe;
    private final int skin;
    private final int hair;
    private final int trim;

    public Palette(Color jersey, Color shorts, Color shoe, int skin, int hair, Color trim) {
        this.jersey = jersey.getRGB() & 0xFFFFFF;
        this.shorts = shorts.getRGB() & 0xFFFFFF;
        this.shoe = shoe.getRGB() & 0xFFFFFF;
        this.skin = skin;
        this.hair = hair;
        this.trim = trim.getRGB() & 0xFFFFFF;
    }

    /** A palette for a player: team color jersey + shorts, appearance picks skin and hair. */
    public static Palette forPlayer(Color team, boolean home, int appearance) {
        Color shorts = team.darker();
        Color shoe = home ? new Color(0xF4F4F0) : new Color(0x2A2D3A);
        Color trim = luminance(team) > 0.7 ? new Color(0x1A2A5A) : new Color(0xF4F4F0);
        return new Palette(team, shorts, shoe, SKIN_TONES[Math.abs(appearance) % SKIN_TONES.length],
                HAIR_TONES[Math.abs(appearance / 3) % HAIR_TONES.length], trim);
    }

    /** Referees keep their fixed stripes; only skin varies. */
    public static Palette forReferee(int index) {
        return new Palette(Color.BLACK, Color.BLACK, Color.BLACK, SKIN_TONES[(index * 2 + 1) % SKIN_TONES.length],
                HAIR_TONES[index % HAIR_TONES.length], Color.WHITE);
    }

    public static double luminance(Color c) {
        return (0.299 * c.getRed() + 0.587 * c.getGreen() + 0.114 * c.getBlue()) / 255.0;
    }

    public String key() {
        return Integer.toHexString(jersey) + "-" + Integer.toHexString(shorts) + "-" + Integer.toHexString(shoe) + "-"
                + Integer.toHexString(skin) + "-" + Integer.toHexString(hair) + "-" + Integer.toHexString(trim);
    }

    /** mask RGB (no alpha) -> real RGB, for all 18 mask tones. */
    public Map<Integer, Integer> map() {
        Map<Integer, Integer> m = new HashMap<>();
        put(m, JERSEY, jersey);
        put(m, SHORTS, shorts);
        put(m, SHOE, shoe);
        put(m, SKIN, skin);
        put(m, HAIR, hair);
        put(m, TRIM, trim);
        return m;
    }

    private static void put(Map<Integer, Integer> m, int[] mask, int base) {
        for (int t = 0; t < 3; t++) {
            m.put(mask[t], tone(base, t));
        }
    }

    /** Hard 3-tone shading: light, base, dark. */
    static int tone(int rgb, int t) {
        int r = (rgb >> 16) & 255;
        int g = (rgb >> 8) & 255;
        int b = rgb & 255;
        double k = t == 0 ? 1.22 : (t == 1 ? 1.0 : 0.66);
        int add = t == 0 ? 20 : 0;
        r = (int) Math.min(255, r * k + add);
        g = (int) Math.min(255, g * k + add);
        b = (int) Math.min(255, b * k + add);
        return (r << 16) | (g << 8) | b;
    }
}
