package arcshot.messenger;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JPanel;
import javax.swing.Timer;
import arcshot.ui.Theme;

/**
 * The game screen: game loop, input, scoring, and drawing.
 * Reskin (v2): colors and fonts now come from the shared {@link Theme}; game logic is unchanged.
 * OOP pillars: <b>INHERITANCE</b> (extends JPanel) and <b>POLYMORPHISM</b> (stores Ball/Hoop/Defender as GameObject and Collidable).
 */
public class GamePanel extends JPanel {
    public static final int WIDTH = 480;
    public static final int HEIGHT = 720;
    private static final int FLOOR_Y = 680;
    private static final double MAX_DRAG = 150;
    private static final double POWER = 0.15;
    private static final int GAME_SECONDS = 100;

    private enum State { PLAYING, GAME_OVER }

    private final Player player;
    private final Ball ball;
    private final Hoop hoop;
    private final Defender defender;
    private final List<GameObject> objects = new ArrayList<>();
    private final List<Collidable> obstacles = new ArrayList<>();
    private final Timer loop;
    private final Runnable onExit;
    private final java.awt.Rectangle playAgainBtn = new java.awt.Rectangle(140, 440, 200, 44);
    private final java.awt.Rectangle menuBtn = new java.awt.Rectangle(140, 500, 200, 44);

    private State state = State.PLAYING;
    private long startTime;
    private int bestScore;
    private boolean dragging;
    private int dragX;
    private int dragY;
    private int flightFrames;
    private int resetDelay = -1;
    private String popupText = "";
    private int popupFrames;

    public GamePanel(Player player, Runnable onExit) {
        this.player = player;
        this.onExit = onExit;
        setPreferredSize(new java.awt.Dimension(WIDTH, HEIGHT));
        ball = new Ball(WIDTH / 2.0, 600, WIDTH, FLOOR_Y);
        hoop = new Hoop(WIDTH / 2.0, 230, WIDTH, FLOOR_Y);
        defender = new Defender(WIDTH / 2.0, 400, WIDTH);

        // POLYMORPHISM: stored as superclass / interface references
        objects.add(hoop);
        objects.add(defender);
        objects.add(ball);
        obstacles.add(hoop);
        obstacles.add(defender);

        MouseAdapter mouse = new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (state == State.GAME_OVER) {
                    if (menuBtn.contains(e.getPoint())) {
                        exitToMenu();
                    } else if (playAgainBtn.contains(e.getPoint())) {
                        restart();
                    }
                } else if (!ball.isFlying()
                        && Math.hypot(e.getX() - ball.getX(), e.getY() - ball.getY()) < 70) {
                    dragging = true;
                    dragX = e.getX();
                    dragY = e.getY();
                }
            }

            @Override
            public void mouseDragged(MouseEvent e) {
                if (dragging) {
                    dragX = e.getX();
                    dragY = e.getY();
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                if (dragging) {
                    dragging = false;
                    shoot();
                }
            }
        };
        addMouseListener(mouse);
        addMouseMotionListener(mouse);

        startTime = System.nanoTime();
        loop = new Timer(16, e -> {
            tick();
            repaint();
        });
        loop.start();
    }

    /** Pull back from the ball: the launch velocity is the opposite of the drag. */
    private double[] dragVector() {
        double dx = dragX - ball.getX();
        double dy = dragY - ball.getY();
        double len = Math.hypot(dx, dy);
        if (len > MAX_DRAG) {
            dx = dx / len * MAX_DRAG;
            dy = dy / len * MAX_DRAG;
        }
        return new double[] { -dx * POWER, -dy * POWER };
    }

    private void shoot() {
        double[] v = dragVector();
        if (Math.hypot(v[0], v[1]) < 4) {
            return; // too weak, ignore
        }
        ball.launch(v[0], v[1]);
        flightFrames = 0;
        resetDelay = -1;
    }

    /** Added for the new menu: stops the Swing timer when the screen is closed from outside (Esc). */
    public void stop() {
        loop.stop();
    }

    private void exitToMenu() {
        loop.stop();
        onExit.run();
    }

    private void restart() {
        bestScore = Math.max(bestScore, player.getScore());
        player.resetStats();
        ball.reset();
        state = State.PLAYING;
        startTime = System.nanoTime();
        flightFrames = 0;
        resetDelay = -1;
        popupFrames = 0;
    }

    private double remainingSeconds() {
        double elapsed = (System.nanoTime() - startTime) / 1_000_000_000.0;
        return Math.max(0, GAME_SECONDS - elapsed);
    }

    private void tick() {
        if (state == State.GAME_OVER) {
            return;
        }
        if (remainingSeconds() <= 0 && !ball.isFlying()) {
            state = State.GAME_OVER;
            return;
        }

        updateDifficulty();
        for (GameObject obj : objects) {
            obj.update();
        }
        if (ball.isFlying()) {
            for (Collidable c : obstacles) {
                c.resolveCollision(ball);
            }
            checkScoring();
            flightFrames++;
            boolean shotOver = ball.isResting() || flightFrames > 100;
            if (resetDelay > 0) {
                resetDelay--;
            }
            if (resetDelay == 0 || (resetDelay < 0 && shotOver)) {
                finishShot();
            }
        }
        if (popupFrames > 0) {
            popupFrames--;
        }
    }

    private void updateDifficulty() {
        int score = player.getScore();
        hoop.setSpeed(score >= 6 ? Math.min(4, 1.5 + (score - 6) / 6.0) : 0);
        defender.setActive(score >= 14);
    }

    private void checkScoring() {
        if (hoop.isScoredBy(ball)) {
            ball.markScored();
            hoop.flash();
            boolean swish = !ball.isTouchedRim();
            int points = swish ? 3 : 2;
            player.addScore(points);
            popupText = swish ? "SWISH! +3" : "+2";
            popupFrames = 60;
            resetDelay = 30;
        }
    }

    private void finishShot() {
        player.recordShot(ball.isScored());
        ball.reset();
        resetDelay = -1;
        flightFrames = 0;
    }

    @Override
    protected void paintComponent(Graphics g0) {
        super.paintComponent(g0);
        Graphics2D g = (Graphics2D) g0;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        // keep pixel art crisp when scaled
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);

        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setPaint(new GradientPaint(0, 0, Theme.BG, 0, FLOOR_Y, Theme.PANEL_HI));
        g.fillRect(0, 0, WIDTH, HEIGHT);
        g.setColor(new Color(0xC98B4E));
        g.fillRect(0, FLOOR_Y, WIDTH, HEIGHT - FLOOR_Y);
        g.setColor(new Color(0xFFF6E8));
        g.fillRect(0, FLOOR_Y, WIDTH, 3);

        drawBigScore(g);
        drawShadow(g);
        for (GameObject obj : objects) {
            if (obj != ball) {
                obj.draw(g);
            }
        }
        // Rising from underneath: the ball is drawn ON TOP of the rim and net.
        // Dropping from above: it goes behind the front rim and net, so it looks like it falls in.
        boolean rising = ball.isFlying() && ball.getVy() < 0;
        if (rising) {
            hoop.drawFront(g);
            ball.draw(g);
        } else {
            ball.draw(g);
            hoop.drawFront(g);
        }
        if (dragging && !ball.isFlying()) {
            drawAimGuide(g);
        }

        drawHud(g);
        if (popupFrames > 0) {
            g.setFont(Theme.display(40));
            g.setColor(Theme.GOLD);
            int pw = g.getFontMetrics().stringWidth(popupText);
            g.drawString(popupText, WIDTH / 2 - pw / 2, 140 - (60 - popupFrames) / 2);
        }
        if (state == State.GAME_OVER) {
            drawGameOver(g);
        }
    }

    private void drawAimGuide(Graphics2D g) {
        double[] v = dragVector();
        double x = ball.getX();
        double y = ball.getY();
        double vx = v[0];
        double vy = v[1];
        g.setColor(Color.WHITE);
        for (int i = 0; i < 36; i++) {
            vy += Ball.getGravity();
            x += vx;
            y += vy;
            if (i % 3 == 0) {
                g.fillOval((int) x - 3, (int) y - 3, 6, 6);
            }
        }
        g.setColor(new Color(255, 255, 255, 120));
        g.setStroke(new BasicStroke(2f));
        g.drawLine((int) ball.getX(), (int) ball.getY(),
                (int) (ball.getX() - v[0] / POWER), (int) (ball.getY() - v[1] / POWER));
    }

    /** Big faded score in the middle of the scene, behind the ball. */
    private void drawBigScore(Graphics2D g) {
        String text = String.valueOf(player.getScore());
        g.setFont(Theme.display(150));
        int w = g.getFontMetrics().stringWidth(text);
        g.setColor(new Color(255, 255, 255, 40));
        g.drawString(text, (WIDTH - w) / 2, 430);
    }

    /** Court shadow under the ball: it shrinks and fades as the ball rises toward the hoop. */
    private void drawShadow(Graphics2D g) {
        double rise = (ball.getStartY() - ball.getY()) / (ball.getStartY() - hoop.getY());
        double h = Math.max(0, Math.min(1, rise));
        int w = (int) (80 * (1 - 0.55 * h));
        int ht = (int) (24 * (1 - 0.55 * h));
        int alpha = (int) (110 * (1 - 0.75 * h));
        g.setColor(new Color(60, 25, 10, alpha));
        g.fillOval((int) ball.getX() - w / 2, (int) ball.getStartY() + 40 - ht / 2, w, ht);
    }

    private void drawHud(Graphics2D g) {
        g.setColor(Theme.alpha(Theme.PANEL, 220));
        g.fillRoundRect(10, 10, WIDTH - 20, 58, 16, 16);
        g.setColor(Theme.BORDER);
        g.drawRoundRect(10, 10, WIDTH - 20, 58, 16, 16);
        g.setColor(Theme.TEXT_MUTED);
        g.setFont(Theme.semi(14));
        g.drawString(player.getName(), 24, 32);
        g.setColor(Theme.TEXT);
        g.setFont(Theme.display(26));
        g.drawString(String.valueOf(player.getScore()), 24, 60);
        String time = String.format("%02d", (int) Math.ceil(remainingSeconds()));
        g.setFont(Theme.display(30));
        int tw = g.getFontMetrics().stringWidth(time);
        g.setColor(remainingSeconds() <= 10 ? Theme.DANGER : Theme.ACCENT);
        g.drawString(time, (WIDTH - tw) / 2, 54);
        g.setFont(Theme.semi(14));
        g.setColor(Theme.TEXT_MUTED);
        String streak = "Streak " + player.getStreak();
        g.drawString(streak, WIDTH - 24 - g.getFontMetrics().stringWidth(streak), 32);
        String best = "Best " + Math.max(bestScore, player.getScore());
        g.drawString(best, WIDTH - 24 - g.getFontMetrics().stringWidth(best), 56);
        if (player.getScore() == 0 && !ball.isFlying()) {
            g.setFont(Theme.semi(15));
            g.setColor(Theme.TEXT);
            String hint = "Drag the ball back, then release to shoot!";
            g.drawString(hint, (WIDTH - g.getFontMetrics().stringWidth(hint)) / 2, FLOOR_Y + 28);
        }
    }

    private void drawGameOver(Graphics2D g) {
        g.setColor(new Color(5, 8, 16, 200));
        g.fillRect(0, 0, WIDTH, HEIGHT);
        g.setColor(Theme.PANEL);
        g.fillRoundRect(60, 170, WIDTH - 120, 400, 24, 24);
        g.setColor(Theme.BORDER);
        g.drawRoundRect(60, 170, WIDTH - 120, 400, 24, 24);
        g.setColor(Theme.ACCENT);
        g.setFont(Theme.display(48));
        centered(g, "TIME'S UP!", 232);
        g.setColor(Theme.TEXT);
        g.setFont(Theme.display(64));
        centered(g, String.valueOf(player.getScore()), 300);
        g.setFont(Theme.semi(17));
        g.setColor(Theme.TEXT_MUTED);
        centered(g, "Shots made " + player.getShotsMade() + " / " + player.getShotsTaken()
                + "   |   Accuracy " + player.getAccuracyPercent() + "%", 340);
        centered(g, "Best streak " + player.getBestStreak(), 366);
        g.setColor(Theme.GOLD);
        centered(g, "Best score this session: " + Math.max(bestScore, player.getScore()), 404);
        drawButton(g, playAgainBtn, "Play Again");
        drawButton(g, menuBtn, "Back to Menu");
    }

    private void drawButton(Graphics2D g, java.awt.Rectangle r, String text) {
        boolean primary = r == playAgainBtn;
        g.setColor(new Color(0, 0, 0, 70));
        g.fillRoundRect(r.x, r.y + 4, r.width, r.height, 20, 20);
        g.setColor(primary ? Theme.ACCENT : Theme.PANEL_HI);
        g.fillRoundRect(r.x, r.y, r.width, r.height, 20, 20);
        if (!primary) {
            g.setColor(Theme.BORDER);
            g.drawRoundRect(r.x, r.y, r.width, r.height, 20, 20);
        }
        g.setColor(Color.WHITE);
        g.setFont(Theme.semi(18));
        int tw = g.getFontMetrics().stringWidth(text);
        g.drawString(text, r.x + (r.width - tw) / 2, r.y + 29);
    }

    private void centered(Graphics2D g, String text, int y) {
        g.drawString(text, (WIDTH - g.getFontMetrics().stringWidth(text)) / 2, y);
    }
}
