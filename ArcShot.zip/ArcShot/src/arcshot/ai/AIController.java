package arcshot.ai;

import arcshot.ability.Ability;
import arcshot.ability.AbilitySlot;
import arcshot.control.PlayerController;
import arcshot.control.PlayerInput;
import arcshot.court.Ball;
import arcshot.court.Court;
import arcshot.court.CourtEntity;
import arcshot.court.Match;
import arcshot.effect.Reach;
import arcshot.player.Player;
import arcshot.player.PlayerClass;
import java.util.List;
import java.util.Random;

/**
 * Computer control as a finite state machine. Every frame it picks a {@link State} from the situation and acts on it;
 * role-specific choices come from an {@link AIStrategy}, and the {@link Difficulty} scales reaction time and decision
 * quality.
 * <p>
 * OOP pillars: <b>POLYMORPHISM</b> (another {@link PlayerController}, used exactly like the keyboard) and
 * <b>ENCAPSULATION</b> (all decision memory is private).
 */
public final class AIController implements PlayerController {

    /** The states of the machine. */
    public enum State { ATTACK, SUPPORT, GUARD_BALL, GUARD_MAN, CHASE_BALL, CRASH, IDLE }

    private final AIStrategy strategy;
    private final Difficulty difficulty;
    private final Random rng = new Random();

    private State state = State.IDLE;
    private double thinkTimer;
    private double[] target;
    private double holdTarget = -1;
    private double possessionTime;
    private double abilityTimer;
    private double stealTimer;
    private double shotSeenTime;
    private boolean jumpDecided;
    private CourtEntity chasedDecoy;
    private Player lastHolder;
    private double ftWait;

    public AIController(PlayerClass pc, Difficulty difficulty) {
        this.strategy = AIStrategy.forClass(pc);
        this.difficulty = difficulty;
    }

    public State getState() { return state; }

    @Override
    public boolean isHuman() { return false; }

    @Override
    public void fillInput(Player self, Match match, PlayerInput out, double dt) {
        out.clear();
        if (match.isFreeThrow()) {
            freeThrow(self, match, out, dt);
            return;
        }
        if (!match.isLive() || !self.canAct()) {
            return;
        }
        thinkTimer -= dt;
        abilityTimer -= dt;
        stealTimer -= dt;
        state = decideState(self, match);
        switch (state) {
            case ATTACK: attack(self, match, out, dt); break;
            case SUPPORT: support(self, match, out); break;
            case GUARD_BALL: guardBall(self, match, out, dt); break;
            case GUARD_MAN: guardMan(self, match, out); break;
            case CHASE_BALL: chase(self, match, out); break;
            case CRASH: crash(self, match, out); break;
            default: break;
        }
        maybeUseAbility(self, match, out);
    }

    // ---- state selection ------------------------------------------------------------------------------------

    private State decideState(Player self, Match match) {
        Ball ball = match.getBall();
        Ball.State bs = ball.getState();
        if (bs == Ball.State.HELD) {
            Player holder = ball.getHolder();
            if (holder != lastHolder) {
                lastHolder = holder;
                possessionTime = 0;
                holdTarget = -1;
            }
            if (holder == self) {
                return State.ATTACK;
            }
            if (holder.getSide() == self.getSide()) {
                return State.SUPPORT;
            }
            return match.getMatchup(self) == holder ? State.GUARD_BALL : State.GUARD_MAN;
        }
        if (bs == Ball.State.LOOSE) {
            return isClosestOnTeam(self, match, ball) || strategy.crashesBoards() ? State.CHASE_BALL : State.GUARD_MAN;
        }
        if (bs == Ball.State.SHOT) {
            return strategy.crashesBoards() || self.getSide() != match.getOffense() ? State.CRASH : State.SUPPORT;
        }
        if (bs == Ball.State.PASS) {
            return self.getSide() == match.getOffense() ? State.SUPPORT : State.GUARD_MAN;
        }
        return State.IDLE;
    }

    private boolean isClosestOnTeam(Player self, Match match, Ball ball) {
        double mine = self.distanceTo(ball.getX(), ball.getY());
        for (Player mate : match.teammatesOf(self)) {
            if (mate.distanceTo(ball.getX(), ball.getY()) < mine) {
                return false;
            }
        }
        return true;
    }

    // ---- states ---------------------------------------------------------------------------------------------

    private void attack(Player self, Match match, PlayerInput out, double dt) {
        possessionTime += dt;
        if (self.isChargingShot()) {
            out.setShootHeld(self.getShotHold() < holdTarget);
            return;
        }
        Court court = match.getCourt();
        if (match.needsClear()) {
            moveTo(self, court.nearestClearSpot(self.getX(), self.getY()), out, true);
            return;
        }
        if (thinkTimer <= 0) {
            thinkTimer = difficulty.reaction();
            double chance = match.estimateMakeChance(self);
            double value = chance * (court.isOutsideArc(self) ? 2 : 1);
            double threshold = strategy.shotValueThreshold() * difficulty.shotSelection()
                    - Math.max(0, possessionTime - 4) * 0.08;
            boolean urgent = match.getShotClock() < 2.5 && !match.isPractice();
            if (self.canShoot() && (value >= threshold || urgent)) {
                startShot(self, match, out);
                return;
            }
            Player open = betterOption(self, match, value);
            if (open != null && possessionTime > 0.7 && rng.nextDouble() < difficulty.passIq()) {
                out.setMove(open.getX() - self.getX(), open.getY() - self.getY());
                out.setPassPressed(true);
                return;
            }
            target = strategy.driveTarget(self, match);
        }
        if (target != null) {
            moveTo(self, target, out, self.getStamina() > 45);
        }
    }

    private void startShot(Player self, Match match, PlayerInput out) {
        double center = (match.getGreenStart() + match.getGreenEnd()) / 2;
        double error = rng.nextGaussian() * difficulty.timingError();
        holdTarget = Math.max(0.05, (center + error) * match.getMeterTime(self));
        out.setShootHeld(true);
    }

    /** A teammate whose shot looks clearly better than ours, or null. */
    private Player betterOption(Player self, Match match, double myValue) {
        Player best = null;
        double bestValue = myValue + 0.12;
        for (Player mate : match.teammatesOf(self)) {
            double open = match.openness(mate);
            double value = match.estimateMakeChance(mate) * (match.getCourt().isOutsideArc(mate) ? 2 : 1)
                    + Math.min(0.3, open / 400);
            if (value > bestValue && open > 60) {
                bestValue = value;
                best = mate;
            }
        }
        return best;
    }

    private void support(Player self, Match match, PlayerInput out) {
        Ball ball = match.getBall();
        if (ball.getState() == Ball.State.PASS && ball.getReceiver() == self) {
            return; // wait for the catch
        }
        if (thinkTimer <= 0 || target == null) {
            thinkTimer = difficulty.reaction() * 2;
            target = strategy.supportSpot(self, match);
        }
        moveTo(self, target, out, false);
    }

    private void guardBall(Player self, Match match, PlayerInput out, double dt) {
        Player holder = match.getBall().getHolder();
        Court court = match.getCourt();
        double gap = 34 + (1 - difficulty.blockChance()) * 20;
        moveTo(self, between(holder, court, gap), out, self.distanceTo(holder) > 120);
        double dist = self.distanceTo(holder);
        arcshot.action.ActionType ht = holder.getActions().getType();
        boolean finishing = ht == arcshot.action.ActionType.LAYUP || ht == arcshot.action.ActionType.DUNK;
        if (finishing) {
            shotSeenTime += dt;
            if (!jumpDecided && shotSeenTime >= difficulty.reaction() * 0.4) {
                jumpDecided = true;
                if (dist < self.getReach(Reach.BLOCK) * 1.6 && rng.nextDouble() < difficulty.blockChance()) {
                    out.setShootHeld(true);
                }
            }
        } else if (holder.isChargingShot()) {
            shotSeenTime += dt;
            double meter = holder.getShotHold() / match.getMeterTime(holder);
            // time the jump for the release: the higher the difficulty, the closer to the real release point
            if (!jumpDecided && shotSeenTime >= difficulty.reaction() * 0.5 && meter >= 0.84 - difficulty.reaction() * 0.3) {
                jumpDecided = true;
                if (dist < self.getReach(Reach.BLOCK) * 1.4 && rng.nextDouble() < difficulty.blockChance()) {
                    out.setShootHeld(true);
                }
            }
        } else {
            shotSeenTime = 0;
            jumpDecided = false;
            if (dist < self.getReach(Reach.STEAL) && stealTimer <= 0) {
                stealTimer = 1.0 / Math.max(0.05, difficulty.stealRate());
                if (rng.nextDouble() < 0.5) {
                    out.setPassPressed(true);
                }
            }
        }
    }

    private void guardMan(Player self, Match match, PlayerInput out) {
        Player man = match.getMatchup(self);
        double mx = man.getX();
        double my = man.getY();
        List<CourtEntity> decoys = match.getDecoysOf(man);
        if (decoys.isEmpty()) {
            chasedDecoy = null;
        } else {
            if (chasedDecoy == null || !decoys.contains(chasedDecoy)) {
                chasedDecoy = rng.nextDouble() < 0.7 ? decoys.get(rng.nextInt(decoys.size())) : null;
            }
            if (chasedDecoy != null) {
                mx = chasedDecoy.getX();
                my = chasedDecoy.getY();
            }
        }
        Court court = match.getCourt();
        Ball ball = match.getBall();
        double hx = court.getHoopX() - mx;
        double hy = court.getHoopY() - my;
        double len = Math.max(1, Math.hypot(hx, hy));
        double sag = 55 + Math.min(60, Math.hypot(ball.getX() - mx, ball.getY() - my) * 0.12);
        double tx = mx + hx / len * sag + (ball.getX() - mx) * 0.1;
        double ty = my + hy / len * sag + (ball.getY() - my) * 0.1;
        moveTo(self, new double[] {tx, ty}, out, Math.hypot(tx - self.getX(), ty - self.getY()) > 150);
    }

    private void chase(Player self, Match match, PlayerInput out) {
        Ball ball = match.getBall();
        moveTo(self, new double[] {ball.getX(), ball.getY()}, out, true);
        // jump for a high rebound when it is close (same action a human gets with Space)
        if (self.distanceTo(ball.getX(), ball.getY()) < 70 && ball.getZ() > 40 && ball.canBeGrabbed()) {
            out.setShootHeld(true);
        }
    }

    /** Free throws: wait a moment at the line, then hold SHOOT like a human until the arc arrow reaches the rim. */
    private void freeThrow(Player self, Match match, PlayerInput out, double dt) {
        if (match.getBall().getHolder() != self) {
            ftWait = 0;
            return;
        }
        if (self.isChargingShot()) {
            out.setShootHeld(self.getShotHold() < holdTarget);
            return;
        }
        ftWait += dt;
        if (ftWait > 0.9) {
            // aim for power 1.0 on the free-throw arc (tip on the rim), with the same difficulty-based error
            double error = rng.nextGaussian() * difficulty.timingError() * 0.8;
            holdTarget = Math.max(0.05, (1.0 + error) * match.getFreeThrowMeterTime());
            out.setShootHeld(true);
            ftWait = 0;
        }
    }

    private void crash(Player self, Match match, PlayerInput out) {
        Court court = match.getCourt();
        double side = self.getX() < court.getHoopX() ? -1 : 1;
        moveTo(self, new double[] {court.getHoopX() + side * 45, court.getHoopY() + 70}, out, false);
    }

    // ---- helpers --------------------------------------------------------------------------------------------

    private double[] between(Player man, Court court, double gap) {
        double hx = court.getHoopX() - man.getX();
        double hy = court.getHoopY() - man.getY();
        double len = Math.max(1, Math.hypot(hx, hy));
        return new double[] {man.getX() + hx / len * gap, man.getY() + hy / len * gap};
    }

    private void moveTo(Player self, double[] t, PlayerInput out, boolean sprint) {
        double dx = t[0] - self.getX();
        double dy = t[1] - self.getY();
        double dist = Math.hypot(dx, dy);
        if (dist < 8) {
            out.setMove(0, 0);
            return;
        }
        double scale = dist < 40 ? dist / 40 : 1;
        out.setMove(dx / dist * scale, dy / dist * scale);
        out.setSprint(sprint && dist > 60 && self.getStamina() > 25);
    }

    private void maybeUseAbility(Player self, Match match, PlayerInput out) {
        if (abilityTimer > 0) {
            return;
        }
        abilityTimer = 0.5;
        AbilitySlot[] order = {AbilitySlot.R, AbilitySlot.Q, AbilitySlot.E};
        for (AbilitySlot slot : order) {
            Ability a = self.getAbility(slot);
            if (a != null && a.canUse(self, match) && a.aiShouldUse(self, match)
                    && rng.nextDouble() < difficulty.abilityRate()) {
                if (slot == AbilitySlot.Q) {
                    out.setQPressed(true);
                } else if (slot == AbilitySlot.E) {
                    out.setEPressed(true);
                } else {
                    out.setRPressed(true);
                }
                return;
            }
        }
    }
}
