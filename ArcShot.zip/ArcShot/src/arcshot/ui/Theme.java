package arcshot.ui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.RenderingHints;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import javax.swing.UIManager;
import javax.swing.plaf.ColorUIResource;

/**
 * The shared design system: one color palette, one spacing scale, two font families and shared painting helpers.
 * The menu, the Messenger game and the 3x3 mode all draw with these values, so the whole app looks consistent.
 * <p>
 * OOP pillar: <b>ENCAPSULATION</b> + <b>ABSTRACTION</b>. Screens ask for {@code Theme.display(32)} or
 * {@code Theme.ACCENT}; they never hardcode fonts or RGB values, and never know how fonts are loaded.
 */
public final class Theme {
    // ---- palette --------------------------------------------------------------------------------------------
    public static final Color BG = new Color(0x0D1220);
    public static final Color BG_2 = new Color(0x141B30);
    public static final Color PANEL = new Color(0x1A2240);
    public static final Color PANEL_HI = new Color(0x253055);
    public static final Color BORDER = new Color(0x34406A);
    public static final Color ACCENT = new Color(0xFF7A1A);
    public static final Color ACCENT_HI = new Color(0xFF9A4D);
    public static final Color ACCENT_2 = new Color(0x2EC4FF);
    public static final Color TEXT = new Color(0xF2F4FA);
    public static final Color TEXT_MUTED = new Color(0x8E98B8);
    public static final Color SUCCESS = new Color(0x3DDC84);
    public static final Color DANGER = new Color(0xFF4D5E);
    public static final Color GOLD = new Color(0xFFC83D);
    public static final Color LOCKED = new Color(0x4A5274);
    /** Default team colors (home = you). */
    public static final Color HOME = new Color(0xFF7A1A);
    public static final Color AWAY = new Color(0x3A7BFF);

    // ---- spacing scale (use these instead of random numbers) ------------------------------------------------
    public static final int S1 = 4;
    public static final int S2 = 8;
    public static final int S3 = 12;
    public static final int S4 = 16;
    public static final int S5 = 24;
    public static final int S6 = 32;
    public static final int S7 = 48;
    public static final int RADIUS = 18;
    public static final int RADIUS_SM = 10;

    /** Logical game resolution; game canvases are scaled to fit the window with letterboxing. */
    public static final int LOGICAL_W = 1280;
    public static final int LOGICAL_H = 720;

    // ---- fonts ------------------------------------------------------------------------------------------------
    private static final Font DISPLAY_BASE = loadFont("/fonts/Anton-Regular.ttf", new Font("SansSerif", Font.BOLD, 12));
    private static final Font BODY_BASE = loadFont("/fonts/FiraSans-Regular.ttf", new Font("SansSerif", Font.PLAIN, 12));
    private static final Font SEMI_BASE = loadFont("/fonts/FiraSans-SemiBold.ttf", new Font("SansSerif", Font.BOLD, 12));
    private static final Font BOLD_BASE = loadFont("/fonts/FiraSans-Bold.ttf", new Font("SansSerif", Font.BOLD, 12));
    private static final Map<String, Font> FONT_CACHE = new HashMap<>();

    private Theme() { }

    /** Tall condensed headline font (titles, scoreboard). */
    public static Font display(float size) { return cached("d", DISPLAY_BASE, size); }

    /** Regular body text. */
    public static Font body(float size) { return cached("r", BODY_BASE, size); }

    /** Semi-bold body text (buttons, labels). */
    public static Font semi(float size) { return cached("s", SEMI_BASE, size); }

    /** Bold body text. */
    public static Font bold(float size) { return cached("b", BOLD_BASE, size); }

    private static synchronized Font cached(String family, Font base, float size) {
        String key = family + size;
        Font font = FONT_CACHE.get(key);
        if (font == null) {
            font = base.deriveFont(size);
            FONT_CACHE.put(key, font);
        }
        return font;
    }

    /** Loads a bundled TTF with {@code Font.createFont}; falls back to a built-in font if anything goes wrong. */
    private static Font loadFont(String path, Font fallback) {
        try (InputStream in = Theme.class.getResourceAsStream(path)) {
            if (in == null) {
                return fallback;
            }
            Font font = Font.createFont(Font.TRUETYPE_FONT, in);
            GraphicsEnvironment.getLocalGraphicsEnvironment().registerFont(font);
            return font;
        } catch (IOException | FontFormatException | RuntimeException ex) {
            return fallback;
        }
    }

    // ---- painting helpers -----------------------------------------------------------------------------------

    /** Turns on anti-aliasing for shapes and text. Call at the start of every custom paint method. */
    public static void quality(Graphics2D g) {
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
    }

    public static Color alpha(Color c, int alpha) {
        return new Color(c.getRed(), c.getGreen(), c.getBlue(), Math.max(0, Math.min(255, alpha)));
    }

    /** Linear mix between two colors (t = 0 gives a, t = 1 gives b). */
    public static Color mix(Color a, Color b, double t) {
        double k = Math.max(0, Math.min(1, t));
        return new Color(
                (int) (a.getRed() + (b.getRed() - a.getRed()) * k),
                (int) (a.getGreen() + (b.getGreen() - a.getGreen()) * k),
                (int) (a.getBlue() + (b.getBlue() - a.getBlue()) * k),
                (int) (a.getAlpha() + (b.getAlpha() - a.getAlpha()) * k));
    }

    /** The shared screen background: a dark gradient with faint court lines. */
    public static void paintBackground(Graphics2D g, int w, int h) {
        g.setPaint(new GradientPaint(0, 0, BG_2, 0, h, BG));
        g.fillRect(0, 0, w, h);
        g.setColor(alpha(ACCENT, 14));
        g.setStroke(new BasicStroke(3f));
        int r = Math.max(w, h) / 2;
        g.drawOval(w / 2 - r, h - r / 3, r * 2, r * 2);
        g.drawOval(w / 2 - r / 3, h - r / 6, r * 2 / 3, r * 2 / 3);
        g.drawLine(0, h - r / 3 + r, w, h - r / 3 + r);
    }

    /** Draws a string centered in a box. */
    public static void drawCentered(Graphics2D g, String text, int cx, int cy) {
        java.awt.FontMetrics fm = g.getFontMetrics();
        g.drawString(text, cx - fm.stringWidth(text) / 2, cy + (fm.getAscent() - fm.getDescent()) / 2);
    }

    /** Parses "#RRGGBB" with a fallback. */
    public static Color parse(String hex, Color fallback) {
        if (hex == null) {
            return fallback;
        }
        try {
            return new Color(Integer.parseInt(hex.trim().replace("#", ""), 16));
        } catch (NumberFormatException ex) {
            return fallback;
        }
    }

    /** Applies the palette to the few standard Swing parts we still use (tooltips, dialogs, scroll panes). */
    public static void installSwingDefaults() {
        UIManager.put("ToolTip.background", new ColorUIResource(PANEL_HI));
        UIManager.put("ToolTip.foreground", new ColorUIResource(TEXT));
        UIManager.put("ToolTip.font", body(14));
        UIManager.put("ToolTip.border", javax.swing.BorderFactory.createLineBorder(BORDER));
        UIManager.put("OptionPane.background", new ColorUIResource(PANEL));
        UIManager.put("Panel.background", new ColorUIResource(PANEL));
        UIManager.put("OptionPane.messageForeground", new ColorUIResource(TEXT));
        UIManager.put("OptionPane.messageFont", body(15));
        UIManager.put("OptionPane.buttonFont", semi(14));
        UIManager.put("Button.background", new ColorUIResource(PANEL_HI));
        UIManager.put("Button.foreground", new ColorUIResource(TEXT));
        UIManager.put("ScrollPane.background", new ColorUIResource(BG));
        UIManager.put("Viewport.background", new ColorUIResource(BG));
        UIManager.put("TextField.background", new ColorUIResource(BG_2));
        UIManager.put("TextField.foreground", new ColorUIResource(TEXT));
        UIManager.put("TextField.caretForeground", new ColorUIResource(ACCENT));
    }
}
