package arcshot.court;

import arcshot.core.Balance;

/**
 * The ONE place for court measurements that rules, AI and the renderer all read. It extends the existing
 * {@link Court} (arc, paint, hoop, bounds) with the free-throw line, the 3x3 free-throw lineup, the backboard,
 * the stanchion, referee spots and the finishing zone, so art and physics always agree.
 * OOP pillar: <b>INHERITANCE</b> (extends Court; existing code keeps working) and <b>ENCAPSULATION</b>.
 */
public class CourtGeometry extends Court {
    /** Height of the backboard's bottom and top edges (z, world px). */
    public static final double BOARD_BOTTOM_Z = 2.9 * PX_PER_M;
    public static final double BOARD_TOP_Z = 3.95 * PX_PER_M;
    public static final double BOARD_HALF_WIDTH = 0.9 * PX_PER_M;
    public static final double RIM_RADIUS = 0.23 * PX_PER_M;

    /** Free-throw line distance from the baseline (5.8 m, same as the paint depth). */
    public double getFreeThrowY() { return getTop() + getPaintDepth(); }

    /** Where the free-throw shooter stands. */
    public double[] freeThrowSpot() { return new double[] {getHoopX(), getFreeThrowY() + 8}; }

    /** 3x3 lineup: everyone else waits behind the shooter, beyond the arc (index 0..4). */
    public double[] freeThrowLineup(int index) {
        double[] xs = {-120, 120, -60, 60, 0};
        double y = getHoopY() + getArcRadius() + 30 + (index >= 4 ? 30 : 0);
        return new double[] {getHoopX() + xs[index % 5], Math.min(getBottom() - 20, y)};
    }

    /** Where the defense takes the ball after a made basket (directly under the hoop). */
    public double[] underBasketSpot() { return new double[] {getHoopX() + 18, getHoopY() + 26}; }

    /** Floor y of the backboard (1.2 m in from the baseline). */
    public double getBoardY() { return getTop() + 1.2 * PX_PER_M; }

    /** Floor point of the stanchion base, behind the baseline. */
    public double[] stanchionBase() { return new double[] {getHoopX(), getTop() - 34}; }

    /** Shoot inside this distance from the hoop = layup or dunk instead of a jump shot. */
    public double getFinishRange() { return Balance.d("finish.range", 118); }

    /** Where a dunker's feet end up (just in front of the rim, on the approach side). */
    public double[] dunkSpot(double fromX) {
        double side = fromX >= getHoopX() ? 1 : -1;
        return new double[] {getHoopX() + side * 8, getHoopY() + 16};
    }

    /** Where a layup is released (a little in front of / beside the rim). */
    public double[] layupSpot(double fromX, double fromY) {
        double dx = fromX - getHoopX();
        double dy = Math.max(10, fromY - getHoopY());
        double len = Math.hypot(dx, dy);
        return new double[] {getHoopX() + dx / len * 30, getHoopY() + dy / len * 30};
    }

    /** Referee home spots: LEAD under the baseline, TRAIL on the right sideline. */
    public double[] leadRefSpot() { return new double[] {getHoopX() - 150, getTop() - 16}; }

    public double[] trailRefSpot() { return new double[] {getRight() + 18, getHoopY() + getArcRadius()}; }
}
