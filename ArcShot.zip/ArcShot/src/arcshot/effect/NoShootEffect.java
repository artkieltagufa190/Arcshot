package arcshot.effect;

/**
 * Time Stop drawback: the caster can move and pass but NOT shoot.
 * OOP pillars: <b>INHERITANCE</b> (extends StatusEffect) and <b>POLYMORPHISM</b> (overrides only the modifiers it changes).
 */
public class NoShootEffect extends StatusEffect {
    public NoShootEffect(double duration) {
        super("no_shoot", duration, false);
    }

    @Override
    public boolean preventsShooting() { return true; }

    @Override
    public String getLabel() { return "NO SHOT"; }
}
