package arcshot.ai;

/**
 * Big: sets up in the low post and crashes the glass.
 * OOP pillars: <b>INHERITANCE</b> (extends AIStrategy) and <b>POLYMORPHISM</b> (overrides the role choices).
 */
public class BigStrategy extends AIStrategy {
    @Override
    protected double[] preferredSpot(boolean leftSide) {
        return new double[] {leftSide ? -40 : 40, 115};
    }

    @Override
    public double shotValueThreshold() { return 0.68; }

    @Override
    public boolean crashesBoards() { return true; }
}
