package arcshot.effect;

/**
 * Faster movement, optionally harder to steal from (Slipstream).
 * OOP pillars: <b>INHERITANCE</b> (extends StatusEffect) and <b>POLYMORPHISM</b> (overrides only the modifiers it changes).
 */
public class SpeedBoostEffect extends StatusEffect {
    private final double factor;
    private final boolean stealResistant;

    public SpeedBoostEffect(String id, double duration, double factor, boolean stealResistant) {
        super(id, duration, false);
        this.factor = factor;
        this.stealResistant = stealResistant;
    }

    @Override
    public double speedMultiplier() { return factor; }

    @Override
    public boolean isStealResistant() { return stealResistant; }
}
