package arcshot.action;

import java.util.HashMap;
import java.util.Map;

/**
 * Which cast animation each ability uses ("one per ability family"). Movement abilities have none: their
 * {@link DashAction} is the animation. Unknown ids get the generic power-up pose.
 */
public final class CastFamilies {
    private static final Map<String, String> MAP = new HashMap<>();

    static {
        for (String id : new String[] {"guard.shadow_step", "guard.crossover_snap", "forward.rising_fang",
            "forward.bull_rush", "forward.final_burst", "forward.meteor_crash", "big.boulder_toss"}) {
            MAP.put(id, null);
        }
        for (String id : new String[] {"big.quake_fist", "big.tremor_stomp", "forward.tiger_claw"}) {
            MAP.put(id, "cast_strike");
        }
    }

    private CastFamilies() { }

    /** Cast animation name, or null if the ability has its own movement. */
    public static String animationFor(String abilityId) {
        return MAP.containsKey(abilityId) ? MAP.get(abilityId) : "cast";
    }
}
