package arcshot.reward;

import arcshot.ability.AbilityInfo;
import arcshot.ability.AbilityRegistry;
import arcshot.save.Profile;
import arcshot.ui.ThemeSkin;

/**
 * Unlocks an alternate ability for the loadout screen.
 * OOP pillar: <b>POLYMORPHISM</b> - implements Reward; the manager just calls grant().
 */
public final class AbilityUnlock implements Reward {
    private final String abilityId;

    public AbilityUnlock(String abilityId) {
        this.abilityId = abilityId;
    }

    @Override
    public void grant(Profile profile) {
        profile.unlock(Profile.ABILITY + abilityId);
    }

    @Override
    public String describe(ThemeSkin skin) {
        AbilityInfo info = AbilityRegistry.get(abilityId);
        String where = info == null ? "" : " (" + info.getPlayerClass().getDisplayName() + " " + info.getSlot() + ")";
        return "Ability: " + skin.abilityName(abilityId) + where;
    }

    @Override
    public boolean provides(String unlockKey) {
        return (Profile.ABILITY + abilityId).equals(unlockKey);
    }
}
