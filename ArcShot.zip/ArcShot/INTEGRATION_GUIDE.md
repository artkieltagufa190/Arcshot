# Integration guide - v3 upgrade pass (retro look, actions, layups/dunks, referees, FIBA 3x3 fouls)

This guide turns the **v2 project** into **v3** step by step. Every change is one of three kinds:

* **NEW FILE**: copy the complete file from the delivered project (same folder). Nothing in your existing code changes.
* **SMALL EDIT**: a guided step with *Where* (a line you can search for), *Add / Replace / Delete*, the exact code, *Why* and *Check*.
* **LARGE EDIT**: replace the whole file with the delivered one (only for structural rewrites).

If you did not change anything since v2, you can also simply take the delivered project as it is. The steps below are
how the same result is reached by hand, so the team can review and defend every change. Steps are ordered so the
project **compiles at every COMPILE CHECKPOINT**.

Summary of what is touched:

| Kind | Files |
|---|---|
| NEW | 51 Java files (`action/`, `anim/`, `referee/`, `rules/`, `render/retro/`, `render/sprite/`, `test/`, 6 in `court/` + `render/MatchView`), `tools/SpriteSheetGenerator.java`, `resources/sprites/**`, `docs/*`, `CHANGELOG.md`, this guide |
| LARGE | `court/Match.java`, `court/Ball.java`, `court/ShotAttempt.java`, `player/Player.java`, `ui/components/GameCanvas.java`, `ui/screens/MatchScreen.java`, `build.sh`, `build.bat` |
| SMALL | `Court`, `Balance`, `GameEventType`, `MatchConfig`, `PlayerStats`, `Settings`, `SoundManager`, `AIController`, `QuakeFist`, `HudRenderer`, `MatchRenderer`, `SettingsScreen`, `ClassSelectScreen`, `ResultsScreen`, `AchievementCatalog`, `HowToPlayScreen`, `balance.properties`, `README.md`, `OOP_MAPPING.md`, `TEST_CHECKLIST.md`, `resources/sprites/README.md` |
| Untouched | the Messenger mode (`messenger/`), menu, every ability except one line in `QuakeFist`, effects, perks, achievements engine, saves format (new settings keys are optional, old saves load with defaults) |

**Renamed / changed public signatures (call sites):** only one. `Match.getPhase()` now returns `court.MatchPhase` instead of the
old nested `Match.Phase` (the old enum still exists inside `Match` for reference). The only call site outside `Match` is
`HudRenderer.drawDebug()`, which just prints it (`"Phase: " + m.getPhase()`), so it needs no change.
**No ability was rewritten:** `Player.startDash(...)`, `startJump(...)` and `cancelDash()` keep their signatures and now *request*
actions from the `ActionController`, so Shadow Step, Rising Fang, Bull Rush, Final Burst etc. are re-routed automatically.

About the phase letters: the brief's phases D, E and F (actions, finishing, referees/fouls) all meet in the new `Match.java`,
so they are integrated together as **phase D-F** with one compile checkpoint at the end. Do that phase in one sitting.


## Phase A - Study, audit, visual spec (no code)
Nothing to paste. Read `docs/VISUAL_SPEC.md` (camera, palette, sprites, court, HUD) and `docs/MECHANICS_MATRIX.md` (update order, priorities, every overlap). Agree on them as a team.

## Phase B - Foundation: court geometry, phases, rules model, settings fields

> **Before this phase:** commit (`git add -A && git commit -m "before phase B: foundation"`) or copy the project folder, so you can roll back.


### STEP 1 - NEW FILES (phase B)

Copy each file **complete** from the delivered project into the same folder in your repo (they are full files with package line, imports and Javadoc):

| File (folder = package) | What it is |
|---|---|
| `src/arcshot/rules/FoulFrequency.java` | Off / Low / Normal / High multiplier |
| `src/arcshot/rules/RulesConfig.java` | every 3x3 rule number, read from balance.properties |
| `src/arcshot/rules/FoulContext.java` | shot made? / outside? for a foul |
| `src/arcshot/rules/FoulOutcome.java` | free throws, shooter, possession, check ball, turnover |
| `src/arcshot/rules/Foul.java` | abstract foul, TEMPLATE METHOD resolve() with the team-foul bonus rules |
| `src/arcshot/rules/ShootingFoul.java` | 1 inside / 2 outside / and-one |
| `src/arcshot/rules/PersonalFoul.java` | non-shooting foul (reach-in, blocking...) |
| `src/arcshot/rules/OffensiveFoul.java` | charge: turnover, never free throws |
| `src/arcshot/rules/TechnicalFoul.java` | 1 FT |
| `src/arcshot/rules/UnsportsmanlikeFoul.java` | 2 FT, counts as 2 team fouls |
| `src/arcshot/rules/RuleEngine.java` | counts team fouls, returns the FoulOutcome |
| `src/arcshot/rules/FreeThrowSequence.java` | state of one free-throw trip |
| `src/arcshot/court/CourtBody.java` | interface: anything on the court with x / y / z |
| `src/arcshot/court/CourtGeometry.java` | extends Court: backboard, FT spots, dunk/layup spots, referee spots |
| `src/arcshot/court/MatchPhase.java` | CHECK_BALL, LIVE, SHOT_IN_AIR, DEAD_BALL, FOUL_CALLED, FREE_THROW, OVERTIME_BREAK, PAUSED, GAME_OVER |
| `src/arcshot/court/PhaseMachine.java` | allowed-transition table, counts illegal changes |
| `src/arcshot/court/Interaction.java` | same-frame events with a fixed priority order |
| `src/arcshot/court/FreeThrowAim.java` | the 2K-style free-throw arc aim (power + sway) and its grading |

Why:   the rules, phases and court geometry are plain classes that do not depend on the new Match yet, so they compile against v2.


### STEP 2 - Edit Court.java

```
Where: the class line `public final class Court {`
Replace with:
```
```java
public class Court {
```
Why:   `CourtGeometry` extends `Court` (one source of truth for measurements); `final` would forbid that.  
Check: compiles; nothing visible changes.


### STEP 3 - Edit Balance.java

```
Where: directly above the line `/** Where the current values came from (shown in the debug overlay). */`
Add:
```
```java
    /** A text value, or {@code def}. */
    public static String s(String key, String def) {
        String value = props.getProperty(key);
        return value == null ? def : value.trim();
    }
```
Why:   `RulesConfig` reads the list of foulable abilities as text.  
Check: compiles.


### STEP 4 - Edit GameEventType.java

```
Where: directly below the line `    MATCH_STARTED,`
Add:
```
```java
    /** A made layup (also sends BASKET_MADE). */
    LAYUP,
    /** A foul was called. Source = the fouled player; payload = the Foul. */
    FOUL_DRAWN,
    /** A foul was called. Source = the player who fouled; payload = the Foul. */
    FOUL_COMMITTED,
    FREE_THROW_MADE,
    FREE_THROW_MISSED,
    /** A made basket on which the shooter was fouled. */
    AND_ONE,
    /** Sound-effect hook: payload = sound name (sneaker, dribble, rim, backboard, whistle, crowd ...). */
    SOUND,
```
Why:   new events for achievements, the HUD ticker and sound hooks (the brief's DUNK/LAYUP/FOUL_DRAWN/FREE_THROW_MADE/AND_ONE/BLOCK; DUNK and BLOCK already existed).  
Check: compiles; the achievement manager ignores events nobody listens to.


### STEP 5 - Edit MatchConfig.java (1/2)

```
Where: directly below the line `    private boolean autoSwitch = true;`
Add:
```
```java
    private double gameSeconds = arcshot.core.Balance.d("rules.gameSeconds", 360);
    private arcshot.rules.FoulFrequency foulFrequency = arcshot.rules.FoulFrequency.NORMAL;
    private boolean strictRefs;
    private long seed = System.nanoTime();
```
Why:   per-match game length, foul settings and a random seed (tests replay matches with it).  
Check: compiles.


### STEP 6 - Edit MatchConfig.java (2/2)

```
Where: directly below the line `    public void setAutoSwitch(boolean autoSwitch) { this.autoSwitch = autoSwitch; }`
Add:
```
```java
    /** Regulation length in seconds (Settings: 4 / 6 / 8 / 10 minutes). */
    public double getGameSeconds() { return gameSeconds; }

    public void setGameSeconds(double gameSeconds) { this.gameSeconds = Math.max(30, gameSeconds); }

    public arcshot.rules.FoulFrequency getFoulFrequency() { return foulFrequency; }

    public void setFoulFrequency(arcshot.rules.FoulFrequency f) { this.foulFrequency = f; }

    public boolean isStrictRefs() { return strictRefs; }

    public void setStrictRefs(boolean strictRefs) { this.strictRefs = strictRefs; }

    /** Random seed for fouls and rolls (set it to replay the same match in tests). */
    public long getSeed() { return seed; }

    public void setSeed(long seed) { this.seed = seed; }
```
Why:   getters/setters for the new fields.  
Check: compiles.


### STEP 7 - Edit PlayerStats.java (1/2)

```
Where: directly below the line `    private int ultimatesUsed;`
Add:
```
```java
    private int fouls;
    private int freeThrowsMade;
    private int freeThrowsTaken;
    private int dunks;
    private int layups;
```
Why:   box-score columns for fouls, free throws, dunks and layups.  
Check: compiles.


### STEP 8 - Edit PlayerStats.java (2/2)

```
Where: directly above the line `    public int getPoints() { return points; }`
Add:
```
```java
    /** Free-throw attempt (each make is worth the free-throw value). */
    public void addFreeThrow(boolean made, int pts) {
        freeThrowsTaken++;
        if (made) {
            freeThrowsMade++;
            points += pts;
        }
    }

    public void addFoul() { fouls++; }

    public void addDunk() { dunks++; }

    public void addLayup() { layups++; }

    public int getFouls() { return fouls; }

    public int getFreeThrowsMade() { return freeThrowsMade; }

    public int getFreeThrowsTaken() { return freeThrowsTaken; }

    public int getDunks() { return dunks; }

    public int getLayups() { return layups; }
```
Why:   record and read the new stats.  
Check: compiles.


### STEP 9 - Edit Settings.java (1/4)

```
Where: directly below the line `    private boolean unlockAllDemo;`
Add:
```
```java
    private String graphicsStyle = "retro";
    private boolean crt;
    private String foulFrequency = "NORMAL";
    private boolean strictRefs;
    private int gameMinutes = 6;
```
Why:   new options: retro/smooth graphics, CRT, foul frequency, strict refs, game length.  
Check: compiles.


### STEP 10 - Edit Settings.java (2/4)

```
Where: directly above the line `    public KeyBindings getKeys() { return keys; }`
Add:
```
```java
    /** "retro" (640x360 pixel art, default) or "smooth" (the original HD renderer). */
    public String getGraphicsStyle() { return graphicsStyle; }

    public void setGraphicsStyle(String style) { this.graphicsStyle = "smooth".equals(style) ? "smooth" : "retro"; }

    public boolean isRetro() { return "retro".equals(graphicsStyle); }

    /** Optional CRT scanlines over the retro picture. */
    public boolean isCrt() { return crt; }

    public void setCrt(boolean crt) { this.crt = crt; }

    /** OFF / LOW / NORMAL / HIGH (see FoulFrequency). */
    public String getFoulFrequency() { return foulFrequency; }

    public void setFoulFrequency(String f) {
        this.foulFrequency = "OFF".equals(f) || "LOW".equals(f) || "HIGH".equals(f) ? f : "NORMAL";
    }

    public boolean isStrictRefs() { return strictRefs; }

    public void setStrictRefs(boolean strictRefs) { this.strictRefs = strictRefs; }

    /** Game length in minutes (3x3 is 10; this project's default stays 6). */
    public int getGameMinutes() { return gameMinutes; }

    public void setGameMinutes(int m) { this.gameMinutes = Math.max(2, Math.min(10, m)); }
```
Why:   validated getters/setters (ENCAPSULATION: bad values fall back to defaults).  
Check: compiles.


### STEP 11 - Edit Settings.java (3/4)

```
Where: in `writeTo(...)`, directly below the line `        p.setProperty("settings.unlockAllDemo", String.valueOf(unlockAllDemo));`
Add:
```
```java
        p.setProperty("settings.graphicsStyle", graphicsStyle);
        p.setProperty("settings.crt", String.valueOf(crt));
        p.setProperty("settings.foulFrequency", foulFrequency);
        p.setProperty("settings.strictRefs", String.valueOf(strictRefs));
        p.setProperty("settings.gameMinutes", String.valueOf(gameMinutes));
```
Why:   save the new options.  
Check: compiles.


### STEP 12 - Edit Settings.java (4/4)

```
Where: in `readFrom(...)`, directly below the line `        unlockAllDemo = Boolean.parseBoolean(p.getProperty("settings.unlockAllDemo", "false"));`
Add:
```
```java
        // new in the upgrade pass: old saves simply get the defaults
        setGraphicsStyle(p.getProperty("settings.graphicsStyle", "retro"));
        crt = Boolean.parseBoolean(p.getProperty("settings.crt", "false"));
        setFoulFrequency(p.getProperty("settings.foulFrequency", "NORMAL"));
        strictRefs = Boolean.parseBoolean(p.getProperty("settings.strictRefs", "false"));
        setGameMinutes(SaveManager.intOf(p, "settings.gameMinutes", gameMinutes));
```
Why:   load them; an old save simply gets the defaults (save format stays compatible).  
Check: compiles; your existing profile still loads.


### STEP 13 - Edit resources/config/balance.properties (1/2)

```
Where: the two lines starting with `# points needed in overtime to win (1 = sudden death, next basket wins)`
Replace with:
```
```properties
# points needed in overtime to win (FIBA 3x3: first team to score 2 points)
rules.overtimePoints=2
```
Why:   FIBA 3x3 overtime is first to 2 points (brief).  
Check: F5 in a match reloads it.


### STEP 14 - Edit resources/config/balance.properties (2/2)

```
Where: at the very end of the file
Add:
```
```text
(copy everything from the line `# UPGRADE PASS (retro + rules)` down to the end of the delivered balance.properties)
```
Why:   every new number (rules, foul odds, FT aim, finishing, animation heights, movement feel, heat, new achievement targets) is tunable without code. Every value is also the code default, so a missing line is harmless.  
Check: file loads; the debug overlay shows `Balance: resources/...`.


> **COMPILE CHECKPOINT** - `./build.sh compile` (Windows: `build.bat compile`). Run the game: it must look and play exactly like v2 (only overtime is now first to 2).


## Phase C - Sprite tool, sprite sheets, animation data, sprite loader, retro court

> **Before this phase:** commit (`git add -A && git commit -m "before phase C: sprites"`) or copy the project folder, so you can roll back.


### STEP 15 - NEW FILES (phase C)

Copy each file **complete** from the delivered project into the same folder in your repo (they are full files with package line, imports and Javadoc):

| File (folder = package) | What it is |
|---|---|
| `src/arcshot/anim/AnimationDef.java` | frames, fps, loop and frame events of one animation |
| `src/arcshot/anim/AnimationTable.java` | all player and referee animations with their frame events (manifest can override) |
| `src/arcshot/anim/Facing.java` | BACK / FRONT / SIDE with anti-flicker hysteresis |
| `src/arcshot/render/sprite/Palette.java` | mask colors -> team/skin/hair colors (keep in sync with the generator) |
| `src/arcshot/render/sprite/SpriteSheet.java` | one recolored sheet + anchors (hand, number, head) |
| `src/arcshot/render/sprite/SpriteLoader.java` | loads, recolors and caches sheets; missing files = null (placeholder drawn) |
| `src/arcshot/render/sprite/AnimatedSprite.java` | draws one frame with the feet at a screen point |
| `src/arcshot/render/retro/Projection.java` | court (x, y, z) -> 640x360 angled camera |
| `src/arcshot/render/retro/PixelFont.java` | 5x7 bitmap font + 3x5 jersey digits |
| `src/arcshot/render/retro/RetroCourtRenderer.java` | retro arena, hardwood, lines, logo, backboard, rim and net |
| `tools/SpriteSheetGenerator.java` | the puppet-rig sprite generator (not part of the game build) |
| `resources/sprites/guard/ forward/ big/ ref/ + preview.png` | generated sheets and manifests (or generate them: next step) |

Why:   sprites and the static retro court do not depend on gameplay; the game still uses the v2 renderer after this phase.


### STEP 16 - LARGE EDIT: replace `build.sh`

**Replace the whole file** with the delivered `build.sh` (28 lines). Do not merge by hand.  
Why:   adds `test` and `sprites` targets (short file).  
Check: `./build.sh sprites` writes `resources/sprites/preview.png`.


### STEP 17 - LARGE EDIT: replace `build.bat`

**Replace the whole file** with the delivered `build.bat` (31 lines). Do not merge by hand.  
Why:   same targets for Windows (keep CRLF line endings).  
Check: `build.bat sprites` works.


### STEP 18 - LARGE EDIT: replace `resources/sprites/README.md`

**Replace the whole file** with the delivered `resources/sprites/README.md` (104 lines). Do not merge by hand.  
Why:   documents sheet layout, mask colors, manifest, frame events and the art-tweak constants.  
Check: compile at the checkpoint at the end of this phase.


> **COMPILE CHECKPOINT** - `./build.sh compile` (Windows: `build.bat compile`). Then `./build.sh sprites` and open `resources/sprites/preview.png`: every animation of Guard, Forward, Big and the referee. The game itself is unchanged.


## Phase D-F - Action system, layups/dunks, ball and phase state machines, referees, fouls, free throws

> **Before this phase:** commit (`git add -A && git commit -m "before phase D-F: actions + rules"`) or copy the project folder, so you can roll back.

Do this phase in one sitting: the new `Match` ties actions, rules and referees together, so the compile checkpoint is at the end.


### STEP 19 - NEW FILES (phase D-F)

Copy each file **complete** from the delivered project into the same folder in your repo (they are full files with package line, imports and Javadoc):

| File (folder = package) | What it is |
|---|---|
| `src/arcshot/action/ActionType.java` | every action with priority, interruptible, forces, locks, root motion |
| `src/arcshot/action/Action.java` | abstract action: TEMPLATE METHOD update() firing frame events once |
| `src/arcshot/action/ActionController.java` | owns exactly ONE current action per player; request() enforces priorities |
| `src/arcshot/action/JumpShotAction.java` | charge / release on `ball_release`; also the free-throw action |
| `src/arcshot/action/LayupAction.java` | approach + takeoff + release, root motion, bank variant |
| `src/arcshot/action/DunkAction.java` | dunk / dunk2 / windmill, scores on `rim_touch`, forced (Final Burst) variant |
| `src/arcshot/action/BlockAction.java` | block jump and rebound jump (contact window, `grab`) |
| `src/arcshot/action/StealAction.java` | swipe; `contact` frame queues the steal |
| `src/arcshot/action/PassAction.java` | pass leaves on `ball_release` |
| `src/arcshot/action/DashAction.java` | dashes and crossovers used by abilities (root motion, intangible option) |
| `src/arcshot/action/SimpleAction.java` | fouled / celebrate / ability cast poses |
| `src/arcshot/action/CastFamilies.java` | which cast pose each ability uses |
| `src/arcshot/referee/CourtActor.java` | abstract non-player court figure (walk, face, animate) |
| `src/arcshot/referee/Referee.java` | LEAD / TRAIL referee, whistle + signals |
| `src/arcshot/referee/RefereeAI.java` | positioning; never blocks players |
| `src/arcshot/referee/RefereeCrew.java` | the two referees; `sees(x, y)` for calls |
| `src/arcshot/rules/FoulDetector.java` | decides calls from contact frames, context, settings and referee view |

Why:   the new gameplay core. Abilities keep calling the same Player methods, which now request actions.


### STEP 20 - LARGE EDIT: replace `src/arcshot/court/ShotAttempt.java`

**Replace the whole file** with the delivered `src/arcshot/court/ShotAttempt.java` (92 lines). Do not merge by hand.  
Why:   adds the shot kind (jump shot / layup / dunk / free throw), bank shots and a pending foul.  
Check: compile at the checkpoint at the end of this phase.


### STEP 21 - LARGE EDIT: replace `src/arcshot/court/Ball.java`

**Replace the whole file** with the delivered `src/arcshot/court/Ball.java` (359 lines). Do not merge by hand.  
Why:   ball state machine: ownership only through `giveTo(player, reason)` (refused while a shot flies), `validate()`, z-height, bank shots, rim rattles, derived DRIBBLING / REBOUND_CONTEST.  
Check: compile at the checkpoint at the end of this phase.


### STEP 22 - LARGE EDIT: replace `src/arcshot/player/Player.java`

**Replace the whole file** with the delivered `src/arcshot/player/Player.java` (686 lines). Do not merge by hand.  
Why:   implements CourtBody; owns an ActionController; acceleration/deceleration, smooth turning, defensive slide; startDash/startJump now request actions (same signatures, so abilities need no change).  
Check: compile at the checkpoint at the end of this phase.


### STEP 23 - LARGE EDIT: replace `src/arcshot/court/Match.java`

**Replace the whole file** with the delivered `src/arcshot/court/Match.java` (2180 lines). Do not merge by hand.  
Why:   phase state machine, documented update order, interaction priority queue, context shoot (jump shot / layup / dunk), blocks on the rise, fouls + FIBA 3x3 free throws, referees, clear/check rules, overtime to 2, sound hooks, debug scenarios.  
Check: compile at the checkpoint at the end of this phase.


### STEP 24 - Edit SoundManager.java (1/2)

```
Where: in `onEvent`, the three cases that start with `            case BASKET_MADE:` (BASKET_MADE, DUNK, BLOCK each calling `play(...)`)
Replace with:
```
```java
            case BASKET_MADE:
            case DUNK:
            case BLOCK:
                break; // v3: the match sends precise SOUND events (swish / rim / backboard / dunk / block)
```
Why:   the match now sends precise SOUND events (swish vs rim vs backboard), so these would play twice.  
Check: compiles.


### STEP 25 - Edit SoundManager.java (2/2)

```
Where: in `onEvent`, directly above the line `            default:` of the same switch
Add:
```
```java
            case SOUND:
                if (event.getPayload() != null) {
                    play(String.valueOf(event.getPayload()));
                }
                break;
```
Why:   plays the sound named in the event; missing .wav files are skipped silently as before.  
Check: compiles.


### STEP 26 - Edit AIController.java (1/5)

```
Where: directly below the line `    private Player lastHolder;`
Add:
```
```java
    private double ftWait;
```
Why:   a small wait before AI free throws.  
Check: nothing new to see yet; compile at the checkpoint at the end of this phase.


### STEP 27 - Edit AIController.java (2/5)

```
Where: in `fillInput(...)`, directly below the line `        out.clear();`
Add:
```
```java
        if (match.isFreeThrow()) {
            freeThrow(self, match, out, dt);
            return;
        }
```
Why:   during free throws the AI only shoots (if it is the shooter) and otherwise stands still.  
Check: nothing new to see yet; compile at the checkpoint at the end of this phase.


### STEP 28 - Edit AIController.java (3/5)

```
Where: in the defensive method, the line `        if (holder.isChargingShot()) {`
Replace with:
```
```java
        arcshot.action.ActionType ht = holder.getActions().getType();
        boolean finishing = ht == arcshot.action.ActionType.LAYUP || ht == arcshot.action.ActionType.DUNK;
        if (finishing) {
            shotSeenTime += dt;
            if (!jumpDecided && shotSeenTime >= difficulty.reaction() * 0.4) {
                jumpDecided = true;
                if (dist < self.getReach(Reach.BLOCK) * 1.6 && rng.nextDouble() < difficulty.blockChance()) {
                    out.setShootHeld(true);
                }
            }
        } else if (holder.isChargingShot()) {
```
Why:   defenders also try to block layups and dunks during the rise.  
Check: nothing new to see yet; compile at the checkpoint at the end of this phase.


### STEP 29 - Edit AIController.java (4/5)

```
Where: a few lines below, the condition containing `meter >= 0.62 - difficulty.reaction() * 0.4`
Replace:
```
```java
meter >= 0.84 - difficulty.reaction() * 0.3
```
Why:   blocks are now timed against the real release frame; the old timing jumped too early.  
Check: nothing new to see yet; compile at the checkpoint at the end of this phase.


### STEP 30 - Edit AIController.java (5/5)

```
Where: in the loose-ball chase method, the method's closing `    }` directly below the line `        moveTo(self, new double[] {ball.getX(), ball.getY()}, out, true);`
Replace that closing brace with (the code closes the chase method and adds the new freeThrow method):
```
```java
        // jump for a high rebound when it is close (same action a human gets with Space)
        if (self.distanceTo(ball.getX(), ball.getY()) < 70 && ball.getZ() > 40 && ball.canBeGrabbed()) {
            out.setShootHeld(true);
        }
    }

    /** Free throws: wait a moment at the line, then hold SHOOT like a human until the arc arrow reaches the rim. */
    private void freeThrow(Player self, Match match, PlayerInput out, double dt) {
        if (match.getBall().getHolder() != self) {
            ftWait = 0;
            return;
        }
        if (self.isChargingShot()) {
            out.setShootHeld(self.getShotHold() < holdTarget);
            return;
        }
        ftWait += dt;
        if (ftWait > 0.9) {
            // aim for power 1.0 on the free-throw arc (tip on the rim), with the same difficulty-based error
            double error = rng.nextGaussian() * difficulty.timingError() * 0.8;
            holdTarget = Math.max(0.05, (1.0 + error) * match.getFreeThrowMeterTime());
            out.setShootHeld(true);
            ftWait = 0;
        }
    }
```
Why:   AI uses the same rebound jump as a human, and shoots free throws with the same hold-and-release arc aim (difficulty-based error).  
Check: nothing new to see yet; compile at the checkpoint at the end of this phase.


### STEP 31 - Edit QuakeFist.java

```
Where: in `aiShouldUse`, the line `        return near != null && (hasBall(near, match) || hasBall(owner, match));`
Replace with:
```
```java
        return near != null && hasBall(near, match);
```
Why:   Quake Fist is a foulable ability; swinging it while holding the ball now draws offensive fouls, so the AI only uses it on defense.  
Check: nothing new to see yet; compile at the checkpoint at the end of this phase.


### STEP 32 - Edit HudRenderer.java (1/2)

```
Where: at the top of `drawShotMeter(...)`, directly above the line `        if (!p.isChargingShot()) {`
Add:
```
```java
        if (m.isFreeThrow()) {
            drawFreeThrowArc(g, m);
            return;
        }
```
Why:   free throws use the arc arrow, not the jump-shot meter (smooth view).  
Check: nothing new to see yet; compile at the checkpoint at the end of this phase.


### STEP 33 - Edit HudRenderer.java (2/2)

```
Where: directly above the line `    // ---- banners, hints, chips, toasts ----------------------------------------------------------------------`
Add:
```
```java
    /** Free throws use the 2K-style arc arrow (see FreeThrowAim), not the vertical meter. */
    private void drawFreeThrowArc(Graphics2D g, Match m) {
        Player s = m.getBall().getHolder();
        if (s == null || !s.isHumanControlled()) {
            return;
        }
        arcshot.court.FreeThrowAim aim = m.getFreeThrowAim();
        double sx = s.getX();
        double sy = s.getY() - 70;
        double hx = m.getCourt().getHoopX();
        double hy = m.getCourt().getHoopY() - m.getCourt().getRimHeight() * CourtRenderer.LIFT;
        double power = aim.isAiming() ? Math.min(1.5, aim.getPower()) : 0.25;
        double tipX = hx + aim.getSway() * 60;
        double e = aim.error(1.0);
        Color c = !aim.isAiming() ? new Color(255, 255, 255, 120)
                : (e <= 1 ? new Color(0x3DDC84) : (e <= 2 ? Theme.GOLD : Theme.DANGER));
        g.setStroke(new BasicStroke(9f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        int steps = 24;
        double prevX = sx;
        double prevY = sy;
        for (int i = 1; i <= steps; i++) {
            double t = power * i / steps;
            double x = sx + (tipX - sx) * t;
            double y = sy + (hy - sy) * t - Math.sin(Math.min(1, t) * Math.PI) * 110;
            g.setColor(c);
            g.drawLine((int) prevX, (int) prevY, (int) x, (int) y);
            prevX = x;
            prevY = y;
        }
        g.setStroke(new BasicStroke(1f));
        g.setColor(c);
        g.fillOval((int) prevX - 9, (int) prevY - 9, 18, 18);
    }
```
Why:   draws the arc arrow in the smooth view.  
Check: nothing new to see yet; compile at the checkpoint at the end of this phase.


> **COMPILE CHECKPOINT** - `./build.sh compile` (Windows: `build.bat compile`). Run a match (still the smooth v2 view): drive at the rim for layups/dunks, get fouled, shoot free throws with the arc arrow, watch the FOUL banner and the referee signal. Classic Shootout and the menu still work.


## Phase G - Retro renderer, settings, debug scenarios, self-tests

> **Before this phase:** commit (`git add -A && git commit -m "before phase G: retro renderer"`) or copy the project folder, so you can roll back.


### STEP 34 - NEW FILES (phase G)

Copy each file **complete** from the delivered project into the same folder in your repo (they are full files with package line, imports and Javadoc):

| File (folder = package) | What it is |
|---|---|
| `src/arcshot/render/MatchView.java` | interface for both renderers (POLYMORPHISM) |
| `src/arcshot/render/retro/RetroParticles.java` | FxSink in pixel style (sparks, rings, afterimages, text pops) |
| `src/arcshot/render/retro/RetroAbilityIcons.java` | Q/E/R tiles with cooldown shutter |
| `src/arcshot/render/retro/RetroHud.java` | scoreboard, foul pips, BONUS, player card, jump-shot meter, FT arc arrow, banners, ticker, toasts, F3 readout |
| `src/arcshot/render/retro/RetroMatchRenderer.java` | depth-sorted retro scene, sprites, shadows, ball in hand, hitboxes |
| `src/arcshot/test/SelfTests.java` | main-based self-tests (rules table, FT aim, phases, headless matches) |

Why:   the new look plugs in behind one interface; gameplay is not touched.


### STEP 35 - Edit MatchRenderer.java (1/5)

```
Where: the class line `public final class MatchRenderer {`
Replace with:
```
```java
public final class MatchRenderer implements MatchView {
```
Why:   both renderers are interchangeable `MatchView`s.  
Check: nothing new to see yet; compile at the checkpoint at the end of this phase.


### STEP 36 - Edit MatchRenderer.java (2/5)

```
Where: directly above the line `    public HudRenderer getHud() { return hud; }`
Add:
```
```java
    @Override
    public arcshot.court.FxSink getFx() { return particles; }

    @Override
    public arcshot.core.GameEventListener getHudListener() { return hud; }

    @Override
    public int frameWidth() { return 1280; }

    @Override
    public int frameHeight() { return 720; }

    @Override
    public boolean isPixelArt() { return false; }
```
Why:   the MatchView contract (frame size 1280x720, smooth scaling).  
Check: nothing new to see yet; compile at the checkpoint at the end of this phase.


### STEP 37 - Edit MatchRenderer.java (3/5)

```
Where: add `@Override` on the line above `    public void update(double dt) {` and above `    public void render(Graphics2D g, Match m, int w, int h) {`
Add:
```
```java
    @Override
```
Why:   they now implement the interface methods.  
Check: nothing new to see yet; compile at the checkpoint at the end of this phase.


### STEP 38 - Edit MatchRenderer.java (4/5)

```
Where: in `render(...)`, directly above the line `        drawActors(g, m, time);`
Add:
```
```java
        for (arcshot.referee.Referee r : m.getRefs().getReferees()) {
            if (r.getY() < m.getCourt().getTop() + 10) {
                continue; // the lead referee stands behind the baseline: off-camera in this top-down view
            }
            g.setColor(new Color(0, 0, 0, 80));
            g.fillOval((int) r.getX() - 14, (int) r.getY() - 5, 28, 10);
            for (int i = 0; i < 4; i++) {
                g.setColor(i % 2 == 0 ? Color.WHITE : new Color(30, 30, 30));
                g.fillRect((int) r.getX() - 11 + i * 6, (int) r.getY() - 44, 6, 26);
            }
            g.setColor(new Color(40, 40, 50));
            g.fillRect((int) r.getX() - 9, (int) r.getY() - 18, 18, 18);
            g.setColor(new Color(0xC68A5E));
            g.fillOval((int) r.getX() - 8, (int) r.getY() - 60, 16, 16);
        }
```
Why:   the two referees also appear in the smooth view (the lead referee is off-camera there).  
Check: nothing new to see yet; compile at the checkpoint at the end of this phase.


### STEP 39 - Edit MatchRenderer.java (5/5)

```
Where: in `drawBall(...)`, the trail line `                g.fillOval((int) (b.getTrailX(i) - r), (int) (b.getTrailY(i) - r), (int) (r * 2), (int) (r * 2));`
Replace with:
```
```java
                g.fillOval((int) (b.getTrailX(i) - r), (int) (b.getTrailY(i) - b.getTrailZ(i) * CourtRenderer.LIFT - r), (int) (r * 2), (int) (r * 2));
```
Why:   the ball trail follows the ball's height.  
Check: nothing new to see yet; compile at the checkpoint at the end of this phase.


### STEP 40 - LARGE EDIT: replace `src/arcshot/ui/components/GameCanvas.java`

**Replace the whole file** with the delivered `src/arcshot/ui/components/GameCanvas.java` (118 lines). Do not merge by hand.  
Why:   buffers of any size (640x360 retro), whole-number nearest-neighbour scaling with letterboxing, optional CRT scanlines.  
Check: compile at the checkpoint at the end of this phase.


### STEP 41 - LARGE EDIT: replace `src/arcshot/ui/screens/MatchScreen.java`

**Replace the whole file** with the delivered `src/arcshot/ui/screens/MatchScreen.java` (326 lines). Do not merge by hand.  
Why:   picks `RetroMatchRenderer` or `MatchRenderer` from Settings (as a `MatchView`), sets pixel-art/CRT on the canvas, debug scenario keys F6-F11 (F3 on), practice tips and drills (4 = free throws, 5 = dunk).  
Check: compile at the checkpoint at the end of this phase.


### STEP 42 - Edit SettingsScreen.java (1/3)

```
Where: in the audio/display rows method, directly below the line `        ToggleSwitch fps = toggle(s.isShowFps(), s::setShowFps);`
Add:
```
```java
        ValueStepper<String> style = new ValueStepper<>();
        style.addOption("retro", "Retro pixel (default)");
        style.addOption("smooth", "Smooth HD (classic v2)");
        style.setSelected(s.getGraphicsStyle());
        style.setOnChange(id -> {
            s.setGraphicsStyle(id);
            app.save();
        });
```
Why:   graphics style option.  
Check: nothing new to see yet; compile at the checkpoint at the end of this phase.


### STEP 43 - Edit SettingsScreen.java (2/3)

```
Where: in the same `return new JComponent[] {` list, directly below the line `            UIFactory.formRow("Theme skin", "Ability names, effect colors and particles", skin),`
Add:
```
```java
            UIFactory.formRow("Match graphics", "Retro = 640x360 pixel art, angled court", style),
            UIFactory.formRow("CRT scanlines", "Retro style only", toggle(s.isCrt(), s::setCrt)),
```
Why:   two new rows.  
Check: nothing new to see yet; compile at the checkpoint at the end of this phase.


### STEP 44 - Edit SettingsScreen.java (3/3)

```
Where: in `gameplayRows()`, replace the lines from `        return new JComponent[] {` down to `            UIFactory.formRow("Default AI difficulty", null, diff),` with
Replace with:
```
```java
        ValueStepper<String> fouls = new ValueStepper<>();
        fouls.addOption("OFF", "Off");
        fouls.addOption("LOW", "Low");
        fouls.addOption("NORMAL", "Normal");
        fouls.addOption("HIGH", "High");
        fouls.setSelected(s.getFoulFrequency());
        fouls.setOnChange(id -> {
            s.setFoulFrequency(id);
            app.save();
        });
        ValueStepper<Integer> minutes = new ValueStepper<>();
        for (int m : new int[] {4, 6, 8, 10}) {
            minutes.addOption(m, m + " minutes" + (m == 10 ? " (official 3x3)" : (m == 6 ? " (default)" : "")));
        }
        minutes.setSelected(s.getGameMinutes());
        minutes.setOnChange(m -> {
            s.setGameMinutes(m);
            app.save();
        });
        return new JComponent[] {
            UIFactory.formRow("Default AI difficulty", null, diff),
            UIFactory.formRow("Game length", "Or first to 21 points", minutes),
            UIFactory.formRow("Foul frequency", "How often contact is called", fouls),
            UIFactory.formRow("Strict refs", "Technicals for abilities on frozen players, more calls", toggle(s.isStrictRefs(), s::setStrictRefs)),
```
Why:   game length, foul frequency and strict refs (the brief's settings additions).  
Check: Settings shows the new rows; changes are saved.


### STEP 45 - Edit ClassSelectScreen.java (1/2)

```
Where: in `start()`, directly below the line `        cfg.setDifficulty(difficulty.getSelected());`
Add:
```
```java
        cfg.setGameSeconds(p.getSettings().getGameMinutes() * 60);
        cfg.setFoulFrequency(arcshot.rules.FoulFrequency.valueOf(p.getSettings().getFoulFrequency()));
        cfg.setStrictRefs(p.getSettings().isStrictRefs());
```
Why:   the match gets the chosen length and foul settings.  
Check: nothing new to see yet; compile at the checkpoint at the end of this phase.


### STEP 46 - Edit ClassSelectScreen.java (2/2)

```
Where: the rules text line ending with ` min. Tie = sudden death.";`
Replace with:
```
```java
                + " or most points after " + app.profile().getSettings().getGameMinutes() + " min. Tie = overtime, first to "
                + Balance.i("rules.overtimePoints", 2) + ".";
```
Why:   shows the real game length and the new overtime rule.  
Check: nothing new to see yet; compile at the checkpoint at the end of this phase.


> **COMPILE CHECKPOINT** - `./build.sh compile` (Windows: `build.bat compile`). Run a match: retro pixel view by default. Settings -> Match graphics switches back to Smooth HD. F3 shows the overlay; F6-F11 run scenarios. Then `./build.sh test` must end with `FAILED 0`.


## Phase H - Results, achievements, how-to-play, docs

> **Before this phase:** commit (`git add -A && git commit -m "before phase H: polish + docs"`) or copy the project folder, so you can roll back.


### STEP 47 - Edit ResultsScreen.java (1/3)

```
Where: the line `        table.add(row("PLAYER", "PTS", "REB", "AST", "STL", "BLK", "FG", true, Theme.TEXT_MUTED));`
Replace with:
```
```java
        table.add(row("PLAYER", true, Theme.TEXT_MUTED, "PTS", "REB", "AST", "STL", "BLK", "DNK", "PF", "FG", "FT"));
```
Why:   new columns DNK, PF and FT.  
Check: nothing new to see yet; compile at the checkpoint at the end of this phase.


### STEP 48 - Edit ResultsScreen.java (2/3)

```
Where: the line `        table.add(row("", "", "", "", "", "", "", false, Theme.TEXT_MUTED));`
Replace with:
```
```java
        table.add(row("", false, Theme.TEXT_MUTED));
```
Why:   the separator row with the new signature.  
Check: nothing new to see yet; compile at the checkpoint at the end of this phase.


### STEP 49 - Edit ResultsScreen.java (3/3)

```
Where: replace the two methods `playerRow(...)` and `row(...)` (from `    private JComponent playerRow(Player p, Color color) {` to the end of `row`)
Replace with:
```
```java
    private JComponent playerRow(Player p, Color color) {
        PlayerStats st = p.getStats();
        return row(p.getName() + "  (" + p.getPlayerClass().getDisplayName().charAt(0) + ")", false, color,
                String.valueOf(st.getPoints()), String.valueOf(st.getRebounds()), String.valueOf(st.getAssists()),
                String.valueOf(st.getSteals()), String.valueOf(st.getBlocks()), String.valueOf(st.getDunks()),
                String.valueOf(st.getFouls()), st.getShotsMade() + "/" + st.getShotsTaken(),
                st.getFreeThrowsMade() + "/" + st.getFreeThrowsTaken());
    }

    /** One box-score row: name on the left, the number columns right-aligned (DNK, PF and FT added in the upgrade). */
    private JComponent row(String name, boolean header, Color color, String... values) {
        JPanel r = UIFactory.clear(new BorderLayout());
        JLabel n = UIFactory.label(name, header ? Theme.bold(12) : Theme.semi(15), color);
        r.add(n, BorderLayout.CENTER);
        JPanel nums = UIFactory.clear(new GridLayout(1, 9, Theme.S1, 0));
        for (int i = 0; i < 9; i++) {
            String v = i < values.length ? values[i] : "";
            JLabel l = UIFactory.label(v, header ? Theme.bold(12) : Theme.semi(14), color);
            l.setHorizontalAlignment(SwingConstants.RIGHT);
            nums.add(l);
        }
        nums.setPreferredSize(new java.awt.Dimension(390, 26));
        r.add(nums, BorderLayout.EAST);
        return r;
    }
```
Why:   a varargs row with 9 number columns.  
Check: Results shows DNK, PF, FG and FT.


### STEP 50 - Edit AchievementCatalog.java

```
Where: in `create()`, directly above the line `        List<String> others = new ArrayList<>();`
Add:
```
```java
        // ---------------- UPGRADE PASS: finishing, fouls, free throws ----------------
        list.add(new CounterAchievement("layup_line", "Layup Line", "Make 5 career layups.",
                "Press SHOOT while driving into the paint.", ROOKIE, SCORING, Filters.user(GameEventType.LAYUP), t("layup_line", 5))
                .reward(new TitleUnlock("Finisher")));
        list.add(new CounterAchievement("high_flyer", "High Flyer", "Throw down 5 career dunks.",
                "Attack the rim at full speed - Bigs dunk the easiest.", STARTER, SCORING, Filters.user(GameEventType.DUNK), t("high_flyer", 5))
                .requires("layup_line").reward(new TitleUnlock("High Flyer")));
        list.add(new CounterAchievement("charity_stripe", "Charity Stripe", "Make 10 career free throws.",
                "Release when the arrow tip sits on the rim.", STARTER, SCORING, Filters.user(GameEventType.FREE_THROW_MADE), t("charity_stripe", 10))
                .reward(new TitleUnlock("Ice Water")));
        list.add(new CounterAchievement("contact_artist", "Contact Artist", "Draw 5 career fouls.",
                "Drive to the rim and finish through contact.", STARTER, PLAYMAKING, Filters.user(GameEventType.FOUL_DRAWN), t("contact_artist", 5))
                .reward(new TitleUnlock("Contact Artist")));
        list.add(new CounterAchievement("and_one", "And One!", "Score while being fouled.",
                "A made shot through a foul counts + 1 free throw.", ALL_STAR, SCORING, Filters.user(GameEventType.AND_ONE), 1)
                .requires("contact_artist").reward(new TitleUnlock("And-One")));
```
Why:   5 new achievements on the new events, using the existing classes (no engine change). They sit before Completionist, so Completionist includes them.  
Check: Achievements screen shows 35.


### STEP 51 - Edit balance.properties (achievement targets)

```
Where: at the end of the file
Add:
```
```properties
# ---------- Achievements added in the upgrade pass ----------
achievement.layup_line.target=5
achievement.high_flyer.target=5
achievement.charity_stripe.target=10
achievement.contact_artist.target=5
```
Why:   targets are tunable like the others.  
Check: nothing new to see yet; compile at the checkpoint at the end of this phase.


### STEP 52 - Edit HowToPlayScreen.java (1/2)

```
Where: in the controls card, replace the string starting with `"Practice: C refills cooldowns, 1/2/3 picks a class. F3 debug, F5 reload balance."`
Replace with:
```
```java
                + "Practice: C refills cooldowns, 1/2/3 picks a class, 4 free-throw drill, 5 dunk drill. F3 debug overlay, F5 reload balance.\n"
                + "With F3 on: F6 shooting foul, F7 dunk, F8 block, F9 out of bounds, F10 7th team foul, F11 free throws.");
```
Why:   new practice drills and debug scenario keys.  
Check: nothing new to see yet; compile at the checkpoint at the end of this phase.


### STEP 53 - Edit HowToPlayScreen.java (2/2)

```
Where: in the rules card, replace the whole `String text = ...;` statement (from `        String text = "- " + Balance.i("rules.insidePoints", 1)` to its `;`)
Replace with:
```
```java
        String text = "- " + Balance.i("rules.insidePoints", 1) + " point inside the arc, " + Balance.i("rules.outsidePoints", 2)
                + " points outside, free throws 1 point.\n- First to " + Balance.i("rules.targetScore", 21)
                + ", or most points when the clock runs out (game length in Settings).\n"
                + "- Tie at the buzzer: overtime, first team to score " + Balance.i("rules.overtimePoints", 2) + " points wins.\n"
                + "- After a made basket or last free throw: the defense takes it under the hoop and must clear it behind the arc.\n"
                + "- After a steal or defensive rebound: clear the ball behind the arc before shooting.\n"
                + "- " + (int) Balance.d("rules.shotClock", 12) + "-second shot clock (resets when the ball hits the rim).\n"
                + "- SHOOT is context-sensitive: jump shot outside the paint, layup or dunk when driving at the rim.\n"
                + "- Jump shots: hold, release when the meter beside you is in the GREEN zone.\n"
                + "- Fouls (FIBA 3x3): fouled shooting inside = 1 FT, outside = 2 FT, made shot = basket + 1 FT.\n"
                + "  Team fouls 7-9 = 2 FT, 10+ = 2 FT and the ball. Offensive fouls = turnover, no FT.\n"
                + "- Free throws: hold SHOOT - an arrow grows toward the hoop and swings side to side.\n"
                + "  Release when its tip sits on the rim (green). No abilities during free throws.\n"
                + "- Ultimate meter fills from scoring, steals, blocks, assists, rebounds and slowly over time.";
```
Why:   explains context shoot, fouls, free throws and overtime.  
Check: How to Play shows the new rules.


### STEP 54 - Docs (NEW / replace)

Copy from the delivered project: `docs/RULES.md`, `docs/MECHANICS_MATRIX.md`, `docs/VISUAL_SPEC.md`, `CHANGELOG.md`, this
`INTEGRATION_GUIDE.md`, and replace `README.md`, `OOP_MAPPING.md` (section 5 added) and `TEST_CHECKLIST.md` (v3 section added).


> **COMPILE CHECKPOINT** - `./build.sh compile` (Windows: `build.bat compile`). Final: `./build.sh test` -> `FAILED 0`, then play one full match and walk through `TEST_CHECKLIST.md`.


## If something does not compile

* `cannot inherit from final Court` -> Phase B step 1 was skipped.
* `cannot find symbol getActions()` / `getZ()` on Player -> Player.java was not replaced (phase D-F).
* `cannot find symbol getFreeThrowAim()` -> Match.java is still the v2 version.
* `MatchView` errors in MatchScreen -> do all MatchRenderer steps of phase G.
* Sprites missing at runtime -> the game draws simple placeholder figures; copy `resources/sprites/` or run `./build.sh sprites`.

