package arcshot.court;

import java.util.EnumMap;
import java.util.EnumSet;
import java.util.Map;
import java.util.Set;

/**
 * Validated transitions between {@link MatchPhase}s. An illegal transition is still applied (the game must not
 * freeze) but counted and printed, and the self-tests assert that the count stays 0.
 * OOP pillar: <b>ENCAPSULATION</b> - the phase can only change through {@link #go}.
 */
public final class PhaseMachine {
    private static final Map<MatchPhase, Set<MatchPhase>> ALLOWED = new EnumMap<>(MatchPhase.class);

    static {
        allow(MatchPhase.CHECK_BALL, MatchPhase.LIVE, MatchPhase.FOUL_CALLED, MatchPhase.CHECK_BALL);
        allow(MatchPhase.LIVE, MatchPhase.SHOT_IN_AIR, MatchPhase.DEAD_BALL, MatchPhase.FOUL_CALLED,
                MatchPhase.OVERTIME_BREAK, MatchPhase.GAME_OVER, MatchPhase.CHECK_BALL);
        allow(MatchPhase.SHOT_IN_AIR, MatchPhase.LIVE, MatchPhase.DEAD_BALL, MatchPhase.FOUL_CALLED, MatchPhase.GAME_OVER);
        allow(MatchPhase.DEAD_BALL, MatchPhase.CHECK_BALL, MatchPhase.LIVE, MatchPhase.FOUL_CALLED, MatchPhase.FREE_THROW,
                MatchPhase.OVERTIME_BREAK, MatchPhase.GAME_OVER);
        allow(MatchPhase.FOUL_CALLED, MatchPhase.FREE_THROW, MatchPhase.CHECK_BALL, MatchPhase.DEAD_BALL,
                MatchPhase.LIVE, MatchPhase.GAME_OVER);
        allow(MatchPhase.FREE_THROW, MatchPhase.FREE_THROW, MatchPhase.LIVE, MatchPhase.CHECK_BALL, MatchPhase.DEAD_BALL,
                MatchPhase.GAME_OVER, MatchPhase.OVERTIME_BREAK, MatchPhase.SHOT_IN_AIR);
        allow(MatchPhase.OVERTIME_BREAK, MatchPhase.CHECK_BALL);
        allow(MatchPhase.PAUSED);
        allow(MatchPhase.GAME_OVER);
    }

    private static void allow(MatchPhase from, MatchPhase... to) {
        Set<MatchPhase> set = EnumSet.noneOf(MatchPhase.class);
        for (MatchPhase p : to) {
            set.add(p);
        }
        ALLOWED.put(from, set);
    }

    private MatchPhase phase = MatchPhase.CHECK_BALL;
    private double timeInPhase;
    private int illegal;

    public MatchPhase get() { return phase; }

    public double timeInPhase() { return timeInPhase; }

    public void tick(double dt) { timeInPhase += dt; }

    /** Number of transitions that broke the table (should stay 0). */
    public int illegalTransitions() { return illegal; }

    public static boolean isAllowed(MatchPhase from, MatchPhase to) {
        return ALLOWED.get(from).contains(to);
    }

    public void go(MatchPhase next) {
        if (!isAllowed(phase, next)) {
            illegal++;
            System.err.println("[PhaseMachine] illegal transition " + phase + " -> " + next);
        }
        phase = next;
        timeInPhase = 0;
    }
}
