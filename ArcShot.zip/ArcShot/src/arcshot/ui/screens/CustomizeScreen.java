package arcshot.ui.screens;

import arcshot.achievement.Achievement;
import arcshot.app.AppContext;
import arcshot.cosmetic.Cosmetic;
import arcshot.cosmetic.CosmeticRegistry;
import arcshot.cosmetic.CosmeticType;
import arcshot.save.Profile;
import arcshot.ui.Screen;
import arcshot.ui.Theme;
import arcshot.ui.UIFactory;
import arcshot.ui.components.RoundedPanel;
import arcshot.ui.components.ValueStepper;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.util.EnumMap;
import java.util.Map;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * Customize: jersey color, number, aura, player style, court theme and title. Locked items can be previewed but not
 * equipped; the label says which achievement unlocks them. Colors are applied in code (no duplicate art).
 * OOP pillars: <b>INHERITANCE</b> (extends Screen) and <b>POLYMORPHISM</b> (the ScreenManager calls its lifecycle hooks).
 */
public class CustomizeScreen extends Screen {
    private final Map<CosmeticType, ValueStepper<String>> steppers = new EnumMap<>(CosmeticType.class);
    private final Map<CosmeticType, String> preview = new EnumMap<>(CosmeticType.class);
    private final ValueStepper<Integer> number = new ValueStepper<>();
    private final ValueStepper<String> title = new ValueStepper<>();
    private final JLabel status = UIFactory.muted(" ");
    private final Preview previewPanel = new Preview();

    public CustomizeScreen(AppContext app) {
        super(app);
        add(UIFactory.header("Customize", "Locked items show which achievement unlocks them", e -> app.back()), BorderLayout.NORTH);
        JPanel center = UIFactory.clear(new GridLayout(1, 2, Theme.S5, 0));
        RoundedPanel left = UIFactory.card(new BorderLayout());
        left.add(previewPanel, BorderLayout.CENTER);
        center.add(left);
        RoundedPanel right = UIFactory.card(null);
        right.setLayout(new javax.swing.BoxLayout(right, javax.swing.BoxLayout.Y_AXIS));
        Profile p = app.profile();
        preview.put(CosmeticType.JERSEY, p.getJersey());
        preview.put(CosmeticType.AURA, p.getAura());
        preview.put(CosmeticType.STYLE, p.getStyle());
        preview.put(CosmeticType.COURT, p.getCourt());
        for (CosmeticType type : CosmeticType.values()) {
            ValueStepper<String> st = new ValueStepper<>();
            for (Cosmetic c : CosmeticRegistry.byType(type)) {
                boolean ok = CosmeticRegistry.isAvailable(c, p);
                st.addOption(c.getId(), ok ? c.getName() : "[Locked] " + c.getName());
            }
            st.setSelected(preview.get(type));
            st.setOnChange(id -> choose(type, id));
            steppers.put(type, st);
            right.add(row(UIFactory.formRow(type.getLabel(), null, st)));
        }
        for (int i = 0; i <= 99; i++) {
            number.addOption(i, "#" + i);
        }
        number.setSelected(p.getJerseyNumber());
        number.setOnChange(n -> {
            app.profile().setJerseyNumber(n);
            app.save();
            previewPanel.repaint();
        });
        right.add(row(UIFactory.formRow("Jersey number", null, number)));
        title.addOption("", "No title");
        for (String key : p.getUnlocks()) {
            if (key.startsWith(Profile.TITLE)) {
                title.addOption(key.substring(Profile.TITLE.length()), key.substring(Profile.TITLE.length()));
            }
        }
        title.setSelected(p.getTitle());
        title.setOnChange(t -> {
            app.profile().setTitle(t);
            app.save();
            previewPanel.repaint();
        });
        right.add(row(UIFactory.formRow("Title", "Earned from achievements", title)));
        status.setAlignmentX(LEFT_ALIGNMENT);
        right.add(UIFactory.vgap(Theme.S3));
        right.add(status);
        center.add(right);
        add(center, BorderLayout.CENTER);
    }

    private static JComponent row(JComponent c) {
        c.setAlignmentX(LEFT_ALIGNMENT);
        c.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));
        return c;
    }

    private void choose(CosmeticType type, String id) {
        preview.put(type, id);
        Cosmetic c = CosmeticRegistry.get(id);
        Profile p = app.profile();
        if (CosmeticRegistry.isAvailable(c, p)) {
            switch (type) {
                case JERSEY: p.setJersey(id); break;
                case AURA: p.setAura(id); break;
                case STYLE: p.setStyle(id); break;
                default: p.setCourt(id); break;
            }
            app.save();
            status.setForeground(Theme.SUCCESS);
            status.setText("Equipped: " + c.getName());
        } else {
            Achievement src = app.achievements().findSourceOf(Profile.COSMETIC + id);
            status.setForeground(Theme.GOLD);
            status.setText("Preview only - " + c.getName() + " unlocks with \"" + (src == null ? "?" : src.getName()) + "\"");
        }
        previewPanel.repaint();
    }

    /** Live preview of a player on a court tile, recolored in code. */
    private final class Preview extends JComponent {
        @Override
        protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.quality(g);
            int w = getWidth();
            int h = getHeight();
            Cosmetic court = CosmeticRegistry.getOrDefault(preview.get(CosmeticType.COURT), CosmeticType.COURT);
            Color jersey = CosmeticRegistry.getOrDefault(preview.get(CosmeticType.JERSEY), CosmeticType.JERSEY).color(0);
            Cosmetic aura = CosmeticRegistry.getOrDefault(preview.get(CosmeticType.AURA), CosmeticType.AURA);
            String style = preview.get(CosmeticType.STYLE);
            g.setColor(court.color(3));
            g.fillRoundRect(0, 0, w, h, 20, 20);
            g.setColor(court.color(0));
            g.fillRoundRect(20, 40, w - 40, h - 80, 16, 16);
            g.setColor(court.color(2));
            g.fillRect(w / 2 - 70, 40, 140, (h - 80) / 2);
            g.setColor(court.color(1));
            g.setStroke(new BasicStroke(3f));
            g.drawRoundRect(20, 40, w - 40, h - 80, 16, 16);
            g.drawArc(w / 2 - 160, 40 - 160 + 30, 320, 320, 180, 180);
            int cx = w / 2;
            int base = h / 2 + 90;
            Color auraColor = "aura.default".equals(aura.getId()) ? jersey : aura.color(0);
            for (int i = 4; i > 0; i--) {
                g.setColor(Theme.alpha(auraColor, 26 * i));
                int r = 60 + (4 - i) * 14;
                g.fillOval(cx - r, base - 80 - r, r * 2, r * 2);
            }
            g.setColor(new Color(0, 0, 0, 90));
            g.fillOval(cx - 46, base - 12, 92, 26);
            g.setColor(new Color(0xC68E5E));
            g.fillRoundRect(cx - 22, base - 44, 16, 44, 8, 8);
            g.fillRoundRect(cx + 6, base - 44, 16, 44, 8, 8);
            g.setColor(Theme.mix(jersey, Color.BLACK, 0.45));
            g.fillRoundRect(cx - 32, base - 66, 64, 30, 14, 14);
            g.setColor(jersey);
            g.fillRoundRect(cx - 38, base - 140, 76, 82, 26, 26);
            if ("style.gold".equals(style)) {
                g.setColor(new Color(0xF5C542));
                g.setStroke(new BasicStroke(4f));
                g.drawRoundRect(cx - 38, base - 140, 76, 82, 26, 26);
            }
            g.setColor(new Color(0xC68E5E));
            g.fillOval(cx - 56, base - 128, 22, 44);
            g.fillOval(cx + 34, base - 128, 22, 44);
            g.fillOval(cx - 26, base - 196, 52, 52);
            g.setColor(new Color(30, 22, 18));
            g.fillArc(cx - 26, base - 200, 52, 40, 0, 180);
            if ("style.headband".equals(style) || "style.legend".equals(style)) {
                g.setColor("style.legend".equals(style) ? new Color(0xFFE27A) : Color.WHITE);
                g.fillRect(cx - 26, base - 182, 52, 9);
            }
            double lum = (0.299 * jersey.getRed() + 0.587 * jersey.getGreen() + 0.114 * jersey.getBlue()) / 255.0;
            g.setColor(lum > 0.72 ? new Color(30, 30, 40) : Color.WHITE);
            g.setFont(Theme.display(40));
            Theme.drawCentered(g, String.valueOf(app.profile().getJerseyNumber()), cx, base - 100);
            g.setFont(Theme.display(30));
            g.setColor(Theme.TEXT);
            Theme.drawCentered(g, app.profile().getName().toUpperCase(), cx, 24);
            g.setFont(Theme.semi(14));
            g.setColor(Theme.GOLD);
            Theme.drawCentered(g, app.profile().getTitle(), cx, h - 20);
            g.dispose();
        }
    }
}
