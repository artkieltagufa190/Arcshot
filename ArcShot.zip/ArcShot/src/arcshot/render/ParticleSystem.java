package arcshot.render;

import arcshot.court.FxSink;
import arcshot.player.Player;
import arcshot.ui.Theme;
import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * The particle system: sparks, rings, afterimages, trails and floating text.
 * It is the real {@link FxSink} used in a match, so gameplay can request effects by key without knowing how they look.
 * <p>
 * OOP pillars: <b>POLYMORPHISM</b> (implements {@code FxSink}) and <b>ENCAPSULATION</b> (the particle list is private).
 */
public final class ParticleSystem implements FxSink {
    private static final int MAX = 900;

    /** One particle. Kept tiny and simple. */
    private static final class Particle {
        int kind; // 0 dot, 1 ring, 2 ghost, 3 text, 4 trail
        double x;
        double y;
        double vx;
        double vy;
        double life;
        double maxLife;
        double size;
        Color color;
        String text;
        Color body;
        double facing;
    }

    private final List<Particle> particles = new ArrayList<>();
    private final EffectRenderer effects;
    private final Random rng = new Random();

    public ParticleSystem(EffectRenderer effects) {
        this.effects = effects;
    }

    private Particle add(int kind, String key, double x, double y, double life) {
        Particle p = new Particle();
        p.kind = kind;
        p.x = x;
        p.y = y;
        p.life = life;
        p.maxLife = life;
        p.color = effects.colorFor(key);
        if (particles.size() < MAX) {
            particles.add(p);
        }
        return p;
    }

    @Override
    public void burst(String key, double x, double y, int count, double speed) {
        int n = (int) Math.max(1, Math.round(count * effects.particleScale()));
        for (int i = 0; i < n; i++) {
            double a = rng.nextDouble() * Math.PI * 2;
            double s = speed * (0.35 + rng.nextDouble() * 0.65);
            Particle p = add(0, key, x, y, 0.35 + rng.nextDouble() * 0.35);
            p.vx = Math.cos(a) * s;
            p.vy = Math.sin(a) * s * 0.7 - 40;
            p.size = 2.5 + rng.nextDouble() * 3;
        }
    }

    @Override
    public void ring(String key, double x, double y, double radius, double duration) {
        Particle p = add(1, key, x, y, duration);
        p.size = radius;
    }

    @Override
    public void afterimage(Player player, String key) {
        if (effects.particleScale() < 0.4 && rng.nextBoolean()) {
            return;
        }
        Particle p = add(2, key, player.getX(), player.getY(), 0.28);
        p.facing = player.getFacingX();
    }

    @Override
    public void trail(String key, double x, double y, double size) {
        if (rng.nextDouble() > effects.particleScale() + 0.2) {
            return;
        }
        Particle p = add(4, key, x + (rng.nextDouble() - 0.5) * 10, y + (rng.nextDouble() - 0.5) * 10, 0.35);
        p.size = size * (0.6 + rng.nextDouble() * 0.6);
    }

    @Override
    public void text(String text, String key, double x, double y) {
        Particle p = add(3, key, x, y, 1.0);
        p.text = text;
        p.vy = -38;
    }

    /** Advances every particle. Called once per fixed step by the match screen. */
    public void update(double dt) {
        Iterator<Particle> it = particles.iterator();
        while (it.hasNext()) {
            Particle p = it.next();
            p.life -= dt;
            if (p.life <= 0) {
                it.remove();
                continue;
            }
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            if (p.kind == 0) {
                p.vy += 260 * dt;
                p.vx *= Math.exp(-2 * dt);
            } else if (p.kind == 3) {
                p.vy *= Math.exp(-2.5 * dt);
            }
        }
    }

    public int count() {
        return particles.size();
    }

    public void draw(Graphics2D g) {
        Composite old = g.getComposite();
        for (Particle p : particles) {
            float t = (float) Math.max(0, Math.min(1, p.life / p.maxLife));
            switch (p.kind) {
                case 0:
                    g.setColor(Theme.alpha(p.color, (int) (255 * t)));
                    g.fillOval((int) (p.x - p.size), (int) (p.y - p.size), (int) (p.size * 2), (int) (p.size * 2));
                    break;
                case 1:
                    double r = p.size * (1.15 - t * 0.85);
                    effects.floorRing(g, p.x, p.y, r, p.color, 2f + 4f * t, (int) (230 * t));
                    break;
                case 2:
                    g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.45f * t));
                    g.setColor(p.color);
                    g.fillRoundRect((int) p.x - 12, (int) p.y - 44, 24, 30, 12, 12);
                    g.fillOval((int) p.x - 8, (int) p.y - 58, 16, 16);
                    g.setComposite(old);
                    break;
                case 3:
                    g.setFont(Theme.display(22));
                    int w = g.getFontMetrics().stringWidth(p.text);
                    g.setColor(new Color(0, 0, 0, (int) (160 * t)));
                    g.drawString(p.text, (int) p.x - w / 2 + 2, (int) p.y + 2);
                    g.setColor(Theme.alpha(p.color, (int) (255 * Math.min(1, t * 2))));
                    g.drawString(p.text, (int) p.x - w / 2, (int) p.y);
                    break;
                default:
                    g.setColor(Theme.alpha(p.color, (int) (170 * t)));
                    g.fillOval((int) (p.x - p.size * t), (int) (p.y - p.size * t), (int) (p.size * 2 * t) + 1, (int) (p.size * 2 * t) + 1);
                    break;
            }
        }
        g.setStroke(new BasicStroke(1f));
    }
}
