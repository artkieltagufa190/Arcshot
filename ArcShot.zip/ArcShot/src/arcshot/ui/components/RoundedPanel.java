package arcshot.ui.components;

import arcshot.ui.Theme;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.LayoutManager;
import javax.swing.BorderFactory;
import javax.swing.JPanel;

/**
 * A panel with rounded corners, a soft border and a drop shadow ("card").
 * OOP pillars: <b>INHERITANCE</b> (a real {@link JPanel}, so any layout works inside it) and
 * <b>POLYMORPHISM</b> (overrides {@code paintComponent}).
 */
public class RoundedPanel extends JPanel {
    private Color fill;
    private Color border;
    private final int radius;

    public RoundedPanel(LayoutManager layout) {
        this(layout, Theme.PANEL, Theme.BORDER, Theme.RADIUS);
    }

    public RoundedPanel(LayoutManager layout, Color fill, Color border, int radius) {
        super(layout);
        this.fill = fill;
        this.border = border;
        this.radius = radius;
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(Theme.S5, Theme.S5, Theme.S5, Theme.S5));
    }

    public void setFill(Color fill) {
        this.fill = fill;
        repaint();
    }

    public void setBorderColor(Color border) {
        this.border = border;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g0) {
        Graphics2D g = (Graphics2D) g0.create();
        Theme.quality(g);
        int w = getWidth();
        int h = getHeight();
        g.setColor(new Color(0, 0, 0, 60));
        g.fillRoundRect(2, 5, w - 4, h - 5, radius * 2, radius * 2);
        g.setColor(fill);
        g.fillRoundRect(0, 0, w - 1, h - 4, radius * 2, radius * 2);
        if (border != null) {
            g.setColor(border);
            g.setStroke(new BasicStroke(1.2f));
            g.drawRoundRect(0, 0, w - 1, h - 5, radius * 2, radius * 2);
        }
        g.dispose();
    }
}
