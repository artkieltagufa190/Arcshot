package arcshot.control;

import java.awt.event.KeyEvent;

/**
 * Every rebindable action, with its default key.
 * OOP pillar: <b>ENCAPSULATION</b> - each enum constant keeps its data in private fields behind getters.
 */
public enum InputAction {
    MOVE_UP("Move up", KeyEvent.VK_W),
    MOVE_DOWN("Move down", KeyEvent.VK_S),
    MOVE_LEFT("Move left", KeyEvent.VK_A),
    MOVE_RIGHT("Move right", KeyEvent.VK_D),
    SHOOT("Shoot (hold) / Block", KeyEvent.VK_SPACE),
    PASS("Pass / Steal", KeyEvent.VK_F),
    SPRINT("Sprint", KeyEvent.VK_SHIFT),
    ABILITY_Q("Ability Q", KeyEvent.VK_Q),
    ABILITY_E("Ability E", KeyEvent.VK_E),
    ULTIMATE("Ultimate R", KeyEvent.VK_R),
    SWITCH("Switch player", KeyEvent.VK_TAB),
    PAUSE("Pause", KeyEvent.VK_ESCAPE);

    private final String label;
    private final int defaultKey;

    InputAction(String label, int defaultKey) {
        this.label = label;
        this.defaultKey = defaultKey;
    }

    public String getLabel() { return label; }

    public int getDefaultKey() { return defaultKey; }
}
