package arcshot.action;

import arcshot.court.Match;
import arcshot.player.Player;

/**
 * Root-motion dash used by movement abilities (Shadow Step, Bull Rush, Crossover Snap, Final Burst ...).
 * Abilities still call {@code Player.startDash}; that method now requests this action, so no ability changed.
 * OOP pillars: <b>INHERITANCE</b> + <b>POLYMORPHISM</b>.
 */
public class DashAction extends Action {
    private final double vx;
    private final double vy;
    private final double seconds;
    private final boolean intangible;

    public DashAction(double dirX, double dirY, double distance, double seconds, boolean intangible, boolean crossover) {
        super(crossover ? ActionType.CROSSOVER : ActionType.DASH, crossover ? "dribble_run" : "run");
        double len = Math.max(0.0001, Math.hypot(dirX, dirY));
        this.seconds = Math.max(0.03, seconds);
        this.vx = dirX / len * distance / this.seconds;
        this.vy = dirY / len * distance / this.seconds;
        this.intangible = intangible;
    }

    @Override
    protected void onStart(Player p, Match m) {
        p.face(vx, vy);
    }

    @Override
    protected void onUpdate(double dt, Player p, Match m) {
        p.setPosition(p.getX() + vx * dt, p.getY() + vy * dt);
    }

    @Override
    protected void onEnd(Player p, Match m, boolean cancelled) {
        p.carryMomentum(vx * 0.25, vy * 0.25);
    }

    @Override
    public double duration() { return seconds; }

    @Override
    public boolean isIntangible() { return intangible; }
}
