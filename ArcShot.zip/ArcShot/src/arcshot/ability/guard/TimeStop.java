package arcshot.ability.guard;

import arcshot.ability.Ultimate;
import arcshot.court.Match;
import arcshot.effect.FreezeEffect;
import arcshot.effect.NoShootEffect;
import arcshot.player.Player;

/**
 * Guard R (default): every opponent freezes for 3 s. You may move and pass, but NOT shoot.
 * OOP pillars: <b>INHERITANCE</b> (extends ActiveAbility / Ultimate) and <b>POLYMORPHISM</b> (overrides perform() and the optional hooks).
 */
public class TimeStop extends Ultimate {
    public TimeStop() {
        super("guard.time_stop");
    }

    @Override
    protected void perform(Player owner, Match match) {
        double duration = param("duration", 3);
        for (Player o : match.opponentsOf(owner)) {
            o.applyEffect(new FreezeEffect(duration));
        }
        owner.applyEffect(new NoShootEffect(duration));
        match.tint("timestop", duration);
        match.flash("timestop", 0.2);
        match.fx().ring("timestop", owner.getX(), owner.getY(), 400, 0.6);
    }

    @Override
    public boolean aiShouldUse(Player owner, Match match) {
        return match.getBall().getState() == arcshot.court.Ball.State.HELD;
    }
}
