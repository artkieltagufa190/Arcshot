package arcshot.render;

import arcshot.control.KeyBindings;
import arcshot.cosmetic.Cosmetic;
import arcshot.ui.ThemeSkin;
import java.awt.Color;

/**
 * Display options the renderer needs (skin, accessibility, debug, cosmetics).
 * Plain settings holder; gameplay never reads it.
 * OOP pillar: <b>ENCAPSULATION</b> - private fields with getters and setters.
 */
public final class RenderContext {
    private final ThemeSkin skin;
    private final KeyBindings keys;
    private final Cosmetic courtTheme;
    private final Color auraColor;
    private final String style;
    private volatile boolean colorblind;
    private volatile boolean screenShake;
    private volatile boolean showFps;
    private volatile boolean debug;
    private volatile int fps;

    public RenderContext(ThemeSkin skin, KeyBindings keys, Cosmetic courtTheme, Color auraColor, String style) {
        this.skin = skin;
        this.keys = keys;
        this.courtTheme = courtTheme;
        this.auraColor = auraColor;
        this.style = style;
    }

    public ThemeSkin getSkin() { return skin; }

    public KeyBindings getKeys() { return keys; }

    public Cosmetic getCourtTheme() { return courtTheme; }

    /** Custom aura color for your team, or null to use the team color. */
    public Color getAuraColor() { return auraColor; }

    public String getStyle() { return style; }

    public boolean isColorblind() { return colorblind; }

    public void setColorblind(boolean v) { colorblind = v; }

    public boolean isScreenShake() { return screenShake; }

    public void setScreenShake(boolean v) { screenShake = v; }

    public boolean isShowFps() { return showFps; }

    public void setShowFps(boolean v) { showFps = v; }

    public boolean isDebug() { return debug; }

    public void setDebug(boolean v) { debug = v; }

    public int getFps() { return fps; }

    public void setFps(int fps) { this.fps = fps; }
}
