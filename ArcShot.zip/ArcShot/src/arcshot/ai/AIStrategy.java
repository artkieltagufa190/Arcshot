package arcshot.ai;

import arcshot.court.Court;
import arcshot.court.Match;
import arcshot.player.Player;
import arcshot.player.PlayerClass;

/**
 * Strategy pattern: how a role likes to play. The {@link AIController} state machine decides <i>what</i> to do
 * (attack, support, defend); the strategy decides <i>where</i> and <i>how picky</i> for its role.
 * <p>
 * OOP pillars: <b>ABSTRACTION</b> (abstract spots/thresholds), <b>INHERITANCE</b> and <b>POLYMORPHISM</b>
 * ({@link GuardStrategy}, {@link ForwardStrategy}, {@link BigStrategy} answer differently).
 */
public abstract class AIStrategy {

    public static AIStrategy forClass(PlayerClass pc) {
        switch (pc) {
            case GUARD: return new GuardStrategy();
            case FORWARD: return new ForwardStrategy();
            default: return new BigStrategy();
        }
    }

    /** Where to stand on offense when a teammate has the ball: {angle in degrees, distance from hoop}. */
    protected abstract double[] preferredSpot(boolean leftSide);

    /** Expected points (chance x value) a shot must reach before this role takes it. */
    public abstract double shotValueThreshold();

    /** True if this role goes for offensive rebounds. */
    public abstract boolean crashesBoards();

    /** A spot to support the ball handler, spaced away from teammates. */
    public double[] supportSpot(Player self, Match match) {
        Court court = match.getCourt();
        boolean left = self.getNumber() % 2 == 0;
        double[] pref = preferredSpot(left);
        double[] spot = court.spot(pref[0], pref[1]);
        Player holder = match.getBall().getHolder();
        if (crowded(spot, self, match) || (holder != null && Math.hypot(holder.getX() - spot[0], holder.getY() - spot[1]) < 140)) {
            spot = court.spot(-pref[0], pref[1]); // mirror to the other side of the floor
        }
        return spot;
    }

    private boolean crowded(double[] spot, Player self, Match match) {
        for (Player mate : match.teammatesOf(self)) {
            if (Math.hypot(mate.getX() - spot[0], mate.getY() - spot[1]) < 120) {
                return true;
            }
        }
        return false;
    }

    /** Where to drive: toward the hoop, leaning away from the nearest defender. */
    public double[] driveTarget(Player self, Match match) {
        Court court = match.getCourt();
        double tx = court.getHoopX();
        double ty = court.getHoopY() + 40;
        Player d = match.nearestOpponent(self, 120);
        if (d != null) {
            double side = d.getX() > self.getX() ? -1 : 1;
            tx += side * 70;
        }
        return new double[] {tx, ty};
    }
}
