package arcshot.rules;

import arcshot.player.Player;

/**
 * Base class of all fouls. {@link #resolve} is a <b>Template Method</b>: each foul type supplies its base penalty
 * ({@link #baseFreeThrows}, {@link #basePossession}) and whether the team-foul penalty applies; the common FIBA 3x3
 * team-foul rules (7-9 = 2 FT, 10+ = 2 FT + ball) are applied here once.
 * <p>
 * OOP pillars: <b>ABSTRACTION</b>, <b>INHERITANCE</b> (5 foul types), <b>POLYMORPHISM</b> (the rule engine calls
 * {@code resolve()} on any foul), <b>ENCAPSULATION</b>.
 */
public abstract class Foul {
    private final Player offender;
    private final Player victim;

    protected Foul(Player offender, Player victim) {
        this.offender = offender;
        this.victim = victim;
    }

    public final Player getOffender() { return offender; }

    public final Player getVictim() { return victim; }

    /** Banner text, e.g. "SHOOTING FOUL". */
    public abstract String getName();

    /** Referee animation after the whistle. */
    public String getSignal() { return "signal_foul"; }

    /** How many team fouls this adds (unsportsmanlike = 2). */
    public int teamFoulsAdded() { return 1; }

    /** Whether the 7-9 / 10+ team-foul penalties apply to this foul type. */
    protected boolean usesTeamFoulPenalty() { return true; }

    protected abstract int baseFreeThrows(FoulContext ctx);

    /** Possession after the free throws before the team-foul rules (null = normal flow). */
    protected boolean basePossession(FoulContext ctx) { return false; }

    /** True if the fouled team keeps the ball by check (non-shooting foul with no free throws). */
    protected boolean isTurnover() { return false; }

    /**
     * TEMPLATE METHOD.
     * @param teamFoulsAfter the offender team's foul count including this foul
     */
    public final FoulOutcome resolve(int teamFoulsAfter, FoulContext ctx) {
        int ft = baseFreeThrows(ctx);
        boolean possession = basePossession(ctx);
        if (usesTeamFoulPenalty()) {
            if (teamFoulsAfter >= RulesConfig.possessionFrom()) {
                ft = RulesConfig.bonusFreeThrows();
                possession = true;
            } else if (teamFoulsAfter >= RulesConfig.bonusFrom()) {
                ft = RulesConfig.bonusFreeThrows();
            }
        }
        if (ft <= 0) {
            // no free throws: the fouled team gets a check ball (offensive foul: also a turnover)
            return new FoulOutcome(0, null, null, victim.getSide(), isTurnover());
        }
        return new FoulOutcome(ft, freeThrowShooter(), possession ? victim.getSide() : null, null, false);
    }

    /** Who shoots the free throws (the fouled player by default). */
    protected Player freeThrowShooter() { return victim; }
}
