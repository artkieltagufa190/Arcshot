package arcshot;

import arcshot.app.AppContext;
import arcshot.ui.Theme;
import arcshot.ui.screens.SplashScreen;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

/**
 * Entry point: {@code java -cp out arcshot.App}.
 * Creates the window on the Swing Event Dispatch Thread and shows the splash screen.
 * OOP pillar: <b>ABSTRACTION</b> - main() only starts the app; services live in AppContext.
 */
public final class App {
    private App() { }

    public static void main(String[] args) {
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");
        SwingUtilities.invokeLater(App::start);
    }

    private static void start() {
        Theme.installSwingDefaults();
        JFrame frame = new JFrame("ArcShot - Basketball");
        AppContext app = new AppContext(frame);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                app.quit();
            }
        });
        frame.setContentPane(app.screens());
        frame.setIconImage(icon());
        frame.setMinimumSize(new Dimension(960, 600));
        frame.setSize(initialSize());
        frame.setLocationRelativeTo(null);
        app.screens().replaceAll(new SplashScreen(app));
        frame.setVisible(true);
    }

    /** 1280x720 content if it fits on screen, otherwise 90% of the usable screen. */
    private static Dimension initialSize() {
        Rectangle usable = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
        int w = Theme.LOGICAL_W + 16;
        int h = Theme.LOGICAL_H + 39;
        if (w > usable.width || h > usable.height) {
            double k = Math.min(usable.width * 0.92 / w, usable.height * 0.92 / h);
            w = (int) (w * k);
            h = (int) (h * k);
        }
        return new Dimension(w, h);
    }

    private static BufferedImage icon() {
        BufferedImage img = new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB);
        java.awt.Graphics2D g = img.createGraphics();
        Theme.quality(g);
        g.setColor(Theme.ACCENT);
        g.fillOval(4, 4, 56, 56);
        g.setColor(new Color(60, 28, 10));
        g.setStroke(new java.awt.BasicStroke(3f));
        g.drawOval(4, 4, 56, 56);
        g.drawLine(4, 32, 60, 32);
        g.drawLine(32, 4, 32, 60);
        g.drawArc(-12, 4, 56, 56, -60, 120);
        g.drawArc(20, 4, 56, 56, 120, 120);
        g.dispose();
        return img;
    }
}
