package arcshot.player;

import arcshot.core.Balance;
import arcshot.effect.Reach;

/**
 * The Fighter: balanced, strong mid-range and drives, good rebounder.
 * OOP pillar: <b>INHERITANCE</b> + <b>POLYMORPHISM</b>.
 */
public class Forward extends Player {
    public Forward(String name, int number, TeamSide side, boolean userTeam) {
        super(name, number, side, userTeam, "forward", 222, 72, 68, 60);
    }

    @Override
    public PlayerClass getPlayerClass() { return PlayerClass.FORWARD; }

    @Override
    public double rangeModifier(double distanceToHoop, boolean outsideArc) {
        return outsideArc ? 0.0 : Balance.d("forward.midBonus", 0.04);
    }

    @Override
    public double getMass() { return 1.25; }

    @Override
    public double getGrabHeight() { return Balance.d("forward.grabHeight", 128); }

    @Override
    public double getDunkRange() { return Balance.d("forward.dunkRange", 72); }

    @Override
    protected double classReachFactor(Reach reach) {
        return reach == Reach.REBOUND ? 1.1 : 1.0;
    }
}
