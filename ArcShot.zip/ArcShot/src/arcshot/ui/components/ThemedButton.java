package arcshot.ui.components;

import arcshot.ui.Theme;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.Timer;

/**
 * A custom-painted button with hover, pressed, focused and disabled states, and an optional subtitle line.
 * <p>
 * OOP pillars: <b>INHERITANCE</b> (extends {@link JButton}, so it still works with ActionListeners, keyboard and
 * focus) and <b>POLYMORPHISM</b> (overrides {@code paintComponent} to draw itself differently).
 */
public class ThemedButton extends JButton {

    /** Visual variants. */
    public enum Style { PRIMARY, SECONDARY, GHOST, DANGER }

    private final Style style;
    private final String subtitle;
    private float hover;          // 0..1, animated
    private boolean hovering;
    private final Timer anim;

    public ThemedButton(String text, Style style) {
        this(text, null, style);
    }

    public ThemedButton(String text, String subtitle, Style style) {
        super(text);
        this.style = style;
        this.subtitle = subtitle;
        setContentAreaFilled(false);
        setBorderPainted(false);
        setFocusPainted(false);
        setOpaque(false);
        setRolloverEnabled(true);
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        setFont(Theme.semi(subtitle == null ? 17f : 20f));
        setForeground(Theme.TEXT);
        anim = new Timer(15, e -> animate());
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                hovering = true;
                anim.start();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                hovering = false;
                anim.start();
            }
        });
    }

    private void animate() {
        float target = hovering && isEnabled() ? 1f : 0f;
        hover += (target - hover) * 0.25f;
        if (Math.abs(target - hover) < 0.02f) {
            hover = target;
            anim.stop();
        }
        repaint();
    }

    @Override
    public Dimension getPreferredSize() {
        if (isPreferredSizeSet()) {
            return super.getPreferredSize();
        }
        FontMetrics fm = getFontMetrics(getFont());
        int w = fm.stringWidth(getText()) + Theme.S6 * 2;
        int h = subtitle == null ? 46 : 70;
        if (subtitle != null) {
            w = Math.max(w, getFontMetrics(Theme.body(14)).stringWidth(subtitle) + Theme.S6 * 2);
        }
        return new Dimension(Math.max(140, w), h);
    }

    private Color baseColor() {
        switch (style) {
            case PRIMARY: return Theme.ACCENT;
            case DANGER: return Theme.DANGER;
            case GHOST: return Theme.alpha(Theme.PANEL_HI, 0);
            default: return Theme.PANEL_HI;
        }
    }

    @Override
    protected void paintComponent(Graphics g0) {
        Graphics2D g = (Graphics2D) g0.create();
        Theme.quality(g);
        int w = getWidth();
        int h = getHeight();
        boolean pressed = getModel().isArmed() && getModel().isPressed();
        int lift = pressed ? 0 : Math.round(hover * 2);
        int y = 2 - lift;
        Color base = baseColor();
        if (!isEnabled()) {
            base = Theme.alpha(Theme.LOCKED, 160);
        } else if (style == Style.GHOST) {
            base = Theme.alpha(Theme.PANEL_HI, (int) (hover * 200));
        } else {
            base = Theme.mix(base, Color.WHITE, hover * 0.12 - (pressed ? 0.1 : 0));
        }
        // drop shadow
        g.setColor(new Color(0, 0, 0, 70));
        g.fillRoundRect(0, 4, w, h - 4, Theme.RADIUS_SM * 2, Theme.RADIUS_SM * 2);
        // body with a soft vertical gradient
        g.setPaint(new GradientPaint(0, y, Theme.mix(base, Color.WHITE, 0.08), 0, y + h - 4, base));
        g.fillRoundRect(0, y, w, h - 4, Theme.RADIUS_SM * 2, Theme.RADIUS_SM * 2);
        if (style == Style.SECONDARY || style == Style.GHOST) {
            g.setColor(Theme.mix(Theme.BORDER, Theme.ACCENT, hover));
            g.setStroke(new BasicStroke(1.5f));
            g.drawRoundRect(1, y + 1, w - 3, h - 7, Theme.RADIUS_SM * 2, Theme.RADIUS_SM * 2);
        }
        if (isFocusOwner()) {
            g.setColor(Theme.alpha(Theme.ACCENT_2, 200));
            g.setStroke(new BasicStroke(2f));
            g.drawRoundRect(2, y + 2, w - 5, h - 9, Theme.RADIUS_SM * 2, Theme.RADIUS_SM * 2);
        }
        paintLabel(g, w, y, h - 4);
        g.dispose();
    }

    private void paintLabel(Graphics2D g, int w, int y, int h) {
        Color fg = isEnabled() ? getForeground() : Theme.TEXT_MUTED;
        if (style == Style.PRIMARY && isEnabled()) {
            fg = Color.WHITE;
        }
        g.setColor(fg);
        g.setFont(getFont());
        FontMetrics fm = g.getFontMetrics();
        if (subtitle == null) {
            int tx = (w - fm.stringWidth(getText())) / 2;
            int ty = y + (h + fm.getAscent() - fm.getDescent()) / 2;
            g.drawString(getText(), tx, ty);
            return;
        }
        int tx = Theme.S5;
        g.drawString(getText(), tx, y + h / 2 - 2);
        g.setFont(Theme.body(14));
        g.setColor(isEnabled() ? Theme.alpha(fg, 190) : Theme.TEXT_MUTED);
        g.drawString(subtitle, tx, y + h / 2 + 18);
        // chevron
        g.setColor(Theme.alpha(fg, (int) (120 + 135 * hover)));
        g.setStroke(new BasicStroke(2.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        int cx = w - Theme.S5 + Math.round(hover * 4);
        int cy = y + h / 2;
        g.drawLine(cx - 6, cy - 7, cx, cy);
        g.drawLine(cx, cy, cx - 6, cy + 7);
    }
}
