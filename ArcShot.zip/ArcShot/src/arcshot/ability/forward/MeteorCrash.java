package arcshot.ability.forward;

import arcshot.ability.Ultimate;
import arcshot.core.Balance;
import arcshot.court.Court;
import arcshot.court.Match;
import arcshot.effect.StunEffect;
import arcshot.effect.UnblockableEffect;
import arcshot.player.Player;

/**
 * Forward R (alternate): a huge leap dunk; everyone near the landing is stunned.
 * OOP pillars: <b>INHERITANCE</b> (extends ActiveAbility / Ultimate) and <b>POLYMORPHISM</b> (overrides perform() and the optional hooks).
 */
public class MeteorCrash extends Ultimate {
    private double leapTime;

    public MeteorCrash() {
        super("forward.meteor_crash");
    }

    @Override
    protected boolean meetsRequirements(Player owner, Match match) {
        return hasBall(owner, match) && !match.needsClear()
                && match.getCourt().distanceToHoop(owner.getX(), owner.getY()) <= param("range", 400);
    }

    @Override
    protected void perform(Player owner, Match match) {
        Court c = match.getCourt();
        double dist = c.distanceToHoop(owner.getX(), owner.getY());
        leapTime = param("leapTime", 0.6);
        owner.applyEffect(new UnblockableEffect("meteor", leapTime + 0.5, true));
        owner.startDash(c.getHoopX() - owner.getX(), c.getHoopY() - owner.getY(), Math.max(0, dist - 24), leapTime, true);
        match.fx().text("METEOR CRASH!", "meteor", owner.getX(), owner.getY() - 90);
    }

    @Override
    protected double activeDuration() {
        return leapTime;
    }

    @Override
    protected void whileActive(double dt, Player owner, Match match) {
        match.fx().trail("meteor", owner.getX(), owner.getY() - 40, 14);
    }

    @Override
    protected void onEnd(Player owner, Match match) {
        match.forceDunk(owner, (int) param("points", Balance.i("rules.insidePoints", 1)));
        for (Player o : opponentsNear(owner, match, param("radius", 150))) {
            o.applyEffect(new StunEffect(param("stun", 1.5)));
        }
        match.shake(14);
        match.hitStop(0.1);
        match.fx().ring("meteor", owner.getX(), owner.getY(), param("radius", 150), 0.6);
        match.fx().burst("meteor", owner.getX(), owner.getY(), 30, 300);
    }

    @Override
    public boolean aiShouldUse(Player owner, Match match) {
        return meetsRequirements(owner, match);
    }
}
