package arcshot.reward;

import arcshot.save.Profile;
import arcshot.ui.ThemeSkin;

/**
 * What an achievement gives. Implementations: {@link AbilityUnlock}, {@link PerkUnlock}, {@link CosmeticUnlock},
 * {@link TitleUnlock}.
 * OOP pillars: <b>ABSTRACTION</b> + <b>POLYMORPHISM</b> - the achievement manager just calls {@code grant(profile)}.
 */
public interface Reward {
    /** Gives the reward to the player. */
    void grant(Profile profile);

    /** Text for the achievement screen, e.g. "Ability: Crossover Snap". */
    String describe(ThemeSkin skin);

    /** True if this reward unlocks the given key (used to show "unlocked by ..." in menus). */
    boolean provides(String unlockKey);
}
