package arcshot.ui.screens;

import arcshot.app.AppContext;
import arcshot.ui.Screen;
import arcshot.ui.Theme;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.Timer;

/**
 * Title screen: animated logo, then the main menu after a moment or on any key / click.
 * OOP pillars: <b>INHERITANCE</b> (extends Screen) and <b>POLYMORPHISM</b> (the ScreenManager calls its lifecycle hooks).
 */
public class SplashScreen extends Screen {
    private final Timer timer;
    private double t;
    private boolean done;

    public SplashScreen(AppContext app) {
        super(app);
        setFocusable(true);
        timer = new Timer(16, e -> {
            t += 0.016;
            repaint();
            if (t > 2.6) {
                finish();
            }
        });
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                finish();
            }
        });
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                finish();
            }
        });
    }

    private void finish() {
        if (!done) {
            done = true;
            timer.stop();
            app.showMainMenu();
        }
    }

    @Override
    public void onEnter() {
        timer.start();
    }

    @Override
    public void onExit() {
        timer.stop();
    }

    @Override
    protected void paintComponent(Graphics g0) {
        super.paintComponent(g0);
        Graphics2D g = (Graphics2D) g0.create();
        Theme.quality(g);
        int cx = getWidth() / 2;
        int cy = getHeight() / 2;
        double p = Math.min(1, t / 1.1);
        // ball flying in an arc into the logo
        double bx = cx - 380 + 380 * p;
        double by = cy - 40 - Math.sin(p * Math.PI) * 160;
        g.setColor(Theme.alpha(Theme.ACCENT, 60));
        for (int i = 1; i < 10; i++) {
            double q = Math.max(0, p - i * 0.03);
            g.fillOval((int) (cx - 380 + 380 * q) - 10, (int) (cy - 40 - Math.sin(q * Math.PI) * 160) - 10, 20, 20);
        }
        drawBall(g, bx, by - 70, 26);
        int alpha = (int) (255 * Math.max(0, Math.min(1, (t - 0.6) * 2)));
        g.setFont(Theme.display(120));
        g.setColor(Theme.alpha(Theme.TEXT, alpha));
        Theme.drawCentered(g, "ARCSHOT", cx, cy + 40);
        g.setFont(Theme.semi(20));
        g.setColor(Theme.alpha(Theme.ACCENT, alpha));
        Theme.drawCentered(g, app.skin().text("splash.tagline", "3x3 HALF-COURT SHOWDOWN"), cx, cy + 112);
        g.setFont(Theme.body(14));
        g.setColor(Theme.alpha(Theme.TEXT_MUTED, (int) (alpha * (0.6 + 0.4 * Math.sin(t * 5)))));
        Theme.drawCentered(g, "Press any key", cx, getHeight() - 60);
        String note = app.saves().getLastMessage();
        if (note.startsWith("Save file")) {
            g.setColor(Theme.alpha(Theme.GOLD, alpha));
            Theme.drawCentered(g, note, cx, getHeight() - 90);
        }
        g.dispose();
    }

    static void drawBall(Graphics2D g, double x, double y, double r) {
        g.setColor(Theme.ACCENT);
        g.fillOval((int) (x - r), (int) (y - r), (int) (r * 2), (int) (r * 2));
        g.setColor(new Color(60, 28, 10));
        g.setStroke(new BasicStroke(2.5f));
        g.drawOval((int) (x - r), (int) (y - r), (int) (r * 2), (int) (r * 2));
        g.drawLine((int) (x - r), (int) y, (int) (x + r), (int) y);
        g.drawLine((int) x, (int) (y - r), (int) x, (int) (y + r));
    }
}
