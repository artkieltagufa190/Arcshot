# OOP Mapping – where each pillar lives in ArcShot

Every public class has a Javadoc comment naming the pillar(s) it demonstrates. This page is the summary for the defense.

## 1. Encapsulation – hide the data, expose safe methods

| Class / file | What is hidden and how it is protected |
|---|---|
| `player/Player.java` | The base ratings (speed, shooting, defense, rebound), stamina and ultimate meter are `private`. They change only through controlled methods: `applyEffect()`, `addUltimateCharge()` (clamped to 100, multiplied by perks) and `getEffectiveSpeed()` (base × every effect × sprint). No other class can write `speed = 999`. |
| `save/Profile.java`, `save/Settings.java` | Collections are private and returned as read-only views. `setName()` validates 1–12 characters and `setVolume()` clamps to 0–100, so invalid data can never be saved. |
| `core/Balance.java` | The raw `Properties` object is private. Callers get typed values through `d()/i()/b()`, always with a safe default. |
| `effect/StatusEffect.java` | The remaining time is private and changes only through `update()`, `refresh()`, `scaleDuration()` and `expire()`. |
| `court/Team.java`, `player/PlayerStats.java` | The score and stat counters can only go up through `addPoints()` / `add...()`. |

Encapsulation keeps each object responsible for its own valid state. For example, a status effect can slow a player, but only through `Player`'s rules.

## 2. Inheritance – share code in a base class, specialise in subclasses

| Hierarchy | Files |
|---|---|
| `Player` → `Guard`, `Forward`, `Big` | `player/` |
| `Ability` → `ActiveAbility` / `Ultimate` → 24 concrete abilities | `ability/`, `ability/guard|forward|big/` |
| `StatusEffect` → `SlowEffect`, `FreezeEffect`, `StunEffect`, `BarrierEffect`, `SpeedBoostEffect`, `AccuracyBoostEffect`, `ReachBoostEffect`, `UnblockableEffect`, `GreenLightEffect`, `ShotPenaltyEffect`, `NoShootEffect`, `RimProtectorEffect`, `ColossusEffect` | `effect/` |
| `Achievement` → `CounterAchievement`, `SingleMatchAchievement` → `StreakAchievement`, `ConditionalAchievement`, `CompositeAchievement` | `achievement/` |
| `Perk` → 5 perks | `perk/` |
| `CourtEntity` → `TitanSealField`, `PickScreen`, `Decoy` | `court/` |
| `AIStrategy` → `GuardStrategy`, `ForwardStrategy`, `BigStrategy` | `ai/` |
| `Screen` → 11 screens; `JButton` → `ThemedButton`; `JPanel` → `RoundedPanel` | `ui/` |
| **`GamePanel` → `ScaledMessengerPanel`** (and the original `GameObject` → `Ball`, `Hoop`, `Defender`) | `messenger/` |

Movement, stamina, effects and cooldown timing are written **once** in a base class. For example, `ActiveAbility` handles every cooldown, so each of the 18 Q/E abilities only writes what makes it different. `ScaledMessengerPanel` shows how inheritance extends the original game without changing its code.

## 3. Polymorphism – one call, many behaviours

| Where the call happens | What varies |
|---|---|
| `Match.handleActions()` calls `ability.activate(owner, match)` | The match never knows whether it is Shadow Step or Titan Seal. Each subclass overrides `perform()`. |
| `Player.getEffectiveSpeed()` loops `effect.speedMultiplier()` | `SlowEffect` returns 0.6, `FreezeEffect` returns 0, `SpeedBoostEffect` returns 1.35, every other effect returns the neutral 1.0. |
| `Match.estimateMakeChance()` calls `player.rangeModifier(...)` | The Guard gets a long-range bonus, the Big a close bonus and a long-range penalty, the Forward a mid-range bonus. |
| `Match` calls `controller.fillInput(...)` | `KeyboardController` (human), `AIController` (computer) or `DummyController` (practice). |
| `AchievementManager` calls `achievement.handle(event, ctx)` | Counter, single-match, streak, conditional and composite achievements each count differently. |
| `GameEventBus.publish()` calls `listener.onEvent()` | `AchievementManager`, `CareerStatsTracker`, `HudRenderer` (toasts) and `SoundManager` all react differently. |
| `reward.grant(profile)` | `AbilityUnlock`, `PerkUnlock`, `CosmeticUnlock`, `TitleUnlock` |
| `MainMenuScreen` builds a button per `GameMode` and calls `mode.launch(app)` | 3x3, Classic Shootout, Practice (kept from the original `GameMode` design) |
| `ScreenManager` calls `screen.onEnter()/onExit()` | Every screen starts and stops its own timers and threads. |

## 4. Abstraction – show what, hide how

| Abstract type | What it hides |
|---|---|
| `abstract class Ability` | Uses the **Template Method** pattern. `activate()` is `final` and always runs check → `perform()` → `onActivated()` → publish event. Subclasses fill in only the abstract steps. |
| `abstract class Player`, `StatusEffect`, `Achievement`, `Perk`, `CourtEntity`, `AIStrategy`, `Screen` | Each says *what* every subtype must provide. |
| `interface PlayerController`, `GameEventListener`, `Reward`, `FxSink`, `GameMode`, `AchievementContext` | Callers depend on a small contract, not on a concrete class. |
| `FxSink` | Gameplay asks for an effect by **key** (`"shockwave"`). Only the renderer knows how it looks, which is why switching between the Anime and Street skins never touches gameplay. |
| `AbilityRegistry` + `AbilityFactory` | The game creates abilities from string ids (saved loadouts), never with `new ShadowStep()`. |
| `SaveManager` | The game calls `load()/save()` and never deals with files, temp files or corrupt-file recovery. |

## Design patterns used (bonus points)
Template Method (`Ability.activate`), Observer (`GameEventBus`), Strategy (`AIStrategy`), State machine (`AIController.State`), Factory + Registry (`AbilityFactory`, `PerkRegistry`), Composite (`CompositeAchievement`).

---

## UML class diagram (core hierarchy)

```mermaid
classDiagram
    direction TB

    class Player {
        <<abstract>>
        -double baseSpeed
        -double shooting
        -double defense
        -double rebound
        -double stamina
        -double ultimate
        -List~StatusEffect~ effects
        +update(dt, match)
        +applyEffect(StatusEffect)
        +getEffectiveSpeed() double
        +addUltimateCharge(double)
        +getPlayerClass() PlayerClass*
        +rangeModifier(dist, outside) double*
        +getMass() double*
    }
    Player <|-- Guard
    Player <|-- Forward
    Player <|-- Big
    Player o-- "0..*" StatusEffect
    Player o-- "3" Ability
    Player o-- "0..2" Perk
    Player --> PlayerController

    class Ability {
        <<abstract>>
        -String id
        +activate(owner, match) bool
        +canUse(owner, match) bool
        +update(dt, owner, match)
        +render(g, owner, fx)
        #perform(owner, match)*
        +aiShouldUse(owner, match) bool
    }
    Ability <|-- ActiveAbility
    Ability <|-- Ultimate
    ActiveAbility <|-- ShadowStep
    ActiveAbility <|-- FocusAura
    ActiveAbility <|-- RisingFang
    ActiveAbility <|-- IronWall
    Ultimate <|-- TimeStop
    Ultimate <|-- FinalBurst
    Ultimate <|-- TitanSeal
    note for Ability "activate() is final: the Template Method"
    note for ActiveAbility "18 Q/E abilities in total"
    note for Ultimate "6 ultimates in total"
    AbilityFactory ..> AbilityRegistry
    AbilityFactory ..> Ability : creates

    class StatusEffect {
        <<abstract>>
        -double remaining
        +update(dt)
        +speedMultiplier() double
        +shootingBonus(outside) double
        +reachMultiplier(Reach) double
        +preventsMovement() bool
    }
    StatusEffect <|-- SlowEffect
    StatusEffect <|-- FreezeEffect
    StatusEffect <|-- StunEffect
    StatusEffect <|-- BarrierEffect
    StatusEffect <|-- SpeedBoostEffect
    StatusEffect <|-- ReachBoostEffect

    class PlayerController {
        <<interface>>
        +fillInput(self, match, input, dt)
        +isHuman() bool
    }
    PlayerController <|.. KeyboardController
    PlayerController <|.. AIController
    PlayerController <|.. DummyController
    AIController --> AIStrategy
    AIStrategy <|-- GuardStrategy
    AIStrategy <|-- ForwardStrategy
    AIStrategy <|-- BigStrategy

    class Achievement {
        <<abstract>>
        +handle(event, ctx)*
        +getTarget() int*
        +isComplete(ctx) bool
    }
    Achievement <|-- CounterAchievement
    Achievement <|-- SingleMatchAchievement
    SingleMatchAchievement <|-- StreakAchievement
    Achievement <|-- ConditionalAchievement
    Achievement <|-- CompositeAchievement
    Achievement o-- "1..*" Reward
    class Reward {
        <<interface>>
        +grant(profile)
    }
    Reward <|.. AbilityUnlock
    Reward <|.. PerkUnlock
    Reward <|.. CosmeticUnlock
    Reward <|.. TitleUnlock

    class GameEventListener {
        <<interface>>
        +onEvent(GameEvent)
    }
    GameEventBus o-- "0..*" GameEventListener
    GameEventListener <|.. AchievementManager
    GameEventListener <|.. HudRenderer
    GameEventListener <|.. SoundManager
    GameEventListener <|.. CareerStatsTracker
    AchievementManager o-- "35" Achievement
    Match --> GameEventBus : publishes
    Match o-- "6" Player
    Match --> FxSink
    FxSink <|.. ParticleSystem

    class Screen {
        <<abstract>>
        +onEnter()
        +onResume()
        +onHide()
        +onExit()
    }
    ScreenManager o-- "stack" Screen
    Screen <|-- MainMenuScreen
    Screen <|-- ClassSelectScreen
    Screen <|-- MatchScreen
    Screen <|-- ResultsScreen
    Screen <|-- AchievementsScreen
    Screen <|-- MessengerScreen
    GamePanel <|-- ScaledMessengerPanel
    MessengerScreen --> ScaledMessengerPanel
```

---

## 5. Upgrade pass (v3): new classes and their pillars

| Hierarchy / type | Pillar | Why it matters |
|---|---|---|
| `abstract class Action` → `JumpShotAction`, `LayupAction`, `DunkAction`, `BlockAction`, `StealAction`, `PassAction`, `DashAction`, `SimpleAction` (`action/`) | **Inheritance**, **Polymorphism**, **Template Method** | `Action.update()` is written once: it advances time, fires each frame event once, and ends or cancels the action. Subclasses only override the hooks `onStart`, `onEvent`, `onUpdate`, `onEnd` and `getZ`. `ActionController` calls `current.update()` and never checks which action it is. |
| `ActionController`, `ActionType` | **Encapsulation** | The single "current action" field is private. The only way to change it is `request()`, which checks priority and interruptibility. Abilities, AI and input all go through it, so two actions can never overlap. |
| `abstract class Foul` → `ShootingFoul`, `PersonalFoul`, `OffensiveFoul`, `TechnicalFoul`, `UnsportsmanlikeFoul` (`rules/`) | **Inheritance**, **Polymorphism**, **Template Method** | `Foul.resolve()` is `final` and applies the team-foul bonus rules the same way for every foul. Each subclass overrides only `baseFreeThrows()`, `teamFoulsAdded()`, `getSignal()`, `usesTeamFoulPenalty()`, etc. |
| `RuleEngine`, `RulesConfig`, `FoulDetector`, `FreeThrowSequence` | **Abstraction**, **Encapsulation** | `Match` asks "what does this foul give?" and receives a `FoulOutcome`. The rule numbers live only in `RulesConfig` (backed by `balance.properties`). |
| `interface CourtBody` ← `Player`, `abstract CourtActor` → `Referee` (`court/`, `referee/`) | **Abstraction**, **Inheritance** | The renderer and the depth sort only need x / y / z. Players and referees share that contract, and `CourtActor` shares the walking, facing and animation code with every non-player court figure. |
| `Court` → `CourtGeometry` | **Inheritance** | Adds the backboard, free-throw spots, dunk and layup spots and referee spots on top of the v2 court, without editing its measurements. Rules, AI and both renderers read the same object. |
| `MatchPhase` + `PhaseMachine` | **Encapsulation** (state machine) | Every phase change is validated against a table. Each phase says whether input, abilities, AI and the clock may run. |
| `Ball.giveTo(player, reason)` | **Encapsulation** | The only method that changes the ball's owner. It refuses while a shot is in the air, and `validate()` checks the invariants. |
| `interface MatchView` ← `MatchRenderer` (smooth) and `RetroMatchRenderer` (pixel) | **Abstraction**, **Polymorphism** | `MatchScreen` draws "a `MatchView`". The Settings option picks the class at runtime. |
| `FxSink` ← `ParticleSystem` and `RetroParticles` | **Polymorphism** | No ability code changed for the retro look: abilities still ask for `"shockwave"`, and the retro sink draws it in pixels. |
| `GameEventListener` ← `RetroHud` | **Polymorphism** (Observer) | Toasts and the commentary ticker come from events, so gameplay never calls the HUD. |
| `SpriteLoader` / `SpriteSheet` / `Palette` / `AnimatedSprite` (`render/sprite/`) | **Abstraction**, **Encapsulation** | "Give me the Guard sheet in these colors." Loading, the manifest, mask recoloring, mirroring and caching are hidden. |
| `FreeThrowAim` | **Encapsulation** | The arc-arrow state (power, sway) and its grading formula live in one class. Renderers only read them. |
| `AnimationTable` / `AnimationDef` | **Encapsulation** | Frame counts, fps and frame events in one place, overridable from the manifest. |
| `SelfTests` | (testing) | A table-driven rule test plus invariant checks on headless matches. |

New patterns: **State machine** (`PhaseMachine`, the ball states), **Template Method** (`Action.update`, `Foul.resolve`), **Command / queue** (`Interaction`s resolved in priority order), **Flyweight-style cache** (recolored sprite sheets are shared per palette).

```mermaid
classDiagram
    direction LR
    class Action {
        <<abstract>>
        +update(dt, player, match)
        #onStart()
        #onEvent(name)
        #onEnd(cancelled)
        +getZ() double
    }
    Action <|-- JumpShotAction
    Action <|-- LayupAction
    Action <|-- DunkAction
    Action <|-- BlockAction
    Action <|-- StealAction
    Action <|-- PassAction
    Action <|-- DashAction
    Action <|-- SimpleAction
    ActionController o-- "0..1" Action : current
    Player *-- ActionController

    class Foul {
        <<abstract>>
        +resolve(teamFouls, ctx) FoulOutcome
        #baseFreeThrows(ctx) int
    }
    Foul <|-- ShootingFoul
    Foul <|-- PersonalFoul
    Foul <|-- OffensiveFoul
    Foul <|-- TechnicalFoul
    Foul <|-- UnsportsmanlikeFoul
    RuleEngine --> Foul : assess
    FoulDetector --> Foul : creates

    class CourtBody {
        <<interface>>
        +getX() double
        +getY() double
        +getZ() double
    }
    CourtBody <|.. Player
    CourtBody <|.. CourtActor
    CourtActor <|-- Referee
    RefereeCrew o-- "2" Referee
    Court <|-- CourtGeometry

    class MatchView {
        <<interface>>
        +render(g, match, w, h)
        +getFx() FxSink
    }
    MatchView <|.. MatchRenderer
    MatchView <|.. RetroMatchRenderer
    FxSink <|.. RetroParticles
    RetroMatchRenderer --> RetroHud
    RetroMatchRenderer --> SpriteLoader
```
