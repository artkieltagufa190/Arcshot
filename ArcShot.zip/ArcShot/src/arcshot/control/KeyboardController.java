package arcshot.control;

import arcshot.court.Match;
import arcshot.player.Player;
import java.util.EnumMap;
import java.util.Map;

/**
 * Human control through the keyboard, using rebindable {@link KeyBindings}.
 * A second instance with other bindings is all local multiplayer would need.
 * OOP pillar: <b>POLYMORPHISM</b> - one implementation of {@link PlayerController}.
 */
public final class KeyboardController implements PlayerController {
    private final KeyboardState keyboard;
    private final KeyBindings bindings;
    private final Map<InputAction, Integer> seenPresses = new EnumMap<>(InputAction.class);

    public KeyboardController(KeyboardState keyboard, KeyBindings bindings) {
        this.keyboard = keyboard;
        this.bindings = bindings;
        for (InputAction a : InputAction.values()) {
            seenPresses.put(a, keyboard.pressCount(bindings.keyFor(a)));
        }
    }

    private boolean down(InputAction a) {
        return keyboard.isDown(bindings.keyFor(a));
    }

    /** True once per key press. */
    public boolean pressed(InputAction a) {
        int now = keyboard.pressCount(bindings.keyFor(a));
        int before = seenPresses.get(a);
        seenPresses.put(a, now);
        return now != before;
    }

    @Override
    public void fillInput(Player self, Match match, PlayerInput out, double dt) {
        double x = 0;
        double y = 0;
        if (down(InputAction.MOVE_LEFT)) {
            x -= 1;
        }
        if (down(InputAction.MOVE_RIGHT)) {
            x += 1;
        }
        if (down(InputAction.MOVE_UP)) {
            y -= 1;
        }
        if (down(InputAction.MOVE_DOWN)) {
            y += 1;
        }
        out.setMove(x, y);
        out.setSprint(down(InputAction.SPRINT));
        // a press shorter than one frame still counts as "held" for that frame
        out.setShootHeld(down(InputAction.SHOOT) || pressed(InputAction.SHOOT));
        out.setPassPressed(pressed(InputAction.PASS));
        out.setQPressed(pressed(InputAction.ABILITY_Q));
        out.setEPressed(pressed(InputAction.ABILITY_E));
        out.setRPressed(pressed(InputAction.ULTIMATE));
        out.setSwitchPressed(pressed(InputAction.SWITCH));
    }

    @Override
    public boolean isHuman() {
        return true;
    }
}
