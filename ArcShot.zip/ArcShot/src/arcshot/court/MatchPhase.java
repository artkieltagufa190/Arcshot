package arcshot.court;

/**
 * The phase of a match. Input, abilities, AI and the clock each ask the current phase whether they may run.
 * (PAUSED is applied by the match screen, which simply stops stepping the match; it is listed for completeness.)
 * OOP pillar: <b>ENCAPSULATION</b> - each constant carries its permission flags in private fields.
 */
public enum MatchPhase {
    CHECK_BALL(false, false, false, false),
    LIVE(true, true, true, true),
    SHOT_IN_AIR(true, true, true, true),
    DEAD_BALL(false, false, false, false),
    FOUL_CALLED(false, false, false, false),
    FREE_THROW(false, true, false, true),
    OVERTIME_BREAK(false, false, false, false),
    PAUSED(false, false, false, false),
    GAME_OVER(false, false, false, false);

    private final boolean clockRuns;
    private final boolean inputAllowed;
    private final boolean abilitiesAllowed;
    private final boolean aiAllowed;

    MatchPhase(boolean clockRuns, boolean inputAllowed, boolean abilitiesAllowed, boolean aiAllowed) {
        this.clockRuns = clockRuns;
        this.inputAllowed = inputAllowed;
        this.abilitiesAllowed = abilitiesAllowed;
        this.aiAllowed = aiAllowed;
    }

    public boolean clockRuns() { return clockRuns; }

    public boolean allowsInput() { return inputAllowed; }

    public boolean allowsAbilities() { return abilitiesAllowed; }

    public boolean allowsAI() { return aiAllowed; }

    /** LIVE or SHOT_IN_AIR: normal play. */
    public boolean isPlay() { return this == LIVE || this == SHOT_IN_AIR; }
}
