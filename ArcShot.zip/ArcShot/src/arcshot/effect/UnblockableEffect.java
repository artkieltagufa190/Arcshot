package arcshot.effect;

/**
 * Shots cannot be blocked; optionally the player also passes through defenders.
 * OOP pillars: <b>INHERITANCE</b> (extends StatusEffect) and <b>POLYMORPHISM</b> (overrides only the modifiers it changes).
 */
public class UnblockableEffect extends StatusEffect {
    private final boolean intangible;

    public UnblockableEffect(String id, double duration, boolean intangible) {
        super(id, duration, false);
        this.intangible = intangible;
    }

    @Override
    public boolean isUnblockable() { return true; }

    @Override
    public boolean isIntangible() { return intangible; }
}
