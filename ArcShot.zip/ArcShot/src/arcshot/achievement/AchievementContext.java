package arcshot.achievement;

/**
 * What an achievement may read/write while tracking progress (implemented by {@link AchievementManager}).
 * OOP pillar: <b>ABSTRACTION</b> - achievements never touch the save file directly.
 */
public interface AchievementContext {
    int getProgress(String id);

    void setProgress(String id, int value);

    boolean isUnlocked(String id);
}
