package arcshot.messenger;

/** Holds the player's name and stats. ENCAPSULATION: everything is private and validated. */
public class Player {
    private String name;
    private int score;
    private int shotsTaken;
    private int shotsMade;
    private int streak;
    private int bestStreak;

    public Player(String name) {
        setName(name);
    }

    public String getName() { return name; }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Name cannot be empty.");
        }
        if (name.trim().length() > 12) {
            throw new IllegalArgumentException("Name must be 12 characters or fewer.");
        }
        this.name = name.trim();
    }

    public void addScore(int points) {
        if (points <= 0) {
            throw new IllegalArgumentException("Points must be positive.");
        }
        score += points;
    }

    /** Record the result of one finished shot. */
    public void recordShot(boolean made) {
        shotsTaken++;
        if (made) {
            shotsMade++;
            streak++;
            bestStreak = Math.max(bestStreak, streak);
        } else {
            streak = 0;
        }
    }

    public void resetStats() {
        score = 0;
        shotsTaken = 0;
        shotsMade = 0;
        streak = 0;
        bestStreak = 0;
    }

    public int getAccuracyPercent() {
        return shotsTaken == 0 ? 0 : Math.round(100f * shotsMade / shotsTaken);
    }

    public int getScore() { return score; }
    public int getShotsTaken() { return shotsTaken; }
    public int getShotsMade() { return shotsMade; }
    public int getStreak() { return streak; }
    public int getBestStreak() { return bestStreak; }
}
