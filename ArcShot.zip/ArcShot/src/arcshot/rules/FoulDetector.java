package arcshot.rules;

import arcshot.action.ActionType;
import arcshot.core.Balance;
import arcshot.court.Match;
import arcshot.effect.Reach;
import arcshot.player.Player;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * Decides whether contact is a foul. Called at animation contact moments (shot takeoff/release, steal swipe),
 * on body collisions, and when a foulable ability hits someone. It uses distance, the defender's action, the ball
 * handler's speed and a seeded random number (so a test run is repeatable). A referee must see the play.
 * <p>
 * Ability policy: abilities are LEGAL ("superpower rule") except those listed in {@code foul.foulableAbilities}.
 * OOP pillar: <b>ABSTRACTION</b> - the match asks "is this a foul?" and receives a {@link Foul} or null.
 */
public final class FoulDetector {
    private final Random rng;
    private final FoulFrequency frequency;
    private final boolean strict;
    private final Map<String, Double> pairCooldown = new HashMap<>();

    public FoulDetector(long seed, FoulFrequency frequency, boolean strict) {
        this.rng = new Random(seed);
        this.frequency = frequency;
        this.strict = strict;
    }

    private double scale() {
        return frequency.getMultiplier() * (strict ? 1.4 : 1.0);
    }

    public void tick(double dt) {
        for (Map.Entry<String, Double> e : pairCooldown.entrySet()) {
            e.setValue(e.getValue() - dt);
        }
    }

    private boolean roll(double p, Match m, double x, double y) {
        if (p <= 0 || rng.nextDouble() >= Math.min(0.95, p)) {
            return false;
        }
        return m.getRefs().sees(x, y) || rng.nextDouble() < Balance.d("ref.unseenCallChance", 0.25);
    }

    /** Contact on a shooter at takeoff (jump shot, layup, dunk). */
    public Foul checkShooting(Player shooter, String kind, Match m) {
        if (frequency == FoulFrequency.OFF) {
            return null;
        }
        double base = Balance.d("foul.shooting." + kind, "dunk".equals(kind) ? 0.22 : ("layup".equals(kind) ? 0.26 : 0.12));
        double radius = Balance.d("foul.contactRadius", 42);
        Player best = null;
        double bestP = 0;
        for (Player d : m.opponentsOf(shooter)) {
            double dist = d.distanceTo(shooter);
            if (dist > radius || !d.canAct()) {
                continue;
            }
            double p = base * scale() * (1 - dist / radius) * 2;
            ActionType t = d.getActions().getType();
            if (t == ActionType.BLOCK) {
                p *= 1.3; // mistimed block attempts are the classic shooting foul
            }
            if (p > bestP) {
                bestP = p;
                best = d;
            }
        }
        if (best != null && roll(bestP, m, shooter.getX(), shooter.getY())) {
            return new ShootingFoul(best, shooter);
        }
        return null;
    }

    /** Reach-in check on a steal swipe (from behind is much more likely to be called). */
    public Foul checkStealSwipe(Player thief, Player holder, boolean stole, Match m) {
        if (frequency == FoulFrequency.OFF || holder == null) {
            return null;
        }
        double toThiefX = thief.getX() - holder.getX();
        double toThiefY = thief.getY() - holder.getY();
        double len = Math.max(1, Math.hypot(toThiefX, toThiefY));
        double dot = (toThiefX * holder.getFacingX() + toThiefY * holder.getFacingY()) / len;
        boolean fromBehind = dot < -0.3;
        double p = Balance.d("foul.reachIn", 0.10) * scale() * (fromBehind ? 2.5 : 0.7) * (stole ? 0.4 : 1.0);
        if (thief.distanceTo(holder) > thief.getReach(Reach.STEAL) * 1.1) {
            return null; // nothing touched
        }
        return roll(p, m, holder.getX(), holder.getY()) ? new PersonalFoul(thief, holder, "REACH-IN") : null;
    }

    /** Body contact between a ball handler and a defender (charge or blocking foul). */
    public Foul checkBodyContact(Player a, Player b, Match m) {
        if (frequency == FoulFrequency.OFF || a.getSide() == b.getSide()) {
            return null;
        }
        Player holder = m.getBall().getHolder();
        if (holder != a && holder != b) {
            return null;
        }
        Player d = holder == a ? b : a;
        String key = holder.getNumber() + ":" + d.getNumber() + ":" + d.getSide();
        Double cd = pairCooldown.get(key);
        if (cd != null && cd > 0) {
            return null;
        }
        pairCooldown.put(key, 1.5);
        // only a real dash counts as "driving through" (layups/dunks are judged by the shooting-foul check)
        boolean dashing = holder.isDashing();
        double hs = Math.hypot(holder.getVx(), holder.getVy()) + (dashing ? 300 : 0);
        double ds = Math.hypot(d.getVx(), d.getVy());
        if (hs > 230 && ds < 60 && d.getActions().getType() == ActionType.DEFENSIVE_STANCE) {
            double p = Balance.d("foul.charge", 0.12) * scale();
            return roll(p, m, d.getX(), d.getY()) ? new OffensiveFoul(holder, d) : null;
        }
        if (ds > 170 && ds > hs) {
            double p = Balance.d("foul.blocking", 0.12) * scale();
            return roll(p, m, holder.getX(), holder.getY()) ? new PersonalFoul(d, holder, "BLOCKING FOUL") : null;
        }
        return null;
    }

    /** A foulable ability (e.g. Quake Fist, Bull Rush) hit an opponent. Other abilities are legal. */
    public Foul checkAbility(Player owner, String abilityId, Match m) {
        if (frequency == FoulFrequency.OFF || !RulesConfig.isFoulableAbility(abilityId)) {
            return null;
        }
        Player victim = m.nearestOpponent(owner, Balance.d("foul.abilityRadius", 110));
        if (victim == null) {
            return null;
        }
        double p = Balance.d("foul.ability", 0.25) * scale();
        if (!roll(p, m, victim.getX(), victim.getY())) {
            return null;
        }
        if (strict && victim.hasEffect("freeze")) {
            return new TechnicalFoul(owner, victim); // hitting a frozen player: unsporting behaviour
        }
        if (m.getBall().getHolder() == owner) {
            return new OffensiveFoul(owner, victim);
        }
        if (victim.getActions().isAirborne() && rng.nextDouble() < Balance.d("foul.flagrantShare", 0.3)) {
            return new UnsportsmanlikeFoul(owner, victim);
        }
        return new PersonalFoul(owner, victim, "PERSONAL FOUL");
    }

    /** Seeded random numbers for other rule decisions (free-throw AI, etc.). */
    public Random random() { return rng; }
}
