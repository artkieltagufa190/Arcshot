package arcshot.control;

import arcshot.court.Match;
import arcshot.player.Player;

/**
 * Practice-mode dummy: stands still and does nothing. Simplest possible {@link PlayerController}.
 * OOP pillar: <b>POLYMORPHISM</b> - implements PlayerController.
 */
public final class DummyController implements PlayerController {
    @Override
    public void fillInput(Player self, Match match, PlayerInput out, double dt) {
        out.clear();
    }

    @Override
    public boolean isHuman() {
        return false;
    }
}
