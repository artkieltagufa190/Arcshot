# Visual spec (retro style)

The reference image is a late-90s / early-2000s console broadcast view. It is used as a **style guide only**.
No real league or game logos, team names or player likenesses are copied: every team, sponsor and logo in
ArcShot is fictional.

## Camera and buffer

- The match is drawn into a **640 x 360** buffer (`Projection.W/H`). `GameCanvas` scales it up by a
  **whole number** with nearest-neighbour sampling and letterboxes the rest: 2x at 1280 x 720, 3x at
  1920 x 1080. There is no smoothing anywhere.
- **Angled broadcast camera behind the half-court line**, looking at the hoop. The far baseline (hoop end)
  is narrower and higher on screen. `Projection` maps a court point (x, y) plus height z to the screen:
  - far baseline scale 0.50, near edge scale 0.70;
  - the floor is slightly curved in depth;
  - z lifts things up, scaled by depth.

  The camera never changes game logic: gameplay stays in court coordinates.
- Depth sort, back to front:
  1. backboard (at its own floor depth);
  2. back half of the rim;
  3. players, referees, decoys and the free ball, sorted by court y;
  4. front half of the rim and the net.

  A ball dropping through the hoop is placed between the two rim halves. Shadows are drawn on the floor
  before the sorted list.

## Sprites

- 48 x 64 frames. Characters stand about 46–54 px tall: Guard shortest and slim, Forward athletic, Big tallest
  and broad.
- 1 px dark outline `#141018`, 3 hard tones per material (light, base, dark), no anti-aliasing.
- Facings: back, front and side (mirrored for left).
- The jersey number is drawn in a 3x5 micro font at the number anchor, on the front and back views.
- Team colors come from mask recoloring (see `resources/sprites/README.md`).

## Palette (32 colors)

| Use | Hex |
|---|---|
| Outline | `#141018` |
| Arena dark | `#0B0F1E` |
| Stands A / B | `#1A2140`, `#2A2D3A` |
| HUD panel / panel light / edge | `#0B0F1E`, `#1A2140`, `#4A4F66` |
| HUD white / muted | `#F4F4F0`, `#9AA0B4` |
| Gold (clock, bonus pips, ult) | `#F4CC3A` |
| Green (release, stamina) | `#2ECC40` |
| Red (danger, bonus light, rim) | `#D8462A` |
| Rim dark | `#9C2A18` |
| Cyan (control marker, key labels) | `#5FD3F0` |
| Backboard / shade | `#E8ECF2`, `#C9CED8` |
| Board padding | `#1E73C8` |
| Stanchion | `#A02828` |
| Ball / dark / light | `#E8742A`, `#A04A18`, `#F8A860` |
| Center logo / dark | `#E8742A`, `#3A1E10` |
| Net | `#F4F4F0` |
| Skin tones | `#5C3A26`, `#8A5A3C`, `#C68A5E`, `#E8B890`, `#6E4630` |
| Hair tones | `#1E1410`, `#2A1A10`, `#3A2414` |
| Sponsor boards | `#D8462A`, `#1E73C8`, `#2ECC40`, `#E8742A`, `#5B3A8C` |

The hardwood, lines, paint and apron colors come from the selected **court cosmetic**: floor = color 0,
lines = 1, paint = 2, apron = 3. Every court unlock therefore also works in the retro view.

## Court

- Hardwood with vertical plank lines (every 3rd plank lighter) and staggered plank ends.
- A dithered diagonal **sheen** band, baked once into a cached image.
- Painted key in the court's paint color, plus a darker strip under the basket.
- Lines:
  - 2 px sidelines and baseline;
  - free-throw circle: front half solid, back half dashed;
  - restricted-area arc;
  - 3x3 arc with corner straights;
  - check/clear tick at the top of the arc.
- Big orange **ARCSHOT** ball logo at the center of the near side.
- Apron in the court's apron color. Around it:
  - a row of 5 fictional sponsor boards along the far apron: KALAMANSI COLA, BAYANIHAN BANK,
    JEEPNEY EXPRESS, SARI-SARI MART, HALO-HALO HUT;
  - benches on both sides;
  - tiered stands filled with 2x2 crowd pixels, darker toward the top.
- Stanchion with pole and arm, backboard with blue padding and a shooter's square that flashes green on
  makes.
- Rim drawn as two half-ellipses. The net strands swing after a make (`netSwing`), and the rim dips after a
  dunk (`rimBend`).

## HUD (all in the 5x7 bitmap `PixelFont`)

- **Scoreboard, bottom right** (like the reference):
  - header row: period (1ST / OT / PRAC), game clock, and a shot-clock box that turns red at 4 s;
  - one row per team: color tab, 3-letter abbreviation, possession dot, 6 team-foul pips, then a red
    **BONUS** light or `F#`, and the score.
- **Player card, bottom left:** number tile, name, class, stamina and ultimate bars, and Q/E/R tiles. Each
  tile has a key tab and a cooldown shutter that drops in 2 px steps. A tile goes grey when the ability is
  ready but not allowed right now. The ultimate frame blinks gold when the ultimate is ready.
- **Jump-shot meter:** vertical, chunky, beside the shooter. It shows a green window and turns white in the
  green.
- **Free-throw aim:** an arc arrow from the shooter's hands that hooks over onto the rim, as in the
  reference. It grows while SHOOT is held and sways left and right on its own. Red = off, yellow = close,
  green = on the rim. "FREE THROW n OF m" is shown at the top.
- **Banners:** a band slides open from the center with large pixel text (FOUL, AND ONE!, SHOT CLOCK...).
  Free-throw banners are skipped so the shooter stays visible.
- **Text pops at the action:** GREEN / GOOD / EARLY / LATE, SWISH, BLOCKED!, STEAL!, FOUL!, +1 / +2.
- **Commentary ticker** above the scoreboard and **achievement toasts** on the right.
- **Controlled player:** a cyan ring under the feet, a bouncing arrow above the head, and the name under
  the feet.
- **Heat streak:** pixel flames above the head and "HOT" on the player card.

## Effects

- Square 1–2 px sparks with gravity.
- Dithered floor rings.
- Afterimages: the real sprite frame tinted and flickering.
- Zones: a dotted outline with a checkerboard fill.
- Freeze: an ice-tinted sprite.
- Stun: a white flash on alternate frames plus circling stars.
- Screen tint and flash in hard steps (full, half, off).
- Screen shake: integer pixel offsets.
- Optional **CRT scanlines** (Settings), off by default.
