Pixel-art sprites: ball.png (22x22), backboard.png (26x19),
rim_back.png (25x4) + rim_front.png (25x14, rim front and net), plus *_hit.png green versions shown when you score.
Edit them in any pixel editor (keep the same sizes). If a file is missing, the game draws default shapes.
Run the game from the project folder so Java can find this images folder.
