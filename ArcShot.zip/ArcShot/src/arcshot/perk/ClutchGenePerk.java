package arcshot.perk;

import arcshot.core.Balance;
import arcshot.court.Match;
import arcshot.player.Player;

/**
 * Shooting bonus in the last 30 seconds and in overtime.
 * OOP pillars: <b>INHERITANCE</b> (extends Perk) and <b>POLYMORPHISM</b> (overrides one hook).
 */
public class ClutchGenePerk extends Perk {
    public ClutchGenePerk() {
        super("clutch_gene", "Clutch Gene", "+8% shooting in the last 30s and overtime");
    }

    @Override
    public double shootingBonus(Player player, Match match) {
        boolean clutch = match.isOvertime() || match.getClockRemaining() <= Balance.d("perk.clutch_gene.seconds", 30);
        return clutch ? Balance.d("perk.clutch_gene.bonus", 0.08) : 0.0;
    }
}
