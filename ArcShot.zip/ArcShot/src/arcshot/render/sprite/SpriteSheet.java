package arcshot.render.sprite;

import arcshot.anim.Facing;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * One recolored character sheet plus its manifest data: frame size, feet origin, the row of every animation, and
 * per-frame anchor points (hand = where the ball goes, number = jersey number, head = name tag / effects).
 * Rows are {@code animIndex * 3 + facing} (BACK, FRONT, SIDE); SIDE facing left uses the mirrored copy.
 * OOP pillar: <b>ENCAPSULATION</b> - images and anchor tables are private; use {@link #frame} and the anchor getters.
 */
public final class SpriteSheet {
    private final BufferedImage image;
    private final BufferedImage flipped;
    private final int frameW;
    private final int frameH;
    private final int originX;
    private final int originY;
    private final Map<String, Integer> rows = new HashMap<>();
    private final Map<String, int[][]> anchors = new HashMap<>();

    SpriteSheet(BufferedImage image, Properties manifest) {
        this.image = image;
        this.frameW = Integer.parseInt(manifest.getProperty("frameWidth", "48"));
        this.frameH = Integer.parseInt(manifest.getProperty("frameHeight", "64"));
        this.originX = Integer.parseInt(manifest.getProperty("originX", "24"));
        this.originY = Integer.parseInt(manifest.getProperty("originY", "61"));
        for (String anim : manifest.getProperty("anims", "").split(",")) {
            if (anim.isEmpty()) {
                continue;
            }
            rows.put(anim, Integer.parseInt(manifest.getProperty(anim + ".row", "0")));
            for (Facing f : Facing.values()) {
                String fk = f.name().toLowerCase();
                for (String kind : new String[] {"hand", "number", "head"}) {
                    anchors.put(kind + "." + anim + "." + fk, parse(manifest.getProperty(anim + "." + kind + "." + fk, "")));
                }
            }
        }
        flipped = mirror(image, frameW);
    }

    private SpriteSheet(SpriteSheet base, BufferedImage recolored) {
        this.image = recolored;
        this.frameW = base.frameW;
        this.frameH = base.frameH;
        this.originX = base.originX;
        this.originY = base.originY;
        this.rows.putAll(base.rows);
        this.anchors.putAll(base.anchors);
        this.flipped = mirror(recolored, frameW);
    }

    /** Same layout and anchors, different pixels (recolored / tinted copy). */
    SpriteSheet withImage(BufferedImage recolored) {
        return new SpriteSheet(this, recolored);
    }

    BufferedImage getImage() { return image; }

    private static int[][] parse(String spec) {
        if (spec.isEmpty() || "null".equals(spec)) {
            return new int[0][];
        }
        String[] parts = spec.split(";");
        int[][] out = new int[parts.length][];
        for (int i = 0; i < parts.length; i++) {
            String[] xy = parts[i].split(",");
            out[i] = new int[] {Integer.parseInt(xy[0].trim()), Integer.parseInt(xy[1].trim())};
        }
        return out;
    }

    private static BufferedImage mirror(BufferedImage src, int fw) {
        BufferedImage out = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_ARGB);
        int cols = src.getWidth() / fw;
        for (int c = 0; c < cols; c++) {
            for (int y = 0; y < src.getHeight(); y++) {
                for (int x = 0; x < fw; x++) {
                    out.setRGB(c * fw + (fw - 1 - x), y, src.getRGB(c * fw + x, y));
                }
            }
        }
        return out;
    }

    public boolean has(String anim) { return rows.containsKey(anim); }

    /** The frame image. {@code flip} mirrors (SIDE facing left). */
    public BufferedImage frame(String anim, Facing facing, int frame, boolean flip) {
        Integer base = rows.get(anim);
        if (base == null) {
            base = rows.containsKey("idle") ? rows.get("idle") : 0;
            frame = 0;
        }
        int row = base + facing.ordinal();
        int col = Math.max(0, frame);
        if ((col + 1) * frameW > image.getWidth()) {
            col = 0;
        }
        return (flip ? flipped : image).getSubimage(col * frameW, row * frameH, frameW, frameH);
    }

    /** Anchor offset from the feet {x, y}, already mirrored when flipped. kind = hand / number / head. */
    public int[] anchor(String kind, String anim, Facing facing, int frame, boolean flip) {
        int[][] a = anchors.get(kind + "." + anim + "." + facing.name().toLowerCase());
        if (a == null || a.length == 0) {
            return new int[] {0, -frameH / 2};
        }
        int[] p = a[Math.max(0, Math.min(a.length - 1, frame))];
        return new int[] {flip ? -p[0] : p[0], p[1]};
    }

    public int getOriginX() { return originX; }

    public int getOriginY() { return originY; }

    public int getFrameW() { return frameW; }

    public int getFrameH() { return frameH; }
}
