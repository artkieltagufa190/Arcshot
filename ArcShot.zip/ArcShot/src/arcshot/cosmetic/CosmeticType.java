package arcshot.cosmetic;

/**
 * The categories on the Customize screen.
 * OOP pillar: <b>ENCAPSULATION</b> - each enum constant keeps its data in private fields behind getters.
 */
public enum CosmeticType {
    JERSEY("Jersey color"), AURA("Aura color"), STYLE("Player style"), COURT("Court theme");

    private final String label;

    CosmeticType(String label) {
        this.label = label;
    }

    public String getLabel() { return label; }
}
