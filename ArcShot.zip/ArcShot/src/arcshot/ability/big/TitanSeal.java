package arcshot.ability.big;

import arcshot.ability.Ultimate;
import arcshot.court.Court;
import arcshot.court.Match;
import arcshot.court.TitanSealField;
import arcshot.player.Player;

/**
 * Big R (default): a 6 s field around the hoop; opponents inside are slowed and shoot badly.
 * OOP pillars: <b>INHERITANCE</b> (extends ActiveAbility / Ultimate) and <b>POLYMORPHISM</b> (overrides perform() and the optional hooks).
 */
public class TitanSeal extends Ultimate {
    public TitanSeal() {
        super("big.titan_seal");
    }

    @Override
    protected void perform(Player owner, Match match) {
        Court c = match.getCourt();
        match.addEntity(new TitanSealField(owner, c.getHoopX(), c.getHoopY() + 40, param("radius", 170),
                param("duration", 6), param("slow", 0.6), param("penalty", 0.25)));
        match.flash("titan_seal", 0.25);
        match.shake(6);
        match.fx().ring("titan_seal", c.getHoopX(), c.getHoopY() + 40, param("radius", 170), 0.6);
    }

    @Override
    public boolean aiShouldUse(Player owner, Match match) {
        return opponentHasBall(owner, match) && match.getCourt().distanceToHoop(
                match.getBall().getHolder().getX(), match.getBall().getHolder().getY()) < 360;
    }
}
