package arcshot.court;

import arcshot.ai.Difficulty;
import arcshot.player.Player;
import arcshot.player.PlayerClass;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The final result of a match, sent with MATCH_FINISHED. Used by the results screen and by conditional
 * achievements ("win allowing 10 or fewer", "comeback from 6 down", ...).
 * OOP pillar: <b>ENCAPSULATION</b> - immutable after construction.
 */
public final class MatchSummary {
    private final boolean won;
    private final int userScore;
    private final int opponentScore;
    private final int maxDeficit;
    private final Difficulty difficulty;
    private final PlayerClass mainClass;
    private final boolean overtime;
    private final boolean practice;
    private final boolean cooldownWaste;
    private final double secondsPlayed;
    private final List<Player> userPlayers;
    private final List<Player> opponentPlayers;
    private final List<String> highlights;

    public MatchSummary(boolean won, int userScore, int opponentScore, int maxDeficit, Difficulty difficulty,
                        PlayerClass mainClass, boolean overtime, boolean practice, boolean cooldownWaste,
                        double secondsPlayed, List<Player> userPlayers, List<Player> opponentPlayers, List<String> highlights) {
        this.won = won;
        this.userScore = userScore;
        this.opponentScore = opponentScore;
        this.maxDeficit = maxDeficit;
        this.difficulty = difficulty;
        this.mainClass = mainClass;
        this.overtime = overtime;
        this.practice = practice;
        this.cooldownWaste = cooldownWaste;
        this.secondsPlayed = secondsPlayed;
        this.userPlayers = new ArrayList<>(userPlayers);
        this.opponentPlayers = new ArrayList<>(opponentPlayers);
        this.highlights = new ArrayList<>(highlights);
    }

    public boolean isWon() { return won; }

    public int getUserScore() { return userScore; }

    public int getOpponentScore() { return opponentScore; }

    /** Biggest number of points the user's team was behind at any time. */
    public int getMaxDeficit() { return maxDeficit; }

    public Difficulty getDifficulty() { return difficulty; }

    public PlayerClass getMainClass() { return mainClass; }

    public boolean isOvertime() { return overtime; }

    public boolean isPractice() { return practice; }

    /** True if the controlled player left Q or E sitting ready too long. */
    public boolean hadCooldownWaste() { return cooldownWaste; }

    public double getSecondsPlayed() { return secondsPlayed; }

    public List<Player> getUserPlayers() { return Collections.unmodifiableList(userPlayers); }

    public List<Player> getOpponentPlayers() { return Collections.unmodifiableList(opponentPlayers); }

    public List<String> getHighlights() { return Collections.unmodifiableList(highlights); }

    /** Sum of a stat over the user's team (helper for achievements). */
    public int userOutsidePoints(int outsideValue) {
        int made = 0;
        for (Player p : userPlayers) {
            made += p.getStats().getOutsideMade();
        }
        return made * outsideValue;
    }

    public int userUltimates() {
        int n = 0;
        for (Player p : userPlayers) {
            n += p.getStats().getUltimatesUsed();
        }
        return n;
    }
}
