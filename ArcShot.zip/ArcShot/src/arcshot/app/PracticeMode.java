package arcshot.app;

import arcshot.ui.screens.ClassSelectScreen;

/**
 * Empty-court practice: test abilities and loadouts with no clock. Nothing counts for achievements.
 * OOP pillar: <b>POLYMORPHISM</b> - implements GameMode; the menu launches it without knowing the type.
 */
public final class PracticeMode implements GameMode {
    @Override
    public String getTitle() { return "Practice Court"; }

    @Override
    public String getDescription() { return "No clock, refill cooldowns with C - try every ability"; }

    @Override
    public void launch(AppContext app) {
        app.screens().push(new ClassSelectScreen(app, true));
    }
}
