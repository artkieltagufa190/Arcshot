package arcshot.render.retro;

import arcshot.ability.Ability;
import arcshot.ability.AbilitySlot;
import arcshot.court.Match;
import arcshot.player.Player;
import arcshot.ui.ThemeSkin;
import java.awt.Color;
import java.awt.Graphics2D;

/**
 * Q/E/R ability icons for the retro HUD: a 26x22 chunky tile in the ability's color with its initials,
 * a cooldown shutter that drops in 2-px steps, the key label, and a blinking gold frame when the ultimate is ready.
 * OOP pillar: <b>ABSTRACTION</b> - the HUD just says "draw this ability here".
 */
final class RetroAbilityIcons {
    void draw(Graphics2D g, Match m, Player p, Ability a, int x, int y, String key, ThemeSkin skin) {
        int w = 26;
        int h = 22;
        Color base = skin.color("ability." + a.getId(), classColor(p));
        double frac = a.getCooldownFraction(p);
        boolean ready = frac <= 0.0001;
        boolean ult = a.getSlot() == AbilitySlot.R;
        boolean blink = ((int) (m.getElapsed() * 5)) % 2 == 0;
        Color frame = a.isActive() ? RetroHud.WHITE
                : (ready ? (ult ? (blink ? RetroHud.GOLD : RetroHud.WHITE) : RetroCourtRenderer.shade(base, 1.3)) : RetroHud.EDGE);
        g.setColor(RetroHud.OUTLINE);
        g.fillRect(x - 2, y - 2, w + 4, h + 4);
        g.setColor(frame);
        g.fillRect(x - 1, y - 1, w + 2, h + 2);
        g.setColor(RetroCourtRenderer.shade(base, 0.7));
        g.fillRect(x, y, w, h);
        g.setColor(base);
        g.fillRect(x, y, w, h - 4);
        g.setColor(RetroCourtRenderer.shade(base, 1.25));
        g.fillRect(x, y, w, 2);
        String initials = initials(skin.abilityName(a.getId()));
        if (!ready) {
            int sh = (int) Math.round(h * frac);
            sh -= sh % 2;
            g.setColor(RetroCourtRenderer.shade(base, 0.35));
            g.fillRect(x, y, w, sh); // cooldown shutter, drops in 2-px steps
            String s = a.getStatusText(p);
            PixelFont.drawCentered(g, s.length() > 4 ? s.substring(0, 4) : s, x + w / 2, y + 8, RetroHud.WHITE, RetroHud.OUTLINE, 1);
        } else {
            PixelFont.drawCentered(g, initials, x + w / 2, y + 8, RetroHud.WHITE, RetroHud.OUTLINE, 1);
            if (!a.canUse(p, m) && !a.isActive()) {
                // ready but not allowed right now (dead ball, free throw...): greyed tile
                g.setColor(new Color(0x4A4F66));
                g.fillRect(x, y, w, h);
                PixelFont.drawCentered(g, initials, x + w / 2, y + 8, RetroHud.MUTED, RetroHud.OUTLINE, 1);
            }
        }
        // key label tab
        g.setColor(RetroHud.OUTLINE);
        g.fillRect(x - 2, y - 2, PixelFont.width(key, 1) + 4, 9);
        g.setColor(RetroHud.CYAN);
        g.fillRect(x - 1, y - 1, PixelFont.width(key, 1) + 2, 7);
        PixelFont.draw(g, key, x, y - 1, RetroHud.OUTLINE, 1);
    }

    private static Color classColor(Player p) {
        switch (p.getPlayerClass()) {
            case GUARD: return new Color(0x7B5CFF);
            case FORWARD: return new Color(0xFF4D6D);
            default: return new Color(0x3AA0FF);
        }
    }

    private static String initials(String name) {
        StringBuilder sb = new StringBuilder();
        for (String part : name.split(" ")) {
            if (!part.isEmpty() && sb.length() < 2) {
                sb.append(Character.toUpperCase(part.charAt(0)));
            }
        }
        return sb.toString();
    }
}
