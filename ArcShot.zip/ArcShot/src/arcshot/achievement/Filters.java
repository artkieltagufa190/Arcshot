package arcshot.achievement;

import arcshot.core.GameEventType;
import arcshot.player.PlayerClass;

/**
 * Ready-made {@link EventFilter}s so the catalog reads like a list of rules.
 * OOP pillar: <b>ABSTRACTION</b> - achievements state a rule without knowing how events are produced.
 */
public final class Filters {
    private Filters() { }

    /** Events of this type caused by the user's team. */
    public static EventFilter user(final GameEventType type) {
        return e -> e.getType() == type && e.isUserTeam();
    }

    /** Events of this type caused by the user's player of a given class. */
    public static EventFilter userClass(final GameEventType type, final PlayerClass pc) {
        return e -> e.getType() == type && e.isUserTeam() && e.getSource() != null
                && e.getSource().getPlayerClass() == pc;
    }
}
