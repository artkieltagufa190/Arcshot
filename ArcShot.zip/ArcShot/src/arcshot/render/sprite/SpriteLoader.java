package arcshot.render.sprite;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import javax.imageio.ImageIO;

/**
 * Loads character sheets ({@code /sprites/<character>/sheet_<variant>.png} + {@code manifest.properties}),
 * recolors them with a {@link Palette} and caches the result, so each team/skin combination is built once.
 * A missing file returns {@code null}; the renderer then draws a simple placeholder, so the game never crashes.
 * OOP pillar: <b>ABSTRACTION</b> + <b>ENCAPSULATION</b> - callers just ask for a sheet; caching is hidden.
 */
public final class SpriteLoader {
    private static final Map<String, SpriteSheet> BASE = new HashMap<>();
    private static final Map<String, SpriteSheet> COLORED = new HashMap<>();
    private static final Map<String, Boolean> MISSING = new HashMap<>();

    private SpriteLoader() { }

    /** A recolored sheet, or null if the sprite files are missing. */
    public static synchronized SpriteSheet get(String character, String variant, Palette palette) {
        String key = character + "|" + variant + "|" + palette.key();
        SpriteSheet s = COLORED.get(key);
        if (s == null) {
            SpriteSheet base = base(character, variant);
            if (base == null) {
                return null;
            }
            s = base.withImage(recolor(base.getImage(), palette.map()));
            COLORED.put(key, s);
        }
        return s;
    }

    /** A one-color silhouette (afterimages, freeze tint), mixed {@code amount} toward {@code tint}. */
    public static synchronized SpriteSheet tinted(SpriteSheet src, Color tint, double amount, String cacheKey) {
        SpriteSheet s = COLORED.get("tint|" + cacheKey);
        if (s == null) {
            BufferedImage in = src.getImage();
            BufferedImage out = new BufferedImage(in.getWidth(), in.getHeight(), BufferedImage.TYPE_INT_ARGB);
            int tr = tint.getRed();
            int tg = tint.getGreen();
            int tb = tint.getBlue();
            for (int y = 0; y < in.getHeight(); y++) {
                for (int x = 0; x < in.getWidth(); x++) {
                    int c = in.getRGB(x, y);
                    if ((c >>> 24) == 0) {
                        continue;
                    }
                    int r = (int) (((c >> 16) & 255) * (1 - amount) + tr * amount);
                    int g = (int) (((c >> 8) & 255) * (1 - amount) + tg * amount);
                    int b = (int) ((c & 255) * (1 - amount) + tb * amount);
                    out.setRGB(x, y, 0xFF000000 | (r << 16) | (g << 8) | b);
                }
            }
            s = src.withImage(out);
            COLORED.put("tint|" + cacheKey, s);
        }
        return s;
    }

    private static SpriteSheet base(String character, String variant) {
        String key = character + "|" + variant;
        if (BASE.containsKey(key)) {
            return BASE.get(key);
        }
        if (MISSING.containsKey(key)) {
            return null;
        }
        try {
            BufferedImage img = readImage("/sprites/" + character + "/sheet_" + variant + ".png");
            if (img == null && !"a".equals(variant)) {
                img = readImage("/sprites/" + character + "/sheet_a.png");
            }
            Properties manifest = new Properties();
            try (InputStream in = open("/sprites/" + character + "/manifest.properties")) {
                if (in != null) {
                    manifest.load(in);
                }
            }
            if (img == null || manifest.isEmpty()) {
                MISSING.put(key, Boolean.TRUE);
                return null;
            }
            BufferedImage argb = new BufferedImage(img.getWidth(), img.getHeight(), BufferedImage.TYPE_INT_ARGB);
            argb.getGraphics().drawImage(img, 0, 0, null);
            SpriteSheet s = new SpriteSheet(argb, manifest);
            BASE.put(key, s);
            return s;
        } catch (Exception ex) {
            MISSING.put(key, Boolean.TRUE);
            return null;
        }
    }

    private static InputStream open(String path) throws java.io.IOException {
        File f = new File("resources" + path);
        if (f.isFile()) {
            return new java.io.FileInputStream(f);
        }
        return SpriteLoader.class.getResourceAsStream(path);
    }

    private static BufferedImage readImage(String path) throws java.io.IOException {
        try (InputStream in = open(path)) {
            return in == null ? null : ImageIO.read(in);
        }
    }

    private static BufferedImage recolor(BufferedImage src, Map<Integer, Integer> map) {
        BufferedImage out = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_ARGB);
        int[] px = src.getRGB(0, 0, src.getWidth(), src.getHeight(), null, 0, src.getWidth());
        for (int i = 0; i < px.length; i++) {
            int c = px[i];
            if ((c >>> 24) == 0) {
                px[i] = 0;
                continue;
            }
            Integer r = map.get(c & 0xFFFFFF);
            if (r != null) {
                px[i] = 0xFF000000 | r;
            }
        }
        out.setRGB(0, 0, src.getWidth(), src.getHeight(), px, 0, src.getWidth());
        return out;
    }
}
