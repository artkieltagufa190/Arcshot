package arcshot.court;

import arcshot.player.Player;

/**
 * Phantom Squad afterimage: mirrors its owner with an offset; AI defenders may chase it instead.
 * OOP pillars: <b>INHERITANCE</b> (extends CourtEntity) and <b>POLYMORPHISM</b> (overrides affect / blocks / update).
 */
public class Decoy extends CourtEntity {
    private final double offsetX;
    private final double offsetY;

    public Decoy(Player owner, double offsetX, double offsetY, double duration) {
        super(owner, "decoy", owner.getX() + offsetX, owner.getY() + offsetY, Player.RADIUS, duration);
        this.offsetX = offsetX;
        this.offsetY = offsetY;
    }

    @Override
    public void update(double dt, Match match) {
        super.update(dt, match);
        double tx = getOwner().getX() + offsetX;
        double ty = getOwner().getY() + offsetY;
        double k = Math.min(1, 5 * dt);
        Court c = match.getCourt();
        double nx = Math.max(c.getLeft() + 15, Math.min(c.getRight() - 15, getX() + (tx - getX()) * k));
        double ny = Math.max(c.getTop() + 15, Math.min(c.getBottom() - 15, getY() + (ty - getY()) * k));
        moveTo(nx, ny);
    }
}
