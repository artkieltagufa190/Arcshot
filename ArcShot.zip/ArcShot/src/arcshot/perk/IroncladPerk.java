package arcshot.perk;

import arcshot.core.Balance;

/**
 * Stuns and slows on you last a shorter time.
 * OOP pillars: <b>INHERITANCE</b> (extends Perk) and <b>POLYMORPHISM</b> (overrides one hook).
 */
public class IroncladPerk extends Perk {
    public IroncladPerk() {
        super("ironclad", "Ironclad", "Stuns and slows on you are 35% shorter");
    }

    @Override
    public double debuffDurationMultiplier() { return Balance.d("perk.ironclad.multiplier", 0.65); }
}
