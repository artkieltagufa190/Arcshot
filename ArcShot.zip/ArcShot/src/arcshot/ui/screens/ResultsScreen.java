package arcshot.ui.screens;

import arcshot.achievement.Achievement;
import arcshot.app.AppContext;
import arcshot.court.MatchConfig;
import arcshot.court.MatchSummary;
import arcshot.player.Player;
import arcshot.player.PlayerStats;
import arcshot.reward.Reward;
import arcshot.ui.Screen;
import arcshot.ui.Theme;
import arcshot.ui.UIFactory;
import arcshot.ui.components.RoundedPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 * Post-match: final score, box score, achievements earned this match and ultimate highlights.
 * OOP pillars: <b>INHERITANCE</b> (extends Screen) and <b>POLYMORPHISM</b> (the ScreenManager calls its lifecycle hooks).
 */
public class ResultsScreen extends Screen {

    public ResultsScreen(AppContext app, MatchSummary s, MatchConfig config, List<Achievement> earned) {
        super(app);
        JPanel head = UIFactory.column();
        JLabel title = UIFactory.label(s.isWon() ? "VICTORY" : "DEFEAT", Theme.display(72), s.isWon() ? Theme.SUCCESS : Theme.DANGER);
        head.add(title);
        head.add(UIFactory.label(s.getUserScore() + "  -  " + s.getOpponentScore()
                + (s.isOvertime() ? "  (OT)" : "") + "     " + s.getDifficulty().getLabel() + " AI   |   You started as "
                + s.getMainClass().getDisplayName() + "   |   " + formatTime(s.getSecondsPlayed()), Theme.semi(18), Theme.TEXT_MUTED));
        head.setBorder(BorderFactory.createEmptyBorder(0, 0, Theme.S5, 0));
        add(head, BorderLayout.NORTH);

        JPanel center = UIFactory.clear(new GridLayout(1, 2, Theme.S5, 0));
        RoundedPanel box = UIFactory.card(new BorderLayout(0, Theme.S3));
        box.add(UIFactory.heading("Box score"), BorderLayout.NORTH);
        JPanel table = UIFactory.clear(new GridLayout(0, 1, 0, 2));
        table.add(row("PLAYER", true, Theme.TEXT_MUTED, "PTS", "REB", "AST", "STL", "BLK", "DNK", "PF", "FG", "FT"));
        for (Player p : s.getUserPlayers()) {
            table.add(playerRow(p, Theme.TEXT));
        }
        table.add(row("", false, Theme.TEXT_MUTED));
        for (Player p : s.getOpponentPlayers()) {
            table.add(playerRow(p, Theme.TEXT_MUTED));
        }
        box.add(table, BorderLayout.CENTER);
        center.add(box);

        JPanel right = UIFactory.clear(new GridLayout(2, 1, 0, Theme.S5));
        RoundedPanel ach = UIFactory.card(new BorderLayout(0, Theme.S3));
        ach.add(UIFactory.heading("Achievements earned (" + earned.size() + ")"), BorderLayout.NORTH);
        JPanel list = UIFactory.column();
        if (earned.isEmpty()) {
            list.add(UIFactory.muted(config.isPractice() ? "Practice does not count." : "None this time - check the Achievements screen for progress."));
        }
        for (Achievement a : earned) {
            list.add(UIFactory.label(a.getName() + "  (" + a.getTier().getDisplayName() + ")", Theme.semi(16), Theme.GOLD));
            for (Reward r : a.getRewards()) {
                list.add(UIFactory.muted("   + " + r.describe(app.skin())));
            }
        }
        ach.add(UIFactory.scroll(list), BorderLayout.CENTER);
        right.add(ach);
        RoundedPanel hl = UIFactory.card(new BorderLayout(0, Theme.S3));
        hl.add(UIFactory.heading("Ultimate highlights"), BorderLayout.NORTH);
        JPanel hlist = UIFactory.column();
        if (s.getHighlights().isEmpty()) {
            hlist.add(UIFactory.muted("No ultimates were used."));
        }
        for (String h : s.getHighlights()) {
            String[] parts = h.split("\\|");
            if (parts.length >= 4) {
                boolean mine = "HOME".equals(parts[3]);
                hlist.add(UIFactory.label(parts[0] + "   " + parts[1] + " - " + app.skin().abilityName(parts[2]),
                        Theme.semi(15), mine ? Theme.TEXT : Theme.TEXT_MUTED));
            }
        }
        hl.add(UIFactory.scroll(hlist), BorderLayout.CENTER);
        right.add(hl);
        center.add(right);
        add(center, BorderLayout.CENTER);

        JPanel south = UIFactory.clear(new FlowLayout(FlowLayout.RIGHT, Theme.S3, 0));
        south.setBorder(BorderFactory.createEmptyBorder(Theme.S5, 0, 0, 0));
        south.add(UIFactory.secondary("Achievements", e -> app.screens().push(new AchievementsScreen(app))));
        south.add(UIFactory.secondary("Main Menu", e -> app.showMainMenu()));
        south.add(UIFactory.primary("Play Again", e -> app.screens().replaceTop(new MatchScreen(app, config))));
        add(south, BorderLayout.SOUTH);
    }

    private JComponent playerRow(Player p, Color color) {
        PlayerStats st = p.getStats();
        return row(p.getName() + "  (" + p.getPlayerClass().getDisplayName().charAt(0) + ")", false, color,
                String.valueOf(st.getPoints()), String.valueOf(st.getRebounds()), String.valueOf(st.getAssists()),
                String.valueOf(st.getSteals()), String.valueOf(st.getBlocks()), String.valueOf(st.getDunks()),
                String.valueOf(st.getFouls()), st.getShotsMade() + "/" + st.getShotsTaken(),
                st.getFreeThrowsMade() + "/" + st.getFreeThrowsTaken());
    }

    /** One box-score row: name on the left, the number columns right-aligned (DNK, PF and FT added in the upgrade). */
    private JComponent row(String name, boolean header, Color color, String... values) {
        JPanel r = UIFactory.clear(new BorderLayout());
        JLabel n = UIFactory.label(name, header ? Theme.bold(12) : Theme.semi(15), color);
        r.add(n, BorderLayout.CENTER);
        JPanel nums = UIFactory.clear(new GridLayout(1, 9, Theme.S1, 0));
        for (int i = 0; i < 9; i++) {
            String v = i < values.length ? values[i] : "";
            JLabel l = UIFactory.label(v, header ? Theme.bold(12) : Theme.semi(14), color);
            l.setHorizontalAlignment(SwingConstants.RIGHT);
            nums.add(l);
        }
        nums.setPreferredSize(new java.awt.Dimension(390, 26));
        r.add(nums, BorderLayout.EAST);
        return r;
    }

    private static String formatTime(double seconds) {
        int s = (int) seconds;
        return String.format("%d:%02d played", s / 60, s % 60);
    }
}
