package arcshot.achievement;

/**
 * Playstyle branches (rows of the achievement tree), plus one branch per class.
 * OOP pillar: <b>ENCAPSULATION</b> - each enum constant keeps its data in private fields behind getters.
 */
public enum AchievementBranch {
    SCORING("Scoring"), DEFENSE("Defense"), PLAYMAKING("Playmaking"), ABILITY("Ability Mastery"),
    CAREER("Career"), GUARD("Guard"), FORWARD("Forward"), BIG("Big");

    private final String displayName;

    AchievementBranch(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() { return displayName; }
}
