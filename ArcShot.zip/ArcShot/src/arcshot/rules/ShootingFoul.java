package arcshot.rules;

import arcshot.player.Player;

/**
 * Foul on a player in the act of shooting (jump shot, layup or dunk).
 * Missed: 1 FT inside the arc, 2 behind it. Made: the basket counts + 1 FT ("and one").
 * OOP pillars: <b>INHERITANCE</b> (extends Foul) and <b>POLYMORPHISM</b> (own base penalty).
 */
public class ShootingFoul extends Foul {
    public ShootingFoul(Player offender, Player victim) {
        super(offender, victim);
    }

    @Override
    public String getName() { return "SHOOTING FOUL"; }

    @Override
    protected int baseFreeThrows(FoulContext ctx) {
        if (Boolean.TRUE.equals(ctx.getShotMade())) {
            return RulesConfig.andOneFreeThrows();
        }
        return ctx.isShotOutside() ? RulesConfig.shootingFoulOutside() : RulesConfig.shootingFoulInside();
    }
}
