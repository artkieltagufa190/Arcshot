package arcshot.ui.screens;

import arcshot.ability.AbilityInfo;
import arcshot.ability.AbilityRegistry;
import arcshot.ability.AbilitySlot;
import arcshot.achievement.Achievement;
import arcshot.ai.Difficulty;
import arcshot.app.AppContext;
import arcshot.core.Balance;
import arcshot.cosmetic.CosmeticRegistry;
import arcshot.cosmetic.CosmeticType;
import arcshot.court.MatchConfig;
import arcshot.perk.Perk;
import arcshot.perk.PerkRegistry;
import arcshot.player.PlayerClass;
import arcshot.save.Loadout;
import arcshot.save.Profile;
import arcshot.ui.Screen;
import arcshot.ui.Theme;
import arcshot.ui.UIFactory;
import arcshot.ui.components.RoundedPanel;
import arcshot.ui.components.ValueStepper;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.EnumMap;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * Class select + loadout screen. Pick the class you control, choose one Q, E and R per class (locked alternates
 * show which achievement unlocks them), pick perks and difficulty, then start.
 * OOP pillars: <b>INHERITANCE</b> (extends Screen) and <b>POLYMORPHISM</b> (the ScreenManager calls its lifecycle hooks).
 */
public class ClassSelectScreen extends Screen {
    private final boolean practice;
    private final Map<PlayerClass, Loadout> loadouts = new EnumMap<>(PlayerClass.class);
    private final Map<PlayerClass, ClassCard> cards = new EnumMap<>(PlayerClass.class);
    private PlayerClass selected = PlayerClass.GUARD;

    private final JLabel loadoutTitle = UIFactory.heading("");
    private final Map<AbilitySlot, ValueStepper<String>> steppers = new EnumMap<>(AbilitySlot.class);
    private static final int TEXT_W = 360;
    private final Map<AbilitySlot, JLabel> descriptions = new EnumMap<>(AbilitySlot.class);
    private final JLabel lockedInfo = UIFactory.wrap("", TEXT_W, Theme.body(12), Theme.TEXT_MUTED);
    private final ValueStepper<String> perk1 = new ValueStepper<>();
    private final ValueStepper<String> perk2 = new ValueStepper<>();
    private final JLabel perkInfo = UIFactory.muted("");
    private final ValueStepper<Difficulty> difficulty = new ValueStepper<>();
    private boolean updating;

    public ClassSelectScreen(AppContext app, boolean practice) {
        super(app);
        this.practice = practice;
        Profile profile = app.profile();
        for (PlayerClass pc : PlayerClass.values()) {
            Loadout saved = profile.getLoadout(pc);
            Loadout l = saved != null ? saved : new Loadout(pc, AbilityRegistry.defaultId(pc, AbilitySlot.Q),
                    AbilityRegistry.defaultId(pc, AbilitySlot.E), AbilityRegistry.defaultId(pc, AbilitySlot.R));
            sanitize(l);
            loadouts.put(pc, l);
        }
        add(UIFactory.header(practice ? "Practice Setup" : "Choose your squad",
                "Your team is always Guard + Forward + Big. Pick who you control first (Tab switches in-game).",
                e -> app.back()), BorderLayout.NORTH);

        JPanel center = UIFactory.clear(new BorderLayout(0, Theme.S5));
        JPanel classRow = UIFactory.clear(new GridLayout(1, 3, Theme.S5, 0));
        for (PlayerClass pc : PlayerClass.values()) {
            ClassCard card = new ClassCard(pc);
            cards.put(pc, card);
            classRow.add(card);
        }
        center.add(classRow, BorderLayout.NORTH);
        JPanel bottom = UIFactory.clear(new GridLayout(1, 2, Theme.S5, 0));
        bottom.add(buildLoadoutCard());
        bottom.add(buildMatchCard());
        center.add(bottom, BorderLayout.CENTER);
        add(UIFactory.scroll(center), BorderLayout.CENTER);

        JPanel south = UIFactory.clear(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        south.setBorder(BorderFactory.createEmptyBorder(Theme.S4, 0, 0, 0));
        south.add(UIFactory.primary(practice ? "Start Practice" : "Start Match", e -> start()));
        add(south, BorderLayout.SOUTH);
        String main = profile.getSettings().getDifficulty();
        difficulty.setSelected(Difficulty.fromName(main));
        select(PlayerClass.GUARD);
    }

    /** Replaces locked or invalid ids with the defaults. */
    private void sanitize(Loadout l) {
        PlayerClass pc = l.getPlayerClass();
        if (!valid(l.getQ(), pc, AbilitySlot.Q)) {
            l.setQ(AbilityRegistry.defaultId(pc, AbilitySlot.Q));
        }
        if (!valid(l.getE(), pc, AbilitySlot.E)) {
            l.setE(AbilityRegistry.defaultId(pc, AbilitySlot.E));
        }
        if (!valid(l.getR(), pc, AbilitySlot.R)) {
            l.setR(AbilityRegistry.defaultId(pc, AbilitySlot.R));
        }
    }

    private boolean valid(String id, PlayerClass pc, AbilitySlot slot) {
        AbilityInfo info = AbilityRegistry.get(id);
        return info != null && info.getPlayerClass() == pc && info.getSlot() == slot
                && AbilityRegistry.isAvailable(id, app.profile());
    }

    private JComponent buildLoadoutCard() {
        RoundedPanel card = UIFactory.card(new BorderLayout(0, Theme.S3));
        card.add(loadoutTitle, BorderLayout.NORTH);
        JPanel rows = UIFactory.column();
        for (AbilitySlot slot : AbilitySlot.values()) {
            ValueStepper<String> stepper = new ValueStepper<>();
            stepper.setPreferredSize(new Dimension(300, 40));
            stepper.setOnChange(id -> onAbilityChosen(slot, id));
            steppers.put(slot, stepper);
            JLabel desc = UIFactory.wrap("", TEXT_W, Theme.body(13), Theme.TEXT_MUTED);
            descriptions.put(slot, desc);
            JPanel row = UIFactory.clear(new BorderLayout(Theme.S3, 2));
            JLabel key = UIFactory.label(slot == AbilitySlot.R ? "R (ULT)" : slot.name(), Theme.display(22),
                    slot == AbilitySlot.R ? Theme.GOLD : Theme.ACCENT_2);
            key.setPreferredSize(new Dimension(78, 30));
            row.add(key, BorderLayout.WEST);
            row.add(stepper, BorderLayout.CENTER);
            row.add(desc, BorderLayout.SOUTH);
            row.setAlignmentX(LEFT_ALIGNMENT);
            rows.add(row);
            rows.add(UIFactory.vgap(Theme.S1));
        }
        lockedInfo.setAlignmentX(LEFT_ALIGNMENT);
        rows.add(lockedInfo);
        card.add(rows, BorderLayout.CENTER);
        return card;
    }

    private JComponent buildMatchCard() {
        RoundedPanel card = UIFactory.card(null);
        card.setLayout(new javax.swing.BoxLayout(card, javax.swing.BoxLayout.Y_AXIS));
        JLabel h = UIFactory.heading("Perks & match");
        h.setAlignmentX(LEFT_ALIGNMENT);
        card.add(h);
        card.add(UIFactory.vgap(Theme.S3));
        fillPerks(perk1);
        fillPerks(perk2);
        Profile p = app.profile();
        perk1.setSelected(p.getPerk1());
        perk2.setSelected(p.getPerk2());
        boolean slot2 = app.achievements().isPerkSlot2Unlocked();
        perk2.setEnabled(slot2);
        for (java.awt.Component c : perk2.getComponents()) {
            c.setEnabled(slot2);
        }
        perk1.setOnChange(id -> updatePerkInfo());
        perk2.setOnChange(id -> updatePerkInfo());
        card.add(left(UIFactory.formRow("Perk slot 1", null, perk1)));
        card.add(left(UIFactory.formRow(slot2 ? "Perk slot 2" : "Perk slot 2 (All-Star tier)", null, perk2)));
        perkInfo.setAlignmentX(LEFT_ALIGNMENT);
        card.add(perkInfo);
        card.add(UIFactory.vgap(Theme.S2));
        for (Difficulty d : Difficulty.values()) {
            difficulty.addOption(d, d.getLabel());
        }
        if (!practice) {
            card.add(left(UIFactory.formRow("AI difficulty", null, difficulty)));
        } else {
            JLabel tip = UIFactory.wrap("Practice: no clock, opponents are idle dummies. Press C to refill all "
                    + "cooldowns and ultimates, 1 / 2 / 3 to control Guard / Forward / Big. Nothing counts for achievements.",
                    TEXT_W, Theme.body(14), Theme.TEXT_MUTED);
            tip.setAlignmentX(LEFT_ALIGNMENT);
            card.add(tip);
        }
        card.add(UIFactory.vgap(Theme.S2));
        String rules = "Rules: " + Balance.i("rules.insidePoints", 1) + " pt inside the arc, "
                + Balance.i("rules.outsidePoints", 2) + " outside. First to " + Balance.i("rules.targetScore", 21)
                + " or most points after " + app.profile().getSettings().getGameMinutes() + " min. Tie = overtime, first to "
                + Balance.i("rules.overtimePoints", 2) + ".";
        JLabel r = UIFactory.wrap(rules, TEXT_W, Theme.body(13), Theme.TEXT_MUTED);
        r.setAlignmentX(LEFT_ALIGNMENT);
        card.add(r);
        updatePerkInfo();
        return card;
    }

    private static JComponent left(JComponent c) {
        c.setAlignmentX(LEFT_ALIGNMENT);
        c.setMaximumSize(new Dimension(Integer.MAX_VALUE, c.getPreferredSize().height));
        return c;
    }

    private void fillPerks(ValueStepper<String> stepper) {
        stepper.addOption("", "None");
        for (Perk perk : PerkRegistry.all()) {
            if (app.profile().hasUnlock(Profile.PERK + perk.getId())) {
                stepper.addOption(perk.getId(), perk.getName());
            }
        }
    }

    private void updatePerkInfo() {
        StringBuilder sb = new StringBuilder("<html>");
        for (String id : new String[] {perk1.getSelected(), perk2.isEnabled() ? perk2.getSelected() : ""}) {
            Perk perk = PerkRegistry.create(id);
            if (perk != null) {
                sb.append(perk.getName()).append(": ").append(perk.getDescription()).append("<br>");
            }
        }
        int locked = 0;
        for (String id : PerkRegistry.allIds()) {
            if (!app.profile().hasUnlock(Profile.PERK + id)) {
                locked++;
            }
        }
        if (locked > 0) {
            sb.append(locked).append(" perk(s) still locked - see Achievements.");
        }
        perkInfo.setText(sb.append("</html>").toString());
    }

    private void select(PlayerClass pc) {
        selected = pc;
        for (Map.Entry<PlayerClass, ClassCard> e : cards.entrySet()) {
            e.getValue().setSelected(e.getKey() == pc);
        }
        loadoutTitle.setText(pc.getDisplayName() + " loadout");
        updating = true;
        Loadout l = loadouts.get(pc);
        StringBuilder locked = new StringBuilder();
        for (AbilitySlot slot : AbilitySlot.values()) {
            ValueStepper<String> st = steppers.get(slot);
            st.clearOptions();
            for (AbilityInfo info : AbilityRegistry.forSlot(pc, slot)) {
                String name = app.skin().abilityName(info.getId());
                if (AbilityRegistry.isAvailable(info.getId(), app.profile())) {
                    st.addOption(info.getId(), name);
                } else {
                    Achievement src = app.achievements().findSourceOf(Profile.ABILITY + info.getId());
                    locked.append(locked.length() == 0 ? "Locked: " : ",  ").append(slot).append(" ").append(name)
                            .append(" (").append(src == null ? "?" : src.getName()).append(")");
                }
            }
            String current = slot == AbilitySlot.Q ? l.getQ() : (slot == AbilitySlot.E ? l.getE() : l.getR());
            st.setSelected(current);
            describe(slot, current);
        }
        UIFactory.setWrapText(lockedInfo, locked.length() == 0 ? "All alternates unlocked for this class."
                : locked.toString().trim(), TEXT_W);
        updating = false;
        revalidate();
        repaint();
    }

    private void onAbilityChosen(AbilitySlot slot, String id) {
        if (updating) {
            return;
        }
        Loadout l = loadouts.get(selected);
        if (slot == AbilitySlot.Q) {
            l.setQ(id);
        } else if (slot == AbilitySlot.E) {
            l.setE(id);
        } else {
            l.setR(id);
        }
        describe(slot, id);
    }

    private void describe(AbilitySlot slot, String id) {
        String text = app.skin().abilityDescription(id);
        if (slot != AbilitySlot.R) {
            double cd = Balance.d("ability." + id + ".cooldown", Double.NaN);
            if (!Double.isNaN(cd)) {
                text += "  (" + (int) cd + "s cooldown)";
            }
        } else {
            text += "  (needs a full ultimate meter)";
        }
        UIFactory.setWrapText(descriptions.get(slot), text, TEXT_W);
    }

    private void start() {
        Profile p = app.profile();
        for (Loadout l : loadouts.values()) {
            p.setLoadout(l);
        }
        String second = perk2.isEnabled() ? perk2.getSelected() : "";
        p.setPerks(perk1.getSelected(), second);
        p.getSettings().setDifficulty(difficulty.getSelected().name());
        MatchConfig cfg = new MatchConfig();
        cfg.setMainClass(selected);
        cfg.setPractice(practice);
        cfg.setDifficulty(difficulty.getSelected());
        cfg.setGameSeconds(p.getSettings().getGameMinutes() * 60);
        cfg.setFoulFrequency(arcshot.rules.FoulFrequency.valueOf(p.getSettings().getFoulFrequency()));
        cfg.setStrictRefs(p.getSettings().isStrictRefs());
        for (Loadout l : loadouts.values()) {
            cfg.setLoadout(l);
        }
        cfg.setPerks(p.getPerk1(), p.getPerk2());
        cfg.setPlayerName(p.getName());
        cfg.setJerseyNumber(p.getJerseyNumber());
        Color home = CosmeticRegistry.getOrDefault(p.getJersey(), CosmeticType.JERSEY).color(0);
        cfg.setHomeColor(home);
        cfg.setAwayColor(contrastingAway(home));
        cfg.setAutoSwitch(p.getSettings().isAutoSwitch());
        app.startMatch(cfg);
    }

    /** Blue opponents, unless you wear something blue-ish - then red. */
    static Color contrastingAway(Color home) {
        float[] hsb = Color.RGBtoHSB(home.getRed(), home.getGreen(), home.getBlue(), null);
        boolean bluish = hsb[0] > 0.5f && hsb[0] < 0.75f && hsb[1] > 0.3f;
        return bluish ? new Color(0xE23B4A) : Theme.AWAY;
    }

    /** A clickable class card with stat bars. */
    private final class ClassCard extends RoundedPanel {
        private final PlayerClass pc;
        private boolean selectedCard;

        ClassCard(PlayerClass pc) {
            super(new BorderLayout());
            this.pc = pc;
            setPreferredSize(new Dimension(300, 138));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    select(ClassCard.this.pc);
                }
            });
        }

        void setSelected(boolean s) {
            selectedCard = s;
            setFill(s ? Theme.PANEL_HI : Theme.PANEL);
            setBorderColor(s ? Theme.ACCENT : Theme.BORDER);
        }

        @Override
        protected void paintComponent(Graphics g0) {
            super.paintComponent(g0);
            Graphics2D g = (Graphics2D) g0.create();
            Theme.quality(g);
            int x = Theme.S5;
            g.setFont(Theme.display(34));
            g.setColor(selectedCard ? Theme.ACCENT : Theme.TEXT);
            g.drawString(pc.getDisplayName().toUpperCase(), x, 42);
            g.setFont(Theme.semi(14));
            g.setColor(Theme.TEXT_MUTED);
            g.drawString(pc.getRole() + (selectedCard ? "   -   YOU START AS THIS" : ""), x, 62);
            String k = pc.key();
            stat(g, "Speed", Balance.d(k + ".speed", 220) / 260.0, x, 80);
            stat(g, "Shooting", Balance.d(k + ".shooting", 70) / 100.0, x, 95);
            stat(g, "Defense", Balance.d(k + ".defense", 65) / 100.0, x, 110);
            stat(g, "Rebound", Balance.d(k + ".rebound", 60) / 100.0, x, 125);
            g.dispose();
        }

        private void stat(Graphics2D g, String label, double v, int x, int y) {
            g.setFont(Theme.body(12));
            g.setColor(Theme.TEXT_MUTED);
            g.drawString(label, x, y);
            int bx = x + 70;
            int bw = getWidth() - bx - Theme.S5;
            g.setColor(Theme.BG);
            g.fillRoundRect(bx, y - 8, bw, 8, 8, 8);
            g.setColor(selectedCard ? Theme.ACCENT : Theme.ACCENT_2);
            g.fillRoundRect(bx, y - 8, (int) (bw * Math.min(1, v)), 8, 8, 8);
        }
    }
}
