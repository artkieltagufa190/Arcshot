package arcshot.ui.components;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Rectangle;
import javax.swing.JPanel;
import javax.swing.Scrollable;

/**
 * A transparent wrapper for scroll panes that always matches the viewport's width (so content wraps instead of
 * scrolling sideways) and scrolls only vertically.
 * OOP pillar: <b>POLYMORPHISM</b> - implements Swing's {@link Scrollable} interface.
 */
public class WidthTrackingPanel extends JPanel implements Scrollable {
    public WidthTrackingPanel(Component content) {
        super(new BorderLayout());
        setOpaque(false);
        add(content, BorderLayout.NORTH);
    }

    @Override
    public Dimension getPreferredScrollableViewportSize() { return getPreferredSize(); }

    @Override
    public int getScrollableUnitIncrement(Rectangle visible, int orientation, int direction) { return 24; }

    @Override
    public int getScrollableBlockIncrement(Rectangle visible, int orientation, int direction) { return visible.height - 40; }

    @Override
    public boolean getScrollableTracksViewportWidth() { return true; }

    @Override
    public boolean getScrollableTracksViewportHeight() { return false; }
}
