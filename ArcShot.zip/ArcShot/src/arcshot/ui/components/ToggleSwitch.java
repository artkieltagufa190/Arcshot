package arcshot.ui.components;

import arcshot.ui.Theme;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.function.Consumer;
import javax.swing.JComponent;

/**
 * A custom-painted on/off switch.
 * OOP pillars: <b>INHERITANCE</b> from {@link JComponent}; <b>ENCAPSULATION</b> of the on/off state.
 */
public class ToggleSwitch extends JComponent {
    private boolean on;
    private Consumer<Boolean> onChange;

    public ToggleSwitch(boolean initial) {
        on = initial;
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                setOn(!on);
                if (onChange != null) {
                    onChange.accept(on);
                }
            }
        });
    }

    public boolean isOn() {
        return on;
    }

    public void setOn(boolean on) {
        this.on = on;
        repaint();
    }

    public void setOnChange(Consumer<Boolean> onChange) {
        this.onChange = onChange;
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(56, 30);
    }

    @Override
    protected void paintComponent(Graphics g0) {
        Graphics2D g = (Graphics2D) g0.create();
        Theme.quality(g);
        int w = 52;
        int h = 26;
        int y = (getHeight() - h) / 2;
        g.setColor(on ? Theme.ACCENT : Theme.LOCKED);
        g.fillRoundRect(0, y, w, h, h, h);
        g.setColor(Theme.TEXT);
        int knob = h - 6;
        g.fillOval(on ? w - knob - 3 : 3, y + 3, knob, knob);
        g.dispose();
    }
}
