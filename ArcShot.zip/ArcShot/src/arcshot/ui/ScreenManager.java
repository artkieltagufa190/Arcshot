package arcshot.ui;

import java.awt.AlphaComposite;
import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.ArrayDeque;
import java.util.Deque;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

/**
 * Holds a stack of {@link Screen}s and swaps between them with a short cross-fade.
 * {@link #push} opens a screen on top (Back returns), {@link #pop} goes back, {@link #replaceAll} starts fresh.
 * OOP pillar: <b>ENCAPSULATION</b> - the stack and fade state are private; screens only use the public methods.
 */
public final class ScreenManager extends JPanel {
    private static final float FADE_STEP = 0.09f;

    private final Deque<Screen> stack = new ArrayDeque<>();
    private BufferedImage fadeImage;
    private float fadeAlpha;
    private final Timer fadeTimer;

    public ScreenManager() {
        super(new BorderLayout());
        setBackground(Theme.BG);
        fadeTimer = new Timer(15, e -> {
            fadeAlpha -= FADE_STEP;
            if (fadeAlpha <= 0) {
                fadeImage = null;
                ((Timer) e.getSource()).stop();
            }
            repaint();
        });
    }

    public Screen current() {
        return stack.peek();
    }

    public void push(Screen screen) {
        Screen top = stack.peek();
        if (top != null) {
            top.onHide();
        }
        stack.push(screen);
        show(screen);
        screen.onEnter();
    }

    public void pop() {
        if (stack.size() <= 1) {
            return;
        }
        Screen old = stack.pop();
        old.onExit();
        Screen top = stack.peek();
        show(top);
        top.onResume();
    }

    /** Replaces the top screen (e.g. Match -> Results). */
    public void replaceTop(Screen screen) {
        if (!stack.isEmpty()) {
            stack.pop().onExit();
        }
        stack.push(screen);
        show(screen);
        screen.onEnter();
    }

    /** Clears the whole stack and shows one screen (e.g. back to the main menu). */
    public void replaceAll(Screen screen) {
        while (!stack.isEmpty()) {
            stack.pop().onExit();
        }
        stack.push(screen);
        show(screen);
        screen.onEnter();
    }

    private void show(Screen screen) {
        snapshot();
        removeAll();
        add(screen, BorderLayout.CENTER);
        revalidate();
        repaint();
        SwingUtilities.invokeLater(screen::requestFocusInWindow);
    }

    private void snapshot() {
        if (getWidth() <= 0 || getHeight() <= 0 || getComponentCount() == 0) {
            return;
        }
        BufferedImage img = new BufferedImage(getWidth(), getHeight(), BufferedImage.TYPE_INT_RGB);
        Graphics2D g = img.createGraphics();
        paint(g);
        g.dispose();
        fadeImage = img;
        fadeAlpha = 1f;
        fadeTimer.restart();
    }

    /** While fading, children repaint through us so the fade overlay is always drawn on top. */
    @Override
    protected boolean isPaintingOrigin() {
        return fadeImage != null;
    }

    @Override
    public void paint(Graphics g0) {
        super.paint(g0);
        BufferedImage img = fadeImage;
        if (img != null) {
            Graphics2D g = (Graphics2D) g0.create();
            g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, Math.max(0, Math.min(1, fadeAlpha))));
            g.drawImage(img, 0, 0, null);
            g.dispose();
        }
    }
}
