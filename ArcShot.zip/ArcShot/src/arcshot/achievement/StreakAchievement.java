package arcshot.achievement;

import arcshot.core.GameEvent;

/**
 * A single-match achievement that resets when a "reset" event happens (e.g. 5 straight makes; a miss resets).
 * OOP pillars: <b>INHERITANCE</b> (extends Achievement) and <b>POLYMORPHISM</b> (overrides handle() / progress).
 */
public class StreakAchievement extends SingleMatchAchievement {
    private final EventFilter reset;

    public StreakAchievement(String id, String name, String description, String hint, AchievementTier tier,
                             AchievementBranch branch, EventFilter count, EventFilter reset, int target) {
        super(id, name, description, hint, tier, branch, count, target);
        this.reset = reset;
    }

    @Override
    public void handle(GameEvent event, AchievementContext ctx) {
        if (reset.matches(event)) {
            resetCurrent();
            return;
        }
        super.handle(event, ctx);
    }
}
