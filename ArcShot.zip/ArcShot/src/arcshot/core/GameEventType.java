package arcshot.core;

/**
 * Everything that can happen in a match that other systems (achievements, HUD, sound) may care about.
 * Gameplay code only <i>publishes</i> these; it never calls the achievement system directly.
 * OOP pillar: <b>ABSTRACTION</b> - a fixed set of named values instead of magic strings or numbers.
 */
public enum GameEventType {
    MATCH_STARTED,
    /** A made layup (also sends BASKET_MADE). */
    LAYUP,
    /** A foul was called. Source = the fouled player; payload = the Foul. */
    FOUL_DRAWN,
    /** A foul was called. Source = the player who fouled; payload = the Foul. */
    FOUL_COMMITTED,
    FREE_THROW_MADE,
    FREE_THROW_MISSED,
    /** A made basket on which the shooter was fouled. */
    AND_ONE,
    /** Sound-effect hook: payload = sound name (sneaker, dribble, rim, backboard, whistle, crowd ...). */
    SOUND,
    /** Any made basket. {@code value} = points scored. */
    BASKET_MADE,
    /** A made basket from outside the arc (worth 2 under 3x3 rules; the brief calls it a "three"). */
    THREE_MADE,
    SHOT_MISSED,
    DUNK,
    STEAL,
    BLOCK,
    ASSIST,
    REBOUND,
    TURNOVER,
    POSSESSION_CHANGE,
    ABILITY_USED,
    ULTIMATE_USED,
    MATCH_WON,
    MATCH_LOST,
    /** Always the last event of a match. Payload = {@code arcshot.court.MatchSummary}. */
    MATCH_FINISHED,
    /** Published by the achievement system itself. Payload = the {@code Achievement}. */
    ACHIEVEMENT_UNLOCKED
}
