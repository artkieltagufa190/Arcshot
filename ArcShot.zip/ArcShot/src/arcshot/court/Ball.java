package arcshot.court;

import arcshot.action.ActionType;
import arcshot.player.Player;

/**
 * The 3x3 ball: floor position (x, y) plus height z. It is always in exactly one {@link State}:
 * <ul>
 *   <li>HELD - owned by exactly one player ({@link #isDribbling()} tells DRIBBLING apart);</li>
 *   <li>PASS - flying to a receiver (PASSING);</li>
 *   <li>SHOT - SHOT_IN_FLIGHT;</li>
 *   <li>LOOSE - nobody owns it ({@link #isReboundContest()} = still above grab height after a shot);</li>
 *   <li>DEAD - after a score / whistle / out of bounds.</li>
 * </ul>
 * Ownership changes ONLY through {@link #giveTo(Player, String)}, which validates the change; every other method
 * releases ownership. {@link #validate()} reports a broken invariant (used by the self-tests).
 * OOP pillar: <b>ENCAPSULATION</b> - state and owner are private and change only through these methods.
 */
public final class Ball {
    /** What the ball is doing right now. */
    public enum State { HELD, SHOT, PASS, LOOSE, DEAD }

    private static final double GRAVITY = 900;
    private static final int TRAIL = 12;

    private State state = State.DEAD;
    private double x;
    private double y;
    private double z;
    private double vx;
    private double vy;
    private double vz;
    private double spin;
    private Player holder;
    private Player lastTouch;
    private int ownerChanges;
    private String lastReason = "";

    private ShotAttempt shot;
    private Player passer;
    private Player receiver;
    private boolean passSafe;
    private double passSpeed;
    private double passTime;
    private double noGrab;
    private boolean fromShot;
    private Player reboundOverride;
    private boolean rattle;
    private int bounceSounds;

    private final double[] trailX = new double[TRAIL];
    private final double[] trailY = new double[TRAIL];
    private final double[] trailZ = new double[TRAIL];
    private int trailCount;

    // ---- the ONE ownership method ---------------------------------------------------------------------------

    /**
     * Gives the ball to {@code p}. This is the only way a player becomes the owner.
     * Refused (returns false) if p is null or the ball is in a shot that has not landed yet.
     */
    public boolean giveTo(Player p, String reason) {
        if (p == null || state == State.SHOT) {
            System.err.println("[Ball] refused giveTo(" + p + ") while " + state + " (" + reason + ")");
            return false;
        }
        state = State.HELD;
        holder = p;
        lastTouch = p;
        shot = null;
        passer = null;
        receiver = null;
        reboundOverride = null;
        fromShot = false;
        trailCount = 0;
        z = 30;
        ownerChanges++;
        lastReason = reason;
        return true;
    }

    /** Kept for older code: same as {@code giveTo(p, "legacy")}. */
    public void giveTo(Player p) {
        giveTo(p, "legacy");
    }

    /** Null if every invariant holds, otherwise a description of what is wrong. */
    public String validate() {
        if (state == State.HELD && holder == null) {
            return "HELD without an owner";
        }
        if (state != State.HELD && holder != null) {
            return state + " but still has owner " + holder;
        }
        if (z < -0.01) {
            return "ball below the floor";
        }
        if (state == State.SHOT && shot == null) {
            return "SHOT without shot data";
        }
        return null;
    }

    // ---- releases (the ball has no owner afterwards) --------------------------------------------------------

    public void startShot(ShotAttempt attempt) {
        state = State.SHOT;
        shot = attempt;
        holder = null;
        lastTouch = attempt.getShooter();
        trailCount = 0;
    }

    public void startPass(Player from, Player to, double speed, boolean safe) {
        state = State.PASS;
        passer = from;
        receiver = to;
        passSpeed = speed;
        passSafe = safe;
        passTime = 0;
        holder = null;
        lastTouch = from;
        z = 45;
    }

    /** Makes the ball loose with a velocity (rebounds, blocks, deflections). */
    public void makeLoose(double nx, double ny, double nz, double vx, double vy, double vz, boolean fromShot, double noGrab) {
        state = State.LOOSE;
        holder = null;
        shot = null;
        x = nx;
        y = ny;
        z = Math.max(0, nz);
        this.vx = vx;
        this.vy = vy;
        this.vz = vz;
        this.fromShot = fromShot;
        this.noGrab = noGrab;
    }

    /** Dead ball after a score / out of bounds. {@code throughHoop} = drops through the net (rattles sometimes). */
    public void makeDead(double nx, double ny, double nz, boolean throughHoop, boolean rattleFirst) {
        state = State.DEAD;
        holder = null;
        shot = null;
        x = nx;
        y = ny;
        z = Math.max(0, nz);
        vx = throughHoop ? 0 : vx * 0.2;
        vy = throughHoop ? 14 : 30;
        vz = throughHoop ? -40 : -60;
        rattle = rattleFirst;
    }

    public void makeDead(double nx, double ny, double nz) {
        makeDead(nx, ny, nz, false, false);
    }

    public void setReboundOverride(Player p) { reboundOverride = p; }

    public Player getReboundOverride() { return reboundOverride; }

    // ---- per-step movement ----------------------------------------------------------------------------------

    public void update(double dt, Court court) {
        switch (state) {
            case HELD:
                followHolder();
                break;
            case SHOT:
                flyShot(dt, court);
                break;
            case PASS:
                flyPass(dt);
                break;
            default:
                physics(dt);
                break;
        }
        noGrab = Math.max(0, noGrab - dt);
        recordTrail();
    }

    /** Logic position = the holder's position. (The renderer draws the ball at the sprite's hand.) */
    private void followHolder() {
        x = holder.getX();
        y = holder.getY() + 1;
        ActionType t = holder.getActions().getType();
        boolean high = t == ActionType.JUMP_SHOT || t == ActionType.FREE_THROW || t == ActionType.DUNK
                || t == ActionType.LAYUP || holder.isChargingShot();
        z = holder.getZ() + (high ? 80 : 30);
        spin += Math.hypot(holder.getVx(), holder.getVy()) * 0.0005;
    }

    private void flyShot(double dt, Court court) {
        shot.advance(dt);
        double t = shot.getProgress();
        double tx = court.getHoopX();
        double ty = court.getHoopY();
        double endZ = court.getRimHeight() + 8;
        if (shot.isBank() && t < 0.72) {
            // first part of a bank shot: to the backboard square, above the rim
            double bx = tx + (shot.getStartX() > tx ? 9 : -9);
            double by = court.getTop() + 1.2 * Court.PX_PER_M + 4;
            double u = t / 0.72;
            x = shot.getStartX() + (bx - shot.getStartX()) * u;
            y = shot.getStartY() + (by - shot.getStartY()) * u;
            z = shot.getStartZ() + (endZ + 34 - shot.getStartZ()) * u + 4 * shot.getPeak() * u * (1 - u);
        } else if (shot.isBank()) {
            double bx = tx + (shot.getStartX() > tx ? 9 : -9);
            double by = court.getTop() + 1.2 * Court.PX_PER_M + 4;
            double u = (t - 0.72) / 0.28;
            x = bx + (tx - bx) * u;
            y = by + (ty - by) * u;
            z = endZ + 34 - 34 * u;
        } else {
            x = shot.getStartX() + (tx - shot.getStartX()) * t;
            y = shot.getStartY() + (ty - shot.getStartY()) * t;
            z = shot.getStartZ() + (endZ - shot.getStartZ()) * t + 4 * shot.getPeak() * t * (1 - t);
        }
        z = Math.max(0, z);
        spin += dt * 9;
    }

    private void flyPass(double dt) {
        passTime += dt;
        double dx = receiver.getX() - x;
        double dy = receiver.getY() - y;
        double dist = Math.hypot(dx, dy);
        double step = passSpeed * dt;
        if (dist > 0.001) {
            x += dx / Math.max(dist, step) * Math.min(step, dist);
            y += dy / Math.max(dist, step) * Math.min(step, dist);
        }
        z = 40 + Math.min(30, dist * 0.06);
        spin += dt * 6;
    }

    private void physics(double dt) {
        if (rattle && state == State.DEAD && z > 60) {
            // a made shot circling the rim before dropping
            spin += dt * 20;
            vz -= GRAVITY * 0.15 * dt;
            z += vz * dt;
            x += Math.sin(spin) * 0.6;
            if (vz < -60) {
                rattle = false;
            }
            return;
        }
        vz -= GRAVITY * dt;
        x += vx * dt;
        y += vy * dt;
        z += vz * dt;
        if (z < 0) {
            z = 0;
            if (vz < -120) {
                bounceSounds++;
            }
            vz = -vz * 0.55;
            if (vz < 40) {
                vz = 0;
            }
            vx *= 0.8;
            vy *= 0.8;
        }
        if (z == 0 && vz == 0) {
            double friction = Math.exp(-1.6 * dt);
            vx *= friction;
            vy *= friction;
        }
        spin += Math.hypot(vx, vy) * dt * 0.02;
    }

    private void recordTrail() {
        System.arraycopy(trailX, 0, trailX, 1, TRAIL - 1);
        System.arraycopy(trailY, 0, trailY, 1, TRAIL - 1);
        System.arraycopy(trailZ, 0, trailZ, 1, TRAIL - 1);
        trailX[0] = x;
        trailY[0] = y;
        trailZ[0] = z;
        if (state == State.SHOT || state == State.PASS) {
            trailCount = Math.min(TRAIL, trailCount + 1);
        } else {
            trailCount = Math.max(0, trailCount - 1);
        }
    }

    /** Number of hard floor bounces since the last call (for the bounce sound). */
    public int consumeBounces() {
        int b = bounceSounds;
        bounceSounds = 0;
        return b;
    }

    // ---- getters --------------------------------------------------------------------------------------------

    public State getState() { return state; }

    public Player getHolder() { return holder; }

    /** DRIBBLING = held by a player who is not shooting, passing or finishing. */
    /** Dribble bounces per second at this speed (shared by the dribble sound and the retro renderer). */
    public static double dribbleRate(double speed) {
        return speed > 40 ? 2.5 : 1.7;
    }

    public boolean isDribbling() {
        if (state != State.HELD) {
            return false;
        }
        ActionType t = holder.getActions().getType();
        return t == ActionType.DRIBBLE_IDLE || t == ActionType.DRIBBLE_MOVE || t == ActionType.CROSSOVER
                || t == ActionType.IDLE || t == ActionType.WALK || t == ActionType.SPRINT;
    }

    /** REBOUND_CONTEST = loose after a shot and still bouncing high. */
    public boolean isReboundContest() { return state == State.LOOSE && fromShot && z > 20; }

    public Player getLastTouch() { return lastTouch; }

    public void setLastTouch(Player p) { lastTouch = p; }

    public ShotAttempt getShot() { return shot; }

    public Player getPasser() { return passer; }

    public Player getReceiver() { return receiver; }

    public boolean isPassSafe() { return passSafe; }

    public double getPassTime() { return passTime; }

    public boolean canBeGrabbed() { return noGrab <= 0; }

    public boolean isFromShot() { return fromShot; }

    public int getOwnerChanges() { return ownerChanges; }

    public String getLastReason() { return lastReason; }

    public double getX() { return x; }

    public double getY() { return y; }

    public double getZ() { return z; }

    public double getSpin() { return spin; }

    public double getSpeed() { return Math.hypot(vx, vy); }

    public int getTrailCount() { return trailCount; }

    public double getTrailX(int i) { return trailX[i]; }

    public double getTrailY(int i) { return trailY[i]; }

    public double getTrailZ(int i) { return trailZ[i]; }
}
