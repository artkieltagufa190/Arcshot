package arcshot.effect;

/**
 * Rim Protector: every opponent shot inside the paint is automatically contested.
 * OOP pillars: <b>INHERITANCE</b> (extends StatusEffect) and <b>POLYMORPHISM</b> (overrides only the modifiers it changes).
 */
public class RimProtectorEffect extends StatusEffect {
    public RimProtectorEffect(double duration) {
        super("rim_protector", duration, false);
    }

    @Override
    public boolean autoContestsPaint() { return true; }
}
