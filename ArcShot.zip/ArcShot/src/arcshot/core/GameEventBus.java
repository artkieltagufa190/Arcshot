package arcshot.core;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Observer / publish-subscribe hub. Gameplay publishes {@link GameEvent}s; achievements, HUD toasts and
 * sound effects subscribe. Publishers and subscribers never reference each other directly (loose coupling).
 * <p>
 * OOP pillar: <b>ENCAPSULATION</b> (the listener list is private) and <b>ABSTRACTION</b> (only the
 * {@link GameEventListener} interface is known).
 */
public final class GameEventBus {
    private final List<GameEventListener> listeners = new CopyOnWriteArrayList<>();

    public void subscribe(GameEventListener listener) {
        if (listener != null && !listeners.contains(listener)) {
            listeners.add(listener);
        }
    }

    public void unsubscribe(GameEventListener listener) {
        listeners.remove(listener);
    }

    /** Delivers the event to every listener. A crashing listener never stops the others. */
    public void publish(GameEvent event) {
        for (GameEventListener listener : listeners) {
            try {
                listener.onEvent(event);
            } catch (RuntimeException ex) {
                ex.printStackTrace();
            }
        }
    }
}
