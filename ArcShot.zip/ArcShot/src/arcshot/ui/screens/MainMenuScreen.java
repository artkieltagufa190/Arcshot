package arcshot.ui.screens;

import arcshot.app.AppContext;
import arcshot.app.GameMode;
import arcshot.cosmetic.CosmeticRegistry;
import arcshot.cosmetic.CosmeticType;
import arcshot.save.Profile;
import arcshot.ui.Screen;
import arcshot.ui.Theme;
import arcshot.ui.UIFactory;
import arcshot.ui.components.RoundedPanel;
import arcshot.ui.components.ThemedButton;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

/**
 * Main menu. Game-mode buttons are built from the list of {@link GameMode}s (POLYMORPHISM, as in the original menu),
 * plus Achievements, Customize, Settings, How to Play, Stats and Quit.
 */
public class MainMenuScreen extends Screen {
    private final Timer anim;
    private final HeroArt hero = new HeroArt();

    public MainMenuScreen(AppContext app) {
        super(app);
        JPanel left = UIFactory.column();
        JLabel title = UIFactory.label("ARCSHOT", Theme.display(88), Theme.TEXT);
        left.add(title);
        left.add(UIFactory.label(app.skin().text("menu.tagline", "3x3 half-court basketball with abilities"),
                Theme.semi(18), Theme.ACCENT));
        left.add(UIFactory.vgap(Theme.S5));
        for (GameMode mode : app.modes()) {
            ThemedButton b = new ThemedButton(mode.getTitle(), mode.getDescription(),
                    mode == app.modes().get(0) ? ThemedButton.Style.PRIMARY : ThemedButton.Style.SECONDARY);
            b.setAlignmentX(LEFT_ALIGNMENT);
            b.setMaximumSize(new Dimension(470, 74));
            b.addActionListener(e -> mode.launch(app));
            left.add(b);
            left.add(UIFactory.vgap(Theme.S3));
        }
        left.add(UIFactory.vgap(Theme.S3));
        JPanel grid = UIFactory.clear(new GridLayout(0, 3, Theme.S3, Theme.S3));
        grid.setAlignmentX(LEFT_ALIGNMENT);
        grid.setMaximumSize(new Dimension(470, 110));
        grid.add(UIFactory.secondary("Achievements", e -> app.screens().push(new AchievementsScreen(app))));
        grid.add(UIFactory.secondary("Customize", e -> app.screens().push(new CustomizeScreen(app))));
        grid.add(UIFactory.secondary("Settings", e -> app.screens().push(new SettingsScreen(app))));
        grid.add(UIFactory.secondary("How to Play", e -> app.screens().push(new HowToPlayScreen(app))));
        grid.add(UIFactory.secondary("Stats", e -> app.screens().push(new StatsScreen(app))));
        grid.add(UIFactory.button("Quit", ThemedButton.Style.GHOST, e -> app.quit()));
        left.add(grid);
        JPanel leftWrap = UIFactory.clear(new BorderLayout());
        leftWrap.setPreferredSize(new Dimension(470, 1));
        leftWrap.add(left, BorderLayout.NORTH);
        add(leftWrap, BorderLayout.WEST);

        JPanel right = UIFactory.clear(new BorderLayout());
        right.setBorder(BorderFactory.createEmptyBorder(0, Theme.S7, 0, 0));
        right.add(hero, BorderLayout.CENTER);
        right.add(profileCard(), BorderLayout.SOUTH);
        add(right, BorderLayout.CENTER);
        anim = new Timer(33, e -> hero.repaint());
    }

    private JComponent profileCard() {
        Profile p = app.profile();
        RoundedPanel card = UIFactory.card(new BorderLayout(Theme.S4, 0));
        JPanel text = UIFactory.column();
        text.add(UIFactory.label(p.getName(), Theme.display(32), Theme.TEXT));
        text.add(UIFactory.label(p.getTitle().isEmpty() ? "No title yet" : "\"" + p.getTitle() + "\"", Theme.semi(15), Theme.GOLD));
        card.add(text, BorderLayout.WEST);
        JPanel stats = UIFactory.clear(new GridLayout(1, 3, Theme.S4, 0));
        stats.add(stat(String.valueOf(p.getStat("wins")), "WINS"));
        stats.add(stat(String.valueOf(p.getStat("matches")), "MATCHES"));
        stats.add(stat(app.achievements().countAllUnlocked() + "/" + app.achievements().all().size(), "ACHIEVEMENTS"));
        card.add(stats, BorderLayout.EAST);
        return card;
    }

    private JComponent stat(String value, String label) {
        JPanel p = UIFactory.column();
        p.add(UIFactory.label(value, Theme.display(30), Theme.TEXT));
        p.add(UIFactory.label(label, Theme.bold(11), Theme.TEXT_MUTED));
        return p;
    }

    @Override
    public void onEnter() {
        anim.start();
    }

    @Override
    public void onResume() {
        // stats / title may have changed: rebuild by replacing ourselves
        app.screens().replaceAll(new MainMenuScreen(app));
    }

    @Override
    public void onHide() {
        anim.stop();
    }

    @Override
    public void onExit() {
        anim.stop();
    }

    /** Decorative animated art: a mini court with a ball arcing into the hoop. */
    private final class HeroArt extends JComponent {
        private final long start = System.currentTimeMillis();

        @Override
        protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.quality(g);
            int w = getWidth();
            int h = getHeight() - Theme.S5;
            double t = (System.currentTimeMillis() - start) / 1000.0;
            Color floor = CosmeticRegistry.getOrDefault(app.profile().getCourt(), CosmeticType.COURT).color(0);
            Color lines = CosmeticRegistry.getOrDefault(app.profile().getCourt(), CosmeticType.COURT).color(1);
            int cw = Math.min(w - 20, (int) (h * 1.3));
            int chh = (int) (cw * 0.62);
            int cx = w / 2;
            int top = Math.max(10, (h - chh) / 2);
            g.setColor(new Color(0, 0, 0, 80));
            g.fillRoundRect(cx - cw / 2 + 6, top + 10, cw, chh, 30, 30);
            g.setColor(floor);
            g.fillRoundRect(cx - cw / 2, top, cw, chh, 30, 30);
            g.setColor(Theme.alpha(lines, 200));
            g.setStroke(new BasicStroke(3f));
            g.drawRoundRect(cx - cw / 2, top, cw, chh, 30, 30);
            int r = (int) (cw * 0.42);
            int hoopY = top + chh / 7;
            g.drawArc(cx - r, hoopY - r, r * 2, r * 2, 180, 180);
            g.drawRect(cx - cw / 8, top, cw / 4, chh * 4 / 9);
            // hoop
            g.setColor(new Color(235, 240, 250));
            g.fillRect(cx - 40, hoopY - 34, 80, 12);
            g.setColor(Theme.ACCENT);
            g.drawOval(cx - 18, hoopY - 18, 36, 14);
            // looping shot
            double p = (t % 2.2) / 1.6;
            if (p <= 1) {
                double sx = cx - cw * 0.3;
                double sy = top + chh * 0.85;
                double bx = sx + (cx - sx) * p;
                double by = sy + (hoopY - 18 - sy) * p - Math.sin(p * Math.PI) * chh * 0.5;
                SplashScreen.drawBall(g, bx, by, 14);
            } else {
                g.setFont(Theme.display(40));
                g.setColor(Theme.alpha(Theme.GOLD, (int) (255 * Math.min(1, (p - 1) * 4))));
                Theme.drawCentered(g, "SWISH!", cx, hoopY + 60);
            }
            g.setFont(Theme.semi(15));
            g.setColor(Theme.TEXT_MUTED);
            Theme.drawCentered(g, "Skin: " + app.skin().getDisplayName() + "   |   Court: "
                    + CosmeticRegistry.getOrDefault(app.profile().getCourt(), CosmeticType.COURT).getName(), cx, top + chh + 26);
            g.dispose();
        }
    }
}
