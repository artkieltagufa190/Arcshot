package arcshot.ability.big;

import arcshot.ability.AbilitySlot;
import arcshot.ability.ActiveAbility;
import arcshot.court.Match;
import arcshot.player.Player;

/**
 * Big E (alternate): a long outlet pass to your farthest teammate that cannot be intercepted.
 * OOP pillars: <b>INHERITANCE</b> (extends ActiveAbility / Ultimate) and <b>POLYMORPHISM</b> (overrides perform() and the optional hooks).
 */
public class BoulderToss extends ActiveAbility {
    public BoulderToss() {
        super("big.boulder_toss", AbilitySlot.E, 13);
    }

    @Override
    protected boolean meetsRequirements(Player owner, Match match) {
        return hasBall(owner, match);
    }

    @Override
    protected void perform(Player owner, Match match) {
        Player target = null;
        for (Player mate : match.teammatesOf(owner)) {
            if (target == null || mate.distanceTo(owner) > target.distanceTo(owner)) {
                target = mate;
            }
        }
        if (target != null) {
            match.pass(owner, target, true);
            match.fx().text("OUTLET!", "boulder", owner.getX(), owner.getY() - 70);
        }
    }

    @Override
    public boolean aiShouldUse(Player owner, Match match) {
        return hasBall(owner, match) && match.needsClear();
    }
}
