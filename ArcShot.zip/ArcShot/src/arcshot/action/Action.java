package arcshot.action;

import arcshot.anim.AnimationDef;
import arcshot.anim.AnimationTable;
import arcshot.court.Match;
import arcshot.player.Player;

/**
 * Base class of every player action (shot, layup, dunk, block, ...). An action plays one animation at its designed
 * speed and fires that animation's <b>frame events</b> (e.g. {@code ball_release}) exactly once each, so gameplay
 * moments are tied to what the player sees.
 * <p>
 * OOP pillars: <b>ABSTRACTION</b> (the controller only knows "an Action"), <b>INHERITANCE</b> (timing, events and
 * z handling are written once here), <b>POLYMORPHISM</b> (subclasses override {@link #onEvent}, {@link #getZ},
 * {@link #onUpdate}) and <b>ENCAPSULATION</b> (time and frame bookkeeping are private).
 */
public abstract class Action {
    private final ActionType type;
    private final String animation;
    private AnimationDef def;
    private double time;
    private int lastFrame = -1;
    private boolean finished;
    private boolean holding;

    protected Action(ActionType type, String animation) {
        this.type = type;
        this.animation = animation;
    }

    /** Called once when the controller accepts the action. */
    public final void start(Player p, Match m) {
        def = AnimationTable.get(p.getPlayerClass().key(), animation);
        onStart(p, m);
    }

    /** Advances time, fires frame events (never skipping one), and finishes non-looping actions. */
    public final void update(double dt, Player p, Match m) {
        if (finished) {
            return;
        }
        if (!holding) {
            time += dt;
        }
        int frame = def.frameAt(time);
        if (!def.isLoop()) {
            for (int f = lastFrame + 1; f <= frame; f++) {
                for (String e : def.eventsAt(f)) {
                    onEvent(e, p, m);
                    if (finished) {
                        return;
                    }
                }
            }
        }
        lastFrame = frame;
        onUpdate(dt, p, m);
        if (!finished && !holding && time >= duration()) {
            finish(p, m);
        }
    }

    /** Ends the action normally. */
    protected final void finish(Player p, Match m) {
        if (!finished) {
            finished = true;
            onEnd(p, m, false);
        }
    }

    /** Ends the action because something else replaced it. */
    public final void cancel(Player p, Match m) {
        if (!finished) {
            finished = true;
            onEnd(p, m, true);
        }
    }

    /** Freezes the animation on the current frame (e.g. while the shot meter is charging). */
    protected final void setHolding(boolean holding) {
        this.holding = holding;
    }

    /** Jumps the time to a frame (used to hold on the "dip" frame). */
    protected final void seekFrame(int frame) {
        time = frame / def.getFps();
        lastFrame = frame - 1;
    }

    // ---- hooks ----------------------------------------------------------------------------------------------

    protected void onStart(Player p, Match m) { }

    protected void onEvent(String event, Player p, Match m) { }

    protected void onUpdate(double dt, Player p, Match m) { }

    protected void onEnd(Player p, Match m, boolean cancelled) { }

    /** Height above the floor (world pixels). Default: on the ground. */
    public double getZ() { return 0; }

    /** True if the player passes through others (dashes). */
    public boolean isIntangible() { return false; }

    /** Total length; defaults to the animation length. */
    public double duration() { return def == null ? 0.3 : def.getDuration(); }

    // ---- getters --------------------------------------------------------------------------------------------

    public final ActionType getType() { return type; }

    public final String getAnimation() { return animation; }

    public final int getFrame() { return def == null ? 0 : def.frameAt(time); }

    public final double getTime() { return time; }

    public final boolean isFinished() { return finished; }

    public final boolean isHolding() { return holding; }

    protected final AnimationDef def() { return def; }

    /** 0..1 progress through the action. */
    protected final double progress() {
        double d = duration();
        return d <= 0 ? 1 : Math.min(1, time / d);
    }

    /** A jump arc: 0 at {@code t0}, {@code peak} halfway, 0 again at {@code t1}. */
    protected static double arc(double t, double t0, double t1, double peak) {
        if (t <= t0 || t >= t1) {
            return 0;
        }
        double u = (t - t0) / (t1 - t0);
        return Math.max(0, 4 * peak * u * (1 - u));
    }
}
