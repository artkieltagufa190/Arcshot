package arcshot.ability.big;

import arcshot.ability.AbilitySlot;
import arcshot.ability.ActiveAbility;
import arcshot.court.Match;
import arcshot.effect.SlowEffect;
import arcshot.player.Player;

/**
 * Big E (alternate): a stomp that slows every opponent nearby.
 * OOP pillars: <b>INHERITANCE</b> (extends ActiveAbility / Ultimate) and <b>POLYMORPHISM</b> (overrides perform() and the optional hooks).
 */
public class TremorStomp extends ActiveAbility {
    public TremorStomp() {
        super("big.tremor_stomp", AbilitySlot.E, 14);
    }

    @Override
    protected void perform(Player owner, Match match) {
        double radius = param("radius", 140);
        for (Player o : opponentsNear(owner, match, radius)) {
            o.applyEffect(new SlowEffect(param("slowTime", 2.5), param("slow", 0.6)));
        }
        match.shake(4);
        match.fx().ring("tremor", owner.getX(), owner.getY(), radius, 0.5);
    }

    @Override
    public boolean aiShouldUse(Player owner, Match match) {
        Player near = match.nearestOpponent(owner, 120);
        return near != null && (hasBall(near, match) || hasBall(owner, match));
    }
}
