package arcshot.achievement;

import arcshot.core.GameEvent;

/**
 * Decides whether an event counts for an achievement. Functional interface (can be a lambda).
 * OOP pillar: <b>ABSTRACTION</b> - achievements state a rule without knowing how events are produced.
 */
public interface EventFilter {
    boolean matches(GameEvent event);
}
