package arcshot.render;

import arcshot.court.CourtEntity;
import arcshot.court.Match;
import arcshot.court.PickScreen;
import arcshot.effect.StatusEffect;
import arcshot.player.Player;
import arcshot.ui.Theme;
import arcshot.ui.ThemeSkin;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RadialGradientPaint;
import java.awt.geom.Point2D;
import java.util.HashMap;
import java.util.Map;

/**
 * Draws ability and status-effect visuals by <i>key</i>, using colors from the current {@link ThemeSkin}.
 * Because gameplay only hands over keys, changing the skin or theme never touches gameplay code.
 * <p>
 * OOP pillar: <b>ABSTRACTION</b> + <b>ENCAPSULATION</b> (the key-to-color table is private).
 */
public final class EffectRenderer {
    private static final Map<String, Color> DEFAULTS = new HashMap<>();

    static {
        def("shadow", 0x7B5CFF); def("snap", 0xFFE066); def("slipstream", 0x4FE3FF); def("focus", 0xFFD84A);
        def("green_light", 0x3DDC84); def("pickpocket", 0xFF9F1C); def("timestop", 0x7A93B8); def("decoy", 0xA78BFA);
        def("fang", 0xFF4D6D); def("claw", 0xFF8C42); def("bull", 0xFF6B35); def("shockwave", 0x9AD1FF);
        def("sky_rend", 0x9AD1FF); def("rebound_surge", 0x6EE7B7); def("blazing_screen", 0xFF6A00);
        def("final_burst", 0xFFF3B0); def("meteor", 0xFF7849); def("barrier", 0x8FB8FF); def("bulwark", 0xC0C7D6);
        def("rim_protector", 0x5EEAD4); def("quake", 0xD4A373); def("boulder", 0xB08968); def("tremor", 0xC08552);
        def("titan_seal", 0xA78BFA); def("colossus", 0xF59E0B); def("block", 0xFFFFFF); def("steal", 0xFFD166);
        def("score", 0xFFB703); def("rim", 0xFFFFFF); def("whiff", 0x9CA3AF); def("switch", 0x2EC4FF);
        def("cleared", 0x3DDC84); def("timing_green", 0x3DDC84); def("timing_good", 0xA3E635);
        def("timing_early", 0xF87171); def("timing_late", 0xF87171); def("freeze", 0x9DB4D6); def("slow", 0x60A5FA);
        def("stun", 0xFDE047); def("no_shoot", 0xF87171); def("screen_boost", 0xFFB347); def("rising_fang", 0xFF4D6D);
        def("unblockable", 0xFFF3B0); def("shot_penalty", 0xA78BFA); def("ball_trail", 0xFF9A4D);
    }

    private static void def(String key, int rgb) {
        DEFAULTS.put(key, new Color(rgb));
    }

    private final ThemeSkin skin;
    private final Map<String, Color> cache = new HashMap<>();
    private boolean colorblind;

    public EffectRenderer(ThemeSkin skin) {
        this.skin = skin;
    }

    public void setColorblind(boolean colorblind) { this.colorblind = colorblind; }

    public boolean isColorblind() { return colorblind; }

    /** Skin color for a key, falling back to the built-in table, then white. */
    public Color colorFor(String key) {
        Color c = cache.get(key);
        if (c == null) {
            Color fallback = DEFAULTS.get(key);
            c = skin.color(key, fallback == null ? Color.WHITE : fallback);
            cache.put(key, c);
        }
        return c;
    }

    public double particleScale() { return skin.particleScale(); }

    /** A soft glowing circle. */
    public void glow(Graphics2D g, double x, double y, double radius, Color c, int alpha) {
        if (radius < 1) {
            return;
        }
        Color inner = Theme.alpha(c, alpha);
        Color outer = Theme.alpha(c, 0);
        g.setPaint(new RadialGradientPaint(new Point2D.Double(x, y), (float) radius,
                new float[] {0f, 1f}, new Color[] {inner, outer}));
        g.fillOval((int) (x - radius), (int) (y - radius), (int) (radius * 2), (int) (radius * 2));
    }

    /** An ellipse ring on the floor (top-down perspective squashes circles vertically). */
    public void floorRing(Graphics2D g, double x, double y, double radius, Color c, float width, int alpha) {
        g.setColor(Theme.alpha(c, alpha));
        g.setStroke(new BasicStroke(width));
        g.drawOval((int) (x - radius), (int) (y - radius * 0.55), (int) (radius * 2), (int) (radius * 1.1));
    }

    /** Draws the floor part of every active effect on a player (under the body). */
    public void drawUnder(Graphics2D g, Player p, double time) {
        for (StatusEffect e : p.getEffects()) {
            String key = e.getId();
            Color c = colorFor(key);
            double pulse = 0.5 + 0.5 * Math.sin(time * 8);
            switch (key) {
                case "focus":
                case "green_light":
                case "colossus":
                    glow(g, p.getX(), p.getY() - 26, 46 + pulse * 6, c, 110);
                    break;
                case "barrier":
                    floorRing(g, p.getX(), p.getY(), 32, c, 3f, 200);
                    floorRing(g, p.getX(), p.getY(), 38 + pulse * 4, c, 1.5f, 120);
                    break;
                case "sky_rend":
                case "rebound_surge":
                case "pickpocket":
                    floorRing(g, p.getX(), p.getY(), 28 + pulse * 10, c, 2f, 170);
                    break;
                case "slow":
                    floorRing(g, p.getX(), p.getY(), 22, c, 2f, 150);
                    break;
                case "rim_protector":
                    floorRing(g, p.getX(), p.getY(), 26, c, 2.5f, 190);
                    break;
                default:
                    break;
            }
        }
    }

    /** Draws effect overlays on top of a player body (freeze tint, stun stars, labels). */
    public void drawOver(Graphics2D g, Player p, double time, double headY) {
        int labelRow = 0;
        for (StatusEffect e : p.getEffects()) {
            String key = e.getId();
            Color c = colorFor(key);
            if ("freeze".equals(key)) {
                g.setColor(Theme.alpha(c, 150));
                g.fillRoundRect((int) p.getX() - 18, (int) headY - 12, 36, 62, 14, 14);
                g.setColor(Theme.alpha(Color.WHITE, 200));
                g.setStroke(new BasicStroke(1.5f));
                g.drawRoundRect((int) p.getX() - 18, (int) headY - 12, 36, 62, 14, 14);
            } else if ("stun".equals(key)) {
                for (int i = 0; i < 3; i++) {
                    double a = time * 6 + i * 2.1;
                    double sx = p.getX() + Math.cos(a) * 14;
                    double sy = headY - 14 + Math.sin(a) * 4;
                    g.setColor(c);
                    g.fillOval((int) sx - 3, (int) sy - 3, 6, 6);
                }
            }
            if (colorblind && labelRow < 2 && !"screen_boost".equals(key)) {
                g.setFont(Theme.bold(10));
                String label = e.getLabel();
                int w = g.getFontMetrics().stringWidth(label) + 8;
                int ly = (int) p.getY() + 14 + labelRow * 13;
                g.setColor(new Color(0, 0, 0, 170));
                g.fillRoundRect((int) p.getX() - w / 2, ly, w, 12, 6, 6);
                g.setColor(e.isDebuff() ? new Color(0xFFB4B4) : new Color(0xB4FFD0));
                g.drawString(label, (int) p.getX() - w / 2 + 4, ly + 10);
                labelRow++;
            }
        }
    }

    /** Draws a court entity (field, screen or decoy). Decoys are drawn by the PlayerRenderer. */
    public void drawEntity(Graphics2D g, CourtEntity e, Match match, double time) {
        Color c = colorFor(e.getVisualKey());
        double fade = Math.min(1, e.getFractionLeft() * 4);
        int a = (int) (200 * fade);
        switch (e.getVisualKey()) {
            case "titan_seal":
                g.setColor(Theme.alpha(c, (int) (55 * fade)));
                g.fillOval((int) (e.getX() - e.getRadius()), (int) (e.getY() - e.getRadius() * 0.6),
                        (int) (e.getRadius() * 2), (int) (e.getRadius() * 1.2));
                floorRing(g, e.getX(), e.getY(), e.getRadius(), c, 3f, a);
                floorRing(g, e.getX(), e.getY(), e.getRadius() * (0.6 + 0.1 * Math.sin(time * 4)), c, 1.5f, a / 2);
                break;
            case "bulwark":
                floorRing(g, e.getX(), e.getY(), e.getRadius(), c, 1.5f, a / 2);
                drawPost(g, e, c, a);
                break;
            case "blazing_screen":
                glow(g, e.getX(), e.getY() - 16, 38, colorFor("blazing_screen"), (int) (150 * fade));
                drawPost(g, e, c, a);
                break;
            default:
                break;
        }
    }

    private void drawPost(Graphics2D g, CourtEntity e, Color c, int a) {
        double r = e instanceof PickScreen ? e.getBlockRadius() : e.getRadius();
        g.setColor(Theme.alpha(Color.BLACK, a / 3));
        g.fillOval((int) (e.getX() - r), (int) (e.getY() - r * 0.45), (int) (r * 2), (int) (r * 0.9));
        g.setColor(Theme.alpha(c, a));
        g.fillRoundRect((int) (e.getX() - r * 0.7), (int) (e.getY() - 46), (int) (r * 1.4), 46, 10, 10);
        g.setColor(Theme.alpha(Color.WHITE, a));
        g.setStroke(new BasicStroke(1.5f));
        g.drawRoundRect((int) (e.getX() - r * 0.7), (int) (e.getY() - 46), (int) (r * 1.4), 46, 10, 10);
    }
}
