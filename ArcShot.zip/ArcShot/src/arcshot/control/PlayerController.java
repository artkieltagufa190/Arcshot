package arcshot.control;

import arcshot.court.Match;
import arcshot.player.Player;

/**
 * Anything that can "drive" a player: the keyboard, the AI, a practice dummy - and later a second keyboard
 * for local multiplayer (just another implementation with different {@link KeyBindings}).
 * <p>
 * OOP pillars: <b>ABSTRACTION</b> (the match only knows this interface) and <b>POLYMORPHISM</b> (the match calls
 * {@code fillInput} the same way whether a human or the AI is in control).
 */
public interface PlayerController {
    /** Decide this frame's input for {@code self} and write it into {@code out}. */
    void fillInput(Player self, Match match, PlayerInput out, double dt);

    /** True for human controllers (used for the "YOU" marker and cooldown-waste tracking). */
    boolean isHuman();
}
