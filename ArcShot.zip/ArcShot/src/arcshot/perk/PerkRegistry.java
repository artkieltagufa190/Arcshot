package arcshot.perk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Creates perks by string id (used by loadouts and unlocks). Factory pattern.
 * OOP pillar: <b>ABSTRACTION</b> - callers ask for "hot_hand" and get a {@link Perk}.
 */
public final class PerkRegistry {
    private static final List<String> IDS = Collections.unmodifiableList(java.util.Arrays.asList(
            "quick_charge", "second_wind", "clutch_gene", "hot_hand", "ironclad"));

    private PerkRegistry() { }

    public static List<String> allIds() { return IDS; }

    /** Returns a new perk, or null for an unknown/empty id. */
    public static Perk create(String id) {
        if (id == null) {
            return null;
        }
        switch (id) {
            case "quick_charge": return new QuickChargePerk();
            case "second_wind": return new SecondWindPerk();
            case "clutch_gene": return new ClutchGenePerk();
            case "hot_hand": return new HotHandPerk();
            case "ironclad": return new IroncladPerk();
            default: return null;
        }
    }

    public static List<Perk> all() {
        List<Perk> list = new ArrayList<>();
        for (String id : IDS) {
            list.add(create(id));
        }
        return list;
    }
}
