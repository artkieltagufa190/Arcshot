@echo off
rem Compile and run ArcShot on Windows. Usage: build.bat   (or: build.bat compile / jar / test / sprites)
cd /d "%~dp0"
if "%1"=="sprites" (
  if exist out-tools rmdir /s /q out-tools
  mkdir out-tools
  javac -encoding UTF-8 --release 10 -sourcepath src -d out-tools tools\SpriteSheetGenerator.java || goto :error
  java -cp out-tools SpriteSheetGenerator resources\sprites
  goto :eof
)
if exist out rmdir /s /q out
mkdir out
dir /s /b src\*.java > out\sources.txt
javac -encoding UTF-8 --release 10 -d out @out\sources.txt || goto :error
xcopy /e /i /q /y resources out >nul
del out\sources.txt
if "%1"=="compile" goto :eof
if "%1"=="test" (
  java -cp out arcshot.test.SelfTests 4
  goto :eof
)
if "%1"=="jar" (
  jar cfe ArcShot.jar arcshot.App -C out .
  echo Built ArcShot.jar - run with: java -jar ArcShot.jar
  goto :eof
)
java -cp out arcshot.App
goto :eof
:error
echo Build failed.
exit /b 1
