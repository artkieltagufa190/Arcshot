package arcshot.achievement;

import arcshot.core.Balance;

/**
 * Rookie -> Starter -> All-Star -> MVP -> Legend. A tier opens when enough achievements of the previous tier are earned.
 * OOP pillar: <b>ENCAPSULATION</b> - each enum constant keeps its data in private fields behind getters.
 */
public enum AchievementTier {
    ROOKIE("Rookie", 0), STARTER("Starter", 3), ALL_STAR("All-Star", 4), MVP("MVP", 4), LEGEND("Legend", 3);

    private final String displayName;
    private final int defaultRequired;

    AchievementTier(String displayName, int defaultRequired) {
        this.displayName = displayName;
        this.defaultRequired = defaultRequired;
    }

    public String getDisplayName() { return displayName; }

    /** How many achievements of the previous tier are needed to open this one (balance.properties). */
    public int requiredFromPrevious() {
        return Balance.i("tier." + name().toLowerCase() + ".required", defaultRequired);
    }

    public AchievementTier previous() {
        return ordinal() == 0 ? null : values()[ordinal() - 1];
    }
}
