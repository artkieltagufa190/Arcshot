package arcshot.ai;

/**
 * Guard: lives on the perimeter, happy to shoot from outside.
 * OOP pillars: <b>INHERITANCE</b> (extends AIStrategy) and <b>POLYMORPHISM</b> (overrides the role choices).
 */
public class GuardStrategy extends AIStrategy {
    @Override
    protected double[] preferredSpot(boolean leftSide) {
        return new double[] {leftSide ? -20 : 20, 380};
    }

    @Override
    public double shotValueThreshold() { return 0.80; }

    @Override
    public boolean crashesBoards() { return false; }
}
