package arcshot.ui.components;

import arcshot.ui.Theme;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.RenderingHints;
import java.awt.Transparency;
import java.awt.image.BufferedImage;
import javax.swing.JPanel;

/**
 * Shows frames rendered by the game thread. The game draws into a back buffer (1280x720 for the smooth style,
 * 640x360 for the retro style); {@link #present} swaps it in, and {@code paintComponent} scales it to fit the window
 * with letterboxing. Pixel-art frames are scaled by a whole number with nearest-neighbour (crisp, no blur),
 * optionally with CRT scanlines.
 * The Swing thread therefore only copies an image and never waits for game logic.
 * OOP pillar: <b>ENCAPSULATION</b> - the buffers and their lock are private.
 */
public class GameCanvas extends JPanel {
    private final Object lock = new Object();
    private BufferedImage front;
    private BufferedImage spare;
    private volatile boolean pixelArt;
    private volatile boolean crt;

    public GameCanvas() {
        setBackground(Theme.BG);
        setFocusable(true);
        setFocusTraversalKeysEnabled(false); // let Tab reach the game (switch player)
        setDoubleBuffered(true);
    }

    /** A buffer for the game thread to draw the next frame into (logical 1280x720). */
    public BufferedImage obtainBuffer() {
        return obtainBuffer(Theme.LOGICAL_W, Theme.LOGICAL_H);
    }

    /** A buffer of the given size (640x360 for the retro renderer). */
    public BufferedImage obtainBuffer(int width, int height) {
        synchronized (lock) {
            if (spare != null) {
                BufferedImage b = spare;
                spare = null;
                if (b.getWidth() == width && b.getHeight() == height) {
                    return b;
                }
            }
        }
        GraphicsConfiguration gc = GraphicsEnvironment.isHeadless() ? null
                : GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().getDefaultConfiguration();
        return gc == null ? new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB)
                : gc.createCompatibleImage(width, height, Transparency.OPAQUE);
    }

    /** True = whole-number nearest-neighbour scaling (retro). */
    public void setPixelArt(boolean pixelArt) { this.pixelArt = pixelArt; }

    public void setCrt(boolean crt) { this.crt = crt; }

    /** Makes {@code frame} the visible frame; the previous one is kept for reuse. */
    public void present(BufferedImage frame) {
        synchronized (lock) {
            if (front != null && front != frame) {
                spare = front;
            }
            front = frame;
        }
        repaint();
    }

    /** Copy of the visible frame (used for screenshots / pause background). */
    public BufferedImage snapshot() {
        synchronized (lock) {
            return front;
        }
    }

    @Override
    protected void paintComponent(Graphics g0) {
        Graphics2D g = (Graphics2D) g0;
        g.setColor(Theme.BG);
        g.fillRect(0, 0, getWidth(), getHeight());
        synchronized (lock) {
            if (front == null) {
                return;
            }
            int fw = front.getWidth();
            int fh = front.getHeight();
            double scale = Math.min(getWidth() / (double) fw, getHeight() / (double) fh);
            if (pixelArt && scale >= 1) {
                scale = Math.floor(scale); // integer scaling keeps every pixel the same size
            }
            int w = (int) Math.round(fw * scale);
            int h = (int) Math.round(fh * scale);
            int x = (getWidth() - w) / 2;
            int y = (getHeight() - h) / 2;
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, pixelArt
                    ? RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR : RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g.drawImage(front, x, y, w, h, null);
            if (pixelArt && crt && scale >= 2) {
                drawScanlines(g, x, y, w, h, (int) scale);
            }
        }
    }

    /** CRT look: a dark line on the last screen row of every source pixel row, plus a soft edge. */
    private static void drawScanlines(Graphics2D g, int x, int y, int w, int h, int scale) {
        g.setColor(new java.awt.Color(0, 0, 0, scale >= 3 ? 70 : 55));
        for (int yy = y + scale - 1; yy < y + h; yy += scale) {
            g.fillRect(x, yy, w, 1);
        }
        g.setColor(new java.awt.Color(0, 0, 0, 40));
        g.fillRect(x, y, w, scale * 2);
        g.fillRect(x, y + h - scale * 2, w, scale * 2);
    }
}
