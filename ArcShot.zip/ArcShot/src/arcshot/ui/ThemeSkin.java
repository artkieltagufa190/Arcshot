package arcshot.ui;

import java.awt.Color;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * A "skin" is the flavor layer: ability names and descriptions, effect colors, particle intensity and UI flavor text.
 * Two skins ship: {@code anime} (default) and {@code street} (neutral / PBA-style names, toned-down effects).
 * Gameplay code only stores ability <i>ids</i>; names and colors are looked up here, so switching skins never
 * touches gameplay.
 * <p>
 * OOP pillar: <b>ENCAPSULATION</b> (properties are private, typed accessors with fallbacks) and
 * <b>ABSTRACTION</b> (callers ask for "the name of guard.shadow_step", not for a file).
 */
public final class ThemeSkin {
    public static final String ANIME = "anime";
    public static final String STREET = "street";

    private final String id;
    private final Properties props = new Properties();
    private final Properties fallback = new Properties();

    public ThemeSkin(String id) {
        this.id = STREET.equals(id) ? STREET : ANIME;
        load(props, "/skins/" + this.id + ".properties");
        load(fallback, "/skins/anime.properties");
    }

    private static void load(Properties target, String path) {
        try (InputStream in = ThemeSkin.class.getResourceAsStream(path)) {
            if (in != null) {
                target.load(new java.io.InputStreamReader(in, java.nio.charset.StandardCharsets.UTF_8));
            }
        } catch (IOException | IllegalArgumentException ex) {
            // keep whatever loaded; every getter has a fallback
        }
    }

    public String getId() { return id; }

    public String getDisplayName() { return text("skin.name", ANIME.equals(id) ? "Anime" : "Street"); }

    private String raw(String key) {
        String value = props.getProperty(key);
        return value != null ? value : fallback.getProperty(key);
    }

    /** Any flavor text, e.g. {@code text("menu.tagline", "...")}. */
    public String text(String key, String def) {
        String value = raw(key);
        return value == null ? def : value;
    }

    public String abilityName(String abilityId) {
        return text("ability." + abilityId + ".name", prettify(abilityId));
    }

    public String abilityDescription(String abilityId) {
        return text("ability." + abilityId + ".desc", "");
    }

    /** Effect color by key, e.g. {@code color("focus")}. */
    public Color color(String key, Color def) {
        return Theme.parse(raw("color." + key), def);
    }

    /** 1.0 = full particles (anime), lower = toned down (street). */
    public double particleScale() {
        try {
            return Double.parseDouble(text("particles.scale", "1.0"));
        } catch (NumberFormatException ex) {
            return 1.0;
        }
    }

    private static String prettify(String abilityId) {
        String last = abilityId.substring(abilityId.lastIndexOf('.') + 1).replace('_', ' ');
        StringBuilder sb = new StringBuilder();
        for (String word : last.split(" ")) {
            if (!word.isEmpty()) {
                sb.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1)).append(' ');
            }
        }
        return sb.toString().trim();
    }
}
