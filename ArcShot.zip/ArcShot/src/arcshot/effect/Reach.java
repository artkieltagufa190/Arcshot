package arcshot.effect;

/**
 * The different "reach" radii a player has; effects can enlarge or shrink each one.
 * OOP pillar: <b>ABSTRACTION</b> - a fixed set of named values instead of magic strings or numbers.
 */
public enum Reach {
    BLOCK, STEAL, REBOUND, CONTEST
}
