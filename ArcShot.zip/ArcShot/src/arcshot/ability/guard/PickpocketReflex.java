package arcshot.ability.guard;

import arcshot.ability.AbilitySlot;
import arcshot.ability.ActiveAbility;
import arcshot.court.Match;
import arcshot.effect.Reach;
import arcshot.effect.ReachBoostEffect;
import arcshot.player.Player;

/**
 * Guard E (alternate): 3 s much larger steal radius.
 * OOP pillars: <b>INHERITANCE</b> (extends ActiveAbility / Ultimate) and <b>POLYMORPHISM</b> (overrides perform() and the optional hooks).
 */
public class PickpocketReflex extends ActiveAbility {
    public PickpocketReflex() {
        super("guard.pickpocket_reflex", AbilitySlot.E, 10);
    }

    @Override
    protected void perform(Player owner, Match match) {
        owner.applyEffect(new ReachBoostEffect("pickpocket", param("duration", 3), param("multiplier", 1.8), Reach.STEAL));
        match.fx().ring("pickpocket", owner.getX(), owner.getY(), owner.getReach(Reach.STEAL), 0.4);
    }

    @Override
    public boolean aiShouldUse(Player owner, Match match) {
        return opponentHasBall(owner, match) && owner.distanceTo(match.getBall().getHolder()) < 120;
    }
}
