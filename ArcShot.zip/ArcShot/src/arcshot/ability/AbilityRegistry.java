package arcshot.ability;

import arcshot.ability.big.BoulderToss;
import arcshot.ability.big.BulwarkScreen;
import arcshot.ability.big.ColossusRebound;
import arcshot.ability.big.IronWall;
import arcshot.ability.big.QuakeFist;
import arcshot.ability.big.RimProtector;
import arcshot.ability.big.TitanSeal;
import arcshot.ability.big.TremorStomp;
import arcshot.ability.forward.BlazingScreen;
import arcshot.ability.forward.BullRush;
import arcshot.ability.forward.FinalBurst;
import arcshot.ability.forward.MeteorCrash;
import arcshot.ability.forward.ReboundSurge;
import arcshot.ability.forward.RisingFang;
import arcshot.ability.forward.SkyRend;
import arcshot.ability.forward.TigerClaw;
import arcshot.ability.guard.CrossoverSnap;
import arcshot.ability.guard.DeadeyeMark;
import arcshot.ability.guard.FocusAura;
import arcshot.ability.guard.PhantomSquad;
import arcshot.ability.guard.PickpocketReflex;
import arcshot.ability.guard.ShadowStep;
import arcshot.ability.guard.Slipstream;
import arcshot.ability.guard.TimeStop;
import arcshot.player.PlayerClass;
import arcshot.save.Profile;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The list of every ability, keyed by string id (e.g. "guard.shadow_step").
 * Loadouts, unlock rewards and the save file only store these ids.
 * <p>
 * <b>To add a new ability:</b> write the class, then add ONE {@code register(...)} line below.
 * OOP pillar: <b>ABSTRACTION</b> - the rest of the game never names a concrete ability class.
 */
public final class AbilityRegistry {
    private static final Map<String, AbilityInfo> ALL = new LinkedHashMap<>();

    static {
        // Guard
        register("guard.shadow_step", PlayerClass.GUARD, AbilitySlot.Q, true, ShadowStep::new);
        register("guard.crossover_snap", PlayerClass.GUARD, AbilitySlot.Q, false, CrossoverSnap::new);
        register("guard.slipstream", PlayerClass.GUARD, AbilitySlot.Q, false, Slipstream::new);
        register("guard.focus_aura", PlayerClass.GUARD, AbilitySlot.E, true, FocusAura::new);
        register("guard.deadeye_mark", PlayerClass.GUARD, AbilitySlot.E, false, DeadeyeMark::new);
        register("guard.pickpocket_reflex", PlayerClass.GUARD, AbilitySlot.E, false, PickpocketReflex::new);
        register("guard.time_stop", PlayerClass.GUARD, AbilitySlot.R, true, TimeStop::new);
        register("guard.phantom_squad", PlayerClass.GUARD, AbilitySlot.R, false, PhantomSquad::new);
        // Forward
        register("forward.rising_fang", PlayerClass.FORWARD, AbilitySlot.Q, true, RisingFang::new);
        register("forward.tiger_claw", PlayerClass.FORWARD, AbilitySlot.Q, false, TigerClaw::new);
        register("forward.bull_rush", PlayerClass.FORWARD, AbilitySlot.Q, false, BullRush::new);
        register("forward.sky_rend", PlayerClass.FORWARD, AbilitySlot.E, true, SkyRend::new);
        register("forward.rebound_surge", PlayerClass.FORWARD, AbilitySlot.E, false, ReboundSurge::new);
        register("forward.blazing_screen", PlayerClass.FORWARD, AbilitySlot.E, false, BlazingScreen::new);
        register("forward.final_burst", PlayerClass.FORWARD, AbilitySlot.R, true, FinalBurst::new);
        register("forward.meteor_crash", PlayerClass.FORWARD, AbilitySlot.R, false, MeteorCrash::new);
        // Big
        register("big.iron_wall", PlayerClass.BIG, AbilitySlot.Q, true, IronWall::new);
        register("big.bulwark_screen", PlayerClass.BIG, AbilitySlot.Q, false, BulwarkScreen::new);
        register("big.rim_protector", PlayerClass.BIG, AbilitySlot.Q, false, RimProtector::new);
        register("big.quake_fist", PlayerClass.BIG, AbilitySlot.E, true, QuakeFist::new);
        register("big.boulder_toss", PlayerClass.BIG, AbilitySlot.E, false, BoulderToss::new);
        register("big.tremor_stomp", PlayerClass.BIG, AbilitySlot.E, false, TremorStomp::new);
        register("big.titan_seal", PlayerClass.BIG, AbilitySlot.R, true, TitanSeal::new);
        register("big.colossus_rebound", PlayerClass.BIG, AbilitySlot.R, false, ColossusRebound::new);
    }

    private AbilityRegistry() { }

    private static void register(String id, PlayerClass pc, AbilitySlot slot, boolean isDefault,
                                 java.util.function.Supplier<Ability> factory) {
        ALL.put(id, new AbilityInfo(id, pc, slot, isDefault, factory));
    }

    public static AbilityInfo get(String id) {
        return id == null ? null : ALL.get(id);
    }

    public static List<AbilityInfo> all() {
        return Collections.unmodifiableList(new ArrayList<>(ALL.values()));
    }

    /** Every ability a class can put in a slot (default first). */
    public static List<AbilityInfo> forSlot(PlayerClass pc, AbilitySlot slot) {
        List<AbilityInfo> list = new ArrayList<>();
        for (AbilityInfo info : ALL.values()) {
            if (info.getPlayerClass() == pc && info.getSlot() == slot) {
                list.add(info);
            }
        }
        return list;
    }

    public static String defaultId(PlayerClass pc, AbilitySlot slot) {
        for (AbilityInfo info : forSlot(pc, slot)) {
            if (info.isDefault()) {
                return info.getId();
            }
        }
        throw new IllegalStateException("No default ability for " + pc + " " + slot);
    }

    /** Defaults are always available; alternates need an unlock (or Demo Mode). */
    public static boolean isAvailable(String id, Profile profile) {
        AbilityInfo info = get(id);
        return info != null && (info.isDefault() || profile.hasUnlock(Profile.ABILITY + id));
    }
}
