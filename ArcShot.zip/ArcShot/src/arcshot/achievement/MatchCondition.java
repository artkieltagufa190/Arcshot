package arcshot.achievement;

import arcshot.court.MatchSummary;

/**
 * A condition on the final result of a match, e.g. "won and allowed 10 or fewer".
 * OOP pillar: <b>ABSTRACTION</b> - achievements state a rule without knowing how events are produced.
 */
public interface MatchCondition {
    boolean test(MatchSummary summary);
}
