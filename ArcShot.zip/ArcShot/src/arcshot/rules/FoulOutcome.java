package arcshot.rules;

import arcshot.player.Player;
import arcshot.player.TeamSide;

/**
 * What a called foul leads to: how many free throws, who shoots them, and who gets the ball afterwards.
 * {@code possessionAfter == null} means "normal flow" (after the last free throw: made = defense clears it,
 * missed = live rebound). {@code checkBallTo} is used when there are no free throws.
 * OOP pillar: <b>ENCAPSULATION</b> (immutable value object).
 */
public final class FoulOutcome {
    private final int freeThrows;
    private final Player shooter;
    private final TeamSide possessionAfter;
    private final TeamSide checkBallTo;
    private final boolean turnover;

    public FoulOutcome(int freeThrows, Player shooter, TeamSide possessionAfter, TeamSide checkBallTo, boolean turnover) {
        this.freeThrows = freeThrows;
        this.shooter = shooter;
        this.possessionAfter = possessionAfter;
        this.checkBallTo = checkBallTo;
        this.turnover = turnover;
    }

    public int getFreeThrows() { return freeThrows; }

    public Player getShooter() { return shooter; }

    public TeamSide getPossessionAfter() { return possessionAfter; }

    public TeamSide getCheckBallTo() { return checkBallTo; }

    public boolean isTurnover() { return turnover; }

    @Override
    public String toString() {
        return freeThrows + " FT" + (possessionAfter != null ? " + ball " + possessionAfter : "")
                + (checkBallTo != null ? ", check ball " + checkBallTo : "") + (turnover ? ", turnover" : "");
    }
}
