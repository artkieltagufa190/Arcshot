package arcshot.action;

import arcshot.court.Interaction;
import arcshot.court.Match;
import arcshot.player.Player;

/** Pass: the ball leaves the hands on the {@code ball_release} frame. {@code safe} = cannot be intercepted. */
public class PassAction extends Action {
    private final Player receiver;
    private final boolean safe;

    public PassAction(Player receiver, boolean safe) {
        super(ActionType.PASS, "pass");
        this.receiver = receiver;
        this.safe = safe;
    }

    public Player getReceiver() { return receiver; }

    public boolean isSafe() { return safe; }

    @Override
    protected void onStart(Player p, Match m) {
        p.face(receiver.getX() - p.getX(), receiver.getY() - p.getY());
    }

    @Override
    protected void onEvent(String event, Player p, Match m) {
        if ("ball_release".equals(event)) {
            m.queue(Interaction.Kind.PASS, p, this);
        }
    }
}
