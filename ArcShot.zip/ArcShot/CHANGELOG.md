# Changelog

## v3.0 - Upgrade pass: retro look, actions, finishing, referees, FIBA 3x3 fouls (2026-11)

### Look
- New **retro renderer**, now the default. The match is drawn at 640x360 and scaled up by a whole number
  with nearest-neighbour sampling and letterboxing. There is an optional **CRT scanlines** setting.
- Angled broadcast camera with a z-axis (height). Depth sort order: backboard, back rim, then players /
  referees / ball by depth, then front rim and net. Pixel shadows shrink with height.
- Retro court: crowd, fictional sponsor boards, benches, glossy hardwood with a dithered sheen, painted key,
  3x3 lines, ARCSHOT center logo, stanchion and padded backboard. The net swings after makes and the rim
  dips after dunks.
- **Generated pixel-art sprites** for Guard, Forward, Big and the referee:
  - 18 player animations and 7 referee animations;
  - 3 facings plus mirroring, 2 hair styles;
  - recolored in code from mask colors (team, skin, hair).

  `tools/SpriteSheetGenerator.java` makes them.
- Retro HUD drawn with a bitmap font:
  - broadcast scoreboard with shot clock, team-foul pips and a BONUS light;
  - player card with Q/E/R tiles;
  - chunky jump-shot meter;
  - banners, text pops, achievement toasts and a commentary ticker.
- **Free throws use a 2K-style arc arrow** (your reference image): hold to grow it toward the rim; the tip
  swings by itself; release when it sits on the rim. The jump shot keeps the vertical meter.
- Retro effects: pixel sparks, dithered rings, flickering sprite afterimages, an ice-tinted freeze and
  stepped flashes.
- The v2 smooth renderer is still available (Settings → Match graphics).

### Gameplay
- `ActionController`: one action per player, with priorities, locks, root motion and **frame events**
  (`ball_release`, `takeoff`, `contact_*`, `rim_touch`, `grab`, `foot_land`) that drive the logic.
- **Context shoot**:
  - outside the finishing zone, a jump shot;
  - driving at the rim, a **layup** (bank shot from the side) or a **dunk** (one-hand / two-hand);
  - the windmill is only used by the Final Burst ultimate.
- Blocks are possible during a layup or dunk rise. There is now a rebound jump. Movement has acceleration,
  deceleration, smooth turning and a defensive slide. Collisions are soft.
- Match phase state machine and ball state machine. The ball changes owner through **one** validated method.
  Each tick has a documented update order, and same-frame events resolve by an interaction priority.
- **Two referees** (lead and trail) with whistle and signal animations.
- **FIBA 3x3 fouls and free throws** (`RulesConfig`, `RuleEngine`, `FoulDetector`, `FreeThrowSequence`):
  - shooting fouls 1/2 FT, and-one;
  - bonus at 7 team fouls, possession at 10;
  - offensive, technical and unsportsmanlike fouls.

  Settings: foul frequency, strict refs and game length. Overtime is first to 2 points.
- After a made basket or last free throw, the defense clears from under the basket.
- "Heat" streak: 3 straight makes give flames and +3 % accuracy.
- Sound hooks: dribble, sneaker, swish, rim, backboard, dunk, block, whistle, crowd.
- The AI uses the same actions as the human: it blocks finishes, jumps for rebounds and shoots free throws
  with the arc aim. Quake Fist AI is used on defense only.

### Tools and docs
- F3 debug overlay: phase, ball state and owner, fouls, action / frame / z, FT aim values, hitboxes.
- Scenario keys F6–F11: shooting foul, dunk, block, out of bounds, 7th team foul, free throws.
- Practice tips; drills 4 (free throws) and 5 (dunk).
- `SelfTests` (`./build.sh test`):
  - table-driven rule tests for every foul type and team-foul count;
  - FT aim and phase checks;
  - headless matches with invariant checks.
- Results screen: DNK, PF, FG and FT columns. 5 new achievements: Layup Line, High Flyer, Charity Stripe,
  Contact Artist, And One!
- Docs: `INTEGRATION_GUIDE.md`, `docs/RULES.md`, `docs/MECHANICS_MATRIX.md`, `docs/VISUAL_SPEC.md`, an
  updated README, OOP mapping (section 5) and test checklist.

### Cut / not done (from the brief)
- Instant replay of the last basket (COULD).
- "3 seconds with back to the basket" violation (the AI and controls never post up).
- Punch-in camera zoom on dunks (it breaks the integer pixel grid; shake and flash are used instead).
- Scoreboard score-flip animation.
- Timeouts and substitutions (not part of the game design).

## v2.0 - 3x3 half-court mode, menu, achievements (2026-11)
- The base for this pass: 3x3 mode with Guard, Forward and Big, 24 abilities, perks, a 30-achievement tree,
  loadouts, cosmetics, settings, and the Messenger mode integrated without logic changes.
