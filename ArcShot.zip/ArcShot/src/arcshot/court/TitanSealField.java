package arcshot.court;

import arcshot.effect.ShotPenaltyEffect;
import arcshot.effect.SlowEffect;
import arcshot.player.Player;

/**
 * Titan Seal: a field around the hoop; opponents inside are slowed and shoot badly.
 * OOP pillars: <b>INHERITANCE</b> (extends CourtEntity) and <b>POLYMORPHISM</b> (overrides affect / blocks / update).
 */
public class TitanSealField extends CourtEntity {
    private final double slow;
    private final double penalty;

    public TitanSealField(Player owner, double x, double y, double radius, double duration, double slow, double penalty) {
        super(owner, "titan_seal", x, y, radius, duration);
        this.slow = slow;
        this.penalty = penalty;
    }

    @Override
    public void affect(Player p, double dt, Match match) {
        if (p.getSide() != getSide()) {
            p.applyEffect(new SlowEffect(0.25, slow));
            p.applyEffect(new ShotPenaltyEffect(0.25, penalty));
        }
    }
}
