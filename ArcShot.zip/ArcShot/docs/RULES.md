# 3x3 rules as implemented

This page covers the rules ArcShot uses for scoring, fouls and free throws. Every number is a key in
`resources/config/balance.properties`, read through `arcshot.rules.RulesConfig`. You can change a value
there without recompiling: press F5 in a match to reload the file.

The rules follow the FIBA 3x3 Official Rules of the Game, Art. 7 "Fouls / Free throws". The FIBA documents
page is fiba.basketball, under 3x3 → rules of the game. Older printed versions and the current short
version disagree on two points. Both are config flags (see "Where versions differ").

## Scoring and time

| Rule | Value | Key |
|---|---|---|
| Inside the arc | 1 point | `rules.insidePoints` |
| Outside the arc | 2 points | `rules.outsidePoints` |
| Free throw | 1 point | `rules.freeThrowPoints` |
| Score limit | 21 | `rules.targetScore` |
| Game length | 6 min by default (official 3x3 is 10). Settings → Game length: 4 / 6 / 8 / 10 | `rules.gameSeconds` + Settings |
| Overtime | first team to score 2 points | `rules.overtimePoints` |
| Shot clock | 12 s, resets on a change of possession or when the ball hits the rim. A violation is a turnover. | `rules.shotClock` |

The game was 6 minutes before this upgrade, so 6 stays the default, as the brief asked.

## Fouls → free throws

Team fouls are counted for each team. Players never foul out. The team-foul number below counts the foul
being called.

| Foul | Team fouls added | Free throws | Ball afterwards |
|---|---|---|---|
| Shooting foul, shot missed, inside the arc | 1 | 1 | normal flow after the last FT |
| Shooting foul, shot missed, outside the arc | 1 | 2 | normal flow |
| Shooting foul, shot **made** (and-one) | 1 | 1 (the basket counts) | normal flow |
| Non-shooting foul, team fouls 1–6 | 1 | 0 | check ball at the top of the arc for the fouled team |
| **Any** foul at team foul 7, 8 or 9 (BONUS) | 1 | **2** (replaces the shooting amounts, a made basket still counts) | normal flow |
| **Any** foul at team foul 10 or more | 1 | **2** | **fouled team keeps the ball** (check ball) |
| Offensive foul (charge, illegal screen, ball handler's foulable ability) | 1 (`rules.offensiveFoulIsTeamFoul`) | 0, never | turnover: check ball for the defense |
| Technical foul | `rules.technicalTeamFouls` (1) | `rules.technicalFT` (1) | possession if `rules.technicalPossession` |
| Unsportsmanlike foul | **2** (`rules.unsportsmanlikeTeamFouls`) | `rules.unsportsmanlikeFT` (2) | possession if `rules.unsportsmanlikePossession` |

The HUD lights **BONUS** on a team's row once that team has 6 team fouls, because its next foul gives 2 free
throws. The six small pips count fouls 1–6.

### Where versions differ (kept configurable)

- **Technical foul possession.** Some FIBA 3x3 tables give no change of possession after a technical. The
  brief asks for "1 FT + possession", so `rules.technicalPossession=true`. Set it to `false` for the other
  reading.
- **First unsportsmanlike foul.** The current short version gives 2 FT without possession for a player's
  first unsportsmanlike foul; possession comes with team foul 10 or a disqualifying foul. The brief asks for
  possession, so `rules.unsportsmanlikePossession=true`. Set it to `false` for the newer rule. The 10+
  possession rule still applies either way.

## Restarts

| Situation | Restart | Where in code |
|---|---|---|
| Made basket or made last free throw | The defense takes the ball under the basket and must clear it behind the arc before scoring | `Match.clearUnderBasket()`, `needsClear` |
| Missed last free throw | Live rebound. The defense must clear it, the offense may shoot right away | `Match.resolveFreeThrow()` → LIVE |
| Defensive rebound or steal | Clear behind the arc | `Match.onControlGained()` |
| Dead ball, non-bonus foul, out of bounds, violation | Check ball at the top of the arc | `Match.setupCheckBall()` |
| Free throws with possession (10+, technical, unsportsmanlike) | Check ball for the fouled team after the last FT, whether it was made or missed | `Match.resolveFreeThrow()` |

## How fouls are detected (`FoulDetector`)

Fouls come from animation contact frames, so the call matches what you see:

- **Shooting contact.** The takeoff frame of `jump_shot`, `layup` or `dunk` sends a `FOUL_CHECK`
  interaction. Any defender within `foul.contactRadius` (42 px) can be called. Base odds:
  `foul.shooting.jump` .12, `foul.shooting.layup` .26 and `foul.shooting.dunk` .22. Closer contact raises
  the odds.
- **Reach-in.** A `STEAL_SWIPE` contact frame has a `foul.reachIn` (.10) chance, ×2.5 when the swipe comes
  from behind the ball handler.
- **Body contact.** Only during a real drive (dash or crossover). A defender who has set his feet draws a
  charge (`foul.charge`, offensive foul). Otherwise it is a blocking foul (`foul.blocking`). Each pair of
  players then has a 1.5 s cooldown so one collision cannot create a chain of fouls.
- **Abilities.** Abilities are legal by default (the "superpower rule"). Only the abilities listed in
  `foul.foulableAbilities` (default `big.quake_fist,forward.bull_rush`) can be called, with chance
  `foul.ability`. If the user of the ability has the ball, it is an offensive foul. If the victim is
  airborne, `foul.flagrantShare` (30 %) of those calls become **unsportsmanlike**.
- **Strict Refs** (Settings). A foulable ability on a frozen or stunned player is a **technical**.
- **Referee view.** A call needs a referee within `ref.viewRange` (480 px). Unseen contact is still called
  `ref.unseenCallChance` (25 %) of the time.
- **Foul frequency** (Settings) multiplies all of the chances above: Off 0, Low 0.5, Normal 1, High 1.7.
- The randomness uses the match seed (`MatchConfig.setSeed`), so a test can replay the same calls.

## Free throws

- The phase becomes `FREE_THROW`: the clock stops, abilities are off and AI defense is off. The shooter goes
  to the line. The other players line up behind the shooter.
- **Aim (new): the arc arrow.** Hold SHOOT and an arrow grows from the shooter's hands toward the rim. Its
  tip also swings left and right by itself. Release when the tip sits on the rim.
  - Power: 1.0 = the tip is on the rim. The window is `ft.powerWindow`.
  - Sway: 0 = centre. The window is `ft.swayWindow`.
  - The release is graded GREEN, GOOD or EARLY/LATE. The grade adds `ft.greenBonus` / `ft.goodBonus` or a
    penalty to the class percentage.
  - This control is separate from the jump-shot meter, which is still the vertical bar.
- Base percentages by class: `ft.guard` .82, `ft.forward` .74, `ft.big` .62.
- Better shooters see a slower sway (`ft.swaySpeed` is scaled by the FT percentage).
- AI shooters hold for power 1.0 with a difficulty-based error. Only `ft.aiSwayWeight` of the sway counts
  against them.

## Not implemented

- The "3 seconds with back to the basket inside the arc" dribble violation. The AI and controls do not
  produce post-ups, so it would almost never trigger. This is listed in the CHANGELOG cut list.
- Time-outs, substitutions and player disqualification (players do not foul out in 3x3; two unsportsmanlike
  fouls by the same player are not tracked).
