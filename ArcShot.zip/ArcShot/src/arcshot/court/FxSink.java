package arcshot.court;

import arcshot.player.Player;

/**
 * What gameplay may ask the visual-effects system to do. Gameplay only passes <i>keys</i> such as "shockwave";
 * the renderer decides colors and particle counts from the current skin.
 * <p>
 * OOP pillar: <b>ABSTRACTION</b> - gameplay never depends on how particles are drawn, so the theme or skin can change
 * without touching any ability. {@link #NONE} is a do-nothing implementation (useful for tests).
 */
public interface FxSink {
    void burst(String key, double x, double y, int count, double speed);

    void ring(String key, double x, double y, double radius, double duration);

    void afterimage(Player player, String key);

    void trail(String key, double x, double y, double size);

    void text(String text, String key, double x, double y);

    /** An implementation that ignores everything. */
    FxSink NONE = new FxSink() {
        @Override
        public void burst(String key, double x, double y, int count, double speed) { }

        @Override
        public void ring(String key, double x, double y, double radius, double duration) { }

        @Override
        public void afterimage(Player player, String key) { }

        @Override
        public void trail(String key, double x, double y, double size) { }

        @Override
        public void text(String text, String key, double x, double y) { }
    };
}
