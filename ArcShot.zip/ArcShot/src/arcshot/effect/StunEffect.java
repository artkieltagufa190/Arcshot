package arcshot.effect;

/**
 * A short stumble / stagger: no moving, no actions.
 * OOP pillars: <b>INHERITANCE</b> (extends StatusEffect) and <b>POLYMORPHISM</b> (overrides only the modifiers it changes).
 */
public class StunEffect extends StatusEffect {
    public StunEffect(double duration) {
        super("stun", duration, true);
    }

    @Override
    public boolean preventsMovement() { return true; }

    @Override
    public boolean preventsActions() { return true; }

    @Override
    public double defenseBonus() { return -40; }
}
