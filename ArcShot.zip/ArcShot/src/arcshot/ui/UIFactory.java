package arcshot.ui;

import arcshot.ui.components.RoundedPanel;
import arcshot.ui.components.ThemedButton;
import arcshot.ui.components.ThemedScrollBarUI;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.LayoutManager;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

/**
 * Factory methods for every standard widget, so all screens build their UI the same way.
 * <p>
 * OOP pillar: <b>ABSTRACTION</b>. A screen says {@code UIFactory.title("Settings")}; it does not care which font,
 * color or border that uses. Change the look here once and every screen follows.
 */
public final class UIFactory {
    private UIFactory() { }

    public static JLabel label(String text, Font font, Color color) {
        JLabel label = new JLabel(text);
        label.setFont(font);
        label.setForeground(color);
        return label;
    }

    /** Big screen title in the display font. */
    public static JLabel title(String text) {
        return label(text.toUpperCase(), Theme.display(48), Theme.TEXT);
    }

    public static JLabel heading(String text) {
        return label(text, Theme.bold(20), Theme.TEXT);
    }

    public static JLabel body(String text) {
        return label(text, Theme.body(15), Theme.TEXT);
    }

    public static JLabel muted(String text) {
        return label(text, Theme.body(14), Theme.TEXT_MUTED);
    }

    /** Multi-line wrapping text that is not editable. */
    public static JTextArea paragraph(String text) {
        JTextArea area = new JTextArea(text);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setEditable(false);
        area.setFocusable(false);
        area.setOpaque(false);
        area.setFont(Theme.body(15));
        area.setForeground(Theme.TEXT);
        area.setBorder(null);
        return area;
    }

    /**
     * Wrapping text with a fixed width, safe inside BoxLayout (unlike a JTextArea, whose height explodes there).
     */
    public static JLabel wrap(String text, int widthPx, Font font, Color color) {
        JLabel l = label(html(text, widthPx), font, color);
        l.setVerticalAlignment(SwingConstants.TOP);
        return l;
    }

    /** Changes the text of a label created by {@link #wrap}. */
    public static void setWrapText(JLabel label, String text, int widthPx) {
        label.setText(html(text, widthPx));
    }

    private static String html(String text, int widthPx) {
        String safe = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\n", "<br>");
        return "<html><div style='width:" + widthPx + "px'>" + safe + "</div></html>";
    }

    public static ThemedButton button(String text, ThemedButton.Style style, ActionListener action) {
        ThemedButton b = new ThemedButton(text, style);
        if (action != null) {
            b.addActionListener(action);
        }
        return b;
    }

    public static ThemedButton primary(String text, ActionListener action) {
        return button(text, ThemedButton.Style.PRIMARY, action);
    }

    public static ThemedButton secondary(String text, ActionListener action) {
        return button(text, ThemedButton.Style.SECONDARY, action);
    }

    /** A card panel (rounded, padded). */
    public static RoundedPanel card(LayoutManager layout) {
        return new RoundedPanel(layout);
    }

    /** A transparent panel. */
    public static JPanel clear(LayoutManager layout) {
        JPanel p = new JPanel(layout);
        p.setOpaque(false);
        return p;
    }

    /** A vertical stack (BoxLayout Y) that is transparent. */
    public static JPanel column() {
        JPanel p = clear(null);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        return p;
    }

    public static Component vgap(int h) {
        return Box.createVerticalStrut(h);
    }

    public static Component hgap(int w) {
        return Box.createHorizontalStrut(w);
    }

    /** A themed, vertical-only scroll pane: content always fits the width. */
    public static JScrollPane scroll(JComponent content) {
        JScrollPane sp = scrollFree(new arcshot.ui.components.WidthTrackingPanel(content));
        sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        return sp;
    }

    /** A themed scroll pane that may scroll both ways (e.g. the achievement tree). */
    public static JScrollPane scrollFree(JComponent content) {
        JScrollPane sp = new JScrollPane(content);
        sp.setOpaque(false);
        sp.getViewport().setOpaque(false);
        sp.setBorder(null);
        sp.getVerticalScrollBar().setUI(new ThemedScrollBarUI());
        sp.getHorizontalScrollBar().setUI(new ThemedScrollBarUI());
        sp.getVerticalScrollBar().setUnitIncrement(24);
        sp.getHorizontalScrollBar().setUnitIncrement(24);
        return sp;
    }

    /**
     * Standard screen header: Back button, big title and optional subtitle.
     * Every secondary screen uses this so navigation is always in the same place.
     */
    public static JPanel header(String title, String subtitle, ActionListener onBack) {
        JPanel header = clear(new BorderLayout(Theme.S5, 0));
        header.setBorder(BorderFactory.createEmptyBorder(0, 0, Theme.S4, 0));
        if (onBack != null) {
            JPanel left = clear(new FlowLayout(FlowLayout.LEFT, 0, Theme.S3));
            left.add(button("< Back", ThemedButton.Style.GHOST, onBack));
            header.add(left, BorderLayout.WEST);
        }
        JPanel text = column();
        JLabel t = title(title);
        text.add(t);
        if (subtitle != null) {
            text.add(muted(subtitle));
        }
        header.add(text, BorderLayout.CENTER);
        return header;
    }

    /** A label + control row used in settings-style forms. */
    public static JPanel formRow(String labelText, String hint, JComponent control) {
        JPanel row = clear(new BorderLayout(Theme.S4, 0));
        row.setBorder(BorderFactory.createEmptyBorder(Theme.S2, 0, Theme.S2, 0));
        JPanel text = column();
        text.add(label(labelText, Theme.semi(16), Theme.TEXT));
        if (hint != null) {
            text.add(muted(hint));
        }
        row.add(text, BorderLayout.CENTER);
        JPanel right = clear(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        right.add(control);
        row.add(right, BorderLayout.EAST);
        return row;
    }

    public static JLabel centered(String text, Font font, Color color) {
        JLabel l = label(text, font, color);
        l.setHorizontalAlignment(SwingConstants.CENTER);
        return l;
    }
}
