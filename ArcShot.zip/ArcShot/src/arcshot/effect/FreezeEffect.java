package arcshot.effect;

/**
 * Time Stop: cannot move or act at all. Shown with a gray-blue tint.
 * OOP pillars: <b>INHERITANCE</b> (extends StatusEffect) and <b>POLYMORPHISM</b> (overrides only the modifiers it changes).
 */
public class FreezeEffect extends StatusEffect {
    public FreezeEffect(double duration) {
        super("freeze", duration, true);
    }

    @Override
    public double speedMultiplier() { return 0.0; }

    @Override
    public boolean preventsMovement() { return true; }

    @Override
    public boolean preventsActions() { return true; }

    @Override
    public double defenseBonus() { return -100; }
}
