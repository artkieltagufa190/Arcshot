package arcshot.render;

import arcshot.ability.Ability;
import arcshot.ability.AbilitySlot;
import arcshot.court.Ball;
import arcshot.court.CourtEntity;
import arcshot.court.Decoy;
import arcshot.court.Match;
import arcshot.court.ShotAttempt;
import arcshot.player.Player;
import arcshot.player.TeamSide;
import arcshot.ui.Theme;
import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

/**
 * Draws one frame of a match: court, entities, players and ball (depth-sorted), particles, screen effects and HUD.
 * Only <i>reads</i> the {@link Match}; it never changes gameplay state.
 * OOP pillar: <b>ABSTRACTION</b> - composes smaller renderers, each with one job.
 */
public final class MatchRenderer implements MatchView {
    private final RenderContext ctx;
    private final EffectRenderer effects;
    private final ParticleSystem particles;
    private final PlayerRenderer playerRenderer;
    private final HudRenderer hud;
    private CourtRenderer courtRenderer;
    private final Random rng = new Random();

    public MatchRenderer(RenderContext ctx) {
        this.ctx = ctx;
        this.effects = new EffectRenderer(ctx.getSkin());
        this.particles = new ParticleSystem(effects);
        this.playerRenderer = new PlayerRenderer(effects);
        this.hud = new HudRenderer(ctx);
    }

    public ParticleSystem getParticles() { return particles; }

    @Override
    public arcshot.court.FxSink getFx() { return particles; }

    @Override
    public arcshot.core.GameEventListener getHudListener() { return hud; }

    @Override
    public int frameWidth() { return 1280; }

    @Override
    public int frameHeight() { return 720; }

    @Override
    public boolean isPixelArt() { return false; }

    public HudRenderer getHud() { return hud; }

    /** Advance visual-only animation (particles, toasts). */
    @Override
    public void update(double dt) {
        particles.update(dt);
        hud.update(dt);
    }

    @Override
    public void render(Graphics2D g, Match m, int w, int h) {
        Theme.quality(g);
        effects.setColorblind(ctx.isColorblind());
        if (courtRenderer == null) {
            courtRenderer = new CourtRenderer(m.getCourt(), ctx.getCourtTheme());
        }
        AffineTransform base = g.getTransform();
        if (ctx.isScreenShake() && m.getShake() > 0.3) {
            g.translate((rng.nextDouble() - 0.5) * m.getShake(), (rng.nextDouble() - 0.5) * m.getShake());
        }
        courtRenderer.drawFloor(g, w, h);
        double time = m.getElapsed();
        for (CourtEntity e : m.getEntities()) {
            effects.drawEntity(g, e, m, time);
        }
        boolean flash = m.getNetSwing() > 0.3;
        courtRenderer.drawHoopBack(g, m.getNetSwing(), flash);
        for (Player p : m.getPlayers()) {
            playerRenderer.drawShadow(g, p);
        }
        drawBallShadow(g, m.getBall());
        for (CourtEntity e : m.getEntities()) {
            if (e instanceof Decoy) {
                playerRenderer.drawDecoy(g, e, m.teamOf(e.getSide()).getColor(), time);
            }
        }
        for (arcshot.referee.Referee r : m.getRefs().getReferees()) {
            if (r.getY() < m.getCourt().getTop() + 10) {
                continue; // the lead referee stands behind the baseline: off-camera in this top-down view
            }
            g.setColor(new Color(0, 0, 0, 80));
            g.fillOval((int) r.getX() - 14, (int) r.getY() - 5, 28, 10);
            for (int i = 0; i < 4; i++) {
                g.setColor(i % 2 == 0 ? Color.WHITE : new Color(30, 30, 30));
                g.fillRect((int) r.getX() - 11 + i * 6, (int) r.getY() - 44, 6, 26);
            }
            g.setColor(new Color(40, 40, 50));
            g.fillRect((int) r.getX() - 9, (int) r.getY() - 18, 18, 18);
            g.setColor(new Color(0xC68A5E));
            g.fillOval((int) r.getX() - 8, (int) r.getY() - 60, 16, 16);
        }
        drawActors(g, m, time);
        for (Player p : m.getPlayers()) {
            for (AbilitySlot s : AbilitySlot.values()) {
                Ability a = p.getAbility(s);
                if (a != null && a.isActive()) {
                    a.render(g, p, effects);
                }
            }
        }
        if (ballInHoop(m)) {
            drawBall(g, m.getBall());
            courtRenderer.drawHoopFront(g, m.getNetSwing(), flash);
        } else {
            courtRenderer.drawHoopFront(g, m.getNetSwing(), flash);
        }
        particles.draw(g);
        g.setTransform(base);
        drawScreenEffects(g, m, w, h);
        hud.draw(g, m);
    }

    private boolean ballInHoop(Match m) {
        Ball b = m.getBall();
        if (b.getState() == Ball.State.DEAD) {
            return m.getCourt().distanceToHoop(b.getX(), b.getY()) < 30 && b.getZ() > 20;
        }
        if (b.getState() == Ball.State.SHOT) {
            ShotAttempt s = b.getShot();
            return s.getProgress() > 0.8;
        }
        return false;
    }

    private void drawActors(Graphics2D g, Match m, double time) {
        List<Player> sorted = new ArrayList<>(m.getPlayers());
        Collections.sort(sorted, new Comparator<Player>() {
            @Override
            public int compare(Player a, Player b) {
                return Double.compare(a.getY(), b.getY());
            }
        });
        Ball ball = m.getBall();
        boolean ballDrawn = ballInHoop(m);
        int index = 0;
        for (Player p : sorted) {
            if (!ballDrawn && ball.getState() != Ball.State.HELD && ball.getY() < p.getY()) {
                drawBall(g, ball);
                ballDrawn = true;
            }
            Color jersey = m.teamOf(p.getSide()).getColor();
            Color aura = p.getSide() == TeamSide.HOME ? ctx.getAuraColor() : null;
            boolean hasBall = ball.getState() == Ball.State.HELD && ball.getHolder() == p;
            boolean faceAway = p.getFacingY() < -0.3;
            if (hasBall && faceAway) {
                drawBall(g, ball);
            }
            playerRenderer.draw(g, p, jersey, aura, ctx.getStyle(), p == m.getControlled(), hasBall, time,
                    m.getPlayers().indexOf(p) + index * 0);
            if (hasBall && !faceAway) {
                drawBall(g, ball);
            }
            if (hasBall) {
                ballDrawn = true;
            }
            index++;
        }
        if (!ballDrawn) {
            drawBall(g, ball);
        }
    }

    private void drawBallShadow(Graphics2D g, Ball b) {
        double z = b.getZ();
        int w = (int) Math.max(8, 20 - z * 0.05);
        g.setColor(new Color(0, 0, 0, (int) Math.max(25, 90 - z * 0.35)));
        g.fillOval((int) b.getX() - w / 2, (int) b.getY() - w / 4, w, w / 2);
    }

    private void drawBall(Graphics2D g, Ball b) {
        double sx = b.getX();
        double sy = b.getY() - b.getZ() * CourtRenderer.LIFT;
        if (b.getTrailCount() > 1) {
            Color tc = effects.colorFor("ball_trail");
            for (int i = 1; i < b.getTrailCount(); i++) {
                int a = (int) (110 * (1 - i / (double) b.getTrailCount()));
                g.setColor(Theme.alpha(tc, a));
                double r = 7 * (1 - i / 14.0);
                g.fillOval((int) (b.getTrailX(i) - r), (int) (b.getTrailY(i) - b.getTrailZ(i) * CourtRenderer.LIFT - r), (int) (r * 2), (int) (r * 2));
            }
        }
        double r = 9 + b.getZ() * 0.012;
        g.setColor(new Color(0xE8712A));
        g.fillOval((int) (sx - r), (int) (sy - r), (int) (r * 2), (int) (r * 2));
        g.setColor(new Color(255, 200, 150, 120));
        g.fillOval((int) (sx - r * 0.6), (int) (sy - r * 0.75), (int) (r * 0.8), (int) (r * 0.6));
        g.setColor(new Color(60, 28, 10));
        g.setStroke(new BasicStroke(1.3f));
        g.drawOval((int) (sx - r), (int) (sy - r), (int) (r * 2), (int) (r * 2));
        double a = b.getSpin();
        g.drawLine((int) (sx + Math.cos(a) * r), (int) (sy + Math.sin(a) * r), (int) (sx - Math.cos(a) * r), (int) (sy - Math.sin(a) * r));
        g.drawLine((int) (sx + Math.cos(a + 1.57) * r), (int) (sy + Math.sin(a + 1.57) * r),
                (int) (sx - Math.cos(a + 1.57) * r), (int) (sy - Math.sin(a + 1.57) * r));
    }

    private void drawScreenEffects(Graphics2D g, Match m, int w, int h) {
        Composite old = g.getComposite();
        if (m.getTintTime() > 0) {
            float a = (float) Math.min(0.32, m.getTintTime() * 0.6);
            g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, a));
            g.setColor(effects.colorFor(m.getTintKey()));
            g.fillRect(0, 0, w, h);
            g.setComposite(old);
        }
        if (m.getFlashTime() > 0) {
            float a = (float) Math.min(0.7, m.getFlashTime() * 2.5);
            g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, a));
            g.setColor(effects.colorFor(m.getFlashKey()));
            g.fillRect(0, 0, w, h);
            g.setComposite(old);
        }
    }
}
