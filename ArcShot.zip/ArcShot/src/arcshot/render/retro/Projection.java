package arcshot.render.retro;

import arcshot.court.Court;

/**
 * Turns a court position (x, y) plus height z into a pixel on the 640x360 retro buffer.
 * The view is an angled broadcast camera behind half court: the far baseline (hoop end) is narrower and higher
 * on screen than the near edge, and height z lifts things up (scaled by depth). The camera never changes logic.
 * OOP pillar: <b>ENCAPSULATION</b> - all camera constants are private; use {@link #x}, {@link #y}, {@link #scale}.
 */
public final class Projection {
    public static final int W = 640;
    public static final int H = 360;

    private static final double FAR_Y = 118;    // screen y of the far baseline
    private static final double NEAR_Y = 372;   // screen y of the near court edge
    private static final double FAR_SCALE = 0.50;
    private static final double NEAR_SCALE = 0.70;
    private static final double Z_SCALE = 0.95;

    private final double top;
    private final double depth;
    private final double centerX;

    public Projection(Court c) {
        this.top = c.getTop();
        this.depth = c.getHeight();
        this.centerX = c.getHoopX();
    }

    /** 0 at the far baseline, 1 at the near edge (can go a little outside for the stands). */
    private double t(double wy) {
        return (wy - top) / depth;
    }

    /** Horizontal pixels per world pixel at this depth. */
    public double scale(double wy) {
        return FAR_SCALE + (NEAR_SCALE - FAR_SCALE) * t(wy);
    }

    public double x(double wx, double wy) {
        return W / 2.0 + (wx - centerX) * scale(wy);
    }

    /** Screen y of a point at height z. */
    public double y(double wx, double wy, double z) {
        double tt = t(wy);
        double floor = FAR_Y + (NEAR_Y - FAR_Y) * (tt * (0.82 + 0.18 * tt));
        return floor - z * scale(wy) * Z_SCALE;
    }

    public int ix(double wx, double wy) {
        return (int) Math.round(x(wx, wy));
    }

    public int iy(double wx, double wy, double z) {
        return (int) Math.round(y(wx, wy, z));
    }
}
