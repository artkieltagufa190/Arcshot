package arcshot.save;

import arcshot.player.PlayerClass;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

/**
 * Everything saved about the player between sessions: name, career stats, achievement progress, unlocks,
 * loadouts, perks, cosmetics and settings.
 * <p>
 * OOP pillar: <b>ENCAPSULATION</b>. All collections are private. Other classes change them only through
 * methods such as {@link #addStat}, {@link #unlock} and {@link #setLoadout}, which keep the data valid
 * (no negative counters, no null ids). Read-only views are returned so nobody can edit the sets directly.
 */
public final class Profile {
    /** Unlock key prefixes, e.g. "ability:guard.crossover_snap". */
    public static final String ABILITY = "ability:";
    public static final String PERK = "perk:";
    public static final String COSMETIC = "cosmetic:";
    public static final String TITLE = "title:";

    private String name = "Player";
    private String title = "";
    private final Map<String, Integer> stats = new HashMap<>();
    private final Map<String, Integer> achievementProgress = new HashMap<>();
    private final Set<String> achievementsUnlocked = new LinkedHashSet<>();
    private final Set<String> unlocks = new LinkedHashSet<>();
    private final Map<PlayerClass, Loadout> loadouts = new EnumMap<>(PlayerClass.class);
    private String perk1 = "";
    private String perk2 = "";
    private String jersey = "jersey.orange";
    private int jerseyNumber = 7;
    private String aura = "aura.default";
    private String style = "style.classic";
    private String court = "court.classic";
    private final Settings settings = new Settings();

    // ---- name / title ---------------------------------------------------------------------------------------

    public String getName() { return name; }

    /** Same rules as the Messenger game: 1..12 characters. */
    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Name cannot be empty.");
        }
        if (name.trim().length() > 12) {
            throw new IllegalArgumentException("Name must be 12 characters or fewer.");
        }
        this.name = name.trim();
    }

    public String getTitle() { return title; }

    public void setTitle(String title) { this.title = title == null ? "" : title; }

    // ---- stats ----------------------------------------------------------------------------------------------

    public int getStat(String key) {
        Integer v = stats.get(key);
        return v == null ? 0 : v;
    }

    public void addStat(String key, int amount) {
        if (amount > 0) {
            stats.put(key, getStat(key) + amount);
        }
    }

    /** Keeps the highest value ever seen (e.g. "best.points"). */
    public void recordBest(String key, int value) {
        if (value > getStat(key)) {
            stats.put(key, value);
        }
    }

    // ---- achievements ---------------------------------------------------------------------------------------

    public int getAchievementProgress(String id) {
        Integer v = achievementProgress.get(id);
        return v == null ? 0 : v;
    }

    public void setAchievementProgress(String id, int value) {
        achievementProgress.put(id, Math.max(0, value));
    }

    public boolean isAchievementUnlocked(String id) {
        return achievementsUnlocked.contains(id);
    }

    public void markAchievementUnlocked(String id) {
        achievementsUnlocked.add(id);
    }

    public Set<String> getUnlockedAchievements() {
        return Collections.unmodifiableSet(achievementsUnlocked);
    }

    // ---- unlocks --------------------------------------------------------------------------------------------

    public void unlock(String key) {
        if (key != null && !key.isEmpty()) {
            unlocks.add(key);
        }
    }

    /** True if the key was earned, or Demo Mode "Unlock All" is on. */
    public boolean hasUnlock(String key) {
        return settings.isUnlockAllDemo() || unlocks.contains(key);
    }

    public Set<String> getUnlocks() {
        return Collections.unmodifiableSet(unlocks);
    }

    // ---- loadouts / perks -----------------------------------------------------------------------------------

    /** May return null if the player never changed this class's loadout (callers use the defaults). */
    public Loadout getLoadout(PlayerClass pc) {
        Loadout l = loadouts.get(pc);
        return l == null ? null : l.copy();
    }

    public void setLoadout(Loadout loadout) {
        loadouts.put(loadout.getPlayerClass(), loadout.copy());
    }

    public String getPerk1() { return perk1; }

    public String getPerk2() { return perk2; }

    public void setPerks(String perk1, String perk2) {
        this.perk1 = perk1 == null ? "" : perk1;
        this.perk2 = perk2 == null || perk2.equals(this.perk1) ? "" : perk2;
    }

    // ---- cosmetics ------------------------------------------------------------------------------------------

    public String getJersey() { return jersey; }

    public void setJersey(String jersey) { this.jersey = jersey; }

    public int getJerseyNumber() { return jerseyNumber; }

    public void setJerseyNumber(int n) { this.jerseyNumber = Math.max(0, Math.min(99, n)); }

    public String getAura() { return aura; }

    public void setAura(String aura) { this.aura = aura; }

    public String getStyle() { return style; }

    public void setStyle(String style) { this.style = style; }

    public String getCourt() { return court; }

    public void setCourt(String court) { this.court = court; }

    public Settings getSettings() { return settings; }

    /** Wipes progress but keeps the name and settings (used by "Reset Progress"). */
    public void resetProgress() {
        stats.clear();
        achievementProgress.clear();
        achievementsUnlocked.clear();
        unlocks.clear();
        loadouts.clear();
        perk1 = "";
        perk2 = "";
        title = "";
        jersey = "jersey.orange";
        aura = "aura.default";
        style = "style.classic";
        court = "court.classic";
    }

    // ---- persistence ----------------------------------------------------------------------------------------

    void writeTo(Properties p) {
        p.setProperty("profile.name", name);
        p.setProperty("profile.title", title);
        for (Map.Entry<String, Integer> e : stats.entrySet()) {
            p.setProperty("stat." + e.getKey(), String.valueOf(e.getValue()));
        }
        for (Map.Entry<String, Integer> e : achievementProgress.entrySet()) {
            p.setProperty("ach.progress." + e.getKey(), String.valueOf(e.getValue()));
        }
        p.setProperty("ach.unlocked", String.join(",", achievementsUnlocked));
        p.setProperty("unlocks", String.join(",", unlocks));
        for (Loadout l : loadouts.values()) {
            String k = "loadout." + l.getPlayerClass().key();
            p.setProperty(k + ".q", l.getQ());
            p.setProperty(k + ".e", l.getE());
            p.setProperty(k + ".r", l.getR());
        }
        p.setProperty("perk.1", perk1);
        p.setProperty("perk.2", perk2);
        p.setProperty("cos.jersey", jersey);
        p.setProperty("cos.number", String.valueOf(jerseyNumber));
        p.setProperty("cos.aura", aura);
        p.setProperty("cos.style", style);
        p.setProperty("cos.court", court);
        settings.writeTo(p);
    }

    void readFrom(Properties p) {
        try {
            setName(p.getProperty("profile.name", name));
        } catch (IllegalArgumentException ex) {
            name = "Player";
        }
        title = p.getProperty("profile.title", "");
        for (String key : p.stringPropertyNames()) {
            if (key.startsWith("stat.")) {
                stats.put(key.substring(5), Math.max(0, SaveManager.intOf(p, key, 0)));
            } else if (key.startsWith("ach.progress.")) {
                achievementProgress.put(key.substring(13), Math.max(0, SaveManager.intOf(p, key, 0)));
            }
        }
        addCsv(achievementsUnlocked, p.getProperty("ach.unlocked", ""));
        addCsv(unlocks, p.getProperty("unlocks", ""));
        for (PlayerClass pc : PlayerClass.values()) {
            String k = "loadout." + pc.key();
            if (p.getProperty(k + ".q") != null) {
                loadouts.put(pc, new Loadout(pc, p.getProperty(k + ".q"), p.getProperty(k + ".e"), p.getProperty(k + ".r")));
            }
        }
        setPerks(p.getProperty("perk.1", ""), p.getProperty("perk.2", ""));
        jersey = p.getProperty("cos.jersey", jersey);
        setJerseyNumber(SaveManager.intOf(p, "cos.number", jerseyNumber));
        aura = p.getProperty("cos.aura", aura);
        style = p.getProperty("cos.style", style);
        court = p.getProperty("cos.court", court);
        settings.readFrom(p);
    }

    private static void addCsv(Set<String> target, String csv) {
        for (String part : csv.split(",")) {
            if (!part.trim().isEmpty()) {
                target.add(part.trim());
            }
        }
    }
}
