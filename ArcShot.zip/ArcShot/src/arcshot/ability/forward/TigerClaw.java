package arcshot.ability.forward;

import arcshot.ability.AbilitySlot;
import arcshot.ability.ActiveAbility;
import arcshot.court.Match;
import arcshot.player.Player;

/**
 * Forward Q (alternate): a strip attempt that always steals if the ball handler is in range.
 * OOP pillars: <b>INHERITANCE</b> (extends ActiveAbility / Ultimate) and <b>POLYMORPHISM</b> (overrides perform() and the optional hooks).
 */
public class TigerClaw extends ActiveAbility {
    public TigerClaw() {
        super("forward.tiger_claw", AbilitySlot.Q, 9);
    }

    @Override
    protected boolean meetsRequirements(Player owner, Match match) {
        return opponentHasBall(owner, match);
    }

    @Override
    protected void perform(Player owner, Match match) {
        Player holder = match.getBall().getHolder();
        match.fx().burst("claw", holder.getX(), holder.getY() - 25, 12, 200);
        if (owner.distanceTo(holder) <= param("range", 95)) {
            match.stealBall(owner);
        } else {
            match.fx().text("TOO FAR", "whiff", owner.getX(), owner.getY() - 70);
        }
    }

    @Override
    public boolean aiShouldUse(Player owner, Match match) {
        return opponentHasBall(owner, match) && owner.distanceTo(match.getBall().getHolder()) < 85;
    }
}
