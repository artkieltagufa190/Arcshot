package arcshot.control;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.concurrent.atomic.AtomicIntegerArray;

/**
 * Thread-safe record of which keys are down. Key events arrive on the Swing thread; the game thread reads them.
 * Each key also counts its presses, so a very quick tap between two frames is never lost.
 * <p>
 * OOP pillars: <b>INHERITANCE</b> (extends {@link KeyAdapter}) and <b>ENCAPSULATION</b> (atomic arrays are private).
 */
public final class KeyboardState extends KeyAdapter {
    private static final int SIZE = 1024;
    private final AtomicIntegerArray down = new AtomicIntegerArray(SIZE);
    private final AtomicIntegerArray presses = new AtomicIntegerArray(SIZE);

    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();
        if (code >= 0 && code < SIZE) {
            if (down.get(code) == 0) {
                presses.incrementAndGet(code);
            }
            down.set(code, 1);
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int code = e.getKeyCode();
        if (code >= 0 && code < SIZE) {
            down.set(code, 0);
        }
    }

    public boolean isDown(int code) {
        return code >= 0 && code < SIZE && down.get(code) == 1;
    }

    /** Total number of times this key was pressed. Compare with a previous value to detect new presses. */
    public int pressCount(int code) {
        return code >= 0 && code < SIZE ? presses.get(code) : 0;
    }

    /** Releases everything (e.g. when the window loses focus or the game pauses). */
    public void releaseAll() {
        for (int i = 0; i < SIZE; i++) {
            down.set(i, 0);
        }
    }
}
