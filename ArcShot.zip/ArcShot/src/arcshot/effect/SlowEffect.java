package arcshot.effect;

/** Reduces movement speed. INHERITANCE: only overrides {@link #speedMultiplier()}. */
public class SlowEffect extends StatusEffect {
    private final double factor;

    /** @param factor speed multiplier, e.g. 0.6 = 40% slower */
    public SlowEffect(double duration, double factor) {
        super("slow", duration, true);
        this.factor = Math.max(0.05, Math.min(1, factor));
    }

    @Override
    public double speedMultiplier() { return factor; }
}
