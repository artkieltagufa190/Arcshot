package arcshot.referee;

/**
 * One of the two 3x3 referees. Runs a whistle -> signal sequence after a call, otherwise follows its {@link RefereeAI}.
 * OOP pillars: <b>INHERITANCE</b> (extends CourtActor) and <b>ENCAPSULATION</b> (signal timer is private).
 */
public class Referee extends CourtActor {
    /** LEAD stands on the baseline, TRAIL on the sideline. */
    public enum Role { LEAD, TRAIL }

    private final String name;
    private final Role role;
    private String pendingSignal;
    private double signalTimer;

    public Referee(String name, Role role, double x, double y) {
        super(x, y);
        this.name = name;
        this.role = role;
    }

    @Override
    public String getCharacterKey() { return "ref"; }

    public String getName() { return name; }

    public Role getRole() { return role; }

    /** Blow the whistle, then show {@code signal} for {@code seconds}. */
    public void call(String signal, double seconds) {
        play("whistle");
        pendingSignal = signal;
        signalTimer = seconds;
    }

    /** True while whistling or signalling (the AI does not move the referee then). */
    public boolean isSignalling() { return signalTimer > 0; }

    public void update(double dt) {
        if (signalTimer > 0) {
            signalTimer -= dt;
            if (pendingSignal != null && "whistle".equals(getAnimation()) && getFrame() >= 2) {
                play(pendingSignal);
                pendingSignal = null;
            }
            tickAnimation(dt, false);
            if (signalTimer <= 0) {
                play("idle");
            }
        } else {
            tickAnimation(dt, true);
        }
    }
}
