package arcshot.core;

/**
 * A fixed-timestep game loop that runs on its own thread (never on the Swing Event Dispatch Thread).
 * Every loop iteration it runs zero or more fixed {@code step(dt)} updates, then renders one frame.
 * <p>
 * OOP pillar: <b>ABSTRACTION</b>. The loop only knows the small {@link Steppable} interface, not what a match is.
 */
public final class GameLoop implements Runnable {

    /** Anything the loop can drive. */
    public interface Steppable {
        /** Advance the simulation by exactly {@code dt} seconds. */
        void step(double dt);

        /** Draw the current state into an off-screen buffer. */
        void renderFrame();
    }

    private static final int MAX_STEPS_PER_FRAME = 5;

    private final Steppable target;
    private final double dt;
    private final long frameNanos;
    private volatile boolean running;
    private volatile int fps;
    private Thread thread;

    /** @param updatesPerSecond fixed update rate, e.g. 60 */
    public GameLoop(Steppable target, int updatesPerSecond) {
        this.target = target;
        this.dt = 1.0 / updatesPerSecond;
        this.frameNanos = 1_000_000_000L / updatesPerSecond;
    }

    public synchronized void start() {
        if (running) {
            return;
        }
        running = true;
        thread = new Thread(this, "arcshot-game-loop");
        thread.setDaemon(true);
        thread.start();
    }

    /** Stops the loop and waits briefly for the thread to finish. */
    public void stop() {
        running = false;
        Thread t = thread;
        if (t != null && t != Thread.currentThread()) {
            try {
                t.join(500);
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
            }
        }
    }

    public boolean isRunning() {
        return running;
    }

    /** Frames rendered during the last second. */
    public int getFps() {
        return fps;
    }

    @Override
    public void run() {
        long previous = System.nanoTime();
        long fpsTimer = previous;
        double accumulator = 0;
        int frames = 0;
        boolean errorReported = false;
        while (running) {
            long now = System.nanoTime();
            double elapsed = Math.min(0.25, (now - previous) / 1_000_000_000.0);
            previous = now;
            accumulator += elapsed;
            try {
                int steps = 0;
                while (accumulator >= dt && steps < MAX_STEPS_PER_FRAME) {
                    target.step(dt);
                    accumulator -= dt;
                    steps++;
                }
                if (steps == MAX_STEPS_PER_FRAME) {
                    accumulator = 0; // computer is too slow: drop time instead of spiralling
                }
                target.renderFrame();
            } catch (RuntimeException ex) {
                if (!errorReported) {
                    ex.printStackTrace();
                    errorReported = true;
                }
            }
            frames++;
            if (now - fpsTimer >= 1_000_000_000L) {
                fps = frames;
                frames = 0;
                fpsTimer = now;
            }
            sleepUntil(now + frameNanos);
        }
    }

    private void sleepUntil(long deadline) {
        long remaining = deadline - System.nanoTime();
        if (remaining <= 0) {
            Thread.yield();
            return;
        }
        try {
            Thread.sleep(remaining / 1_000_000L, (int) (remaining % 1_000_000L));
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            running = false;
        }
    }
}
