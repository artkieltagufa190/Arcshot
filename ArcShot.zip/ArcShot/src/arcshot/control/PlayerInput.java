package arcshot.control;

/**
 * What a player wants to do this frame. Filled by a {@link PlayerController} (keyboard or AI) and read by the match.
 * Plain data object; "pressed" flags are true only on the frame the button went down.
 * OOP pillar: <b>ENCAPSULATION</b> - private fields with getters and setters.
 */
public final class PlayerInput {
    private double moveX;
    private double moveY;
    private boolean sprint;
    private boolean shootHeld;
    private boolean passPressed;
    private boolean qPressed;
    private boolean ePressed;
    private boolean rPressed;
    private boolean switchPressed;

    public void clear() {
        moveX = 0;
        moveY = 0;
        sprint = false;
        shootHeld = false;
        passPressed = false;
        qPressed = false;
        ePressed = false;
        rPressed = false;
        switchPressed = false;
    }

    /** Sets the move direction; it is normalised so diagonal movement is not faster. */
    public void setMove(double x, double y) {
        double len = Math.hypot(x, y);
        if (len > 1) {
            x /= len;
            y /= len;
        }
        moveX = x;
        moveY = y;
    }

    public double getMoveX() { return moveX; }

    public double getMoveY() { return moveY; }

    public boolean isSprint() { return sprint; }

    public void setSprint(boolean sprint) { this.sprint = sprint; }

    public boolean isShootHeld() { return shootHeld; }

    public void setShootHeld(boolean shootHeld) { this.shootHeld = shootHeld; }

    public boolean isPassPressed() { return passPressed; }

    public void setPassPressed(boolean v) { passPressed = v; }

    public boolean isQPressed() { return qPressed; }

    public void setQPressed(boolean v) { qPressed = v; }

    public boolean isEPressed() { return ePressed; }

    public void setEPressed(boolean v) { ePressed = v; }

    public boolean isRPressed() { return rPressed; }

    public void setRPressed(boolean v) { rPressed = v; }

    public boolean isSwitchPressed() { return switchPressed; }

    public void setSwitchPressed(boolean v) { switchPressed = v; }
}
