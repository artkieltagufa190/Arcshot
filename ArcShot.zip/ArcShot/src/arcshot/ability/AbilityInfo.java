package arcshot.ability;

import arcshot.player.PlayerClass;
import java.util.function.Supplier;

/**
 * Registry entry: an ability's id, class, slot, whether it is unlocked from the start, and how to create it.
 * OOP pillar: <b>ENCAPSULATION</b> (immutable).
 */
public final class AbilityInfo {
    private final String id;
    private final PlayerClass playerClass;
    private final AbilitySlot slot;
    private final boolean defaultAbility;
    private final Supplier<Ability> factory;

    public AbilityInfo(String id, PlayerClass playerClass, AbilitySlot slot, boolean defaultAbility, Supplier<Ability> factory) {
        this.id = id;
        this.playerClass = playerClass;
        this.slot = slot;
        this.defaultAbility = defaultAbility;
        this.factory = factory;
    }

    public String getId() { return id; }

    public PlayerClass getPlayerClass() { return playerClass; }

    public AbilitySlot getSlot() { return slot; }

    public boolean isDefault() { return defaultAbility; }

    Ability newInstance() { return factory.get(); }
}
