package arcshot.ability;

import arcshot.player.Player;

/**
 * A Q or E ability: usable again after a cooldown. The cooldown is read from the balance file
 * ({@code ability.<id>.cooldown}).
 * OOP pillar: <b>INHERITANCE</b> (adds cooldown behaviour to {@link Ability}).
 */
public abstract class ActiveAbility extends Ability {
    private final double defaultCooldown;
    private double cooldownLeft;
    private double readyIdle;

    protected ActiveAbility(String id, AbilitySlot slot, double defaultCooldown) {
        super(id, slot);
        this.defaultCooldown = defaultCooldown;
    }

    public double getCooldown() {
        return param("cooldown", defaultCooldown);
    }

    public double getCooldownLeft() { return cooldownLeft; }

    /** Seconds this ability has been sitting ready without being used (for the "no waste" achievement). */
    public double getReadyIdle() { return readyIdle; }

    /** Practice mode helper. */
    public void resetCooldown() {
        cooldownLeft = 0;
    }

    @Override
    protected void onActivated(Player owner) {
        cooldownLeft = getCooldown();
        readyIdle = 0;
    }

    @Override
    protected boolean isReady(Player owner) {
        return cooldownLeft <= 0;
    }

    @Override
    protected void tick(double dt, Player owner) {
        if (cooldownLeft > 0) {
            cooldownLeft = Math.max(0, cooldownLeft - dt);
        } else {
            readyIdle += dt;
        }
    }

    /** Lets an ability refund part of its cooldown (e.g. a whiffed Tiger Claw). */
    protected void reduceCooldown(double seconds) {
        cooldownLeft = Math.max(0, cooldownLeft - seconds);
    }

    @Override
    public double getCooldownFraction(Player owner) {
        double cd = getCooldown();
        return cd <= 0 ? 0 : cooldownLeft / cd;
    }

    @Override
    public String getStatusText(Player owner) {
        return cooldownLeft <= 0 ? "READY" : String.format("%.1f", cooldownLeft);
    }
}
