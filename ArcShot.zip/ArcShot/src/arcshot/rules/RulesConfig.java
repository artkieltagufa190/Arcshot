package arcshot.rules;

import arcshot.core.Balance;

/**
 * Every 3x3 rule number in one place (read from {@code balance.properties}, keys {@code rules.*} / {@code foul.*}).
 * Defaults follow the FIBA 3x3 rules as given in the project brief; see docs/RULES.md for sources and the two
 * settings where newer FIBA editions differ ({@code rules.technicalPossession}, {@code rules.unsportsmanlikePossession}).
 * OOP pillar: <b>ENCAPSULATION</b> + <b>ABSTRACTION</b> - typed getters with safe defaults.
 */
public final class RulesConfig {
    private RulesConfig() { }

    public static int insidePoints() { return Balance.i("rules.insidePoints", 1); }

    public static int outsidePoints() { return Balance.i("rules.outsidePoints", 2); }

    public static int freeThrowPoints() { return Balance.i("rules.freeThrowPoints", 1); }

    public static int overtimePoints() { return Balance.i("rules.overtimePoints", 2); }

    /** Team fouls 1..(bonusFrom-1) give no free throws (unless shooting). Default 7. */
    public static int bonusFrom() { return Balance.i("rules.bonusFromTeamFoul", 7); }

    /** From this team foul on: 2 free throws AND possession. Default 10. */
    public static int possessionFrom() { return Balance.i("rules.possessionFromTeamFoul", 10); }

    public static int bonusFreeThrows() { return Balance.i("rules.bonusFreeThrows", 2); }

    public static int shootingFoulInside() { return Balance.i("rules.shootingFoulInsideFT", 1); }

    public static int shootingFoulOutside() { return Balance.i("rules.shootingFoulOutsideFT", 2); }

    public static int andOneFreeThrows() { return Balance.i("rules.andOneFT", 1); }

    public static int technicalFreeThrows() { return Balance.i("rules.technicalFT", 1); }

    public static boolean technicalPossession() { return Balance.b("rules.technicalPossession", true); }

    public static int technicalTeamFouls() { return Balance.i("rules.technicalTeamFouls", 1); }

    public static int unsportsmanlikeFreeThrows() { return Balance.i("rules.unsportsmanlikeFT", 2); }

    public static boolean unsportsmanlikePossession() { return Balance.b("rules.unsportsmanlikePossession", true); }

    public static int unsportsmanlikeTeamFouls() { return Balance.i("rules.unsportsmanlikeTeamFouls", 2); }

    public static boolean offensiveFoulCountsAsTeamFoul() { return Balance.b("rules.offensiveFoulIsTeamFoul", true); }

    /** Free-throw make chance by class key ("guard", "forward", "big"). */
    public static double freeThrowPercent(String classKey) {
        double def = "guard".equals(classKey) ? 0.82 : ("forward".equals(classKey) ? 0.74 : 0.62);
        return Balance.d("ft." + classKey, def);
    }

    /** Abilities whose contact can be called a foul (the rest are legal "superpowers"). */
    public static boolean isFoulableAbility(String abilityId) {
        String list = Balance.s("foul.foulableAbilities", "big.quake_fist,forward.bull_rush");
        for (String id : list.split(",")) {
            if (id.trim().equals(abilityId)) {
                return true;
            }
        }
        return false;
    }
}
