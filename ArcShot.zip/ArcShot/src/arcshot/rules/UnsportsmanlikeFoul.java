package arcshot.rules;

import arcshot.player.Player;

/**
 * Unsportsmanlike foul (e.g. a flagrant shove on an airborne shooter): 2 free throws (+ possession by default),
 * counts as 2 team fouls.
 * OOP pillars: <b>INHERITANCE</b> + <b>POLYMORPHISM</b>.
 */
public class UnsportsmanlikeFoul extends Foul {
    public UnsportsmanlikeFoul(Player offender, Player victim) {
        super(offender, victim);
    }

    @Override
    public String getName() { return "UNSPORTSMANLIKE"; }

    @Override
    public int teamFoulsAdded() { return RulesConfig.unsportsmanlikeTeamFouls(); }

    @Override
    protected int baseFreeThrows(FoulContext ctx) { return RulesConfig.unsportsmanlikeFreeThrows(); }

    @Override
    protected boolean basePossession(FoulContext ctx) { return RulesConfig.unsportsmanlikePossession(); }
}
