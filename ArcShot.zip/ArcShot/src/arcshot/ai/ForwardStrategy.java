package arcshot.ai;

/**
 * Forward: spaces the wing and attacks the basket.
 * OOP pillars: <b>INHERITANCE</b> (extends AIStrategy) and <b>POLYMORPHISM</b> (overrides the role choices).
 */
public class ForwardStrategy extends AIStrategy {
    @Override
    protected double[] preferredSpot(boolean leftSide) {
        return new double[] {leftSide ? -60 : 60, 300};
    }

    @Override
    public double shotValueThreshold() { return 0.70; }

    @Override
    public boolean crashesBoards() { return true; }
}
