package arcshot.app;

import arcshot.ui.screens.ClassSelectScreen;

/**
 * Version 2: 3x3 half court with classes, abilities and achievements.
 * OOP pillar: <b>POLYMORPHISM</b> - implements GameMode; the menu launches it without knowing the type.
 */
public final class ThreeOnThreeMode implements GameMode {
    @Override
    public String getTitle() { return "3x3 Half Court"; }

    @Override
    public String getDescription() { return "Guard, Forward or Big - abilities, ultimates, first to 21"; }

    @Override
    public void launch(AppContext app) {
        app.screens().push(new ClassSelectScreen(app, false));
    }
}
