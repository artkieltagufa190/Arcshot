package arcshot.messenger;

/**
 * ABSTRACTION (interface): anything the ball can bump into.
 * Hoop and Defender implement it differently.
 */
public interface Collidable {
    /** Push the ball away if touching. Returns true if a collision happened. */
    boolean resolveCollision(Ball ball);
}
