package arcshot.app;

import arcshot.ui.screens.MessengerScreen;

/**
 * Version 1: the original Messenger-style shootout, now reskinned and hosted in the new menu.
 * OOP pillar: <b>POLYMORPHISM</b> - implements GameMode; the menu launches it without knowing the type.
 */
public final class MessengerMode implements GameMode {
    @Override
    public String getTitle() { return "Classic Shootout"; }

    @Override
    public String getDescription() { return "Messenger-style - drag, aim and swish for 100 seconds"; }

    @Override
    public void launch(AppContext app) {
        app.screens().push(new MessengerScreen(app));
    }
}
