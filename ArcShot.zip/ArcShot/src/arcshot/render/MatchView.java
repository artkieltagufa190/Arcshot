package arcshot.render;

import arcshot.core.GameEventListener;
import arcshot.court.FxSink;
import arcshot.court.Match;
import java.awt.Graphics2D;

/**
 * Anything that can draw a match: the retro pixel renderer (default) or the smooth HD renderer (fallback).
 * OOP pillars: <b>ABSTRACTION</b> + <b>POLYMORPHISM</b> - the match screen works with either through this interface.
 */
public interface MatchView {
    /** Visual-only animation (particles, toasts). */
    void update(double dt);

    void render(Graphics2D g, Match m, int w, int h);

    /** Where gameplay sends effect requests. */
    FxSink getFx();

    /** Subscribed to the event bus for toasts / commentary. */
    GameEventListener getHudListener();

    /** Size of the frame buffer this view draws into. */
    int frameWidth();

    int frameHeight();

    /** True = scale up with nearest-neighbour (no smoothing). */
    boolean isPixelArt();
}
