package arcshot.effect;

/**
 * Iron Wall: bigger block radius, stronger steals, cannot be pushed.
 * OOP pillars: <b>INHERITANCE</b> (extends StatusEffect) and <b>POLYMORPHISM</b> (overrides only the modifiers it changes).
 */
public class BarrierEffect extends StatusEffect {
    private final double blockMultiplier;
    private final double stealMultiplier;

    public BarrierEffect(double duration, double blockMultiplier, double stealMultiplier) {
        super("barrier", duration, false);
        this.blockMultiplier = blockMultiplier;
        this.stealMultiplier = stealMultiplier;
    }

    @Override
    public double reachMultiplier(Reach reach) {
        if (reach == Reach.BLOCK || reach == Reach.CONTEST) {
            return blockMultiplier;
        }
        return reach == Reach.STEAL ? stealMultiplier : 1.0;
    }

    @Override
    public double defenseBonus() { return 15; }

    @Override
    public boolean isHeavy() { return true; }
}
