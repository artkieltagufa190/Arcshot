package arcshot.effect;

/**
 * Better shooting, optionally only from outside the arc (Focus Aura).
 * OOP pillars: <b>INHERITANCE</b> (extends StatusEffect) and <b>POLYMORPHISM</b> (overrides only the modifiers it changes).
 */
public class AccuracyBoostEffect extends StatusEffect {
    private final double bonus;
    private final boolean rangeOnly;

    public AccuracyBoostEffect(String id, double duration, double bonus, boolean rangeOnly) {
        super(id, duration, false);
        this.bonus = bonus;
        this.rangeOnly = rangeOnly;
    }

    @Override
    public double shootingBonus(boolean outsideArc) {
        return (!rangeOnly || outsideArc) ? bonus : 0.0;
    }
}
