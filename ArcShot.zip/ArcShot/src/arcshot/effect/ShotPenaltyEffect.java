package arcshot.effect;

/**
 * Titan Seal: heavy shooting penalty while inside the field.
 * OOP pillars: <b>INHERITANCE</b> (extends StatusEffect) and <b>POLYMORPHISM</b> (overrides only the modifiers it changes).
 */
public class ShotPenaltyEffect extends StatusEffect {
    private final double penalty;

    public ShotPenaltyEffect(double duration, double penalty) {
        super("shot_penalty", duration, true);
        this.penalty = penalty;
    }

    @Override
    public double shootingBonus(boolean outsideArc) { return -penalty; }
}
