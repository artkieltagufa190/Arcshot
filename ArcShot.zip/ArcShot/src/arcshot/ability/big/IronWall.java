package arcshot.ability.big;

import arcshot.ability.AbilitySlot;
import arcshot.ability.ActiveAbility;
import arcshot.court.Match;
import arcshot.effect.BarrierEffect;
import arcshot.player.Player;

/**
 * Big Q (default): 3 s barrier - bigger block radius, stronger steals, cannot be pushed.
 * OOP pillars: <b>INHERITANCE</b> (extends ActiveAbility / Ultimate) and <b>POLYMORPHISM</b> (overrides perform() and the optional hooks).
 */
public class IronWall extends ActiveAbility {
    public IronWall() {
        super("big.iron_wall", AbilitySlot.Q, 12);
    }

    @Override
    protected void perform(Player owner, Match match) {
        owner.applyEffect(new BarrierEffect(param("duration", 3), param("blockMultiplier", 1.5), param("stealMultiplier", 1.3)));
        match.fx().ring("barrier", owner.getX(), owner.getY(), 60, 0.4);
    }

    @Override
    public boolean aiShouldUse(Player owner, Match match) {
        return opponentHasBall(owner, match) && owner.distanceTo(match.getBall().getHolder()) < 150;
    }
}
