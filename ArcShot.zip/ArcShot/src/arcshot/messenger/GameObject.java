package arcshot.messenger;

import java.awt.Graphics2D;

/**
 * ABSTRACTION + INHERITANCE: the superclass of everything on the court.
 * It says WHAT every game object must do (update, draw), not HOW.
 * ENCAPSULATION: x and y are private; subclasses use getters/setters.
 */
public abstract class GameObject {
    private double x;
    private double y;

    protected GameObject(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() { return x; }
    public double getY() { return y; }
    public void setX(double x) { this.x = x; }
    public void setY(double y) { this.y = y; }

    /** Move/advance this object by one frame. */
    public abstract void update();

    /** Paint this object. */
    public abstract void draw(Graphics2D g);
}
