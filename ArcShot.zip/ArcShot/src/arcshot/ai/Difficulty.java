package arcshot.ai;

import arcshot.core.Balance;

/**
 * AI difficulty. It scales how fast the AI reacts and how good its decisions and shot timing are -
 * never the players' stats (no cheating).
 * OOP pillar: <b>ENCAPSULATION</b> - each enum constant keeps its data in private fields behind getters.
 */
public enum Difficulty {
    EASY("Easy", 0.50, 0.30, 0.78, 0.20, 0.30, 0.35, 0.25),
    NORMAL("Normal", 0.30, 0.16, 0.92, 0.45, 0.55, 0.60, 0.45),
    HARD("Hard", 0.16, 0.07, 1.02, 0.60, 0.80, 0.85, 0.70);

    private final String label;
    private final double reaction;
    private final double timingError;
    private final double shotSelection;
    private final double stealRate;
    private final double blockChance;
    private final double passIq;
    private final double abilityRate;

    Difficulty(String label, double reaction, double timingError, double shotSelection, double stealRate,
               double blockChance, double passIq, double abilityRate) {
        this.label = label;
        this.reaction = reaction;
        this.timingError = timingError;
        this.shotSelection = shotSelection;
        this.stealRate = stealRate;
        this.blockChance = blockChance;
        this.passIq = passIq;
        this.abilityRate = abilityRate;
    }

    private double cfg(String name, double def) {
        return Balance.d("ai." + name().toLowerCase() + "." + name, def);
    }

    public String getLabel() { return label; }

    /** Seconds between decisions. */
    public double reaction() { return cfg("reaction", reaction); }

    /** Standard deviation of shot-meter timing, as a fraction of the meter. */
    public double timingError() { return cfg("timingError", timingError); }

    /** Multiplier on how good a shot must look before taking it (lower = takes worse shots). */
    public double shotSelection() { return cfg("shotSelection", shotSelection); }

    /** Steal attempts per second when in range. */
    public double stealRate() { return cfg("stealRate", stealRate); }

    /** Chance to jump at a shot it sees. */
    public double blockChance() { return cfg("blockChance", blockChance); }

    /** Chance to make the better pass when a teammate is more open. */
    public double passIq() { return cfg("passIq", passIq); }

    /** Chance to use a useful ability when it is a good moment. */
    public double abilityRate() { return cfg("abilityRate", abilityRate); }

    public static Difficulty fromName(String name) {
        for (Difficulty d : values()) {
            if (d.name().equalsIgnoreCase(name)) {
                return d;
            }
        }
        return NORMAL;
    }
}
