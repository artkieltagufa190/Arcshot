package arcshot.save;

import arcshot.control.InputAction;
import arcshot.control.KeyBindings;
import java.util.Properties;

/**
 * Player options (audio, skin, accessibility, debug, controls).
 * OOP pillar: <b>ENCAPSULATION</b> - private fields, validated setters (e.g. volume is clamped to 0..100).
 */
public final class Settings {
    private int volume = 80;
    private boolean muted;
    private String skin = "anime";
    private String difficulty = "NORMAL";
    private boolean showFps;
    private boolean colorblind;
    private boolean screenShake = true;
    private boolean autoSwitch = true;
    private boolean developerOptions;
    private boolean unlockAllDemo;
    private String graphicsStyle = "retro";
    private boolean crt;
    private String foulFrequency = "NORMAL";
    private boolean strictRefs;
    private int gameMinutes = 6;
    private final KeyBindings keys = new KeyBindings();

    public int getVolume() { return volume; }

    public void setVolume(int volume) { this.volume = Math.max(0, Math.min(100, volume)); }

    public boolean isMuted() { return muted; }

    public void setMuted(boolean muted) { this.muted = muted; }

    public String getSkin() { return skin; }

    public void setSkin(String skin) { this.skin = "street".equals(skin) ? "street" : "anime"; }

    public String getDifficulty() { return difficulty; }

    public void setDifficulty(String difficulty) { this.difficulty = difficulty == null ? "NORMAL" : difficulty; }

    public boolean isShowFps() { return showFps; }

    public void setShowFps(boolean showFps) { this.showFps = showFps; }

    public boolean isColorblind() { return colorblind; }

    public void setColorblind(boolean colorblind) { this.colorblind = colorblind; }

    public boolean isScreenShake() { return screenShake; }

    public void setScreenShake(boolean screenShake) { this.screenShake = screenShake; }

    public boolean isAutoSwitch() { return autoSwitch; }

    public void setAutoSwitch(boolean autoSwitch) { this.autoSwitch = autoSwitch; }

    public boolean isDeveloperOptions() { return developerOptions; }

    public void setDeveloperOptions(boolean developerOptions) { this.developerOptions = developerOptions; }

    public boolean isUnlockAllDemo() { return unlockAllDemo; }

    public void setUnlockAllDemo(boolean unlockAllDemo) { this.unlockAllDemo = unlockAllDemo; }

    /** "retro" (640x360 pixel art, default) or "smooth" (the original HD renderer). */
    public String getGraphicsStyle() { return graphicsStyle; }

    public void setGraphicsStyle(String style) { this.graphicsStyle = "smooth".equals(style) ? "smooth" : "retro"; }

    public boolean isRetro() { return "retro".equals(graphicsStyle); }

    /** Optional CRT scanlines over the retro picture. */
    public boolean isCrt() { return crt; }

    public void setCrt(boolean crt) { this.crt = crt; }

    /** OFF / LOW / NORMAL / HIGH (see FoulFrequency). */
    public String getFoulFrequency() { return foulFrequency; }

    public void setFoulFrequency(String f) {
        this.foulFrequency = "OFF".equals(f) || "LOW".equals(f) || "HIGH".equals(f) ? f : "NORMAL";
    }

    public boolean isStrictRefs() { return strictRefs; }

    public void setStrictRefs(boolean strictRefs) { this.strictRefs = strictRefs; }

    /** Game length in minutes (3x3 is 10; this project's default stays 6). */
    public int getGameMinutes() { return gameMinutes; }

    public void setGameMinutes(int m) { this.gameMinutes = Math.max(2, Math.min(10, m)); }

    public KeyBindings getKeys() { return keys; }

    void writeTo(Properties p) {
        p.setProperty("settings.volume", String.valueOf(volume));
        p.setProperty("settings.muted", String.valueOf(muted));
        p.setProperty("settings.skin", skin);
        p.setProperty("settings.difficulty", difficulty);
        p.setProperty("settings.showFps", String.valueOf(showFps));
        p.setProperty("settings.colorblind", String.valueOf(colorblind));
        p.setProperty("settings.screenShake", String.valueOf(screenShake));
        p.setProperty("settings.autoSwitch", String.valueOf(autoSwitch));
        p.setProperty("settings.developerOptions", String.valueOf(developerOptions));
        p.setProperty("settings.unlockAllDemo", String.valueOf(unlockAllDemo));
        p.setProperty("settings.graphicsStyle", graphicsStyle);
        p.setProperty("settings.crt", String.valueOf(crt));
        p.setProperty("settings.foulFrequency", foulFrequency);
        p.setProperty("settings.strictRefs", String.valueOf(strictRefs));
        p.setProperty("settings.gameMinutes", String.valueOf(gameMinutes));
        for (InputAction a : InputAction.values()) {
            p.setProperty("key." + a.name(), String.valueOf(keys.keyFor(a)));
        }
    }

    void readFrom(Properties p) {
        setVolume(SaveManager.intOf(p, "settings.volume", volume));
        muted = Boolean.parseBoolean(p.getProperty("settings.muted", "false"));
        setSkin(p.getProperty("settings.skin", skin));
        setDifficulty(p.getProperty("settings.difficulty", difficulty));
        showFps = Boolean.parseBoolean(p.getProperty("settings.showFps", "false"));
        colorblind = Boolean.parseBoolean(p.getProperty("settings.colorblind", "false"));
        screenShake = Boolean.parseBoolean(p.getProperty("settings.screenShake", "true"));
        autoSwitch = Boolean.parseBoolean(p.getProperty("settings.autoSwitch", "true"));
        developerOptions = Boolean.parseBoolean(p.getProperty("settings.developerOptions", "false"));
        unlockAllDemo = Boolean.parseBoolean(p.getProperty("settings.unlockAllDemo", "false"));
        // new in the upgrade pass: old saves simply get the defaults
        setGraphicsStyle(p.getProperty("settings.graphicsStyle", "retro"));
        crt = Boolean.parseBoolean(p.getProperty("settings.crt", "false"));
        setFoulFrequency(p.getProperty("settings.foulFrequency", "NORMAL"));
        strictRefs = Boolean.parseBoolean(p.getProperty("settings.strictRefs", "false"));
        setGameMinutes(SaveManager.intOf(p, "settings.gameMinutes", gameMinutes));
        for (InputAction a : InputAction.values()) {
            int code = SaveManager.intOf(p, "key." + a.name(), a.getDefaultKey());
            if (code > 0) {
                keys.bind(a, code);
            }
        }
    }
}
