package arcshot.action;

import arcshot.court.Interaction;
import arcshot.court.Match;
import arcshot.player.Player;

/** Steal swipe: the steal (and the reach-in foul check) happens on the {@code contact} frame. */
public class StealAction extends Action {
    public StealAction() {
        super(ActionType.STEAL_SWIPE, "steal");
    }

    @Override
    protected void onEvent(String event, Player p, Match m) {
        if ("contact".equals(event)) {
            m.queue(Interaction.Kind.STEAL, p, this);
        }
    }
}
