package arcshot.messenger;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

/** The basketball. Extends GameObject (INHERITANCE) and overrides update()/draw() (POLYMORPHISM). */
public class Ball extends GameObject {
    public static final double RADIUS = 22;
    private static final double GRAVITY = 0.5;
    private static final double BOUNCE = 0.65;
    /** Frames it takes the ball to "fly into the screen" and reach the hoop's depth. */
    private static final int DEPTH_FRAMES = 22;

    private final double startX;
    private final double startY;
    private final double courtWidth;
    private final double floorY;

    private double vx;
    private double vy;
    private double prevY;
    private double angle;
    private boolean flying;
    private boolean onFloor;
    private boolean touchedRim;
    private boolean scored;
    private int flightTicks;
    private final java.awt.image.BufferedImage sprite = Sprites.load("ball.png");

    public Ball(double startX, double startY, double courtWidth, double floorY) {
        super(startX, startY);
        this.startX = startX;
        this.startY = startY;
        this.courtWidth = courtWidth;
        this.floorY = floorY;
        this.prevY = startY;
    }

    public void launch(double vx, double vy) {
        this.vx = vx;
        this.vy = vy;
        this.flying = true;
        this.flightTicks = 0;
        this.onFloor = false;
        this.touchedRim = false;
        this.scored = false;
    }

    public void reset() {
        setX(startX);
        setY(startY);
        prevY = startY;
        vx = 0;
        vy = 0;
        angle = 0;
        flying = false;
        flightTicks = 0;
        onFloor = false;
        touchedRim = false;
        scored = false;
    }

    /** Called by Collidable objects: push the ball out and bounce it off a surface normal. */
    public void deflect(double nx, double ny, double overlap) {
        setX(getX() + nx * overlap);
        setY(getY() + ny * overlap);
        double dot = vx * nx + vy * ny;
        if (dot < 0) {
            vx -= (1 + BOUNCE) * dot * nx;
            vy -= (1 + BOUNCE) * dot * ny;
        }
        touchedRim = true;
    }

    @Override
    public void update() {
        if (!flying) {
            return;
        }
        flightTicks++;
        double r = getRadius();
        prevY = getY();
        vy += GRAVITY;
        setX(getX() + vx);
        setY(getY() + vy);
        angle += vx * 0.03;

        if (getX() < r) {
            setX(r);
            vx = -vx * BOUNCE;
        } else if (getX() > courtWidth - r) {
            setX(courtWidth - r);
            vx = -vx * BOUNCE;
        }

        onFloor = false;
        if (getY() > floorY - r) {
            setY(floorY - r);
            vy = -vy * BOUNCE;
            vx *= 0.9;
            if (Math.abs(vy) < 2) {
                vy = 0;
                onFloor = true;
            }
        }
    }

    public void slowSideways() {
        vx *= 0.5;
    }

    public boolean isResting() {
        return flying && onFloor && Math.abs(vx) < 0.3;
    }

    /** PERSPECTIVE: 1.0 at the player, shrinking to the hoop's size as the ball flies away. */
    public double getScale() {
        double progress = Math.min(1.0, flightTicks / (double) DEPTH_FRAMES);
        return 1.0 - (1.0 - Hoop.getScale()) * progress;
    }

    public double getRadius() {
        return RADIUS * getScale();
    }

    public boolean isFlying() { return flying; }
    public boolean isTouchedRim() { return touchedRim; }
    public boolean isScored() { return scored; }
    public void markScored() { scored = true; }
    public double getVx() { return vx; }
    public double getVy() { return vy; }
    public double getPrevY() { return prevY; }
    public double getStartX() { return startX; }
    public double getStartY() { return startY; }
    public static double getGravity() { return GRAVITY; }

    @Override
    public void draw(Graphics2D g) {
        AffineTransform old = g.getTransform();
        g.translate(getX(), getY());
        g.scale(getScale(), getScale());
        double stretch = Math.min(1.0, Math.abs(vy) / 24.0) * 0.1; // slight vertical stretch at speed
        g.scale(1 - stretch, 1 + stretch);
        g.rotate(angle);
        int d = (int) (RADIUS * 2);
        if (sprite != null) {
            g.drawImage(sprite, (int) -RADIUS, (int) -RADIUS, d, d, null);
            g.setTransform(old);
            return;
        }
        g.setColor(new Color(0, 0, 0, 40));
        g.fillOval((int) -RADIUS + 3, (int) -RADIUS + 4, d, d);
        g.setColor(new Color(230, 110, 30));
        g.fillOval((int) -RADIUS, (int) -RADIUS, d, d);
        g.setColor(new Color(60, 30, 10));
        g.setStroke(new BasicStroke(2f));
        g.drawOval((int) -RADIUS, (int) -RADIUS, d, d);
        g.drawLine((int) -RADIUS, 0, (int) RADIUS, 0);
        g.drawLine(0, (int) -RADIUS, 0, (int) RADIUS);
        g.drawArc((int) (-RADIUS * 1.5), (int) -RADIUS, d, d, -60, 120);
        g.drawArc((int) (RADIUS * 0.5), (int) -RADIUS, d, d, 120, 120);
        g.setTransform(old);
    }
}
