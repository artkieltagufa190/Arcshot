package arcshot.player;

import arcshot.core.Balance;
import arcshot.effect.Reach;

/**
 * The Speedster: fastest, best from long range, best at stealing, weakest at rebounding.
 * OOP pillar: <b>INHERITANCE</b> (extends {@link Player}) + <b>POLYMORPHISM</b> (overrides the abstract hooks).
 */
public class Guard extends Player {
    public Guard(String name, int number, TeamSide side, boolean userTeam) {
        super(name, number, side, userTeam, "guard", 238, 80, 58, 38);
    }

    @Override
    public PlayerClass getPlayerClass() { return PlayerClass.GUARD; }

    @Override
    public double rangeModifier(double distanceToHoop, boolean outsideArc) {
        return outsideArc ? Balance.d("guard.rangeBonus", 0.06) : 0.0;
    }

    @Override
    public double getMass() { return 1.0; }

    @Override
    public double getGrabHeight() { return Balance.d("guard.grabHeight", 112); }

    @Override
    public double getDunkRange() { return Balance.d("guard.dunkRange", 58); }

    @Override
    protected double classReachFactor(Reach reach) {
        switch (reach) {
            case STEAL: return 1.15;
            case BLOCK: return 0.85;
            case REBOUND: return 0.85;
            default: return 1.0;
        }
    }
}
