package arcshot.perk;

import arcshot.core.Balance;

/**
 * Faster stamina regeneration.
 * OOP pillars: <b>INHERITANCE</b> (extends Perk) and <b>POLYMORPHISM</b> (overrides one hook).
 */
public class SecondWindPerk extends Perk {
    public SecondWindPerk() {
        super("second_wind", "Second Wind", "+50% stamina regeneration");
    }

    @Override
    public double staminaRegenMultiplier() { return Balance.d("perk.second_wind.multiplier", 1.5); }
}
