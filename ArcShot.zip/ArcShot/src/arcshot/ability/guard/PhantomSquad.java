package arcshot.ability.guard;

import arcshot.ability.Ultimate;
import arcshot.court.Decoy;
import arcshot.court.Match;
import arcshot.player.Player;

/**
 * Guard R (alternate): two decoy afterimages for 5 s; AI defenders often chase a decoy instead of you.
 * OOP pillars: <b>INHERITANCE</b> (extends ActiveAbility / Ultimate) and <b>POLYMORPHISM</b> (overrides perform() and the optional hooks).
 */
public class PhantomSquad extends Ultimate {
    public PhantomSquad() {
        super("guard.phantom_squad");
    }

    @Override
    protected void perform(Player owner, Match match) {
        double d = param("duration", 5);
        match.addEntity(new Decoy(owner, -75, 30, d));
        match.addEntity(new Decoy(owner, 75, 30, d));
        match.fx().burst("decoy", owner.getX(), owner.getY() - 20, 16, 160);
        match.fx().text("PHANTOM SQUAD", "decoy", owner.getX(), owner.getY() - 80);
    }

    @Override
    public boolean aiShouldUse(Player owner, Match match) {
        return hasBall(owner, match) || (match.getBall().getHolder() != null
                && match.getBall().getHolder().getSide() == owner.getSide());
    }
}
