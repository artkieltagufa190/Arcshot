package arcshot.ability;

import arcshot.player.Player;

/**
 * The R ability: only usable when the owner's ultimate meter is full; using it empties the meter.
 * OOP pillar: <b>INHERITANCE</b> + <b>POLYMORPHISM</b> - same {@link Ability} contract, different readiness rule.
 */
public abstract class Ultimate extends Ability {
    protected Ultimate(String id) {
        super(id, AbilitySlot.R);
    }

    @Override
    protected void onActivated(Player owner) {
        owner.consumeUltimate();
    }

    @Override
    protected boolean isReady(Player owner) {
        return owner.isUltimateReady();
    }

    @Override
    protected void tick(double dt, Player owner) {
        // the meter is filled by the match (scoring, steals, ...), nothing to count down here
    }

    @Override
    public double getCooldownFraction(Player owner) {
        return 1.0 - owner.getUltimateCharge() / 100.0;
    }

    @Override
    public String getStatusText(Player owner) {
        return owner.isUltimateReady() ? "READY" : Math.round(owner.getUltimateCharge()) + "%";
    }
}
