package arcshot.core;

/**
 * Observer pattern: anything that wants to react to game events implements this.
 * OOP pillar: <b>ABSTRACTION</b> + <b>POLYMORPHISM</b> - the bus calls {@code onEvent} without knowing
 * whether the listener is the achievement system, the HUD or the sound player.
 */
public interface GameEventListener {
    void onEvent(GameEvent event);
}
