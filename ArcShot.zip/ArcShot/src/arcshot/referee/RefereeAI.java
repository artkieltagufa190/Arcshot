package arcshot.referee;

import arcshot.court.CourtGeometry;
import arcshot.court.Match;
import arcshot.court.MatchPhase;
import arcshot.player.Player;

/**
 * Where a referee stands: the LEAD walks the baseline following the ball's x, the TRAIL walks the sideline following
 * the ball's y. Both stay off the court lines (out of bounds), so they never block players, and step away from any
 * player that comes too close. At check ball the TRAIL brings the ball to the top of the arc.
 * OOP pillar: <b>ABSTRACTION</b> - one method, {@link #update}, hides the positioning rules.
 */
public class RefereeAI {
    private static final double SPEED = 210;

    public void update(Referee r, Match m, double dt) {
        if (r.isSignalling()) {
            r.update(dt);
            return;
        }
        CourtGeometry c = m.getCourt();
        double bx = m.getBall().getX();
        double by = m.getBall().getY();
        double tx;
        double ty;
        if (r.getRole() == Referee.Role.LEAD) {
            tx = Math.max(c.getLeft() + 20, Math.min(c.getRight() - 20, bx + (bx < c.getHoopX() ? 90 : -90)));
            ty = c.getTop() - 16;
        } else if (m.getPhase() == MatchPhase.CHECK_BALL) {
            tx = c.checkX() + 46;
            ty = c.checkY() + 26;
        } else {
            tx = c.getRight() + 18;
            ty = Math.max(c.getTop() + 40, Math.min(c.getBottom() - 10, by));
        }
        // auto-avoid players
        for (Player p : m.getPlayers()) {
            double d = Math.hypot(p.getX() - tx, p.getY() - ty);
            if (d < 26) {
                tx += (tx - p.getX()) / Math.max(1, d) * (26 - d);
                ty += (ty - p.getY()) / Math.max(1, d) * (26 - d);
            }
        }
        r.moveToward(tx, ty, SPEED, dt);
        r.face(bx - r.getX(), by - r.getY());
        r.update(dt);
    }
}
