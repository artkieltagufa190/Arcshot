package arcshot.cosmetic;

import java.awt.Color;

/**
 * One cosmetic item. Colors are recolored in code (no duplicate art needed).
 * For court themes the four colors are floor, lines, paint and out-of-bounds.
 * OOP pillar: <b>ENCAPSULATION</b> (immutable value object).
 */
public final class Cosmetic {
    private final String id;
    private final CosmeticType type;
    private final String name;
    private final boolean defaultUnlocked;
    private final Color[] colors;

    public Cosmetic(String id, CosmeticType type, String name, boolean defaultUnlocked, Color... colors) {
        this.id = id;
        this.type = type;
        this.name = name;
        this.defaultUnlocked = defaultUnlocked;
        this.colors = colors.clone();
    }

    public String getId() { return id; }

    public CosmeticType getType() { return type; }

    public String getName() { return name; }

    public boolean isDefaultUnlocked() { return defaultUnlocked; }

    public Color color(int index) {
        return colors.length == 0 ? Color.GRAY : colors[Math.min(index, colors.length - 1)];
    }
}
