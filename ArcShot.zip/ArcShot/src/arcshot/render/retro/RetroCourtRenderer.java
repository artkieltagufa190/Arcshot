package arcshot.render.retro;

import arcshot.cosmetic.Cosmetic;
import arcshot.court.CourtGeometry;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.image.BufferedImage;
import java.util.Random;

/**
 * Draws the half court in the retro style: arena with crowd, sponsor boards (fictional), out-of-bounds apron,
 * glossy hardwood with plank lines and a dithered sheen, painted key, 3x3 markings, a big center logo, the stanchion,
 * and (every frame) the backboard, rim and net. All geometry comes from {@link CourtGeometry}, so art and physics
 * always agree. The static parts are drawn once into a cached 640x360 image.
 * OOP pillar: <b>ABSTRACTION</b> - the match renderer calls three methods and never deals with court drawing.
 */
public final class RetroCourtRenderer {
    // ---- retro palette (see docs/VISUAL_SPEC.md) ----
    static final Color ARENA = new Color(0x0B0F1E);
    static final Color STAND_A = new Color(0x1A2140);
    static final Color STAND_B = new Color(0x2A2D3A);
    static final Color OUTLINE = new Color(0x141018);
    static final Color BOARD = new Color(0xE8ECF2);
    static final Color BOARD_SHADE = new Color(0xC9CED8);
    static final Color RIM = new Color(0xD8462A);
    static final Color RIM_DARK = new Color(0x9C2A18);
    static final Color STANCHION = new Color(0xA02828);
    static final Color LOGO = new Color(0xE8742A);
    static final Color LOGO_DARK = new Color(0x3A1E10);
    static final Color NET = new Color(0xF4F4F0);

    private static final String[] SPONSORS = {"KALAMANSI COLA", "BAYANIHAN BANK", "JEEPNEY EXPRESS", "SARI-SARI MART", "HALO-HALO HUT"};
    private static final Color[] SPONSOR_BG = {new Color(0xD8462A), new Color(0x1E73C8), new Color(0x2ECC40), new Color(0xE8742A), new Color(0x5B3A8C)};

    private final CourtGeometry c;
    private final Projection p;
    private final Cosmetic theme;
    private BufferedImage background;

    public RetroCourtRenderer(CourtGeometry court, Projection projection, Cosmetic theme) {
        this.c = court;
        this.p = projection;
        this.theme = theme;
    }

    public void drawBackground(Graphics2D g) {
        if (background == null) {
            background = new BufferedImage(Projection.W, Projection.H, BufferedImage.TYPE_INT_RGB);
            Graphics2D bg = background.createGraphics();
            paintStatic(bg);
            bg.dispose();
            sheen();
        }
        g.drawImage(background, 0, 0, null);
    }

    // =========================================================================================================
    // static parts
    // =========================================================================================================

    private void paintStatic(Graphics2D g) {
        Random rng = new Random(42);
        g.setColor(ARENA);
        g.fillRect(0, 0, Projection.W, Projection.H);
        int baseY = p.iy(c.getHoopX(), c.getTop(), 0);
        // stands: alternating tiers with dithered crowd heads
        for (int y = 0; y < baseY - 16; y += 6) {
            g.setColor((y / 6) % 2 == 0 ? STAND_A : STAND_B);
            g.fillRect(0, y, Projection.W, 6);
            for (int x = (y / 6) % 2 * 2; x < Projection.W; x += 3 + rng.nextInt(3)) {
                int k = rng.nextInt(10);
                if (k < 7) {
                    g.setColor(crowdColor(rng, y));
                    g.fillRect(x, y + 1, 2, 2);
                    g.setColor(crowdShirt(rng, y));
                    g.fillRect(x, y + 3, 2, 2);
                }
            }
        }
        // side stands lower down (beyond the sidelines)
        for (int y = baseY - 16; y < Projection.H; y += 5) {
            double wy = c.getTop() + (y - baseY) * 2.3;
            int lx = p.ix(c.getLeft() - 60, wy);
            int rx = p.ix(c.getRight() + 60, wy);
            g.setColor((y / 5) % 2 == 0 ? STAND_A : STAND_B);
            g.fillRect(0, y, Math.max(0, lx), 5);
            g.fillRect(rx, y, Projection.W - rx, 5);
            for (int x = 0; x < Projection.W; x += 3 + rng.nextInt(4)) {
                if ((x < lx - 3 || x > rx + 3) && rng.nextInt(10) < 6) {
                    g.setColor(crowdColor(rng, y));
                    g.fillRect(x, y, 2, 2);
                    g.setColor(crowdShirt(rng, y));
                    g.fillRect(x, y + 2, 2, 2);
                }
            }
        }
        // apron (out of bounds floor)
        Color apron = theme.color(3);
        g.setColor(apron);
        g.fillPolygon(quad(c.getLeft() - 55, c.getTop() - 45, c.getRight() + 55, c.getBottom() + 40));
        drawSponsors(g);
        drawBenches(g);
        // hardwood
        Color floor = theme.color(0);
        g.setColor(floor);
        g.fillPolygon(quad(c.getLeft(), c.getTop(), c.getRight(), c.getBottom()));
        Color plank = shade(floor, 0.9);
        Color plankLight = shade(floor, 1.06);
        for (double x = c.getLeft() + 25; x < c.getRight(); x += 25) {
            g.setColor(((int) (x / 25)) % 3 == 0 ? plankLight : plank);
            g.drawLine(p.ix(x, c.getTop()), p.iy(x, c.getTop(), 0), p.ix(x, c.getBottom()), p.iy(x, c.getBottom(), 0));
        }
        g.setColor(plank);
        for (double y = c.getTop() + 30; y < c.getBottom(); y += 60) {
            for (double x = c.getLeft() + ((int) (y / 60) % 2) * 12; x < c.getRight() - 25; x += 75) {
                g.drawLine(p.ix(x, y), p.iy(x, y, 0), p.ix(x + 25, y), p.iy(x + 25, y, 0));
            }
        }
        // painted key in team color
        Color paint = theme.color(2);
        double pw = c.getPaintHalfWidth();
        g.setColor(paint);
        g.fillPolygon(quad(c.getHoopX() - pw, c.getTop(), c.getHoopX() + pw, c.getFreeThrowY()));
        g.setColor(shade(paint, 0.85));
        g.fillPolygon(quad(c.getHoopX() - pw, c.getTop(), c.getHoopX() + pw, c.getTop() + 12));
        drawLogo(g);
        drawLines(g, theme.color(1));
        drawStanchion(g);
    }

    private static Color crowdColor(Random rng, int y) {
        int[] tones = {0x5C3A26, 0x8A5A3C, 0xC68A5E, 0xE8B890, 0x3A2414};
        Color c = new Color(tones[rng.nextInt(tones.length)]);
        return shade(c, 0.3 + y / 420.0);
    }

    private static Color crowdShirt(Random rng, int y) {
        int[] tones = {0xD8462A, 0x1E73C8, 0xF4F4F0, 0x5B3A8C, 0x2ECC40, 0xE8742A, 0x1A2A5A, 0xF4CC8C};
        return shade(new Color(tones[rng.nextInt(tones.length)]), 0.25 + y / 480.0);
    }

    /** A row of courtside boards standing on the far edge of the apron (fictional sponsors). */
    private void drawSponsors(Graphics2D g) {
        double wy = c.getTop() - 45;
        int y1 = p.iy(c.getHoopX(), wy, 0);
        int left = p.ix(c.getLeft() - 55, wy);
        int right = p.ix(c.getRight() + 55, wy);
        int w = (right - left) / SPONSORS.length;
        for (int i = 0; i < SPONSORS.length; i++) {
            int x = left + i * w;
            g.setColor(OUTLINE);
            g.fillRect(x, y1 - 12, w, 12);
            g.setColor(SPONSOR_BG[i]);
            g.fillRect(x + 1, y1 - 11, w - 2, 10);
            g.setColor(shade(SPONSOR_BG[i], 1.25));
            g.fillRect(x + 1, y1 - 11, w - 2, 1);
            String s = SPONSORS[i];
            int tw = PixelFont.width(s, 1);
            if (tw > w - 4) {
                s = s.substring(0, s.indexOf(' ') > 0 ? s.indexOf(' ') : s.length());
                tw = PixelFont.width(s, 1);
            }
            PixelFont.draw(g, s, x + (w - tw) / 2, y1 - 9, Color.WHITE, 1);
        }
    }

    private void drawBenches(Graphics2D g) {
        for (int side = -1; side <= 1; side += 2) {
            double wx = side < 0 ? c.getLeft() - 40 : c.getRight() + 40;
            for (int i = 0; i < 3; i++) {
                double wy = c.getBottom() - 40 - i * 34;
                int x = p.ix(wx, wy);
                int y = p.iy(wx, wy, 0);
                g.setColor(OUTLINE);
                g.fillRect(x - 6, y - 4, 12, 5);
                g.setColor(new Color(0x4A4F66));
                g.fillRect(x - 5, y - 3, 10, 3);
                g.setColor(new Color(0x8A5A3C));
                g.fillRect(x - 2, y - 10, 4, 4);
                g.setColor(side < 0 ? new Color(0x1A2A5A) : new Color(0x5B3A8C));
                g.fillRect(x - 3, y - 6, 6, 4);
            }
        }
    }

    private void drawLogo(Graphics2D g) {
        double wx = c.getHoopX();
        double wy = c.getBottom() - 62;
        int cx = p.ix(wx, wy);
        int cy = p.iy(wx, wy, 0);
        int rx = (int) Math.round(78 * p.scale(wy));
        int ry = (int) Math.round(rx * 0.42);
        g.setColor(LOGO_DARK);
        g.fillOval(cx - rx - 1, cy - ry - 1, rx * 2 + 2, ry * 2 + 2);
        g.setColor(LOGO);
        g.fillOval(cx - rx, cy - ry, rx * 2, ry * 2);
        g.setColor(shade(LOGO, 1.15));
        g.fillOval(cx - rx + 4, cy - ry + 2, rx, ry);
        g.setColor(LOGO_DARK);
        g.drawLine(cx - rx, cy, cx + rx, cy);
        g.drawLine(cx, cy - ry, cx, cy + ry);
        g.drawArc(cx - rx - rx / 2, cy - ry, rx * 2, ry * 2, -50, 100);
        g.drawArc(cx - rx / 2, cy - ry, rx * 2, ry * 2, 130, 100);
        PixelFont.drawCentered(g, "ARCSHOT", cx, cy + ry + 3, new Color(0xF4F4F0), LOGO_DARK, 1);
    }

    private void drawLines(Graphics2D g, Color line) {
        g.setColor(line);
        // outer lines (2 px near the camera)
        polyline(g, new double[][] {{c.getLeft(), c.getBottom()}, {c.getLeft(), c.getTop()}, {c.getRight(), c.getTop()}, {c.getRight(), c.getBottom()}});
        polyline(g, new double[][] {{c.getLeft() + 2, c.getBottom()}, {c.getLeft() + 2, c.getTop() + 2}, {c.getRight() - 2, c.getTop() + 2}, {c.getRight() - 2, c.getBottom()}});
        polyline(g, new double[][] {{c.getLeft(), c.getBottom() - 1}, {c.getRight(), c.getBottom() - 1}});
        // paint
        double pw = c.getPaintHalfWidth();
        polyline(g, new double[][] {{c.getHoopX() - pw, c.getTop()}, {c.getHoopX() - pw, c.getFreeThrowY()},
            {c.getHoopX() + pw, c.getFreeThrowY()}, {c.getHoopX() + pw, c.getTop()}});
        // free-throw circle (front half solid, back half dashed)
        double ft = 1.8 * CourtGeometry.PX_PER_M;
        arc(g, c.getHoopX(), c.getFreeThrowY(), ft, 0, 180, false);
        arc(g, c.getHoopX(), c.getFreeThrowY(), ft, 180, 360, true);
        // restricted area
        arc(g, c.getHoopX(), c.getHoopY(), 1.25 * CourtGeometry.PX_PER_M, 0, 180, false);
        // the arc: corner straights + arc
        double r = c.getArcRadius();
        double corner = c.getCornerX();
        double yMeet = c.getHoopY() + Math.sqrt(Math.max(0, r * r - corner * corner));
        polyline(g, new double[][] {{c.getHoopX() - corner, c.getTop()}, {c.getHoopX() - corner, yMeet}});
        polyline(g, new double[][] {{c.getHoopX() + corner, c.getTop()}, {c.getHoopX() + corner, yMeet}});
        double a0 = Math.toDegrees(Math.atan2(yMeet - c.getHoopY(), corner));
        arc(g, c.getHoopX(), c.getHoopY(), r, a0, 180 - a0, false);
        arc(g, c.getHoopX(), c.getHoopY(), r + 2, a0 + 2, 178 - a0, false);
        // check / clear tick at the top of the arc
        polyline(g, new double[][] {{c.checkX() - 14, c.getHoopY() + r}, {c.checkX() + 14, c.getHoopY() + r}});
        g.fillRect(p.ix(c.checkX(), c.checkY()) - 1, p.iy(c.checkX(), c.checkY(), 0) - 1, 3, 2);
    }

    private void drawStanchion(Graphics2D g) {
        double[] base = c.stanchionBase();
        int bx = p.ix(base[0], base[1]);
        int by = p.iy(base[0], base[1], 0);
        int topY = p.iy(base[0], base[1], 215);
        g.setColor(OUTLINE);
        g.fillRect(bx - 9, by - 7, 18, 9);
        g.setColor(STANCHION);
        g.fillRect(bx - 8, by - 6, 16, 7);
        g.setColor(OUTLINE);
        g.fillRect(bx - 3, topY, 6, by - topY - 5);
        g.setColor(new Color(0x4A4F66));
        g.fillRect(bx - 2, topY, 4, by - topY - 5);
        int ay = p.iy(c.getHoopX(), c.getBoardY(), 205);
        g.setColor(OUTLINE);
        g.fillRect(bx - 2, Math.min(topY, ay), 4, Math.abs(ay - topY) + 3);
    }

    /** A dithered glossy band across the floor ("soft sheen"), done once on the cached image. */
    private void sheen() {
        Polygon court = quad(c.getLeft(), c.getTop(), c.getRight(), c.getBottom());
        java.awt.Rectangle b = court.getBounds().intersection(new java.awt.Rectangle(0, 0, Projection.W, Projection.H));
        for (int y = b.y; y < b.y + b.height; y++) {
            for (int x = b.x; x < b.x + b.width; x++) {
                if (!court.contains(x, y)) {
                    continue;
                }
                int band = (x + y * 2) % 140;
                boolean inBand = band > 30 && band < 52;
                boolean edge = band == 30 || band == 52;
                if ((inBand && (x + y) % 2 == 0) || (edge && (x + y) % 4 == 0)) {
                    int rgb = background.getRGB(x, y);
                    background.setRGB(x, y, brighten(rgb, 18));
                }
            }
        }
    }

    // =========================================================================================================
    // dynamic parts (depth-sorted by the match renderer)
    // =========================================================================================================

    /** The backboard, drawn at floor depth {@link CourtGeometry#getBoardY()}. */
    public void drawBackboard(Graphics2D g, boolean flashMake) {
        double by = c.getBoardY();
        double hw = CourtGeometry.BOARD_HALF_WIDTH;
        int x1 = p.ix(c.getHoopX() - hw, by);
        int x2 = p.ix(c.getHoopX() + hw, by);
        int yTop = p.iy(c.getHoopX(), by, CourtGeometry.BOARD_TOP_Z);
        int yBot = p.iy(c.getHoopX(), by, CourtGeometry.BOARD_BOTTOM_Z);
        g.setColor(OUTLINE);
        g.fillRect(x1 - 1, yTop - 1, x2 - x1 + 3, yBot - yTop + 4);
        g.setColor(BOARD);
        g.fillRect(x1, yTop, x2 - x1 + 1, yBot - yTop + 1);
        g.setColor(BOARD_SHADE);
        g.fillRect(x1, yBot - 1, x2 - x1 + 1, 2);
        // padding along the bottom
        g.setColor(new Color(0x1E73C8));
        g.fillRect(x1, yBot + 1, x2 - x1 + 1, 2);
        // inner square
        int sx1 = p.ix(c.getHoopX() - 15, by);
        int sx2 = p.ix(c.getHoopX() + 15, by);
        int sy1 = p.iy(c.getHoopX(), by, 3.0 * 50 + 22);
        int sy2 = p.iy(c.getHoopX(), by, 3.0 * 50 + 1);
        g.setColor(flashMake ? new Color(0x2ECC40) : RIM);
        g.drawRect(sx1, sy1, sx2 - sx1, sy2 - sy1);
    }

    /** Rim back half (behind the ball) or front half + net (in front of the ball). */
    public void drawRim(Graphics2D g, boolean front, double netSwing, double bend) {
        int cx = p.ix(c.getHoopX(), c.getHoopY());
        int cy = p.iy(c.getHoopX(), c.getHoopY(), c.getRimHeight());
        int rx = 8;
        int ry = 3;
        int drop = (int) Math.round(bend * 2);
        if (!front) {
            g.setColor(RIM_DARK);
            g.drawArc(cx - rx, cy - ry, rx * 2, ry * 2, 0, 180);
            int by = p.iy(c.getHoopX(), c.getBoardY(), c.getRimHeight());
            g.fillRect(cx - 1, Math.min(by, cy - ry), 3, Math.abs(cy - ry - by) + 1);
            return;
        }
        // net: strands from the front of the rim, swinging after a make
        double sway = Math.sin(netSwing * 18) * 2 * netSwing;
        double stretch = 1 + netSwing * 0.5 + bend * 0.3;
        g.setColor(NET);
        int len = (int) Math.round(10 * stretch);
        for (int i = 0; i <= 4; i++) {
            int topX = cx - rx + 1 + i * (rx * 2 - 2) / 4;
            int botX = (int) Math.round(cx - 4 + i * 2 + sway);
            g.drawLine(topX, cy + drop, botX, cy + drop + len);
        }
        g.drawLine((int) (cx - 6 + sway / 2), cy + drop + len / 2, (int) (cx + 6 + sway / 2), cy + drop + len / 2);
        g.drawLine((int) (cx - 4 + sway), cy + drop + len, (int) (cx + 4 + sway), cy + drop + len);
        g.setColor(OUTLINE);
        g.drawArc(cx - rx, cy - ry + drop + 1, rx * 2, ry * 2, 180, 180);
        g.setColor(RIM);
        g.drawArc(cx - rx, cy - ry + drop, rx * 2, ry * 2, 180, 180);
        g.drawLine(cx - rx, cy + drop, cx - rx, cy + drop);
        g.drawLine(cx + rx, cy + drop, cx + rx, cy + drop);
    }

    // =========================================================================================================
    // helpers
    // =========================================================================================================

    private Polygon quad(double x1, double y1, double x2, double y2) {
        Polygon poly = new Polygon();
        poly.addPoint(p.ix(x1, y1), p.iy(x1, y1, 0));
        poly.addPoint(p.ix(x2, y1), p.iy(x2, y1, 0));
        poly.addPoint(p.ix(x2, y2), p.iy(x2, y2, 0));
        poly.addPoint(p.ix(x1, y2), p.iy(x1, y2, 0));
        return poly;
    }

    private void polyline(Graphics2D g, double[][] pts) {
        for (int i = 0; i + 1 < pts.length; i++) {
            g.drawLine(p.ix(pts[i][0], pts[i][1]), p.iy(pts[i][0], pts[i][1], 0),
                    p.ix(pts[i + 1][0], pts[i + 1][1]), p.iy(pts[i + 1][0], pts[i + 1][1], 0));
        }
    }

    /** A circle arc on the floor (degrees; 0 = +x, 90 = toward the camera). */
    private void arc(Graphics2D g, double cx, double cy, double r, double fromDeg, double toDeg, boolean dashed) {
        int steps = (int) Math.max(8, Math.abs(toDeg - fromDeg) / 3);
        int px = 0;
        int py = 0;
        for (int i = 0; i <= steps; i++) {
            double a = Math.toRadians(fromDeg + (toDeg - fromDeg) * i / steps);
            double wx = cx + Math.cos(a) * r;
            double wy = cy + Math.sin(a) * r;
            if (wy < c.getTop()) {
                continue;
            }
            int x = p.ix(wx, wy);
            int y = p.iy(wx, wy, 0);
            if (i > 0 && (!dashed || (i / 2) % 2 == 0)) {
                g.drawLine(px, py, x, y);
            }
            px = x;
            py = y;
        }
    }

    static Color shade(Color c, double k) {
        return new Color(Math.min(255, (int) (c.getRed() * k)), Math.min(255, (int) (c.getGreen() * k)),
                Math.min(255, (int) (c.getBlue() * k)));
    }

    private static int brighten(int rgb, int add) {
        int r = Math.min(255, ((rgb >> 16) & 255) + add);
        int g = Math.min(255, ((rgb >> 8) & 255) + add);
        int b = Math.min(255, (rgb & 255) + add);
        return (r << 16) | (g << 8) | b;
    }
}
