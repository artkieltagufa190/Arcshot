package arcshot.achievement;

import arcshot.core.GameEvent;
import arcshot.core.GameEventType;
import arcshot.court.MatchSummary;

/**
 * Checked when a match finishes, e.g. "win after trailing by 6 or more".
 * OOP pillars: <b>INHERITANCE</b> (extends Achievement) and <b>POLYMORPHISM</b> (overrides handle() / progress).
 */
public class ConditionalAchievement extends Achievement {
    private final MatchCondition condition;

    public ConditionalAchievement(String id, String name, String description, String hint,
                                  AchievementTier tier, AchievementBranch branch, MatchCondition condition) {
        super(id, name, description, hint, tier, branch);
        this.condition = condition;
    }

    @Override
    public int getTarget() { return 1; }

    @Override
    public void handle(GameEvent event, AchievementContext ctx) {
        if (event.getType() == GameEventType.MATCH_FINISHED && event.getPayload() instanceof MatchSummary
                && condition.test((MatchSummary) event.getPayload())) {
            ctx.setProgress(getId(), 1);
        }
    }

    @Override
    public String getProgressText(AchievementContext ctx) {
        return isComplete(ctx) ? "Done" : "Not yet";
    }
}
