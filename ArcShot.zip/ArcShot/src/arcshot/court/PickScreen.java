package arcshot.court;

import arcshot.effect.SpeedBoostEffect;
import arcshot.player.Player;

/**
 * A screen (Blazing Screen / Bulwark Screen): blocks opponents; the bulwark version also speeds up teammates nearby.
 * OOP pillars: <b>INHERITANCE</b> (extends CourtEntity) and <b>POLYMORPHISM</b> (overrides affect / blocks / update).
 */
public class PickScreen extends CourtEntity {
    private final boolean boostsTeammates;
    private final double boost;

    public PickScreen(Player owner, String visualKey, double x, double y, double radius, double duration,
                      boolean boostsTeammates, double boost) {
        super(owner, visualKey, x, y, radius, duration);
        this.boostsTeammates = boostsTeammates;
        this.boost = boost;
    }

    @Override
    public boolean blocks(Player p) {
        return p.getSide() != getSide();
    }

    @Override
    public void affect(Player p, double dt, Match match) {
        if (boostsTeammates && p.getSide() == getSide()) {
            p.applyEffect(new SpeedBoostEffect("screen_boost", 0.6, boost, false));
        }
    }

    /** The aura of a bulwark screen is larger than its body. */
    @Override
    public double getBlockRadius() {
        return boostsTeammates ? getRadius() * 0.3 : getRadius();
    }
}
