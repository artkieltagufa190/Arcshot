package arcshot.control;

import java.awt.event.KeyEvent;
import java.util.EnumMap;
import java.util.Map;

/**
 * Maps each {@link InputAction} to a key code. Saved in the profile so players can rebind keys.
 * OOP pillar: <b>ENCAPSULATION</b> - the map is private; {@link #bind} also removes the key from any other action
 * so two actions can never share a key.
 */
public final class KeyBindings {
    private final Map<InputAction, Integer> keys = new EnumMap<>(InputAction.class);

    public KeyBindings() {
        resetToDefaults();
    }

    public void resetToDefaults() {
        for (InputAction a : InputAction.values()) {
            keys.put(a, a.getDefaultKey());
        }
    }

    public int keyFor(InputAction action) {
        Integer k = keys.get(action);
        return k == null ? action.getDefaultKey() : k;
    }

    public void bind(InputAction action, int keyCode) {
        for (InputAction other : InputAction.values()) {
            if (other != action && keyFor(other) == keyCode) {
                keys.put(other, keyFor(action)); // swap so nothing is left unbound
            }
        }
        keys.put(action, keyCode);
    }

    /** Human-readable key name, e.g. "Space". */
    public String keyName(InputAction action) {
        return KeyEvent.getKeyText(keyFor(action));
    }

    /** Short name for HUD key labels. */
    public String shortName(InputAction action) {
        String name = keyName(action);
        return name.length() > 5 ? name.substring(0, 5) : name;
    }
}
