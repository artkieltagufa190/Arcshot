package arcshot.save;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Properties;

/**
 * Loads and saves the {@link Profile} as a {@code .properties} file in {@code ~/.arcshot/}.
 * A missing file gives a fresh profile; a corrupt file is renamed to {@code profile.corrupt} and a fresh profile
 * is used, so the game always starts. Saving writes a temporary file first and then replaces the real one, so a
 * crash in the middle of saving cannot destroy old progress.
 * <p>
 * OOP pillar: <b>ABSTRACTION</b> - the rest of the game just calls {@link #load()} / {@link #save(Profile)} and
 * never deals with files.
 */
public final class SaveManager {
    private final File folder;
    private final File file;
    private String lastMessage = "";

    public SaveManager() {
        this(new File(System.getProperty("user.home"), ".arcshot"));
    }

    public SaveManager(File folder) {
        this.folder = folder;
        this.file = new File(folder, "profile.properties");
    }

    public File getFile() { return file; }

    /** Human-readable note about the last load (e.g. "corrupt save was reset"). */
    public String getLastMessage() { return lastMessage; }

    public Profile load() {
        Profile profile = new Profile();
        if (!file.isFile()) {
            lastMessage = "New profile";
            return profile;
        }
        Properties p = new Properties();
        try (InputStream in = new FileInputStream(file)) {
            p.load(in);
            profile.readFrom(p);
            lastMessage = "Loaded " + file.getPath();
            return profile;
        } catch (IOException | RuntimeException ex) {
            backupCorrupt();
            lastMessage = "Save file was unreadable and has been reset (backup: profile.corrupt)";
            return new Profile();
        }
    }

    public synchronized boolean save(Profile profile) {
        Properties p = new Properties();
        profile.writeTo(p);
        try {
            if (!folder.isDirectory() && !folder.mkdirs()) {
                return false;
            }
            File tmp = new File(folder, "profile.tmp");
            try (OutputStream out = new FileOutputStream(tmp)) {
                p.store(out, "ArcShot save - safe to delete to reset progress");
            }
            Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
            return true;
        } catch (IOException | RuntimeException ex) {
            return false;
        }
    }

    private void backupCorrupt() {
        try {
            Files.move(file.toPath(), new File(folder, "profile.corrupt").toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ex) {
            // ignore: we just start fresh
        }
    }

    static int intOf(Properties p, String key, int def) {
        String v = p.getProperty(key);
        if (v == null) {
            return def;
        }
        try {
            return Integer.parseInt(v.trim());
        } catch (NumberFormatException ex) {
            return def;
        }
    }
}
