package arcshot.render.retro;

import arcshot.anim.Facing;
import arcshot.core.GameEventListener;
import arcshot.court.Ball;
import arcshot.court.CourtEntity;
import arcshot.court.CourtGeometry;
import arcshot.court.Decoy;
import arcshot.court.FxSink;
import arcshot.court.Match;
import arcshot.court.ShotAttempt;
import arcshot.player.Player;
import arcshot.player.TeamSide;
import arcshot.referee.Referee;
import arcshot.render.EffectRenderer;
import arcshot.render.MatchView;
import arcshot.render.RenderContext;
import arcshot.render.sprite.AnimatedSprite;
import arcshot.render.sprite.Palette;
import arcshot.render.sprite.SpriteLoader;
import arcshot.render.sprite.SpriteSheet;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * The retro renderer: draws a match into a 640x360 buffer with an angled 3/4 broadcast camera, pixel-art sprites,
 * shadows, and a depth sort. The game canvas then scales the buffer up with nearest-neighbour (crisp pixels).
 * <p>
 * Draw order: cached court -&gt; floor effects -&gt; shadows -&gt; depth-sorted list (backboard, back of rim, players,
 * referees, decoys, ball, front of rim + net, sorted by court y) -&gt; air effects -&gt; screen tint -&gt; HUD.
 * Only <i>reads</i> the match. OOP pillars: <b>POLYMORPHISM</b> (a {@link MatchView}) and <b>ABSTRACTION</b>.
 */
public final class RetroMatchRenderer implements MatchView {
    /** One thing in the depth-sorted list. */
    private interface Drawable {
        void draw(Graphics2D g);
    }

    private static final class Item {
        final double depth;
        final int order;
        final Drawable d;

        Item(double depth, int order, Drawable d) {
            this.depth = depth;
            this.order = order;
            this.d = d;
        }
    }

    private static final Color SHADOW = new Color(0, 0, 0, 90);
    private static final Color BALL = new Color(0xE8742A);
    private static final Color BALL_DARK = new Color(0xA04A18);
    private static final Color BALL_LIGHT = new Color(0xF8A860);

    private final RenderContext ctx;
    private final EffectRenderer colors;
    private final RetroParticles particles;
    private final RetroHud hud;
    private Projection pr;
    private RetroCourtRenderer court;
    private final Random rng = new Random();
    private final Map<Referee, Facing> refFacing = new HashMap<>();
    private Match match;

    public RetroMatchRenderer(RenderContext ctx) {
        this.ctx = ctx;
        this.colors = new EffectRenderer(ctx.getSkin());
        this.particles = new RetroParticles(colors);
        this.hud = new RetroHud(ctx, null);
    }

    @Override
    public FxSink getFx() { return particles; }

    @Override
    public GameEventListener getHudListener() { return hud; }

    @Override
    public int frameWidth() { return Projection.W; }

    @Override
    public int frameHeight() { return Projection.H; }

    @Override
    public boolean isPixelArt() { return true; }

    @Override
    public void update(double dt) {
        particles.update(dt);
        hud.update(dt);
    }

    @Override
    public void render(Graphics2D g, Match m, int w, int h) {
        this.match = m;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_SPEED);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        colors.setColorblind(ctx.isColorblind());
        if (court == null) {
            pr = new Projection(m.getCourt());
            court = new RetroCourtRenderer(m.getCourt(), pr, ctx.getCourtTheme());
            hud.setProjection(pr); // the HUD needs the same camera (meter over the shooter, FT arrow to the rim)
        }
        int ox = 0;
        int oy = 0;
        if (ctx.isScreenShake() && m.getShake() > 0.3) {
            ox = (int) Math.round((rng.nextDouble() - 0.5) * m.getShake() * 0.5);
            oy = (int) Math.round((rng.nextDouble() - 0.5) * m.getShake() * 0.5);
        }
        g.translate(ox, oy);
        court.drawBackground(g);
        for (CourtEntity e : m.getEntities()) {
            if (!(e instanceof Decoy)) {
                drawZone(g, e);
            }
        }
        particles.drawFloor(g, pr);
        drawShadows(g, m);
        drawSorted(g, m);
        drawControlOverlay(g, m);
        particles.drawAir(g, pr, this::paintGhost);
        if (ctx.isDebug()) {
            drawHitboxes(g, m);
        }
        g.translate(-ox, -oy);
        drawScreenEffects(g, m, w, h);
        hud.draw(g, m);
    }

    // =========================================================================================================
    // depth-sorted scene
    // =========================================================================================================

    private void drawSorted(Graphics2D g, final Match m) {
        final CourtGeometry c = m.getCourt();
        List<Item> items = new ArrayList<>();
        int order = 0;
        final boolean flash = m.getNetSwing() > 0.3;
        items.add(new Item(c.getBoardY(), order++, gg -> court.drawBackboard(gg, flash)));
        items.add(new Item(c.getHoopY() - 0.5, order++, gg -> court.drawRim(gg, false, m.getNetSwing(), m.getRimBend())));
        items.add(new Item(c.getHoopY() + 0.5, order++, gg -> court.drawRim(gg, true, m.getNetSwing(), m.getRimBend())));
        final Ball ball = m.getBall();
        for (final Player p : m.getPlayers()) {
            items.add(new Item(p.getY(), order++, gg -> drawPlayer(gg, m, p)));
        }
        int ri = 0;
        for (final Referee r : m.getRefs().getReferees()) {
            final int idx = ri++;
            items.add(new Item(r.getY(), order++, gg -> drawReferee(gg, r, idx)));
        }
        for (final CourtEntity e : m.getEntities()) {
            if (e instanceof Decoy) {
                items.add(new Item(e.getY(), order++, gg -> drawDecoy(gg, m, e)));
            }
        }
        if (ball.getState() != Ball.State.HELD) {
            double depth = ballThroughHoop(m) ? c.getHoopY() : ball.getY() + 0.25;
            items.add(new Item(depth, order++, gg -> drawFreeBall(gg, ball)));
        }
        Collections.sort(items, new Comparator<Item>() {
            @Override
            public int compare(Item a, Item b) {
                int d = Double.compare(a.depth, b.depth);
                return d != 0 ? d : Integer.compare(a.order, b.order);
            }
        });
        for (Item it : items) {
            it.d.draw(g);
        }
    }

    /** While the ball drops through the hoop it sits between the back and front of the rim. */
    private boolean ballThroughHoop(Match m) {
        Ball b = m.getBall();
        CourtGeometry c = m.getCourt();
        if (c.distanceToHoop(b.getX(), b.getY()) > 26) {
            return false;
        }
        if (b.getState() == Ball.State.SHOT) {
            ShotAttempt s = b.getShot();
            return s != null && s.getProgress() > 0.75;
        }
        return b.getState() == Ball.State.DEAD && b.getZ() > 40;
    }

    // =========================================================================================================
    // players
    // =========================================================================================================

    private SpriteSheet sheetFor(Match m, Player p) {
        Color team = m.teamOf(p.getSide()).getColor();
        int look = p.getAppearance();
        String variant = Math.abs(look) % 2 == 0 ? "a" : "b";
        return SpriteLoader.get(p.getPlayerClass().key(), variant, Palette.forPlayer(team, p.getSide() == TeamSide.HOME, look));
    }

    private void drawPlayer(Graphics2D g, Match m, Player p) {
        int fx = pr.ix(p.getX(), p.getY());
        int fy = pr.iy(p.getX(), p.getY(), p.getZ());
        int floorY = pr.iy(p.getX(), p.getY(), 0);
        String anim = p.getActions().getAnimation();
        int frame = p.getActions().getFrame();
        Facing f = p.getSpriteFacing();
        boolean flip = f == Facing.SIDE && p.getFacingX() < 0;
        Ball ball = m.getBall();
        boolean hasBall = ball.getState() == Ball.State.HELD && ball.getHolder() == p;
        boolean controlled = p == m.getControlled();
        if (controlled) {
            pixelRing(g, fx, floorY, 11, 4, markerColor(), true);
        }
        if (p.hasEffect("barrier") || p.hasEffect("rim_protector")) {
            pixelRing(g, fx, floorY, 14, 5, new Color(0x5FD3F0), ((int) (m.getElapsed() * 8)) % 2 == 0);
        }
        SpriteSheet sheet = sheetFor(m, p);
        boolean ballBehind = hasBall && f == Facing.BACK;
        int[] hand = sheet == null ? new int[] {6, -24} : sheet.anchor("hand", anim, f, frame, flip);
        if (ballBehind) {
            drawHeldBall(g, m, p, fx + hand[0], fy + hand[1], floorY);
        }
        if (sheet == null) {
            drawPlaceholder(g, fx, fy, m.teamOf(p.getSide()).getColor());
        } else {
            SpriteSheet use = sheet;
            if (p.hasEffect("freeze")) {
                use = SpriteLoader.tinted(sheet, new Color(0x9FE8FF), 0.6, p.getPlayerClass().key() + p.getAppearance() + p.getSide() + "ice");
            } else if (p.hasEffect("stun") && ((int) (m.getElapsed() * 10)) % 2 == 0) {
                use = SpriteLoader.tinted(sheet, new Color(0xF4F4F0), 0.45, p.getPlayerClass().key() + p.getAppearance() + p.getSide() + "stun");
            }
            AnimatedSprite.draw(g, use, anim, f, frame, flip, fx, fy);
            if (f != Facing.SIDE) {
                int[] num = sheet.anchor("number", anim, f, frame, flip);
                Color trim = Palette.luminance(m.teamOf(p.getSide()).getColor()) > 0.7 ? new Color(0x1A2A5A) : new Color(0xF4F4F0);
                PixelFont.drawTinyNumber(g, String.valueOf(p.getNumber()), fx + num[0], fy + num[1] - 2, trim);
            }
        }
        if (hasBall && !ballBehind) {
            drawHeldBall(g, m, p, fx + hand[0], fy + hand[1], floorY);
        }
        int headY = fy + (sheet == null ? -50 : sheet.anchor("head", anim, f, frame, flip)[1]) - 8;
        drawStatusOver(g, m, p, fx, headY);
    }

    private Color markerColor() {
        return ctx.getAuraColor() != null ? ctx.getAuraColor() : new Color(0x5FD3F0);
    }

    /** Name tag + arrow for the controlled player: drawn after the depth-sorted scene so nobody covers them. */
    private void drawControlOverlay(Graphics2D g, Match m) {
        Player p = m.getControlled();
        if (p == null) {
            return;
        }
        int fx = pr.ix(p.getX(), p.getY());
        int floorY = pr.iy(p.getX(), p.getY(), 0);
        String name = p.getName().toUpperCase();
        PixelFont.drawCentered(g, name.length() > 10 ? name.substring(0, 10) : name, fx, floorY + 5,
                new Color(0xF4F4F0), RetroCourtRenderer.OUTLINE, 1);
        Color c = markerColor();
        // arrow over the head
        int y = pr.iy(p.getX(), p.getY(), p.getZ()) - 54 + (int) (Math.sin(m.getElapsed() * 6) * 1.5);
        g.setColor(RetroCourtRenderer.OUTLINE);
        g.fillRect(fx - 4, y - 1, 9, 4);
        g.fillRect(fx - 2, y + 3, 5, 2);
        g.setColor(c);
        g.fillRect(fx - 3, y, 7, 2);
        g.fillRect(fx - 2, y + 2, 5, 1);
        g.fillRect(fx - 1, y + 3, 3, 1);
        g.fillRect(fx, y + 4, 1, 1);
    }

    private void drawStatusOver(Graphics2D g, Match m, Player p, int x, int y) {
        double t = m.getElapsed();
        if (p.hasEffect("stun")) {
            for (int i = 0; i < 3; i++) {
                double a = t * 5 + i * 2.1;
                g.setColor(new Color(0xF4CC3A));
                g.fillRect(x + (int) (Math.cos(a) * 7), y + (int) (Math.sin(a) * 2), 2, 2);
            }
        }
        if (p.hasEffect("slow")) {
            g.setColor(new Color(0x5B7BD8));
            g.fillRect(x - 6, y + 2 + (int) (t * 20) % 6, 1, 2);
            g.fillRect(x + 6, y + 4 + (int) (t * 20 + 3) % 6, 1, 2);
        }
        if (p.hasEffect("no_shoot") || p.hasEffect("shot_penalty")) {
            g.setColor(new Color(0xD8462A));
            g.fillRect(x - 3, y - 3, 7, 1);
            g.fillRect(x - 3, y - 3, 1, 7);
            g.fillRect(x + 3, y - 3, 1, 7);
            g.fillRect(x - 3, y + 3, 7, 1);
        }
        if (p.isUltimateReady() && ((int) (t * 4)) % 2 == 0) {
            g.setColor(new Color(0xF4CC3A));
            g.fillRect(x - 1, y - 6, 3, 1);
            g.fillRect(x, y - 7, 1, 3);
        }
        if (p.getConsecutiveMakes() >= arcshot.core.Balance.i("heat.streak", 3)) {
            // pixel flames: the "Heat" streak
            for (int i = 0; i < 4; i++) {
                int h = 3 + (int) ((Math.sin(t * 12 + i * 1.7) + 1) * 2);
                g.setColor(i % 2 == 0 ? new Color(0xD8462A) : new Color(0xF4CC3A));
                g.fillRect(x - 5 + i * 3, y - h, 2, h);
            }
        }
    }

    private void drawPlaceholder(Graphics2D g, int fx, int fy, Color team) {
        g.setColor(RetroCourtRenderer.OUTLINE);
        g.fillRect(fx - 7, fy - 45, 14, 45);
        g.setColor(team);
        g.fillRect(fx - 6, fy - 34, 12, 18);
        g.setColor(new Color(0xC68A5E));
        g.fillRect(fx - 4, fy - 44, 8, 9);
        g.fillRect(fx - 5, fy - 15, 4, 14);
        g.fillRect(fx + 1, fy - 15, 4, 14);
    }

    /** Afterimage callback: the same sprite frame as a tinted silhouette. */
    private void paintGhost(Graphics2D g, Player p, String anim, int frame, double x, double y, double z, Color tint) {
        if (match == null) {
            return;
        }
        SpriteSheet sheet = sheetFor(match, p);
        if (sheet == null) {
            return;
        }
        SpriteSheet ghost = SpriteLoader.tinted(sheet, tint, 0.8, p.getPlayerClass().key() + p.getAppearance() + p.getSide() + tint.getRGB());
        Facing f = p.getSpriteFacing();
        boolean flip = f == Facing.SIDE && p.getFacingX() < 0;
        AnimatedSprite.draw(g, ghost, anim, f, frame, flip, pr.ix(x, y), pr.iy(x, y, z));
    }

    private void drawDecoy(Graphics2D g, Match m, CourtEntity e) {
        Player owner = e.getOwner();
        SpriteSheet sheet = sheetFor(m, owner);
        int fx = pr.ix(e.getX(), e.getY());
        int fy = pr.iy(e.getX(), e.getY(), 0);
        if (sheet == null) {
            drawPlaceholder(g, fx, fy, m.teamOf(owner.getSide()).getColor());
            return;
        }
        // decoys flicker every other frame near the end, like an old sprite at its limit
        if (e.getFractionLeft() < 0.3 && ((int) (m.getElapsed() * 15)) % 2 == 0) {
            return;
        }
        SpriteSheet ghost = SpriteLoader.tinted(sheet, colors.colorFor(e.getVisualKey()), 0.35,
                owner.getPlayerClass().key() + owner.getAppearance() + owner.getSide() + "decoy");
        AnimatedSprite.draw(g, ghost, "dribble", owner.getSpriteFacing(), (int) (m.getElapsed() * 8) % 4, false, fx, fy);
    }

    // =========================================================================================================
    // referees
    // =========================================================================================================

    private void drawReferee(Graphics2D g, Referee r, int index) {
        Facing f = Facing.choose(r.getFacingX(), r.getFacingY(), refFacing.containsKey(r) ? refFacing.get(r) : Facing.FRONT);
        refFacing.put(r, f);
        boolean flip = f == Facing.SIDE && r.getFacingX() < 0;
        int fx = pr.ix(r.getX(), r.getY());
        int fy = pr.iy(r.getX(), r.getY(), 0);
        SpriteSheet sheet = SpriteLoader.get("ref", "a", Palette.forReferee(index));
        if (sheet == null) {
            for (int i = 0; i < 4; i++) {
                g.setColor(i % 2 == 0 ? Color.WHITE : new Color(0x1A1A1A));
                g.fillRect(fx - 6 + i * 3, fy - 34, 3, 16);
            }
            g.setColor(new Color(0x2A2D3A));
            g.fillRect(fx - 5, fy - 18, 10, 18);
            g.setColor(new Color(0xC68A5E));
            g.fillRect(fx - 4, fy - 43, 8, 9);
            return;
        }
        AnimatedSprite.draw(g, sheet, r.getAnimation(), f, r.getFrame(), flip, fx, fy);
    }

    // =========================================================================================================
    // ball
    // =========================================================================================================

    /** The ball in a holder's hand: at the hand anchor, bouncing to the floor while dribbling. */
    private void drawHeldBall(Graphics2D g, Match m, Player p, int hx, int hy, int floorY) {
        Ball b = m.getBall();
        if (b.isDribbling()) {
            double t = p.getActions().getLocomotionTime();
            double rate = Ball.dribbleRate(Math.hypot(p.getVx(), p.getVy()));
            double ph = Math.abs(Math.sin(t * rate * Math.PI)); // one floor touch per 1/rate seconds
            int by = (int) Math.round(floorY - 4 - ph * (floorY - 4 - hy));
            drawBallSprite(g, hx, by, b.getSpin(), 7);
            if (ph < 0.12) {
                g.setColor(SHADOW);
                g.fillRect(hx - 3, floorY - 1, 7, 2);
            }
            return;
        }
        drawBallSprite(g, hx, hy, b.getSpin(), 7);
    }

    private void drawFreeBall(Graphics2D g, Ball b) {
        if (b.getTrailCount() > 1 && (b.getState() == Ball.State.SHOT || b.getState() == Ball.State.PASS)) {
            Color tc = colors.colorFor("ball_trail");
            for (int i = 2; i < b.getTrailCount(); i += 2) {
                g.setColor(tc);
                int s = i < 6 ? 2 : 1;
                g.fillRect(pr.ix(b.getTrailX(i), b.getTrailY(i)) - s / 2, pr.iy(b.getTrailX(i), b.getTrailY(i), b.getTrailZ(i)) - s / 2, s, s);
            }
        }
        int size = b.getZ() > 250 ? 8 : 7;
        drawBallSprite(g, pr.ix(b.getX(), b.getY()), pr.iy(b.getX(), b.getY(), b.getZ() + 6), b.getSpin(), size);
    }

    /** A 7x7 (or 8x8) pixel basketball with outline, highlight and two rotating seams. */
    private void drawBallSprite(Graphics2D g, int cx, int cy, double spin, int size) {
        int r = size / 2;
        int x = cx - r;
        int y = cy - r;
        g.setColor(RetroCourtRenderer.OUTLINE);
        g.fillRect(x + 1, y - 1, size - 2, size + 2);
        g.fillRect(x - 1, y + 1, size + 2, size - 2);
        g.fillRect(x, y, size, size);
        g.setColor(BALL);
        g.fillRect(x + 1, y, size - 2, size);
        g.fillRect(x, y + 1, size, size - 2);
        g.setColor(BALL_DARK);
        g.fillRect(x + 1, y + size - 2, size - 2, 1);
        g.fillRect(x + size - 2, y + 1, 1, size - 2);
        g.setColor(BALL_LIGHT);
        g.fillRect(x + 1, y + 1, 2, 1);
        g.fillRect(x + 1, y + 2, 1, 1);
        // seams: 4 spin frames
        int frame = ((int) Math.floor(spin / (Math.PI / 4))) & 3;
        g.setColor(RetroCourtRenderer.OUTLINE);
        switch (frame) {
            case 0: g.fillRect(x, cy, size, 1); g.fillRect(cx, y, 1, size); break;
            case 1: for (int i = 0; i < size; i++) { g.fillRect(x + i, y + i, 1, 1); } break;
            case 2: g.fillRect(x, cy, size, 1); g.fillRect(cx - 2, y + 1, 1, size - 2); g.fillRect(cx + 2, y + 1, 1, size - 2); break;
            default: for (int i = 0; i < size; i++) { g.fillRect(x + size - 1 - i, y + i, 1, 1); } break;
        }
    }

    // =========================================================================================================
    // floor: shadows, zones
    // =========================================================================================================

    private void drawShadows(Graphics2D g, Match m) {
        for (Player p : m.getPlayers()) {
            double z = p.getZ();
            int w = (int) Math.max(8, 18 - z * 0.08);
            shadow(g, pr.ix(p.getX(), p.getY()), pr.iy(p.getX(), p.getY(), 0), w);
        }
        for (Referee r : m.getRefs().getReferees()) {
            shadow(g, pr.ix(r.getX(), r.getY()), pr.iy(r.getX(), r.getY(), 0), 16);
        }
        Ball b = m.getBall();
        if (b.getState() != Ball.State.HELD) {
            int w = (int) Math.max(4, 8 - b.getZ() * 0.015);
            shadow(g, pr.ix(b.getX(), b.getY()), pr.iy(b.getX(), b.getY(), 0), w);
        }
    }

    private static void shadow(Graphics2D g, int x, int y, int w) {
        g.setColor(SHADOW);
        int h = Math.max(2, w / 3);
        g.fillRect(x - w / 2 + 1, y - h / 2, w - 2, h);
        g.fillRect(x - w / 2, y - h / 2 + 1, w, Math.max(1, h - 2));
    }

    private void drawZone(Graphics2D g, CourtEntity e) {
        Color c = colors.colorFor(e.getVisualKey());
        boolean blink = e.getFractionLeft() < 0.25 && ((int) (System.nanoTime() / 80_000_000L)) % 2 == 0;
        if (blink) {
            return;
        }
        int steps = (int) Math.max(20, e.getRadius() / 2);
        g.setColor(c);
        for (int i = 0; i < steps; i++) {
            double a = Math.PI * 2 * i / steps;
            double wx = e.getX() + Math.cos(a) * e.getRadius();
            double wy = e.getY() + Math.sin(a) * e.getRadius();
            g.fillRect(pr.ix(wx, wy), pr.iy(wx, wy, 0), 2, 1);
        }
        // checkerboard fill (dither) inside
        Color fill = new Color(c.getRed(), c.getGreen(), c.getBlue(), 70);
        g.setColor(fill);
        int cx = pr.ix(e.getX(), e.getY());
        int cy = pr.iy(e.getX(), e.getY(), 0);
        int rx = (int) (e.getRadius() * pr.scale(e.getY()));
        int ry = (int) (rx * 0.5);
        for (int yy = -ry; yy <= ry; yy++) {
            double k = 1 - (yy * yy) / (double) (ry * ry + 1);
            int half = (int) (rx * Math.sqrt(Math.max(0, k)));
            for (int xx = -half + ((yy + 1000) % 2); xx <= half; xx += 2) {
                g.fillRect(cx + xx, cy + yy, 1, 1);
            }
        }
    }

    private void pixelRing(Graphics2D g, int cx, int cy, int rx, int ry, Color c, boolean solid) {
        g.setColor(c);
        int steps = rx * 4;
        for (int i = 0; i < steps; i++) {
            if (!solid && i % 2 == 1) {
                continue;
            }
            double a = Math.PI * 2 * i / steps;
            g.fillRect(cx + (int) Math.round(Math.cos(a) * rx), cy + (int) Math.round(Math.sin(a) * ry), 1, 1);
        }
    }

    // =========================================================================================================
    // screen effects + debug
    // =========================================================================================================

    private void drawScreenEffects(Graphics2D g, Match m, int w, int h) {
        if (m.getTintTime() > 0) {
            Color c = colors.colorFor(m.getTintKey());
            g.setColor(new Color(c.getRed(), c.getGreen(), c.getBlue(), (int) (Math.min(0.3, m.getTintTime() * 0.6) * 255)));
            g.fillRect(0, 0, w, h);
        }
        if (m.getFlashTime() > 0) {
            // stepped flash: full, half, off - no smooth fades
            double t = m.getFlashTime();
            int a = t > 0.2 ? 170 : (t > 0.08 ? 90 : 0);
            if (a > 0) {
                Color c = colors.colorFor(m.getFlashKey());
                g.setColor(new Color(c.getRed(), c.getGreen(), c.getBlue(), a));
                g.fillRect(0, 0, w, h);
            }
        }
    }

    private void drawHitboxes(Graphics2D g, Match m) {
        for (Player p : m.getPlayers()) {
            g.setColor(p.getActions().isIntangible() ? Color.MAGENTA : (p.isBlockContactActive() ? Color.RED : Color.GREEN));
            int steps = 24;
            double r = Player.RADIUS;
            for (int i = 0; i < steps; i++) {
                double a = Math.PI * 2 * i / steps;
                double wx = p.getX() + Math.cos(a) * r;
                double wy = p.getY() + Math.sin(a) * r;
                g.fillRect(pr.ix(wx, wy), pr.iy(wx, wy, 0), 1, 1);
            }
            int x = pr.ix(p.getX(), p.getY());
            g.drawLine(x, pr.iy(p.getX(), p.getY(), 0), x, pr.iy(p.getX(), p.getY(), p.getZ()));
        }
        Ball b = m.getBall();
        g.setColor(Color.YELLOW);
        g.drawRect(pr.ix(b.getX(), b.getY()) - 1, pr.iy(b.getX(), b.getY(), 0) - 1, 2, 2);
        CourtGeometry c = m.getCourt();
        g.setColor(Color.CYAN);
        double fr = c.getFinishRange();
        for (int i = 0; i < 40; i++) {
            double a = Math.PI * i / 39;
            double wx = c.getHoopX() + Math.cos(a) * fr;
            double wy = c.getHoopY() + Math.sin(a) * fr;
            g.fillRect(pr.ix(wx, wy), pr.iy(wx, wy, 0), 1, 1);
        }
    }
}
