package arcshot.player;

/**
 * One player's box score for a single match.
 * OOP pillar: <b>ENCAPSULATION</b> - counters are private and can only go up through the {@code add...} methods.
 */
public final class PlayerStats {
    private int points;
    private int shotsMade;
    private int shotsTaken;
    private int outsideMade;
    private int rebounds;
    private int assists;
    private int steals;
    private int blocks;
    private int turnovers;
    private int abilitiesUsed;
    private int ultimatesUsed;
    private int fouls;
    private int freeThrowsMade;
    private int freeThrowsTaken;
    private int dunks;
    private int layups;

    public void addShot(boolean made, int pts, boolean outside) {
        shotsTaken++;
        if (made) {
            shotsMade++;
            points += pts;
            if (outside) {
                outsideMade++;
            }
        }
    }

    public void addRebound() { rebounds++; }

    public void addAssist() { assists++; }

    public void addSteal() { steals++; }

    public void addBlock() { blocks++; }

    public void addTurnover() { turnovers++; }

    public void addAbilityUse(boolean ultimate) {
        if (ultimate) {
            ultimatesUsed++;
        } else {
            abilitiesUsed++;
        }
    }

    /** Free-throw attempt (each make is worth the free-throw value). */
    public void addFreeThrow(boolean made, int pts) {
        freeThrowsTaken++;
        if (made) {
            freeThrowsMade++;
            points += pts;
        }
    }

    public void addFoul() { fouls++; }

    public void addDunk() { dunks++; }

    public void addLayup() { layups++; }

    public int getFouls() { return fouls; }

    public int getFreeThrowsMade() { return freeThrowsMade; }

    public int getFreeThrowsTaken() { return freeThrowsTaken; }

    public int getDunks() { return dunks; }

    public int getLayups() { return layups; }

    public int getPoints() { return points; }

    public int getShotsMade() { return shotsMade; }

    public int getShotsTaken() { return shotsTaken; }

    public int getOutsideMade() { return outsideMade; }

    public int getRebounds() { return rebounds; }

    public int getAssists() { return assists; }

    public int getSteals() { return steals; }

    public int getBlocks() { return blocks; }

    public int getTurnovers() { return turnovers; }

    public int getAbilitiesUsed() { return abilitiesUsed; }

    public int getUltimatesUsed() { return ultimatesUsed; }
}
