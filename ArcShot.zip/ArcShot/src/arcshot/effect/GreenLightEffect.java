package arcshot.effect;

/**
 * Deadeye Mark: the next shot is a perfect ("green") release. Used up by that shot.
 * OOP pillars: <b>INHERITANCE</b> (extends StatusEffect) and <b>POLYMORPHISM</b> (overrides only the modifiers it changes).
 */
public class GreenLightEffect extends StatusEffect {
    public GreenLightEffect(double duration) {
        super("green_light", duration, false);
    }

    @Override
    public boolean guaranteesGreen() { return true; }

    @Override
    public boolean consumedOnShot() { return true; }
}
