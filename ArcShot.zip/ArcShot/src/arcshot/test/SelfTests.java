package arcshot.test;

import arcshot.ai.AIController;
import arcshot.ai.Difficulty;
import arcshot.control.KeyBindings;
import arcshot.control.KeyboardController;
import arcshot.control.KeyboardState;
import arcshot.core.GameEventBus;
import arcshot.court.Ball;
import arcshot.court.FreeThrowAim;
import arcshot.court.Match;
import arcshot.court.MatchConfig;
import arcshot.court.MatchPhase;
import arcshot.court.PhaseMachine;
import arcshot.court.ShotAttempt;
import arcshot.player.Player;
import arcshot.player.PlayerClass;
import arcshot.player.TeamSide;
import arcshot.rules.Foul;
import arcshot.rules.FoulContext;
import arcshot.rules.FoulOutcome;
import arcshot.rules.OffensiveFoul;
import arcshot.rules.PersonalFoul;
import arcshot.rules.RuleEngine;
import arcshot.rules.RulesConfig;
import arcshot.rules.ShootingFoul;
import arcshot.rules.TechnicalFoul;
import arcshot.rules.UnsportsmanlikeFoul;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Plain {@code main}-based self-tests (no JUnit needed). Run before submitting:
 * <pre>
 *   java -cp out arcshot.test.SelfTests          (or: build.sh test / build.bat test)
 * </pre>
 * 1. A table-driven test of the FIBA 3x3 free-throw rules for every foul type and team-foul count.
 * 2. The free-throw arc aim grading.
 * 3. The match phase state machine.
 * 4. Headless AI-vs-AI matches checking invariants every frame: one ball owner, scores never go down, shot clock
 *    inside 0..12, nobody below the floor, no deep player overlap, no stuck phases, no illegal transitions.
 * Exit code 0 = all passed, 1 = at least one failure.
 */
public final class SelfTests {
    private int passed;
    private final List<String> failures = new ArrayList<>();

    public static void main(String[] args) {
        int games = args.length > 0 ? Integer.parseInt(args[0]) : 4;
        SelfTests t = new SelfTests();
        t.ruleTable();
        t.freeThrowAim();
        t.phaseMachine();
        t.simulate(games);
        System.out.println();
        System.out.println("PASSED " + t.passed + "   FAILED " + t.failures.size());
        for (String f : t.failures) {
            System.out.println("  FAIL: " + f);
        }
        System.exit(t.failures.isEmpty() ? 0 : 1);
    }

    private void check(boolean ok, String what) {
        if (ok) {
            passed++;
        } else {
            failures.add(what);
        }
    }

    // =========================================================================================================
    // 1. rules table
    // =========================================================================================================

    /** One row: foul kind, shot context, team fouls BEFORE this foul, expected FT, expected possession, turnover. */
    private static final class Row {
        final String kind;
        final Boolean made;
        final boolean outside;
        final int before;
        final int ft;
        final boolean possession;
        final boolean turnover;
        final int foulsAfter;

        Row(String kind, Boolean made, boolean outside, int before, int ft, boolean possession, boolean turnover, int foulsAfter) {
            this.kind = kind;
            this.made = made;
            this.outside = outside;
            this.before = before;
            this.ft = ft;
            this.possession = possession;
            this.turnover = turnover;
            this.foulsAfter = foulsAfter;
        }
    }

    private void ruleTable() {
        Match m = newMatch(1);
        Player off = m.getAway().getPlayers().get(0);
        Player vic = m.getHome().getPlayers().get(0);
        boolean techPoss = RulesConfig.technicalPossession();
        boolean unspPoss = RulesConfig.unsportsmanlikePossession();
        Row[] rows = {
            // shooting fouls: 1 inside / 2 outside if missed, and-one if made
            new Row("shooting", false, false, 0, 1, false, false, 1),
            new Row("shooting", false, true, 0, 2, false, false, 1),
            new Row("shooting", true, false, 0, 1, false, false, 1),
            new Row("shooting", true, true, 3, 1, false, false, 4),
            // bonus: team fouls 7-9 -> always 2 FT (made basket still counts)
            new Row("shooting", false, false, 6, 2, false, false, 7),
            new Row("shooting", true, false, 7, 2, false, false, 8),
            // 10+: 2 FT and possession
            new Row("shooting", false, true, 9, 2, true, false, 10),
            new Row("shooting", true, false, 12, 2, true, false, 13),
            // non-shooting personal fouls: 1-6 no FT, check ball
            new Row("personal", null, false, 0, 0, false, false, 1),
            new Row("personal", null, false, 5, 0, false, false, 6),
            new Row("personal", null, false, 6, 2, false, false, 7),
            new Row("personal", null, false, 8, 2, false, false, 9),
            new Row("personal", null, false, 9, 2, true, false, 10),
            // offensive: turnover, team foul, never free throws
            new Row("offensive", null, false, 0, 0, false, true, 1),
            new Row("offensive", null, false, 9, 0, false, true, 10),
            // technical: 1 FT (+ possession per config)
            new Row("technical", null, false, 0, 1, techPoss, false, RulesConfig.technicalTeamFouls()),
            // unsportsmanlike: 2 FT + possession, counts as 2 team fouls
            new Row("unsportsmanlike", null, false, 0, 2, unspPoss, false, 2),
            new Row("unsportsmanlike", null, false, 8, 2, true, false, 10),
        };
        for (Row r : rows) {
            RuleEngine engine = new RuleEngine();
            engine.setTeamFouls(off.getSide(), r.before);
            Foul f = make(r.kind, off, vic);
            FoulContext ctx = r.made == null ? FoulContext.nonShooting() : new FoulContext(r.made, r.outside);
            FoulOutcome o = engine.assess(f, ctx);
            String label = r.kind + (r.made == null ? "" : (r.made ? " made" : " missed") + (r.outside ? " outside" : " inside"))
                    + " at team foul " + (r.before + f.teamFoulsAdded());
            check(o.getFreeThrows() == r.ft, label + ": expected " + r.ft + " FT, got " + o.getFreeThrows());
            boolean poss = o.getPossessionAfter() == vic.getSide();
            check(poss == r.possession, label + ": possession expected " + r.possession + ", got " + poss);
            check(o.isTurnover() == r.turnover, label + ": turnover expected " + r.turnover);
            check(engine.getTeamFouls(off.getSide()) == r.foulsAfter,
                    label + ": team fouls expected " + r.foulsAfter + ", got " + engine.getTeamFouls(off.getSide()));
            if (r.ft > 0) {
                check(o.getShooter() == vic, label + ": the fouled player shoots");
            } else {
                check(o.getCheckBallTo() == vic.getSide(), label + ": check ball goes to the fouled team");
            }
        }
        RuleEngine e = new RuleEngine();
        e.setTeamFouls(TeamSide.AWAY, 5);
        check(!e.isInPenalty(TeamSide.AWAY), "5 team fouls is not yet the BONUS");
        e.setTeamFouls(TeamSide.AWAY, 6);
        check(e.isInPenalty(TeamSide.AWAY), "6 team fouls: the next foul is a bonus foul");
        System.out.println("rules table: " + rows.length + " rows checked");
    }

    private static Foul make(String kind, Player off, Player vic) {
        switch (kind) {
            case "shooting": return new ShootingFoul(off, vic);
            case "offensive": return new OffensiveFoul(off, vic); // off = the ball handler who charged
            case "technical": return new TechnicalFoul(off, vic);
            case "unsportsmanlike": return new UnsportsmanlikeFoul(off, vic);
            default: return new PersonalFoul(off, vic, "PERSONAL FOUL");
        }
    }

    // =========================================================================================================
    // 2. free-throw aim
    // =========================================================================================================

    private void freeThrowAim() {
        FreeThrowAim a = new FreeThrowAim();
        a.reset(0.8);
        a.update(0, 1.0, 1.0); // power 1, sway sin(0) = 0
        check(a.grade(1.0) == ShotAttempt.Timing.GREEN, "FT aim: tip on the rim, centred = GREEN");
        a.update(0, 0.5, 1.0);
        check(a.grade(1.0) == ShotAttempt.Timing.EARLY, "FT aim: half power = EARLY (short)");
        a.update(0, 1.4, 1.0);
        check(a.grade(1.0) == ShotAttempt.Timing.LATE, "FT aim: 140% power = LATE (long)");
        check(a.bonus(1.0) < 0, "FT aim: a bad release lowers the make chance");
        a.reset(0.8);
        a.update(0.45, 1.0, 1.0); // sway has moved off centre
        check(Math.abs(a.getSway()) > 0.2, "FT aim: the tip sways on its own");
        check(a.error(1.0) > a.error(0.35), "FT aim: AI shooters are graded mostly on power");
        System.out.println("free-throw aim checked");
    }

    // =========================================================================================================
    // 3. phase machine
    // =========================================================================================================

    private void phaseMachine() {
        check(PhaseMachine.isAllowed(MatchPhase.LIVE, MatchPhase.SHOT_IN_AIR), "LIVE -> SHOT_IN_AIR allowed");
        check(PhaseMachine.isAllowed(MatchPhase.FOUL_CALLED, MatchPhase.FREE_THROW), "FOUL_CALLED -> FREE_THROW allowed");
        check(!PhaseMachine.isAllowed(MatchPhase.GAME_OVER, MatchPhase.LIVE), "GAME_OVER -> LIVE refused");
        check(!PhaseMachine.isAllowed(MatchPhase.FREE_THROW, MatchPhase.FOUL_CALLED), "FREE_THROW -> FOUL_CALLED refused (no fouls during FTs)");
        check(!PhaseMachine.isAllowed(MatchPhase.OVERTIME_BREAK, MatchPhase.LIVE), "OVERTIME_BREAK -> LIVE refused (check ball first)");
        System.out.println("phase machine checked");
    }

    // =========================================================================================================
    // 4. headless matches
    // =========================================================================================================

    private static Match newMatch(long seed) {
        MatchConfig cfg = new MatchConfig();
        cfg.setDifficulty(Difficulty.NORMAL);
        cfg.setSeed(seed);
        cfg.setMainClass(PlayerClass.values()[(int) (seed % 3)]);
        return new Match(cfg, new GameEventBus(), new KeyboardController(new KeyboardState(), new KeyBindings()));
    }

    private void simulate(int games) {
        for (int gi = 0; gi < games; gi++) {
            Match m = newMatch(100 + gi);
            Map<Player, AIController> ais = new HashMap<>();
            for (Player p : m.getHome().getPlayers()) {
                ais.put(p, new AIController(p.getPlayerClass(), Difficulty.NORMAL));
            }
            int lastHome = 0;
            int lastAway = 0;
            int frames = 0;
            int ballErrors = 0;
            int scoreDrops = 0;
            int clockErrors = 0;
            int belowFloor = 0;
            int deepOverlaps = 0;
            String firstBallError = null;
            double samePhase = 0;
            double worstStuck = 0;
            MatchPhase lastPhase = null;
            double clockMax = m.shotClockLength();
            while (!m.isFinished() && frames < 60 * 60 * 20) {
                for (Player p : m.getHome().getPlayers()) {
                    if (p.isHumanControlled()) {
                        p.setController(ais.get(p));
                    }
                }
                m.update(1 / 60.0);
                frames++;
                Ball b = m.getBall();
                String err = b.validate();
                if (err != null) {
                    ballErrors++;
                    if (firstBallError == null) {
                        firstBallError = err;
                    }
                }
                int h = m.getHome().getScore();
                int a = m.getAway().getScore();
                if (h < lastHome || a < lastAway) {
                    scoreDrops++;
                }
                lastHome = h;
                lastAway = a;
                if (m.getShotClock() < 0 || m.getShotClock() > clockMax + 1e-6) {
                    clockErrors++;
                }
                List<Player> ps = m.getPlayers();
                for (int i = 0; i < ps.size(); i++) {
                    Player p = ps.get(i);
                    if (p.getZ() < -0.01) {
                        belowFloor++;
                    }
                    for (int j = i + 1; j < ps.size(); j++) {
                        Player q = ps.get(j);
                        if (p.getActions().isIntangible() || q.getActions().isIntangible()) {
                            continue;
                        }
                        if (p.distanceTo(q) < Player.RADIUS * 0.6) {
                            deepOverlaps++;
                        }
                    }
                }
                if (b.getZ() < -0.01) {
                    belowFloor++;
                }
                if (m.getPhase() == lastPhase) {
                    samePhase += 1 / 60.0;
                } else {
                    samePhase = 0;
                    lastPhase = m.getPhase();
                }
                if (m.getPhase() != MatchPhase.LIVE && m.getPhase() != MatchPhase.SHOT_IN_AIR) {
                    worstStuck = Math.max(worstStuck, samePhase);
                }
            }
            String g = "game " + (gi + 1) + " (" + m.getHome().getScore() + "-" + m.getAway().getScore() + ")";
            System.out.printf("%s  %.0f s  frames %d  deep overlaps %d%n", g, frames / 60.0, frames, deepOverlaps);
            check(m.isFinished(), g + ": the match finishes");
            check(ballErrors == 0, g + ": ball has exactly one owner state every frame (" + ballErrors + " errors, first: " + firstBallError + ")");
            check(scoreDrops == 0, g + ": scores never decrease");
            check(clockErrors == 0, g + ": shot clock stays inside 0.." + (int) clockMax);
            check(belowFloor == 0, g + ": nothing goes below the floor (z >= 0)");
            check(deepOverlaps <= frames / 200, g + ": players do not stand inside each other (" + deepOverlaps + " deep overlaps)");
            check(m.getAnomalies() == 0, g + ": no illegal phase changes or self-heals (" + m.getAnomalies() + ")");
            check(worstStuck < 8, g + String.format(": no dead-ball phase lasts too long (worst %.1f s)", worstStuck));
        }
    }
}
