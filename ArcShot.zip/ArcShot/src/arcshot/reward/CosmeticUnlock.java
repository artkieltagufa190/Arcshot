package arcshot.reward;

import arcshot.cosmetic.Cosmetic;
import arcshot.cosmetic.CosmeticRegistry;
import arcshot.save.Profile;
import arcshot.ui.ThemeSkin;
import java.util.Arrays;
import java.util.List;

/**
 * Unlocks one or more cosmetics (a "pack"). The special id {@link #ALL} unlocks every cosmetic.
 * OOP pillar: <b>POLYMORPHISM</b> - implements Reward; the manager just calls grant().
 */
public final class CosmeticUnlock implements Reward {
    public static final String ALL = "*";

    private final String packName;
    private final List<String> ids;

    public CosmeticUnlock(String packName, String... ids) {
        this.packName = packName;
        this.ids = Arrays.asList(ids);
    }

    @Override
    public void grant(Profile profile) {
        List<String> list = ids.contains(ALL) ? CosmeticRegistry.allIds() : ids;
        for (String id : list) {
            profile.unlock(Profile.COSMETIC + id);
        }
    }

    @Override
    public String describe(ThemeSkin skin) {
        if (packName != null) {
            return "Cosmetics: " + packName;
        }
        Cosmetic c = CosmeticRegistry.get(ids.get(0));
        return "Cosmetic: " + (c == null ? ids.get(0) : c.getName());
    }

    @Override
    public boolean provides(String unlockKey) {
        if (!unlockKey.startsWith(Profile.COSMETIC)) {
            return false;
        }
        return ids.contains(ALL) || ids.contains(unlockKey.substring(Profile.COSMETIC.length()));
    }
}
