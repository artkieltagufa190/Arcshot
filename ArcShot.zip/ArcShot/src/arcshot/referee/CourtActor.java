package arcshot.referee;

import arcshot.anim.AnimationTable;
import arcshot.court.CourtBody;

/**
 * Base class for non-player people on the court (referees). Holds position, facing and the current animation.
 * OOP pillars: <b>ABSTRACTION</b> (abstract {@link #getCharacterKey()}), <b>INHERITANCE</b> (Referee extends it),
 * <b>ENCAPSULATION</b> (position only changes through {@link #moveToward}).
 */
public abstract class CourtActor implements CourtBody {
    private double x;
    private double y;
    private double vx;
    private double vy;
    private double facingX;
    private double facingY = 1;
    private String animation = "idle";
    private double animTime;

    protected CourtActor(double x, double y) {
        this.x = x;
        this.y = y;
    }

    /** Sprite folder, e.g. "ref". */
    public abstract String getCharacterKey();

    /** Moves toward a point at up to {@code speed} px/s; switches between run and idle. */
    public void moveToward(double tx, double ty, double speed, double dt) {
        double dx = tx - x;
        double dy = ty - y;
        double d = Math.hypot(dx, dy);
        if (d < 3) {
            vx = 0;
            vy = 0;
        } else {
            double s = Math.min(speed, d / dt);
            vx = dx / d * s;
            vy = dy / d * s;
            x += vx * dt;
            y += vy * dt;
            facingX = dx / d;
            facingY = dy / d;
        }
    }

    public void tickAnimation(double dt, boolean locomotion) {
        animTime += dt;
        if (locomotion) {
            String want = Math.hypot(vx, vy) > 20 ? "run" : "idle";
            if (!want.equals(animation)) {
                play(want);
            }
        }
    }

    public void play(String anim) {
        animation = anim;
        animTime = 0;
    }

    public void face(double dx, double dy) {
        double d = Math.hypot(dx, dy);
        if (d > 0.01) {
            facingX = dx / d;
            facingY = dy / d;
        }
    }

    public int getFrame() { return AnimationTable.get(getCharacterKey(), animation).frameAt(animTime); }

    public String getAnimation() { return animation; }

    @Override
    public double getX() { return x; }

    @Override
    public double getY() { return y; }

    @Override
    public double getZ() { return 0; }

    public double getFacingX() { return facingX; }

    public double getFacingY() { return facingY; }

    public double getSpeed() { return Math.hypot(vx, vy); }
}
