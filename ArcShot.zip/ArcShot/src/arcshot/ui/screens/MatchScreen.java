package arcshot.ui.screens;

import arcshot.app.AppContext;
import arcshot.control.InputAction;
import arcshot.control.KeyboardController;
import arcshot.control.KeyboardState;
import arcshot.core.Balance;
import arcshot.core.GameLoop;
import arcshot.cosmetic.Cosmetic;
import arcshot.cosmetic.CosmeticRegistry;
import arcshot.cosmetic.CosmeticType;
import arcshot.court.Match;
import arcshot.court.MatchConfig;
import arcshot.player.PlayerClass;
import arcshot.render.MatchRenderer;
import arcshot.render.MatchView;
import arcshot.render.retro.RetroMatchRenderer;
import arcshot.render.RenderContext;
import arcshot.save.Settings;
import arcshot.ui.Screen;
import arcshot.ui.Theme;
import arcshot.ui.UIFactory;
import arcshot.ui.components.GameCanvas;
import arcshot.ui.components.RoundedPanel;
import arcshot.ui.components.ThemedButton;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.util.concurrent.ConcurrentLinkedQueue;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

/**
 * Runs a 3x3 match. The {@link GameLoop} thread updates the {@link Match} at a fixed 60 steps per second and renders
 * into an off-screen buffer; the Swing thread only shows finished frames ({@link GameCanvas}) and handles the pause
 * menu. Commands from the Swing thread (pause, restart, debug keys) are queued and run on the game thread, so game
 * state is only ever touched by one thread.
 * OOP pillars: <b>INHERITANCE</b> (extends Screen) and <b>POLYMORPHISM</b> (the ScreenManager calls its lifecycle hooks).
 */
public class MatchScreen extends Screen implements GameLoop.Steppable {
    private final MatchConfig config;
    private final GameCanvas canvas = new GameCanvas();
    private final KeyboardState keyboard = new KeyboardState();
    private final ConcurrentLinkedQueue<Runnable> commands = new ConcurrentLinkedQueue<>();
    private final PauseOverlay pause = new PauseOverlay();
    private final GameLoop loop = new GameLoop(this, 60);
    private RenderContext renderContext;
    private Match match;
    private MatchView renderer;
    private volatile boolean paused;
    private boolean resultsShown;
    private double practiceTipTimer = 2;
    private int practiceTip;
    private static final String[] PRACTICE_TIPS = {
        "Drive at the rim and press SHOOT: layup, or a dunk if you are fast and open",
        "Outside the paint SHOOT is a jump shot - release in the green",
        "Press 4 for a free-throw drill: hold SHOOT, release when the arrow tip is on the rim",
        "Press 5 for a dunk drill (ball under the rim)",
        "Reaching in from behind (F) is how most fouls happen - steal from the front",
        "Team foul 7 = BONUS: every foul then gives 2 free throws",
        "Space near a shooter = block. Space near a loose ball = rebound jump",
        "F3 shows the debug overlay with actions, frames and hitboxes"
    };

    public MatchScreen(AppContext app, MatchConfig config) {
        super(app);
        this.config = config;
        setBorder(BorderFactory.createEmptyBorder());
        JLayeredPane layers = new JLayeredPane();
        layers.setLayout(new FillLayout());
        layers.add(canvas, JLayeredPane.DEFAULT_LAYER);
        layers.add(pause, JLayeredPane.PALETTE_LAYER);
        pause.setVisible(false);
        add(layers);
        canvas.addKeyListener(keyboard);
        canvas.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                handleMetaKey(e);
            }
        });
        canvas.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {
                keyboard.releaseAll();
            }
        });
    }

    // ---- lifecycle ------------------------------------------------------------------------------------------

    @Override
    public void onEnter() {
        Settings s = app.profile().getSettings();
        Cosmetic court = CosmeticRegistry.getOrDefault(app.profile().getCourt(), CosmeticType.COURT);
        Cosmetic aura = CosmeticRegistry.getOrDefault(app.profile().getAura(), CosmeticType.AURA);
        renderContext = new RenderContext(app.skin(), s.getKeys(), court,
                "aura.default".equals(aura.getId()) ? null : aura.color(0), app.profile().getStyle());
        applySettings();
        createMatch();
        loop.start();
        SwingUtilities.invokeLater(canvas::requestFocusInWindow);
    }

    @Override
    public void onResume() {
        applySettings();
        SwingUtilities.invokeLater(() -> (paused ? pause.focusTarget() : canvas).requestFocusInWindow());
    }

    @Override
    public void onHide() {
        keyboard.releaseAll();
    }

    @Override
    public void onExit() {
        loop.stop();
        if (renderer != null) {
            app.bus().unsubscribe(renderer.getHudListener());
        }
    }

    private void applySettings() {
        Settings s = app.profile().getSettings();
        renderContext.setColorblind(s.isColorblind());
        renderContext.setScreenShake(s.isScreenShake());
        renderContext.setShowFps(s.isShowFps());
        canvas.setCrt(s.isCrt());
        app.applyAudio();
    }

    /** Builds a fresh match + renderer. Runs on the EDT at start, or on the game thread for Restart. */
    private void createMatch() {
        if (renderer != null) {
            app.bus().unsubscribe(renderer.getHudListener());
        }
        // retro (pixel art, default) or smooth (v2) - both are MatchViews, the rest of the screen does not care
        renderer = app.profile().getSettings().isRetro() ? new RetroMatchRenderer(renderContext) : new MatchRenderer(renderContext);
        canvas.setPixelArt(renderer.isPixelArt());
        app.bus().subscribe(renderer.getHudListener());
        Match m = new Match(config, app.bus(), new KeyboardController(keyboard, app.profile().getSettings().getKeys()));
        m.setFx(renderer.getFx());
        match = m;
        resultsShown = false;
    }

    // ---- game thread ----------------------------------------------------------------------------------------

    @Override
    public void step(double dt) {
        Runnable cmd;
        while ((cmd = commands.poll()) != null) {
            cmd.run();
        }
        if (paused) {
            return;
        }
        match.update(dt);
        renderer.update(dt);
        if (config.isPractice()) {
            practiceTipTimer -= dt;
            if (practiceTipTimer <= 0 && match.getHint().isEmpty()) {
                match.showHint(PRACTICE_TIPS[practiceTip++ % PRACTICE_TIPS.length]);
                practiceTipTimer = 9;
            }
        }
        if (match.isFinished() && !resultsShown && match.getFinishedTime() > 2.6) {
            resultsShown = true;
            SwingUtilities.invokeLater(() -> app.showResults(match.getSummary(), config));
        }
    }

    @Override
    public void renderFrame() {
        renderContext.setFps(loop.getFps());
        BufferedImage buffer = canvas.obtainBuffer(renderer.frameWidth(), renderer.frameHeight());
        Graphics2D g = buffer.createGraphics();
        try {
            renderer.render(g, match, buffer.getWidth(), buffer.getHeight());
            if (paused) {
                g.setColor(new Color(5, 8, 16, 150));
                g.fillRect(0, 0, buffer.getWidth(), buffer.getHeight());
            }
        } finally {
            g.dispose();
        }
        canvas.present(buffer);
    }

    // ---- input on the Swing thread --------------------------------------------------------------------------

    private void handleMetaKey(KeyEvent e) {
        int code = e.getKeyCode();
        if (code == app.profile().getSettings().getKeys().keyFor(InputAction.PAUSE)) {
            e.consume(); // stops the pause menu's own Esc binding from resuming right away
            setPaused(true);
        } else if (code == KeyEvent.VK_F3) {
            renderContext.setDebug(!renderContext.isDebug());
        } else if (code == KeyEvent.VK_F1) {
            renderContext.setShowFps(!renderContext.isShowFps());
        } else if (renderContext.isDebug() && code >= KeyEvent.VK_F6 && code <= KeyEvent.VK_F11) {
            // scenario tester (debug only): sets up a situation so a mechanic can be checked by hand
            final String[] names = {"shooting_foul", "dunk", "block", "out_of_bounds", "seventh_foul", "free_throws"};
            final String name = names[code - KeyEvent.VK_F6];
            commands.add(() -> match.showHint("Scenario: " + match.debugScenario(name)));
        } else if (code == KeyEvent.VK_F5) {
            commands.add(() -> {
                Balance.reload();
                match.showHint("Balance reloaded from " + Balance.loadedFrom());
            });
        } else if (config.isPractice()) {
            if (code == KeyEvent.VK_C) {
                commands.add(() -> match.practiceRefill());
            } else if (code == KeyEvent.VK_1) {
                commands.add(() -> match.controlClass(PlayerClass.GUARD));
            } else if (code == KeyEvent.VK_2) {
                commands.add(() -> match.controlClass(PlayerClass.FORWARD));
            } else if (code == KeyEvent.VK_3) {
                commands.add(() -> match.controlClass(PlayerClass.BIG));
            } else if (code == KeyEvent.VK_4) {
                commands.add(() -> match.showHint(match.debugScenario("free_throws")));
            } else if (code == KeyEvent.VK_5) {
                commands.add(() -> match.showHint(match.debugScenario("dunk")));
            }
        }
    }

    private void setPaused(boolean p) {
        if (match != null && match.isFinished()) {
            return;
        }
        paused = p;
        keyboard.releaseAll();
        pause.setVisible(p);
        if (p) {
            SwingUtilities.invokeLater(() -> pause.focusTarget().requestFocusInWindow());
        } else {
            SwingUtilities.invokeLater(canvas::requestFocusInWindow);
        }
    }

    /** Pause menu drawn over the game. */
    private final class PauseOverlay extends JPanel {
        private final ThemedButton resume;

        PauseOverlay() {
            super(new GridBagLayout());
            setOpaque(false);
            RoundedPanel card = UIFactory.card(new GridLayout(0, 1, 0, Theme.S3));
            card.setBorder(BorderFactory.createEmptyBorder(Theme.S6, Theme.S6, Theme.S6, Theme.S6));
            JLabel title = UIFactory.centered("PAUSED", Theme.display(48), Theme.TEXT);
            card.add(title);
            resume = UIFactory.primary("Resume", e -> setPaused(false));
            card.add(resume);
            card.add(UIFactory.secondary("Restart", e -> {
                commands.add(MatchScreen.this::createMatch);
                setPaused(false);
            }));
            card.add(UIFactory.secondary("Settings", e -> app.screens().push(new SettingsScreen(app))));
            card.add(UIFactory.secondary("How to Play", e -> app.screens().push(new HowToPlayScreen(app))));
            card.add(UIFactory.button("Quit to Menu", ThemedButton.Style.DANGER, e -> app.showMainMenu()));
            card.setPreferredSize(new Dimension(320, 400));
            add(card);
            getInputMap(WHEN_IN_FOCUSED_WINDOW).put(javax.swing.KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), "resume");
            getActionMap().put("resume", new javax.swing.AbstractAction() {
                @Override
                public void actionPerformed(java.awt.event.ActionEvent e) {
                    if (isShowing()) {
                        setPaused(false);
                    }
                }
            });
        }

        Component focusTarget() {
            return resume;
        }

        @Override
        protected void paintComponent(Graphics g) {
            g.setColor(new Color(5, 8, 16, 120));
            g.fillRect(0, 0, getWidth(), getHeight());
        }
    }

    /** Every child fills the whole layered pane. */
    private static final class FillLayout implements LayoutManager {
        @Override
        public void addLayoutComponent(String name, Component comp) { }

        @Override
        public void removeLayoutComponent(Component comp) { }

        @Override
        public Dimension preferredLayoutSize(Container parent) {
            return new Dimension(Theme.LOGICAL_W, Theme.LOGICAL_H);
        }

        @Override
        public Dimension minimumLayoutSize(Container parent) {
            return new Dimension(320, 180);
        }

        @Override
        public void layoutContainer(Container parent) {
            for (Component c : parent.getComponents()) {
                c.setBounds(0, 0, parent.getWidth(), parent.getHeight());
            }
        }
    }
}
