package arcshot.ability.big;

import arcshot.ability.AbilitySlot;
import arcshot.ability.ActiveAbility;
import arcshot.court.Match;
import arcshot.court.PickScreen;
import arcshot.player.Player;

/**
 * Big Q (alternate): a stationary pick; teammates near it gain speed.
 * OOP pillars: <b>INHERITANCE</b> (extends ActiveAbility / Ultimate) and <b>POLYMORPHISM</b> (overrides perform() and the optional hooks).
 */
public class BulwarkScreen extends ActiveAbility {
    public BulwarkScreen() {
        super("big.bulwark_screen", AbilitySlot.Q, 10);
    }

    @Override
    protected void perform(Player owner, Match match) {
        match.addEntity(new PickScreen(owner, "bulwark", owner.getX(), owner.getY(), param("radius", 110),
                param("duration", 4), true, param("boost", 1.3)));
        match.fx().ring("bulwark", owner.getX(), owner.getY(), param("radius", 110), 0.5);
    }

    @Override
    public boolean aiShouldUse(Player owner, Match match) {
        Player holder = match.getBall().getHolder();
        return holder != null && holder != owner && holder.getSide() == owner.getSide() && owner.distanceTo(holder) < 180;
    }
}
