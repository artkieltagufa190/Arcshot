package arcshot.action;

import arcshot.core.Balance;
import arcshot.court.Interaction;
import arcshot.court.Match;
import arcshot.player.Player;

/**
 * Layup: two approach steps toward the rim (root motion), takeoff with a z arc, release at the top
 * ({@code ball_release}), land. {@code bank} = off the backboard (chosen from the approach angle).
 * OOP pillars: <b>INHERITANCE</b> + <b>POLYMORPHISM</b>.
 */
public class LayupAction extends Action {
    private final double targetX;
    private final double targetY;
    private final boolean bank;
    private double startX;
    private double startY;

    public LayupAction(double targetX, double targetY, boolean bank) {
        super(ActionType.LAYUP, "layup");
        this.targetX = targetX;
        this.targetY = targetY;
        this.bank = bank;
    }

    public boolean isBank() { return bank; }

    @Override
    protected void onStart(Player p, Match m) {
        startX = p.getX();
        startY = p.getY();
        p.face(targetX - startX, targetY - startY);
    }

    @Override
    protected void onUpdate(double dt, Player p, Match m) {
        double tRelease = def().timeOf("ball_release");
        double u = Math.min(1, getTime() / tRelease);
        double ease = 1 - (1 - u) * (1 - u);
        p.setPosition(startX + (targetX - startX) * ease, startY + (targetY - startY) * ease);
    }

    @Override
    protected void onEvent(String event, Player p, Match m) {
        if ("takeoff".equals(event)) {
            m.queue(Interaction.Kind.FOUL_CHECK, p, "layup");
        } else if ("ball_release".equals(event)) {
            m.queue(Interaction.Kind.SHOT_RELEASE, p, this);
        }
    }

    @Override
    public double getZ() {
        return arc(getTime(), def().timeOf("takeoff"), def().timeOf("foot_land"), Balance.d("anim.layupHeight", 40));
    }
}
