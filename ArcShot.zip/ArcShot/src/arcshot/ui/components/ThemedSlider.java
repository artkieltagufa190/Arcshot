package arcshot.ui.components;

import arcshot.ui.Theme;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.function.IntConsumer;
import javax.swing.JComponent;

/**
 * A custom-painted 0..100 slider (volume).
 * OOP pillars: <b>INHERITANCE</b> from {@link JComponent}, <b>ENCAPSULATION</b> (value is clamped in {@link #setValue}).
 */
public class ThemedSlider extends JComponent {
    private int value;
    private IntConsumer onChange;

    public ThemedSlider(int initial) {
        setValue(initial);
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        MouseAdapter mouse = new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                drag(e.getX());
            }

            @Override
            public void mouseDragged(MouseEvent e) {
                drag(e.getX());
            }
        };
        addMouseListener(mouse);
        addMouseMotionListener(mouse);
    }

    private void drag(int x) {
        int pad = 12;
        setValue(Math.round(100f * (x - pad) / Math.max(1, getWidth() - pad * 2)));
        if (onChange != null) {
            onChange.accept(value);
        }
    }

    public void setOnChange(IntConsumer onChange) {
        this.onChange = onChange;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int v) {
        value = Math.max(0, Math.min(100, v));
        repaint();
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(280, 36);
    }

    @Override
    protected void paintComponent(Graphics g0) {
        Graphics2D g = (Graphics2D) g0.create();
        Theme.quality(g);
        int pad = 12;
        int w = getWidth() - pad * 2;
        int cy = getHeight() / 2;
        g.setColor(Theme.BG_2);
        g.fillRoundRect(pad, cy - 4, w, 8, 8, 8);
        int fillW = w * value / 100;
        g.setColor(Theme.ACCENT);
        g.fillRoundRect(pad, cy - 4, fillW, 8, 8, 8);
        g.setColor(Theme.TEXT);
        g.fillOval(pad + fillW - 9, cy - 9, 18, 18);
        g.dispose();
    }
}
