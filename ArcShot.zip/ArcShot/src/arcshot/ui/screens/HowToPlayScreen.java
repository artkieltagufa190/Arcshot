package arcshot.ui.screens;

import arcshot.ability.AbilityInfo;
import arcshot.ability.AbilityRegistry;
import arcshot.app.AppContext;
import arcshot.control.InputAction;
import arcshot.control.KeyBindings;
import arcshot.core.Balance;
import arcshot.perk.Perk;
import arcshot.perk.PerkRegistry;
import arcshot.player.PlayerClass;
import arcshot.ui.Screen;
import arcshot.ui.Theme;
import arcshot.ui.UIFactory;
import arcshot.ui.components.RoundedPanel;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 * Controls, rules, classes and every ability (names from the current skin).
 * OOP pillars: <b>INHERITANCE</b> (extends Screen) and <b>POLYMORPHISM</b> (the ScreenManager calls its lifecycle hooks).
 */
public class HowToPlayScreen extends Screen {
    public HowToPlayScreen(AppContext app) {
        super(app);
        add(UIFactory.header("How to play", "3x3 half court + Classic Shootout", e -> app.back()), BorderLayout.NORTH);
        JPanel content = UIFactory.column();
        JPanel top = UIFactory.clear(new GridLayout(1, 2, Theme.S5, 0));
        top.add(controls(app.profile().getSettings().getKeys()));
        top.add(rules());
        top.setAlignmentX(LEFT_ALIGNMENT);
        content.add(top);
        content.add(UIFactory.vgap(Theme.S5));
        JPanel classes = UIFactory.clear(new GridLayout(1, 3, Theme.S5, 0));
        for (PlayerClass pc : PlayerClass.values()) {
            classes.add(classCard(pc));
        }
        classes.setAlignmentX(LEFT_ALIGNMENT);
        content.add(classes);
        content.add(UIFactory.vgap(Theme.S5));
        StringBuilder perks = new StringBuilder();
        for (Perk p : PerkRegistry.all()) {
            perks.append(p.getName()).append(" - ").append(p.getDescription()).append('\n');
        }
        content.add(card("Perks (2 slots, slot 2 opens at All-Star)", perks.toString().trim()));
        content.add(UIFactory.vgap(Theme.S5));
        content.add(card("Classic Shootout (Messenger mode)",
                "Drag the ball back and release to shoot. A swish is 3 points, off the rim is 2. "
                        + "The hoop starts moving at 6 points and a defender appears at 14. Esc returns to the menu."));
        add(UIFactory.scroll(content), BorderLayout.CENTER);
    }

    private JComponent controls(KeyBindings k) {
        StringBuilder sb = new StringBuilder();
        for (InputAction a : InputAction.values()) {
            sb.append(k.keyName(a)).append("  -  ").append(a.getLabel()).append('\n');
        }
        sb.append("\nOn defense: Space = jump to block, F = steal.\nWith a teammate holding the ball, F calls for a pass.\n"
                + "Practice: C refills cooldowns, 1/2/3 picks a class, 4 free-throw drill, 5 dunk drill. F3 debug overlay, F5 reload balance.\n"
                + "With F3 on: F6 shooting foul, F7 dunk, F8 block, F9 out of bounds, F10 7th team foul, F11 free throws.");
        return card("Controls (rebind in Settings)", sb.toString());
    }

    private JComponent rules() {
        String text = "- " + Balance.i("rules.insidePoints", 1) + " point inside the arc, " + Balance.i("rules.outsidePoints", 2)
                + " points outside, free throws 1 point.\n- First to " + Balance.i("rules.targetScore", 21)
                + ", or most points when the clock runs out (game length in Settings).\n"
                + "- Tie at the buzzer: overtime, first team to score " + Balance.i("rules.overtimePoints", 2) + " points wins.\n"
                + "- After a made basket or last free throw: the defense takes it under the hoop and must clear it behind the arc.\n"
                + "- After a steal or defensive rebound: clear the ball behind the arc before shooting.\n"
                + "- " + (int) Balance.d("rules.shotClock", 12) + "-second shot clock (resets when the ball hits the rim).\n"
                + "- SHOOT is context-sensitive: jump shot outside the paint, layup or dunk when driving at the rim.\n"
                + "- Jump shots: hold, release when the meter beside you is in the GREEN zone.\n"
                + "- Fouls (FIBA 3x3): fouled shooting inside = 1 FT, outside = 2 FT, made shot = basket + 1 FT.\n"
                + "  Team fouls 7-9 = 2 FT, 10+ = 2 FT and the ball. Offensive fouls = turnover, no FT.\n"
                + "- Free throws: hold SHOOT - an arrow grows toward the hoop and swings side to side.\n"
                + "  Release when its tip sits on the rim (green). No abilities during free throws.\n"
                + "- Ultimate meter fills from scoring, steals, blocks, assists, rebounds and slowly over time.";
        return card("Rules", text);
    }

    private JComponent classCard(PlayerClass pc) {
        StringBuilder sb = new StringBuilder();
        for (AbilityInfo info : AbilityRegistry.all()) {
            if (info.getPlayerClass() == pc) {
                sb.append(info.getSlot()).append(info.isDefault() ? "  " : "* ").append(app.skin().abilityName(info.getId()))
                        .append(" - ").append(app.skin().abilityDescription(info.getId())).append('\n');
            }
        }
        sb.append("\n* = alternate, unlocked through achievements");
        return card(pc.getDisplayName() + " - " + pc.getRole(), sb.toString());
    }

    private JComponent card(String title, String text) {
        RoundedPanel card = UIFactory.card(new BorderLayout(0, Theme.S2));
        JLabel h = UIFactory.heading(title);
        card.add(h, BorderLayout.NORTH);
        JTextArea body = UIFactory.paragraph(text);
        body.setFont(Theme.body(14));
        card.add(body, BorderLayout.CENTER);
        card.setAlignmentX(LEFT_ALIGNMENT);
        return card;
    }
}
