package arcshot.render.retro;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.HashMap;
import java.util.Map;

/**
 * A chunky 5x7 bitmap font drawn with rectangles (no font files, no anti-aliasing) for the retro HUD.
 * Each glyph is 7 rows of 5 bits. Lower-case letters are drawn as upper case.
 * OOP pillar: <b>ENCAPSULATION</b> - the glyph table is private; use {@link #draw} and {@link #width}.
 */
public final class PixelFont {
    private static final Map<Character, int[]> GLYPHS = new HashMap<>();

    static {
        g('A', 14, 17, 17, 31, 17, 17, 17); g('B', 30, 17, 17, 30, 17, 17, 30); g('C', 14, 17, 16, 16, 16, 17, 14);
        g('D', 30, 17, 17, 17, 17, 17, 30); g('E', 31, 16, 16, 30, 16, 16, 31); g('F', 31, 16, 16, 30, 16, 16, 16);
        g('G', 14, 17, 16, 23, 17, 17, 15); g('H', 17, 17, 17, 31, 17, 17, 17); g('I', 14, 4, 4, 4, 4, 4, 14);
        g('J', 7, 2, 2, 2, 2, 18, 12); g('K', 17, 18, 20, 24, 20, 18, 17); g('L', 16, 16, 16, 16, 16, 16, 31);
        g('M', 17, 27, 21, 21, 17, 17, 17); g('N', 17, 25, 21, 19, 17, 17, 17); g('O', 14, 17, 17, 17, 17, 17, 14);
        g('P', 30, 17, 17, 30, 16, 16, 16); g('Q', 14, 17, 17, 17, 21, 18, 13); g('R', 30, 17, 17, 30, 20, 18, 17);
        g('S', 15, 16, 16, 14, 1, 1, 30); g('T', 31, 4, 4, 4, 4, 4, 4); g('U', 17, 17, 17, 17, 17, 17, 14);
        g('V', 17, 17, 17, 17, 17, 10, 4); g('W', 17, 17, 17, 21, 21, 21, 10); g('X', 17, 17, 10, 4, 10, 17, 17);
        g('Y', 17, 17, 10, 4, 4, 4, 4); g('Z', 31, 1, 2, 4, 8, 16, 31);
        g('0', 14, 17, 19, 21, 25, 17, 14); g('1', 4, 12, 4, 4, 4, 4, 14); g('2', 14, 17, 1, 2, 4, 8, 31);
        g('3', 31, 2, 4, 2, 1, 17, 14); g('4', 2, 6, 10, 18, 31, 2, 2); g('5', 31, 16, 30, 1, 1, 17, 14);
        g('6', 6, 8, 16, 30, 17, 17, 14); g('7', 31, 1, 2, 4, 8, 8, 8); g('8', 14, 17, 17, 14, 17, 17, 14);
        g('9', 14, 17, 17, 15, 1, 2, 12);
        g(' ', 0, 0, 0, 0, 0, 0, 0); g('.', 0, 0, 0, 0, 0, 12, 12); g(',', 0, 0, 0, 0, 12, 4, 8);
        g(':', 0, 12, 12, 0, 12, 12, 0); g('!', 4, 4, 4, 4, 4, 0, 4); g('?', 14, 17, 1, 2, 4, 0, 4);
        g('-', 0, 0, 0, 31, 0, 0, 0); g('+', 0, 4, 4, 31, 4, 4, 0); g('/', 1, 1, 2, 4, 8, 16, 16);
        g('\'', 4, 4, 8, 0, 0, 0, 0); g('"', 10, 10, 0, 0, 0, 0, 0); g('%', 24, 25, 2, 4, 8, 19, 3);
        g('(', 2, 4, 8, 8, 8, 4, 2); g(')', 8, 4, 2, 2, 2, 4, 8); g('#', 10, 31, 10, 10, 31, 10, 0);
        g('|', 4, 4, 4, 4, 4, 4, 4); g('<', 2, 4, 8, 16, 8, 4, 2); g('>', 8, 4, 2, 1, 2, 4, 8);
        g('=', 0, 0, 31, 0, 31, 0, 0); g('_', 0, 0, 0, 0, 0, 0, 31); g('*', 0, 21, 14, 31, 14, 21, 0);
    }

    private PixelFont() { }

    private static void g(char c, int... rows) {
        GLYPHS.put(c, rows);
    }

    /** Width in pixels of {@code text} at {@code scale}. */
    public static int width(String text, int scale) {
        return text.isEmpty() ? 0 : (text.length() * 6 - 1) * scale;
    }

    public static int height(int scale) {
        return 7 * scale;
    }

    /** Draws text with its top-left corner at (x, y). */
    public static void draw(Graphics2D g, String text, int x, int y, Color color, int scale) {
        g.setColor(color);
        int cx = x;
        for (char ch : text.toUpperCase().toCharArray()) {
            int[] rows = GLYPHS.get(ch);
            if (rows == null) {
                rows = GLYPHS.get('?');
            }
            for (int r = 0; r < 7; r++) {
                int bits = rows[r];
                for (int c = 0; c < 5; c++) {
                    if ((bits & (16 >> c)) != 0) {
                        g.fillRect(cx + c * scale, y + r * scale, scale, scale);
                    }
                }
            }
            cx += 6 * scale;
        }
    }

    /** Text with a 1-step dark outline (readable on any background). */
    public static void drawOutlined(Graphics2D g, String text, int x, int y, Color color, Color outline, int scale) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                if (dx != 0 || dy != 0) {
                    draw(g, text, x + dx * scale, y + dy * scale, outline, scale);
                }
            }
        }
        draw(g, text, x, y, color, scale);
    }

    /** Centered outlined text. */
    public static void drawCentered(Graphics2D g, String text, int cx, int y, Color color, Color outline, int scale) {
        drawOutlined(g, text, cx - width(text, scale) / 2, y, color, outline, scale);
    }

    /** A 3x5 micro font for jersey numbers (digits only). */
    public static void drawTinyNumber(Graphics2D g, String digits, int cx, int y, Color color) {
        int[][] d = {
            {7, 5, 5, 5, 7}, {2, 6, 2, 2, 7}, {7, 1, 7, 4, 7}, {7, 1, 3, 1, 7}, {5, 5, 7, 1, 1},
            {7, 4, 7, 1, 7}, {7, 4, 7, 5, 7}, {7, 1, 1, 2, 2}, {7, 5, 7, 5, 7}, {7, 5, 7, 1, 7}
        };
        int w = digits.length() * 4 - 1;
        int x = cx - w / 2;
        g.setColor(color);
        for (char ch : digits.toCharArray()) {
            if (ch < '0' || ch > '9') {
                continue;
            }
            int[] rows = d[ch - '0'];
            for (int r = 0; r < 5; r++) {
                for (int c = 0; c < 3; c++) {
                    if ((rows[r] & (4 >> c)) != 0) {
                        g.fillRect(x + c, y + r, 1, 1);
                    }
                }
            }
            x += 4;
        }
    }
}
