import arcshot.anim.AnimationDef;
import arcshot.anim.AnimationTable;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.imageio.ImageIO;

/**
 * ArcShot sprite sheet generator (offline tool, not part of the game).
 * <p>
 * Draws retro pixel-art players and referees with a small 3D "puppet rig": every frame is a set of joint angles
 * (arms, legs, lean, crouch). The rig is projected to three facings (BACK = toward the hoop, FRONT = toward the
 * camera, SIDE = facing right; the game mirrors SIDE for left), shaded with 3 hard tones and outlined with 1 px.
 * Team-dependent parts are painted in MASK colors (magenta jersey, green shorts, cyan shoes, orange skin,
 * brown hair, yellow trim). The game recolors them at load time, so one sheet serves every team and skin tone.
 * <p>
 * Run (from the ArcShot folder):
 * <pre>
 *   javac -sourcepath src -d out-tools tools/SpriteSheetGenerator.java
 *   java -cp out-tools SpriteSheetGenerator resources/sprites
 * </pre>
 * Output per character: {@code sheet_a.png}, {@code sheet_b.png} (two hair styles), {@code manifest.properties},
 * plus {@code docs/sprite_preview.png}-style previews in {@code resources/sprites/preview_*.png}.
 * <p>
 * ======================= ART TWEAK SECTION =======================
 * Change the constants right below (frame size, body proportions, mask palette). Poses live in {@link #pose}.
 */
public class SpriteSheetGenerator {

    // ---- frame layout (pixels) ------------------------------------------------------------------------------
    static final int FW = 48;          // frame width
    static final int FH = 64;          // frame height
    static final int OX = 24;          // feet origin x inside the frame
    static final int OY = 61;          // feet origin y inside the frame
    static final double FORESHORTEN = 0.35; // how much "forward" (toward/away from camera) shifts pixels up/down

    // ---- body types: thigh, shin, torso, headR, shoulderW, hipW, upperArm, foreArm, limbR, torsoW, torsoDepth --
    static final Body GUARD = new Body("guard", 7.5, 7.5, 11, 3.6, 4.4, 2.4, 6.0, 5.5, 1.45, 8.5, 5.0);
    static final Body FORWARD = new Body("forward", 8.5, 8.5, 12, 3.8, 5.0, 2.8, 6.5, 6.0, 1.65, 10.0, 6.0);
    static final Body BIG = new Body("big", 9.0, 9.0, 13.5, 4.0, 6.2, 3.4, 7.0, 6.5, 2.05, 13.0, 7.5);
    static final Body REF = new Body("ref", 8.5, 8.5, 11.5, 3.7, 4.6, 2.6, 6.2, 5.8, 1.5, 9.0, 5.5);

    // ---- MASK palette (the game recolors these; keep them exactly in sync with SpriteLoader) ----------------
    static final int OUTLINE = 0xFF141018;
    static final int EYE = 0xFF1A1A1A;
    static final int[] JERSEY = {0xFFFF66FF, 0xFFFF00FF, 0xFFB000B0};   // light, base, dark
    static final int[] SHORTS = {0xFF66FF66, 0xFF00FF00, 0xFF00B000};
    static final int[] SHOE = {0xFF99FFFF, 0xFF00FFFF, 0xFF00B0B0};
    static final int[] SKIN = {0xFFFFB060, 0xFFFF8000, 0xFFB05000};
    static final int[] HAIR = {0xFFA06020, 0xFF804000, 0xFF502000};
    static final int[] TRIM = {0xFFFFFF80, 0xFFFFFF00, 0xFFB0B000};
    // referee colors are fixed (not recolored, except skin)
    static final int[] REF_SHIRT_W = {0xFFFFFFFF, 0xFFE8E8E8, 0xFFB8B8B8};
    static final int[] REF_SHIRT_B = {0xFF3A3A3A, 0xFF202020, 0xFF101010};
    static final int[] REF_PANTS = {0xFF3A3A44, 0xFF26262E, 0xFF16161C};
    static final int[] REF_SHOE = {0xFF404040, 0xFF202020, 0xFF101010};

    // =====================================================================================================

    /** Body proportions of one character class. */
    static final class Body {
        final String key;
        final double thigh, shin, torso, headR, shoulderW, hipW, upperArm, foreArm, limbR, torsoW, torsoD;

        Body(String key, double thigh, double shin, double torso, double headR, double shoulderW, double hipW,
             double upperArm, double foreArm, double limbR, double torsoW, double torsoD) {
            this.key = key;
            this.thigh = thigh;
            this.shin = shin;
            this.torso = torso;
            this.headR = headR;
            this.shoulderW = shoulderW;
            this.hipW = hipW;
            this.upperArm = upperArm;
            this.foreArm = foreArm;
            this.limbR = limbR;
            this.torsoW = torsoW;
            this.torsoD = torsoD;
        }
    }

    /** Joint angles for one frame. Index 0 = right side, 1 = left side. Angles in degrees. */
    static final class Pose {
        double crouch;
        double lean = 6;
        double[] armA = {12, 12};   // shoulder pitch: 0 down, 90 forward, 180 up, 240 behind head
        double[] armR = {12, 12};   // shoulder roll (outward)
        double[] armE = {12, 12};   // elbow bend (adds to pitch)
        double[] hipA = {0, 0};     // hip pitch (forward swing)
        double[] knee = {4, 4};     // knee bend (shin swings back)
        double[] legR = {5, 5};     // leg roll (stance width)
        boolean twoHand;            // ball held between both hands
    }

    enum Mat { JERSEY, SHORTS, SHOE, SKIN, HAIR, TRIM, REF_SHIRT, REF_PANTS, REF_SHOE }

    /** A rasterizable body part. */
    static final class Part {
        final Mat mat;
        final double depth;      // larger = farther from the camera (drawn first)
        final List<double[]> caps = new ArrayList<>(); // capsules {x1,y1,x2,y2,r}
        double[][] poly;         // optional convex polygon
        Part(Mat mat, double depth) {
            this.mat = mat;
            this.depth = depth;
        }
    }

    enum View { BACK, FRONT, SIDE }

    // =====================================================================================================
    // main
    // =====================================================================================================

    public static void main(String[] args) throws IOException {
        File root = new File(args.length > 0 ? args[0] : "resources/sprites");
        Body[] players = {GUARD, FORWARD, BIG};
        for (Body b : players) {
            File dir = new File(root, b.key);
            dir.mkdirs();
            Anchors anchors = null;
            for (String variant : new String[] {"a", "b"}) {
                Anchors a = new Anchors();
                BufferedImage sheet = buildSheet(b, AnimationTable.PLAYER_ANIMS, variant, false, a);
                ImageIO.write(sheet, "png", new File(dir, "sheet_" + variant + ".png"));
                anchors = a;
            }
            writeManifest(new File(dir, "manifest.properties"), b, AnimationTable.PLAYER_ANIMS, "a,b", anchors);
            System.out.println("wrote " + dir);
        }
        File refDir = new File(root, "ref");
        refDir.mkdirs();
        Anchors ra = new Anchors();
        ImageIO.write(buildSheet(REF, AnimationTable.REF_ANIMS, "a", true, ra), "png", new File(refDir, "sheet_a.png"));
        writeManifest(new File(refDir, "manifest.properties"), REF, AnimationTable.REF_ANIMS, "a", ra);
        System.out.println("wrote " + refDir);
        writePreview(root);
    }

    /** Hand / number anchors collected while drawing, written to the manifest. */
    static final class Anchors {
        final java.util.Map<String, StringBuilder> hand = new java.util.LinkedHashMap<>();
        final java.util.Map<String, StringBuilder> number = new java.util.LinkedHashMap<>();
        final java.util.Map<String, StringBuilder> head = new java.util.LinkedHashMap<>();

        void add(java.util.Map<String, StringBuilder> m, String key, int x, int y) {
            StringBuilder sb = m.get(key);
            if (sb == null) {
                sb = new StringBuilder();
                m.put(key, sb);
            }
            if (sb.length() > 0) {
                sb.append(';');
            }
            sb.append(x).append(',').append(y);
        }
    }

    static BufferedImage buildSheet(Body b, String[] anims, String variant, boolean ref, Anchors anchors) {
        int maxFrames = 0;
        for (String a : anims) {
            maxFrames = Math.max(maxFrames, AnimationTable.get(a).getFrames());
        }
        BufferedImage sheet = new BufferedImage(maxFrames * FW, anims.length * 3 * FH, BufferedImage.TYPE_INT_ARGB);
        for (int ai = 0; ai < anims.length; ai++) {
            AnimationDef def = AnimationTable.get(anims[ai]);
            for (View v : View.values()) {
                int row = ai * 3 + v.ordinal();
                for (int f = 0; f < def.getFrames(); f++) {
                    Pose pose = ref ? refPose(anims[ai], f, def.getFrames()) : pose(anims[ai], f, def.getFrames());
                    int[] px = drawFrame(b, pose, v, variant, ref, anchors, anims[ai] + "." + v.name().toLowerCase());
                    sheet.setRGB(f * FW, row * FH, FW, FH, px, 0, FW);
                }
            }
        }
        return sheet;
    }

    // =====================================================================================================
    // poses (hand-authored key poses as joint angles)
    // =====================================================================================================

    static Pose pose(String anim, int f, int n) {
        Pose p = new Pose();
        double ph = 2 * Math.PI * f / n;
        switch (anim) {
            case "idle":
                p.crouch = 4 + 2 * Math.sin(ph);
                p.armA = new double[] {12, 12};
                p.armE = new double[] {14 + 3 * Math.sin(ph), 14 + 3 * Math.sin(ph)};
                break;
            case "run":
                run(p, ph, 38);
                p.armE = new double[] {75, 75};
                break;
            case "dribble": {
                double[] push = {10, 30, 55, 30};
                p.crouch = 12;
                p.lean = 12;
                p.legR = new double[] {9, 9};
                p.armA = new double[] {38, 45};
                p.armR = new double[] {10, 35};
                p.armE = new double[] {push[f % 4], 25};
                break;
            }
            case "dribble_run":
                run(p, ph, 30);
                p.armA[0] = 32;
                p.armE[0] = 20 + 25 * Math.max(0, Math.sin(ph * 2));
                p.armR[0] = 10;
                p.armE[1] = 70;
                break;
            case "stance":
                p.crouch = 22;
                p.lean = 10;
                p.legR = new double[] {20 + (f % 2) * 3, 20 + ((f + 1) % 2) * 3};
                p.armA = new double[] {50, 50};
                p.armR = new double[] {55, 55};
                p.armE = new double[] {25, 25};
                break;
            case "shoot":
                shoot(p, f);
                break;
            case "layup":
                layup(p, f);
                break;
            case "dunk":
                dunk(p, f, false);
                break;
            case "dunk2":
                dunk(p, f, true);
                break;
            case "windmill":
                windmill(p, f);
                break;
            case "block":
                block(p, f, false);
                break;
            case "rebound":
                block(p, f, true);
                break;
            case "steal": {
                double[] a = {80, 45, 30};
                double[] r = {10, 40, 20};
                p.crouch = 14;
                p.lean = 24;
                p.armA = new double[] {a[f], 30};
                p.armR = new double[] {r[f], 25};
                p.armE = new double[] {8, 30};
                p.hipA = new double[] {25, -15};
                break;
            }
            case "pass": {
                double[] e = {90, 0, 10};
                double[] a = {80, 92, 70};
                p.twoHand = true;
                p.lean = f == 1 ? 14 : 6;
                p.armA = new double[] {a[f], a[f]};
                p.armR = new double[] {14, 14};
                p.armE = new double[] {e[f], e[f]};
                p.hipA = new double[] {f == 1 ? 25 : 5, -5};
                break;
            }
            case "fouled": {
                p.lean = -18 - 4 * f;
                p.armA = new double[] {70 + 10 * f, 50 + 15 * f};
                p.armR = new double[] {55, 60};
                p.armE = new double[] {20, 30};
                p.hipA = new double[] {-10, 20};
                p.knee = new double[] {20, 10};
                break;
            }
            case "celebrate": {
                boolean up = f % 2 == 0;
                p.armA = new double[] {up ? 175 : 125, 20};
                p.armE = new double[] {up ? 20 : 70, 30};
                p.armR = new double[] {15, 20};
                p.crouch = up ? 2 : 8;
                break;
            }
            case "cast": {
                double k = f / 3.0;
                p.crouch = 10 - 6 * k;
                p.armA = new double[] {90 + 60 * k, 90 + 60 * k};
                p.armR = new double[] {50 + 20 * k, 50 + 20 * k};
                p.armE = new double[] {40 - 30 * k, 40 - 30 * k};
                p.lean = 2;
                break;
            }
            case "cast_strike": {
                double[] a = {60, 100, 95, 40};
                double[] e = {110, 10, 0, 40};
                p.lean = f == 1 || f == 2 ? 18 : 4;
                p.crouch = f == 2 ? 18 : 8;
                p.armA = new double[] {a[f], 40};
                p.armE = new double[] {e[f], 40};
                p.armR = new double[] {10, 30};
                p.hipA = new double[] {f == 1 ? 50 : 10, -10};
                p.knee = new double[] {f == 1 ? 70 : 10, 10};
                break;
            }
            default:
                break;
        }
        return p;
    }

    static void run(Pose p, double ph, double amp) {
        double s = Math.sin(ph);
        p.hipA = new double[] {amp * s, -amp * s};
        p.knee = new double[] {12 + 55 * Math.max(0, -s), 12 + 55 * Math.max(0, s)};
        p.armA = new double[] {-35 * s, 35 * s};
        p.armR = new double[] {10, 10};
        p.lean = 14;
    }

    static void shoot(Pose p, int f) {
        // 0 gather, 1 dip, 2 rise, 3 rise2, 4 release, 5 follow, 6 land
        double[] crouch = {14, 24, 2, 0, 0, 0, 16};
        double[] rA = {90, 92, 140, 158, 172, 168, 60};
        double[] rE = {70, 70, 70, 55, 4, 25, 30};
        double[] lA = {90, 92, 135, 150, 150, 120, 50};
        double[] lE = {70, 70, 60, 50, 40, 40, 30};
        p.crouch = crouch[f];
        p.armA = new double[] {rA[f], lA[f]};
        p.armE = new double[] {rE[f], lE[f]};
        p.armR = new double[] {8, 18};
        p.twoHand = f <= 3;
        p.lean = 3;
        if (f >= 2 && f <= 5) {
            p.knee = new double[] {22, 22};
            p.hipA = new double[] {10, 10};
        }
    }

    static void layup(Pose p, int f) {
        // 0 step, 1 step, 2 takeoff, 3 rise, 4 release, 5 hang, 6 land
        if (f <= 1) {
            run(p, f == 0 ? 0.9 : 3.9, 34);
            p.armA = new double[] {70, 70};
            p.armE = new double[] {60, 60};
            p.twoHand = true;
            return;
        }
        double[] rA = {0, 0, 110, 150, 176, 160, 50};
        double[] rE = {0, 0, 50, 20, 0, 10, 30};
        p.armA = new double[] {rA[f], f <= 3 ? 110 : 60};
        p.armE = new double[] {rE[f], 40};
        p.armR = new double[] {8, 20};
        p.twoHand = f == 2;
        p.lean = 8;
        if (f <= 5) {
            p.hipA = new double[] {-15, 75};   // left knee drives up
            p.knee = new double[] {15, 95};
        } else {
            p.crouch = 20;
        }
    }

    static void dunk(Pose p, int f, boolean twoHands) {
        // 0 gather, 1 takeoff, 2 rise, 3 cock, 4 slam, 5 rim hang, 6 drop, 7 land
        double[] crouch = {26, 0, 0, 0, 0, 0, 0, 24};
        double[] rA = {70, 150, 185, 215, 115, 172, 90, 50};
        double[] rE = {60, 20, 40, 75, 0, 0, 30, 30};
        double[] lA = {70, 140, 170, 150, 80, 60, 70, 50};
        double[] lE = {60, 20, 30, 40, 30, 30, 30, 30};
        p.crouch = crouch[f];
        p.lean = f == 4 ? 16 : 6;
        p.armA = new double[] {rA[f], twoHands ? rA[f] : lA[f]};
        p.armE = new double[] {rE[f], twoHands ? rE[f] : lE[f]};
        p.armR = new double[] {10, twoHands ? 10 : 22};
        p.twoHand = twoHands || f == 0;
        if (f >= 2 && f <= 4) {
            p.hipA = new double[] {50, 40};
            p.knee = new double[] {90, 80};
        } else if (f == 5 || f == 6) {
            p.hipA = new double[] {8, 2};
            p.knee = new double[] {30, 20};
        }
    }

    static void windmill(Pose p, int f) {
        // the right arm sweeps a full circle before the slam
        double[] rA = {70, 20, -40, 60, 150, 115, 172, 90, 50};
        double[] rE = {60, 0, 0, 0, 10, 0, 0, 30, 30};
        double[] rR = {10, 25, 35, 30, 15, 10, 10, 10, 10};
        p.crouch = f == 0 ? 26 : (f == 8 ? 24 : 0);
        p.lean = f == 5 ? 18 : 4;
        p.armA = new double[] {rA[f], f >= 2 && f <= 5 ? 160 : 70};
        p.armE = new double[] {rE[f], 30};
        p.armR = new double[] {rR[f], 25};
        if (f >= 1 && f <= 5) {
            p.hipA = new double[] {55, 30};
            p.knee = new double[] {100, 70};
        }
    }

    static void block(Pose p, int f, boolean rebound) {
        // 0 crouch, 1 jump, 2 apex, 3 fall, 4 land
        double[] crouch = {24, 0, 0, 0, 18};
        double[] a = {40, 165, 182, 150, 50};
        p.crouch = crouch[f];
        p.armA = new double[] {a[f], a[f] - (rebound ? 0 : 8)};
        p.armR = new double[] {rebound ? 8 : 14, rebound ? 8 : 18};
        p.armE = new double[] {rebound ? 12 : 4, rebound ? 12 : 8};
        p.twoHand = rebound && f >= 2;
        p.lean = 2;
        if (f >= 1 && f <= 3) {
            p.knee = new double[] {30, 40};
            p.hipA = new double[] {12, 18};
        }
    }

    static Pose refPose(String anim, int f, int n) {
        Pose p = new Pose();
        p.lean = 3;
        switch (anim) {
            case "run":
                run(p, 2 * Math.PI * f / n, 30);
                p.armE = new double[] {80, 80};
                p.lean = 8;
                break;
            case "whistle":
                p.armA = new double[] {f == 0 ? 60 : 150, 12};
                p.armE = new double[] {f == 0 ? 60 : 150, 12};
                p.armR = new double[] {8, 12};
                break;
            case "signal_foul":
                p.armA = new double[] {178, 12};
                p.armE = new double[] {f == 1 ? 30 : 10, 12};
                p.armR = new double[] {6, 12};
                break;
            case "signal_point":
                p.armA = new double[] {175, 175};
                p.armR = new double[] {14 + f * 3, 14 + f * 3};
                p.armE = new double[] {0, 0};
                break;
            case "signal_out":
                p.armA = new double[] {90, 12};
                p.armR = new double[] {80, 12};
                p.armE = new double[] {0, 12};
                break;
            case "handoff":
                p.twoHand = true;
                p.armA = new double[] {60 + 15 * f, 60 + 15 * f};
                p.armE = new double[] {30 - 10 * f, 30 - 10 * f};
                break;
            default:
                p.crouch = 2 + (f % 2);
                break;
        }
        return p;
    }

    // =====================================================================================================
    // rig -> parts -> pixels
    // =====================================================================================================

    static double[] dir(double pitchDeg, double rollDeg, int side) {
        double pa = Math.toRadians(pitchDeg);
        double ro = Math.toRadians(rollDeg);
        return new double[] {Math.sin(ro) * side, -Math.cos(pa) * Math.cos(ro), Math.sin(pa) * Math.cos(ro)};
    }

    static double[] add(double[] a, double[] d, double len) {
        return new double[] {a[0] + d[0] * len, a[1] + d[1] * len, a[2] + d[2] * len};
    }

    /** 3D point (X right, Y up, Z forward) to frame pixels {sx, sy, depth}. */
    static double[] project(double[] p, View v) {
        switch (v) {
            case BACK: return new double[] {OX + p[0], OY - p[1] - p[2] * FORESHORTEN, p[2]};
            case FRONT: return new double[] {OX - p[0], OY - p[1] + p[2] * FORESHORTEN, -p[2]};
            default: return new double[] {OX + p[2], OY - p[1] + p[0] * 0.12, p[0]};
        }
    }

    static int[] drawFrame(Body b, Pose pose, View v, String variant, boolean ref, Anchors anchors, String key) {
        double c = pose.crouch;
        double[] hipA = {pose.hipA[0] + c, pose.hipA[1] + c};
        double[] knee = {pose.knee[0] + 2 * c, pose.knee[1] + 2 * c};
        double lean = pose.lean + c * 0.45;
        // legs (pelvis at origin first, then shift so the lowest foot touches the ground)
        double[][] hip = new double[2][], kneeP = new double[2][], foot = new double[2][], toe = new double[2][];
        double minY = 0;
        for (int s = 0; s < 2; s++) {
            int side = s == 0 ? 1 : -1;
            hip[s] = new double[] {b.hipW * side, 0, 0};
            kneeP[s] = add(hip[s], dir(hipA[s], pose.legR[s], side), b.thigh);
            foot[s] = add(kneeP[s], dir(hipA[s] - knee[s], pose.legR[s], side), b.shin);
            toe[s] = add(foot[s], new double[] {0, 0, 1}, 2.2);
            minY = Math.min(minY, foot[s][1] - 0.8);
        }
        double lift = -minY;
        for (int s = 0; s < 2; s++) {
            hip[s][1] += lift;
            kneeP[s][1] += lift;
            foot[s][1] += lift;
            toe[s][1] += lift;
        }
        double[] pelvis = {0, lift, 0};
        double lr = Math.toRadians(lean);
        double[] top = {0, lift + b.torso * Math.cos(lr), b.torso * Math.sin(lr)};
        double[] head = {0, top[1] + (b.headR + 1.2) * Math.cos(lr * 0.5), top[2] + (b.headR + 1.2) * Math.sin(lr * 0.5)};

        List<Part> parts = new ArrayList<>();
        Mat shortsMat = ref ? Mat.REF_PANTS : Mat.SHORTS;
        Mat shoeMat = ref ? Mat.REF_SHOE : Mat.SHOE;
        // legs
        for (int s = 0; s < 2; s++) {
            double[] h = project(hip[s], v);
            double[] k = project(kneeP[s], v);
            double[] f = project(foot[s], v);
            double[] t = project(toe[s], v);
            double[] mid = {(h[0] + k[0]) / 2, (h[1] + k[1]) / 2};
            double depth = (h[2] + k[2] + f[2]) / 3;
            Part shorts = new Part(shortsMat, depth);
            shorts.caps.add(new double[] {h[0], h[1], mid[0], mid[1], b.limbR + 1.0});
            Part leg = new Part(ref ? Mat.REF_PANTS : Mat.SKIN, depth + 0.01);
            leg.caps.add(new double[] {mid[0], mid[1], k[0], k[1], b.limbR});
            leg.caps.add(new double[] {k[0], k[1], f[0], f[1], b.limbR * 0.9});
            Part shoe = new Part(shoeMat, depth - 0.01);
            double ax = f[0] + (k[0] - f[0]) * 0.28;
            double ay = f[1] + (k[1] - f[1]) * 0.28;
            shoe.caps.add(new double[] {ax, ay, f[0], f[1], b.limbR * 0.95});
            shoe.caps.add(new double[] {f[0], f[1], t[0], t[1], b.limbR + 0.35});
            Part sock = new Part(ref ? Mat.REF_PANTS : Mat.TRIM, depth - 0.005);
            sock.caps.add(new double[] {ax, ay, ax, ay, b.limbR * 0.95});
            parts.add(leg);
            parts.add(shorts);
            parts.add(sock);
            parts.add(shoe);
        }
        // shorts box and torso box
        parts.add(box(shortsMat, new double[] {0, lift - 2.5, 0}, b.hipW + b.limbR + 1.0, 3.2, b.torsoD * 0.55, 0, v, 0.0));
        double shirtLean = lean;
        Mat shirt = ref ? Mat.REF_SHIRT : Mat.JERSEY;
        double[] mid = {0, (lift + top[1]) / 2, top[2] / 2};
        parts.add(torso(shirt, pelvis, top, b, v));
        // neck + head + hair
        double[] hp = project(head, v);
        Part neck = new Part(Mat.SKIN, project(top, v)[2] - 0.02);
        double[] tp = project(top, v);
        neck.caps.add(new double[] {tp[0], tp[1], hp[0], hp[1] + 1, b.limbR * 0.9});
        parts.add(neck);
        Part headPart = new Part(Mat.SKIN, hp[2] - 0.03);
        headPart.caps.add(new double[] {hp[0], hp[1], hp[0], hp[1] - 0.4, b.headR});
        parts.add(headPart);
        parts.add(hair(head, b, v, variant, ref));
        // arms
        double[][] hand = new double[2][];
        for (int s = 0; s < 2; s++) {
            int side = s == 0 ? 1 : -1;
            double[] sh = {b.shoulderW * side * 0.92, top[1] - 1.2, top[2]};
            double[] el = add(sh, dir(pose.armA[s], pose.armR[s], side), b.upperArm);
            double[] hd = add(el, dir(pose.armA[s] + pose.armE[s], pose.armR[s], side), b.foreArm);
            double[] wr0 = add(el, dir(pose.armA[s] + pose.armE[s], pose.armR[s], side), b.foreArm * 0.55);
            double[] wr = add(el, dir(pose.armA[s] + pose.armE[s], pose.armR[s], side), b.foreArm * 0.75);
            double[] ps = project(sh, v);
            double[] pe = project(el, v);
            double[] ph = project(hd, v);
            double[] pw = project(wr, v);
            double[] pw0 = project(wr0, v);
            double depth = (ps[2] + pe[2] + ph[2]) / 3 - 0.05;
            Part arm = new Part(Mat.SKIN, depth);
            arm.caps.add(new double[] {ps[0], ps[1], pe[0], pe[1], b.limbR * 0.95});
            arm.caps.add(new double[] {pe[0], pe[1], ph[0], ph[1], b.limbR * 0.85});
            Part band = new Part(ref ? Mat.SKIN : Mat.TRIM, depth - 0.001);
            band.caps.add(new double[] {pw0[0], pw0[1], pw[0], pw[1], b.limbR * 0.9});
            Part handPart = new Part(Mat.SKIN, depth - 0.002);
            handPart.caps.add(new double[] {ph[0], ph[1], ph[0], ph[1], b.limbR + 0.15});
            parts.add(arm);
            parts.add(band);
            parts.add(handPart);
            hand[s] = ph;
        }
        // anchors (relative to the feet origin)
        double hx = pose.twoHand ? (hand[0][0] + hand[1][0]) / 2 : hand[0][0];
        double hy = pose.twoHand ? (hand[0][1] + hand[1][1]) / 2 : hand[0][1];
        if (v == View.BACK && !pose.twoHand && pose.armA[0] < 120) {
            hy -= 1; // ball held in front of the body when seen from behind
        }
        anchors.add(anchors.hand, key, (int) Math.round(hx - OX), (int) Math.round(hy - OY));
        double[] np = project(new double[] {0, mid[1] + 1, v == View.SIDE ? 0 : mid[2]}, v);
        anchors.add(anchors.number, key, (int) Math.round(np[0] - OX), (int) Math.round(np[1] - OY));
        anchors.add(anchors.head, key, (int) Math.round(hp[0] - OX), (int) Math.round(hp[1] - b.headR - OY));
        int[] img = rasterize(parts, ref);
        drawFace(img, hp, b, v, shirtLean);
        return img;
    }

    static Part torso(Mat mat, double[] pelvis, double[] top, Body b, View v) {
        List<double[]> pts = new ArrayList<>();
        double[][] rings = {
            {pelvis[1] + 0.5, pelvis[2], b.torsoW * 0.42},
            {top[1], top[2], b.torsoW * 0.5}
        };
        for (double[] r : rings) {
            for (int sx = -1; sx <= 1; sx += 2) {
                for (int sz = -1; sz <= 1; sz += 2) {
                    double[] p = project(new double[] {sx * r[2], r[0], r[1] + sz * b.torsoD * 0.5}, v);
                    pts.add(p);
                }
            }
        }
        Part part = new Part(mat, 0);
        part.poly = hull(pts);
        // round the shoulders a little
        double[] l = project(new double[] {-b.torsoW * 0.45, top[1] - 0.8, top[2]}, v);
        double[] r = project(new double[] {b.torsoW * 0.45, top[1] - 0.8, top[2]}, v);
        part.caps.add(new double[] {l[0], l[1], r[0], r[1], 1.6});
        return part;
    }

    static Part box(Mat mat, double[] c, double hx, double hy, double hz, double unused, View v, double depthBias) {
        List<double[]> pts = new ArrayList<>();
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int sy = -1; sy <= 1; sy += 2) {
                for (int sz = -1; sz <= 1; sz += 2) {
                    pts.add(project(new double[] {c[0] + sx * hx, c[1] + sy * hy, c[2] + sz * hz}, v));
                }
            }
        }
        Part p = new Part(mat, 0.02 + depthBias);
        p.poly = hull(pts);
        return p;
    }

    static Part hair(double[] head, Body b, View v, String variant, boolean ref) {
        double[] hp = project(head, v);
        boolean puff = "b".equals(variant) && !ref;
        double r = b.headR + (puff ? 1.4 : 0.35);
        double depthHair = v == View.BACK ? hp[2] - 0.05 : hp[2] - 0.04;
        Part p = new Part(Mat.HAIR, depthHair);
        double cy = hp[1] - (puff ? 1.6 : 0.9);
        if (v == View.BACK) {
            p.caps.add(new double[] {hp[0], cy, hp[0], cy + (puff ? 0.5 : 0.8), r});
        } else if (v == View.FRONT) {
            // a cap over the top of the head only
            p.poly = null;
            p.caps.add(new double[] {hp[0] - b.headR * 0.55, cy - b.headR * 0.45, hp[0] + b.headR * 0.55, cy - b.headR * 0.45, r * 0.62});
        } else {
            p.caps.add(new double[] {hp[0] - 1.2, cy - 0.4, hp[0] - 0.2, cy - b.headR * 0.4, r * 0.85});
        }
        return p;
    }

    static void drawFace(int[] img, double[] hp, Body b, View v, double lean) {
        int ey = (int) Math.round(hp[1] - 0.3);
        if (v == View.FRONT) {
            set(img, (int) Math.round(hp[0] - 1.6), ey, EYE);
            set(img, (int) Math.round(hp[0] + 1.2), ey, EYE);
        } else if (v == View.SIDE) {
            set(img, (int) Math.round(hp[0] + b.headR * 0.55), ey, EYE);
        }
    }

    static void set(int[] img, int x, int y, int c) {
        if (x >= 0 && y >= 0 && x < FW && y < FH && (img[y * FW + x] >>> 24) != 0) {
            img[y * FW + x] = c;
        }
    }

    // ---- rasterizer: part ids -> 3-tone shading -> outline --------------------------------------------------

    static int[] rasterize(List<Part> parts, boolean ref) {
        List<Part> sorted = new ArrayList<>(parts);
        Collections.sort(sorted, new Comparator<Part>() {
            @Override
            public int compare(Part a, Part b) {
                return Double.compare(b.depth, a.depth); // far first
            }
        });
        int[] id = new int[FW * FH];
        for (int i = 0; i < sorted.size(); i++) {
            Part p = sorted.get(i);
            for (int y = 0; y < FH; y++) {
                for (int x = 0; x < FW; x++) {
                    double px = x + 0.5;
                    double py = y + 0.5;
                    boolean in = p.poly != null && insidePoly(p.poly, px, py);
                    for (double[] c : p.caps) {
                        if (!in && distSeg(px, py, c[0], c[1], c[2], c[3]) <= c[4]) {
                            in = true;
                        }
                    }
                    if (in) {
                        id[y * FW + x] = i + 1;
                    }
                }
            }
        }
        int[] out = new int[FW * FH];
        for (int y = 0; y < FH; y++) {
            for (int x = 0; x < FW; x++) {
                int pid = id[y * FW + x];
                if (pid == 0) {
                    continue;
                }
                Part p = sorted.get(pid - 1);
                int tone = 1;
                if (differs(id, x + 1, y, pid) || differs(id, x, y + 1, pid)) {
                    tone = 2;
                } else if (differs(id, x - 1, y, pid) || differs(id, x, y - 1, pid)) {
                    tone = 0;
                }
                // a part in front casts a 1 px dark seam on the part behind it
                if (tone != 2 && frontNeighbour(id, x, y, pid)) {
                    tone = 2;
                }
                out[y * FW + x] = color(p.mat, tone, x, y);
            }
        }
        int[] res = out.clone();
        for (int y = 0; y < FH; y++) {
            for (int x = 0; x < FW; x++) {
                if (id[y * FW + x] == 0 && (filled(id, x + 1, y) || filled(id, x - 1, y) || filled(id, x, y + 1) || filled(id, x, y - 1))) {
                    res[y * FW + x] = OUTLINE;
                }
            }
        }
        return res;
    }

    static boolean filled(int[] id, int x, int y) {
        return x >= 0 && y >= 0 && x < FW && y < FH && id[y * FW + x] != 0;
    }

    static boolean differs(int[] id, int x, int y, int pid) {
        return !(x >= 0 && y >= 0 && x < FW && y < FH) || id[y * FW + x] != pid;
    }

    static boolean frontNeighbour(int[] id, int x, int y, int pid) {
        int[][] n = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        for (int[] d : n) {
            int xx = x + d[0];
            int yy = y + d[1];
            if (xx >= 0 && yy >= 0 && xx < FW && yy < FH) {
                int o = id[yy * FW + xx];
                if (o > pid + 1) {   // drawn later = in front (ignore tiny sibling parts)
                    return true;
                }
            }
        }
        return false;
    }

    static int color(Mat m, int tone, int x, int y) {
        switch (m) {
            case JERSEY: return JERSEY[tone];
            case SHORTS: return SHORTS[tone];
            case SHOE: return SHOE[tone];
            case SKIN: return SKIN[tone];
            case HAIR: return HAIR[tone];
            case TRIM: return TRIM[tone];
            case REF_SHIRT: return ((x / 2) % 2 == 0) ? REF_SHIRT_W[tone] : REF_SHIRT_B[tone];
            case REF_PANTS: return REF_PANTS[tone];
            default: return REF_SHOE[tone];
        }
    }

    static double distSeg(double px, double py, double x1, double y1, double x2, double y2) {
        double dx = x2 - x1;
        double dy = y2 - y1;
        double len2 = dx * dx + dy * dy;
        double t = len2 < 1e-9 ? 0 : Math.max(0, Math.min(1, ((px - x1) * dx + (py - y1) * dy) / len2));
        return Math.hypot(px - (x1 + t * dx), py - (y1 + t * dy));
    }

    static double[][] hull(List<double[]> pts) {
        List<double[]> p = new ArrayList<>(pts);
        Collections.sort(p, new Comparator<double[]>() {
            @Override
            public int compare(double[] a, double[] b) {
                return a[0] != b[0] ? Double.compare(a[0], b[0]) : Double.compare(a[1], b[1]);
            }
        });
        List<double[]> h = new ArrayList<>();
        for (int pass = 0; pass < 2; pass++) {
            int start = h.size();
            for (double[] q : p) {
                while (h.size() >= start + 2 && cross(h.get(h.size() - 2), h.get(h.size() - 1), q) <= 0) {
                    h.remove(h.size() - 1);
                }
                h.add(q);
            }
            h.remove(h.size() - 1);
            Collections.reverse(p);
        }
        return h.toArray(new double[0][]);
    }

    static double cross(double[] o, double[] a, double[] b) {
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
    }

    static boolean insidePoly(double[][] poly, double x, double y) {
        boolean in = false;
        for (int i = 0, j = poly.length - 1; i < poly.length; j = i++) {
            if ((poly[i][1] > y) != (poly[j][1] > y)
                    && x < (poly[j][0] - poly[i][0]) * (y - poly[i][1]) / (poly[j][1] - poly[i][1]) + poly[i][0]) {
                in = !in;
            }
        }
        return in;
    }

    // ---- manifest + preview --------------------------------------------------------------------------------

    static void writeManifest(File file, Body b, String[] anims, String variants, Anchors a) throws IOException {
        try (PrintWriter w = new PrintWriter(new FileWriter(file))) {
            w.println("# Generated by tools/SpriteSheetGenerator - edit fps/events here to retime without code.");
            w.println("# Rows: animation index * 3 + facing (0 back, 1 front, 2 side). Columns: frames.");
            w.println("# hand/number/head anchors are pixel offsets from the feet origin, one 'x,y' per frame.");
            w.println("character=" + b.key);
            w.println("frameWidth=" + FW);
            w.println("frameHeight=" + FH);
            w.println("originX=" + OX);
            w.println("originY=" + OY);
            w.println("variants=" + variants);
            w.println("anims=" + String.join(",", anims));
            for (int i = 0; i < anims.length; i++) {
                AnimationDef d = AnimationTable.get(anims[i]);
                String n = anims[i];
                w.println();
                w.println(n + ".frames=" + d.getFrames());
                w.println(n + ".fps=" + (int) d.getFps());
                w.println(n + ".loop=" + d.isLoop());
                w.println(n + ".events=" + d.eventSpec());
                w.println(n + ".row=" + (i * 3));
                for (View v : View.values()) {
                    String k = n + "." + v.name().toLowerCase();
                    w.println(n + ".hand." + v.name().toLowerCase() + "=" + a.hand.get(k));
                    w.println(n + ".number." + v.name().toLowerCase() + "=" + a.number.get(k));
                    w.println(n + ".head." + v.name().toLowerCase() + "=" + a.head.get(k));
                }
            }
        }
    }

    /** A recolored preview strip so you can judge the art without starting the game. */
    static void writePreview(File root) throws IOException {
        String[] chars = {"guard", "forward", "big"};
        String[] show = {"idle", "run", "dribble", "shoot", "layup", "dunk", "block"};
        int scale = 3;
        BufferedImage out = new BufferedImage(FW * 7 * scale, FH * 3 * 3 * scale, BufferedImage.TYPE_INT_ARGB);
        java.awt.Graphics2D g = out.createGraphics();
        g.setColor(new java.awt.Color(0xD9964E));
        g.fillRect(0, 0, out.getWidth(), out.getHeight());
        int[][] teams = {{0xE8F0F0, 0x5B3A8C}, {0x5B3A8C, 0xE8F0F0}, {0xD8462A, 0x1A2A5A}};
        for (int ci = 0; ci < 3; ci++) {
            BufferedImage sheet = ImageIO.read(new File(root, chars[ci] + "/sheet_" + (ci == 1 ? "b" : "a") + ".png"));
            for (int vi = 0; vi < 3; vi++) {
                for (int ai = 0; ai < show.length; ai++) {
                    int animIndex = java.util.Arrays.asList(AnimationTable.PLAYER_ANIMS).indexOf(show[ai]);
                    AnimationDef d = AnimationTable.get(show[ai]);
                    int frame = Math.min(d.getFrames() - 1, d.frameOf("ball_release") >= 0 ? d.frameOf("ball_release")
                            : (d.frameOf("rim_touch") >= 0 ? d.frameOf("rim_touch") : (d.frameOf("contact_start") >= 0 ? 2 : 1)));
                    BufferedImage f = sheet.getSubimage(frame * FW, (animIndex * 3 + vi) * FH, FW, FH);
                    BufferedImage rc = recolor(f, teams[ci][0], teams[ci][1], ci);
                    g.drawImage(rc, ai * FW * scale, (ci * 3 + vi) * FH * scale, FW * scale, FH * scale, null);
                }
            }
        }
        g.dispose();
        ImageIO.write(out, "png", new File(root, "preview.png"));
    }

    static BufferedImage recolor(BufferedImage src, int jersey, int shorts, int skinIndex) {
        int[] skins = {0x8A5A3C, 0xC68A5E, 0x5C3A26};
        BufferedImage dst = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < src.getHeight(); y++) {
            for (int x = 0; x < src.getWidth(); x++) {
                int c = src.getRGB(x, y);
                int r = map(c, JERSEY, jersey);
                r = r != c ? r : map(c, SHORTS, shorts);
                r = r != c ? r : map(c, SHOE, 0xF4F4F0);
                r = r != c ? r : map(c, SKIN, skins[skinIndex]);
                r = r != c ? r : map(c, HAIR, 0x1E1410);
                r = r != c ? r : map(c, TRIM, 0xF4F4F0);
                dst.setRGB(x, y, r);
            }
        }
        return dst;
    }

    static int map(int c, int[] mask, int base) {
        for (int t = 0; t < 3; t++) {
            if (c == mask[t]) {
                return 0xFF000000 | tone(base, t);
            }
        }
        return c;
    }

    static int tone(int rgb, int t) {
        int r = (rgb >> 16) & 255;
        int g = (rgb >> 8) & 255;
        int b = rgb & 255;
        double k = t == 0 ? 1.25 : (t == 1 ? 1.0 : 0.68);
        r = (int) Math.min(255, r * k + (t == 0 ? 18 : 0));
        g = (int) Math.min(255, g * k + (t == 0 ? 18 : 0));
        b = (int) Math.min(255, b * k + (t == 0 ? 18 : 0));
        return (r << 16) | (g << 8) | b;
    }
}
