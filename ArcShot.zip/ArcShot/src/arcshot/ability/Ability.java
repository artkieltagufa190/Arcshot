package arcshot.ability;

import arcshot.core.Balance;
import arcshot.court.Match;
import arcshot.player.Player;
import arcshot.render.EffectRenderer;
import java.awt.Graphics2D;

/**
 * Base class of every ability. Uses the <b>Template Method</b> pattern: {@link #activate} is final and always runs
 * the same steps (check {@link #canUse} -&gt; {@link #perform} -&gt; {@link #onActivated} -&gt; publish event), while
 * subclasses fill in the steps that differ.
 * <p>
 * OOP pillars:
 * <ul>
 *   <li><b>ABSTRACTION</b> - the match and HUD only talk to "an Ability"; they never know it is Shadow Step.</li>
 *   <li><b>INHERITANCE</b> - {@link ActiveAbility} (cooldown) and {@link Ultimate} (meter) extend this class, and each
 *       concrete ability extends one of those.</li>
 *   <li><b>POLYMORPHISM</b> - each concrete ability overrides {@link #perform}, and optionally {@link #whileActive},
 *       {@link #render} and {@link #aiShouldUse}.</li>
 *   <li><b>ENCAPSULATION</b> - the active timer is private; numbers come from the balance file via {@link #param}.</li>
 * </ul>
 */
public abstract class Ability {
    private final String id;
    private final AbilitySlot slot;
    private double activeTimer;
    private boolean active;

    protected Ability(String id, AbilitySlot slot) {
        this.id = id;
        this.slot = slot;
    }

    public final String getId() { return id; }

    public final AbilitySlot getSlot() { return slot; }

    /**
     * TEMPLATE METHOD. Tries to use the ability; returns true if it fired.
     * Final: no subclass can skip the checks or forget to start the cooldown.
     */
    public final boolean activate(Player owner, Match match) {
        if (!canUse(owner, match)) {
            return false;
        }
        perform(owner, match);
        onActivated(owner);
        activeTimer = activeDuration();
        active = activeTimer > 0;
        match.onAbilityUsed(owner, this);
        return true;
    }

    /** Ready, the owner is able to act, and the ability's own requirement is met. */
    public boolean canUse(Player owner, Match match) {
        return isReady(owner) && owner.canAct() && match.isLive() && meetsRequirements(owner, match);
    }

    /** Called every step by the owner. Ticks the cooldown and runs {@link #whileActive}. */
    public void update(double dt, Player owner, Match match) {
        tick(dt, owner);
        if (active) {
            activeTimer -= dt;
            whileActive(dt, owner, match);
            if (activeTimer <= 0) {
                active = false;
                onEnd(owner, match);
            }
        }
    }

    /** Ends an ongoing ability early (e.g. its sequence finished). */
    protected final void finish(Player owner, Match match) {
        if (active) {
            active = false;
            activeTimer = 0;
            onEnd(owner, match);
        }
    }

    public final boolean isActive() { return active; }

    // ---- steps subclasses fill in ---------------------------------------------------------------------------

    /** The actual effect of the ability. */
    protected abstract void perform(Player owner, Match match);

    /** Cooldown or meter bookkeeping (implemented by ActiveAbility / Ultimate). */
    protected abstract void onActivated(Player owner);

    protected abstract boolean isReady(Player owner);

    protected abstract void tick(double dt, Player owner);

    /** Extra condition, e.g. "must have the ball". Default: none. */
    protected boolean meetsRequirements(Player owner, Match match) { return true; }

    /** Seconds the ability stays "active" after use (0 = instant). */
    protected double activeDuration() { return 0; }

    /** Runs every step while active (dashes, sequences, trails). */
    protected void whileActive(double dt, Player owner, Match match) { }

    /** Runs once when the active time ends. */
    protected void onEnd(Player owner, Match match) { }

    /** Optional world visuals while active. Visual style comes from the renderer / skin, not from here. */
    public void render(Graphics2D g, Player owner, EffectRenderer fx) { }

    /** Simple rule for AI players: is now a good moment? Default: never. */
    public boolean aiShouldUse(Player owner, Match match) { return false; }

    // ---- HUD info -------------------------------------------------------------------------------------------

    /** 0 = ready, 1 = just used. Drives the radial cooldown sweep. */
    public abstract double getCooldownFraction(Player owner);

    /** "READY", seconds left, or meter percent. */
    public abstract String getStatusText(Player owner);

    /** Helper: every opponent of {@code owner} within {@code radius} pixels. */
    protected static java.util.List<Player> opponentsNear(Player owner, Match match, double radius) {
        java.util.List<Player> list = new java.util.ArrayList<>();
        for (Player o : match.opponentsOf(owner)) {
            if (o.distanceTo(owner) <= radius) {
                list.add(o);
            }
        }
        return list;
    }

    /** Helper: true if {@code p} currently holds the ball. */
    protected static boolean hasBall(Player p, Match match) {
        return match.getBall().getState() == arcshot.court.Ball.State.HELD && match.getBall().getHolder() == p;
    }

    /** Helper: true if the other team currently holds the ball. */
    protected static boolean opponentHasBall(Player p, Match match) {
        return match.getBall().getState() == arcshot.court.Ball.State.HELD
                && match.getBall().getHolder().getSide() != p.getSide();
    }

    /** Reads {@code ability.<id>.<name>} from the balance file. */
    protected final double param(String name, double def) {
        return Balance.d("ability." + id + "." + name, def);
    }
}
