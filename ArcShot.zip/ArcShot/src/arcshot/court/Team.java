package arcshot.court;

import arcshot.player.Player;
import arcshot.player.TeamSide;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * One side of the match: three players and a score.
 * OOP pillar: <b>ENCAPSULATION</b> - the score can only go up through {@link #addPoints}.
 */
public final class Team {
    private final TeamSide side;
    private final String name;
    private final Color color;
    private final List<Player> players = new ArrayList<>();
    private int score;
    private int overtimePoints;

    public Team(TeamSide side, String name, Color color) {
        this.side = side;
        this.name = name;
        this.color = color;
    }

    public void addPlayer(Player p) { players.add(p); }

    public List<Player> getPlayers() { return Collections.unmodifiableList(players); }

    public void addPoints(int points, boolean overtime) {
        if (points > 0) {
            score += points;
            if (overtime) {
                overtimePoints += points;
            }
        }
    }

    public TeamSide getSide() { return side; }

    public String getName() { return name; }

    public Color getColor() { return color; }

    public int getScore() { return score; }

    public int getOvertimePoints() { return overtimePoints; }
}
