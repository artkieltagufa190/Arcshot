# Mechanics matrix

This page lists every pair of mechanics that can happen at the same time and the single defined outcome for
each. If behaviour ever differs from this table, it is a bug: please report it. Three rules make the table
possible:

1. **One action per player.** `ActionController` holds exactly one `Action`. A new request wins only if
   `ActionType.canBeReplacedBy()` allows it: the current action is interruptible, or the new one has a higher
   priority, or the new one `forces`. Priorities are:
   - 0: locomotion
   - 1: CELEBRATE
   - 3: PASS / STEAL_SWIPE / CROSSOVER
   - 4: ABILITY_CAST / BLOCK / REBOUND_JUMP
   - 5: JUMP_SHOT / FREE_THROW
   - 6: LAYUP / DASH
   - 7: DUNK
   - 8: FOULED
2. **One phase.** `MatchPhase` decides whether input, abilities, AI and the clock may run. Every phase change
   goes through `Match.goPhase()`, which checks `PhaseMachine.isAllowed()`, counts illegal changes, and
   clears interactions that were queued before a whistle.
3. **One ball owner.** The ball changes owner only through `Ball.giveTo(player, reason)`. It refuses while a
   shot is in flight. `Ball.validate()` checks this every frame in `SelfTests`.

## Update order (each 1/60 s tick, `Match.updatePlay`)

input → AI → status effects and cooldowns → action requests → `ActionController` (frame events become
`Interaction`s) → movement + soft collision → ball → **interactions in priority order** (rules and scoring)
→ clocks → event bus flush → render (on the same thread, reading only).

## Interaction priority (same frame)

When several things happen in the same frame, they resolve in this order. Ties go to the lower player index.

| Rank | Interaction | Note |
|---|---|---|
| 1 | Whistle / foul check (`FOUL_CHECK`) | A call ends live play. Later interactions this frame are dropped. |
| 2 | Score (`SCORE`, dunk `rim_touch`, ball through hoop) | Scores once only (`resolveShot` checks that the ball still carries this shot). |
| 3 | Block contact (`BLOCK`) | |
| 4 | Shot release (`SHOT_RELEASE`) | |
| 5 | Steal (`STEAL`) | |
| 6 | Pass (`PASS`) | |
| 7 | Rebound grab (`REBOUND`) | Then movement. |

## Pairs

| A | B | Outcome |
|---|---|---|
| Dribble | Steal swipe | Steal contact frame rolls against the handler's ball security. Success → `giveTo(thief,"steal")`; a reach-in foul may be called instead (from behind ×2.5). |
| Dribble | Sprint | Allowed; dribble bounce speeds up (`Ball.dribbleRate`), stamina drains. |
| Pass | Steal (same frame) | STEAL ranks above PASS: if the steal succeeds the pass is dropped (passer no longer holds the ball). |
| Pass in flight | Defender in lane | Interception check along the path; success = "PICKED OFF!", ball to defender, defense must clear. |
| Jump shot charging | Any ability (Q/E/R) | Refused: abilities cannot interrupt an action of priority ≥ JUMP_SHOT (DASH-type abilities included). |
| Jump shot released | Block | Block only during the first `block.window` (0.32 s) and while the blocker's contact frames are active (`isBlockContactActive`). Blocked → loose ball, shot never scores. |
| Jump shot released | Foul on takeoff | Shooting foul stored on the shot; resolved when the shot ends: made = basket + 1 FT, missed = 1/2 FT (bonus rules override). |
| Jump shot released | Shot clock hits 0 | Shot clock is paused while the ball is in the air; the shot is valid. A miss that hits the rim resets the clock. |
| Jump shot released | Game clock hits 0 | Buzzer waits until the ball resolves (buzzer beaters count), then GAME_OVER or OVERTIME. |
| Layup | Block | Checked during the rise (`checkFinishBlocks`, `block.layupChance` × reach). Blocked → loose ball. |
| Layup | Foul | `FOUL_CHECK` on takeoff; make chance −`foul.layupPenaltyWhenFouled`; and-one if it still goes in. |
| Dunk | Block | Possible only during the rise (`block.dunkChance`); after `rim_touch` it is a score. Forced dunks (Final Burst) cannot be blocked. |
| Dunk | Foul | Made with `foul.dunkMakeWhenFouled` (70 %); made = and-one, missed = FTs. |
| Dunk / layup | Root motion vs collisions | Root motion moves the player; soft collision still separates bodies; a finish is never counted as a charge (only real dashes are). |
| Rebound | Two players reach the ball the same frame | Deterministic contest: best (reach + jump height + class bonus) wins, ties go to the lower player index. One `giveTo`. |
| Rebound | Colossus Rebound (Big R) | Override player gets the ball if inside the radius; still through `giveTo`. |
| Ball loose | Out of bounds | Whistle, "OUT OF BOUNDS" and a referee signal, then a check ball (`Match.outOfBounds`). |
| Steal | Defender frozen/stunned | `canAct()` false → no swipe, no jump, no block. |
| Time Stop (Guard R) | Shot already released | The shot keeps flying with the result rolled at release; frozen defenders cannot block it; the Guard gets No-Shoot so he cannot start a new shot during the freeze. |
| Time Stop | Opponent charging a jump shot | Any debuff cancels a shot that is still charging (`shotHold = -1`); the ball stays with the shooter. |
| Time Stop | Opponent already in the air (layup/dunk) | Freeze stops input and movement, but a started finish owns its own timing and resolves (it may still be blocked during the rise). |
| Titan Seal (Big R) field | Layup / jump shot inside | `shot_penalty` (−0.25) applies to jump shots and layups via `getShootingBonus`; slow (×0.6) makes reaching dunk speed harder. |
| Titan Seal | Dunk | Not penalized once started (dunks are certain unless blocked/fouled); the slow is what stops drives. |
| Iron Wall (Big Q) | Dunk attempt | Barrier ×1.5 block reach → the Big can block a normal dunk during the rise; it cannot block a forced dunk. Barrier also prevents being pushed in collisions. |
| Shadow Step (Guard Q) | Screener / defender in path | Intangible dash: passes through players and `PickScreen` entities, no collision, no body-contact foul. |
| Final Burst (Forward R) | Fouled | Intangible + unblockable during dash and dunk; the forced dunk skips the foul check. If a whistle already stopped play, `forceDunk` refuses (no teleporting ball) and the ultimate is spent. |
| Final Burst | Not holding the ball at dunk time | `forceDunk` refuses; nothing scores. |
| Quake Fist / Bull Rush | Opponent | Foulable abilities: may be called (`foul.ability`); by the ball handler = offensive foul; airborne victim may become unsportsmanlike; Strict Refs + frozen victim = technical. |
| Any other ability | Opponent | Legal ("superpower rule"), no foul. |
| Any ability | Dead ball / check ball / foul called / free throw | Refused by phase (`allowsAbilities() == false`). |
| Any ability | FOULED action | FOULED has priority 8 and forces: it cancels the current action; abilities wait until it ends. |
| Sprint | Stamina 0 | Sprint ends, normal speed. |
| Freeze / stun | Any input | No movement, shooting, stealing or jumping; an action already started finishes. |
| Slow | Movement | Speed multiplier only. |
| No-shoot / shot penalty | Shoot input | No-shoot: shoot refused with a hint. Penalty: lower make chance. |
| Green Light (Focus Aura etc.) | Shot meter | Guaranteed green on the next release ("LOCK" above the meter). |
| Foul called | Ball in the air (non-shooting foul elsewhere) | Deferred until the shot resolves, so a basket is never wiped out by an unrelated whistle. |
| Foul called | Another foul the same frame | First in priority order wins; the queue is cleared on the phase change. |
| Free throw | Abilities / AI defense / clock | All off. Only the shooter may queue interactions. |
| Free throw | Rebound after last miss | Ball goes LIVE; normal rebound contest. |
| Free throw | Possession awarded (10+, T, U) | After the last FT (made or missed) → check ball for the fouled team. |
| Clear rule | Shot before clearing | Shoot refused with "Clear the ball behind the arc first!"; passes allowed. |
| Overtime | Scoring | First team to `rules.overtimePoints` (2) more points wins. |
| Any state | Score | Score only increases; checked every frame in `SelfTests`. |

## Bug classes and what prevents them

| Bug class | Prevention |
|---|---|
| Double scoring | `resolveShot` returns if the ball no longer carries that shot; SCORE is one interaction. |
| Scoring on a dead ball | Interactions are only accepted during play phases (or from the FT shooter) and are cleared on phase change. |
| Ball stuck / duplicated / owner without ball | One `Ball`; `giveTo` validated; `validate()` checked every frame in tests; a self-heal in FREE_THROW counts as an anomaly (tests require 0). |
| Player inside the hoop or each other | `court.clamp`, stanchion bounds, soft separation every tick; tests count deep overlaps. |
| z below the floor | Actions clamp z ≥ 0; tests check it. |
| Timer drift | Fixed 60 Hz step (`GameLoop`), clocks only run in phases that allow it. |
| Negative cooldowns | Cooldowns clamp at 0 (`Ability`). |
| Infinite foul loops | Pair cooldown 1.5 s, calls end live play, FT phase accepts no new fouls. |
| Animation frozen on last frame | Non-looping actions end (`Action.update` finishes at its duration); the controller falls back to locomotion. |
| Abilities in forbidden phases | `MatchPhase.allowsAbilities()` + action priority rule. |
