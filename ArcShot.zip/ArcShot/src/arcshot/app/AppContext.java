package arcshot.app;

import arcshot.achievement.AchievementManager;
import arcshot.achievement.CareerStatsTracker;
import arcshot.core.GameEventBus;
import arcshot.core.SoundManager;
import arcshot.court.MatchConfig;
import arcshot.court.MatchSummary;
import arcshot.save.Profile;
import arcshot.save.SaveManager;
import arcshot.ui.ScreenManager;
import arcshot.ui.ThemeSkin;
import arcshot.ui.screens.MainMenuScreen;
import arcshot.ui.screens.MatchScreen;
import arcshot.ui.screens.ResultsScreen;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.swing.JFrame;

/**
 * The application's shared services (save data, event bus, achievements, sound, skin, screens) in one place,
 * passed to every screen. Also offers the common navigation actions.
 * <p>
 * OOP pillar: <b>ENCAPSULATION</b> - screens receive what they need through getters instead of global variables.
 */
public final class AppContext {
    private final JFrame window;
    private final ScreenManager screens = new ScreenManager();
    private final SaveManager saveManager = new SaveManager();
    private final Profile profile;
    private final GameEventBus bus = new GameEventBus();
    private final AchievementManager achievements;
    private final SoundManager sound = new SoundManager();
    private final List<GameMode> modes = new ArrayList<>();
    private ThemeSkin skin;

    public AppContext(JFrame window) {
        this.window = window;
        this.profile = saveManager.load();
        this.achievements = new AchievementManager(profile, saveManager, bus);
        bus.subscribe(new CareerStatsTracker(profile));
        bus.subscribe(achievements);
        bus.subscribe(sound);
        this.skin = new ThemeSkin(profile.getSettings().getSkin());
        applyAudio();
        modes.add(new ThreeOnThreeMode());
        modes.add(new MessengerMode());
        modes.add(new PracticeMode());
    }

    public JFrame window() { return window; }

    public ScreenManager screens() { return screens; }

    public Profile profile() { return profile; }

    public SaveManager saves() { return saveManager; }

    public GameEventBus bus() { return bus; }

    public AchievementManager achievements() { return achievements; }

    public SoundManager sound() { return sound; }

    public ThemeSkin skin() { return skin; }

    public List<GameMode> modes() { return Collections.unmodifiableList(modes); }

    /** Re-reads the skin after it is changed in Settings. */
    public void reloadSkin() {
        skin = new ThemeSkin(profile.getSettings().getSkin());
    }

    public void applyAudio() {
        sound.setVolume(profile.getSettings().getVolume() / 100f);
        sound.setMuted(profile.getSettings().isMuted());
    }

    public void save() {
        saveManager.save(profile);
    }

    // ---- navigation -----------------------------------------------------------------------------------------

    public void showMainMenu() {
        screens.replaceAll(new MainMenuScreen(this));
    }

    public void back() {
        screens.pop();
    }

    /** Opens a match on top of the current screen (class select stays underneath for "Back"). */
    public void startMatch(MatchConfig config) {
        save();
        screens.push(new MatchScreen(this, config));
    }

    public void showResults(MatchSummary summary, MatchConfig config) {
        screens.replaceTop(new ResultsScreen(this, summary, config, achievements.getUnlockedThisMatch()));
    }

    public void quit() {
        save();
        System.exit(0);
    }
}
