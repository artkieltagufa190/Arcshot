package arcshot.achievement;

import arcshot.core.GameEvent;

/**
 * Must be done within ONE match (e.g. 5 blocks in a match). Saved progress = best match so far.
 * OOP pillars: <b>INHERITANCE</b> (extends Achievement) and <b>POLYMORPHISM</b> (overrides handle() / progress).
 */
public class SingleMatchAchievement extends Achievement {
    private final EventFilter filter;
    private final int target;
    private int current;

    public SingleMatchAchievement(String id, String name, String description, String hint,
                                  AchievementTier tier, AchievementBranch branch, EventFilter filter, int target) {
        super(id, name, description, hint, tier, branch);
        this.filter = filter;
        this.target = Math.max(1, target);
    }

    @Override
    public int getTarget() { return target; }

    @Override
    public void onMatchStarted(AchievementContext ctx) {
        current = 0;
    }

    @Override
    public void handle(GameEvent event, AchievementContext ctx) {
        if (filter.matches(event)) {
            current++;
            if (current > ctx.getProgress(getId())) {
                ctx.setProgress(getId(), current);
            }
        }
    }

    /** For subclasses that need to reset mid-match (streaks). */
    protected void resetCurrent() {
        current = 0;
    }
}
