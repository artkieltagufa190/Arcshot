package arcshot.render.sprite;

import arcshot.anim.Facing;
import java.awt.Graphics2D;

/**
 * Draws one frame of a character sheet with its feet at a screen point.
 * OOP pillar: <b>ABSTRACTION</b> - "draw this animation frame here" hides rows, origins and mirroring.
 */
public final class AnimatedSprite {
    private AnimatedSprite() { }

    public static void draw(Graphics2D g, SpriteSheet sheet, String anim, Facing facing, int frame, boolean flip,
                            int feetX, int feetY) {
        g.drawImage(sheet.frame(anim, facing, frame, flip), feetX - (flip ? sheet.getFrameW() - 1 - sheet.getOriginX() : sheet.getOriginX()),
                feetY - sheet.getOriginY(), null);
    }
}
