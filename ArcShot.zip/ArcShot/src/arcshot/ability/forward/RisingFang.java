package arcshot.ability.forward;

import arcshot.ability.AbilitySlot;
import arcshot.ability.ActiveAbility;
import arcshot.court.Match;
import arcshot.effect.SpeedBoostEffect;
import arcshot.effect.UnblockableEffect;
import arcshot.player.Player;

/**
 * Forward Q (default): an explosive drive; your shot during the drive cannot be blocked.
 * OOP pillars: <b>INHERITANCE</b> (extends ActiveAbility / Ultimate) and <b>POLYMORPHISM</b> (overrides perform() and the optional hooks).
 */
public class RisingFang extends ActiveAbility {
    public RisingFang() {
        super("forward.rising_fang", AbilitySlot.Q, 10);
    }

    @Override
    protected boolean meetsRequirements(Player owner, Match match) {
        return hasBall(owner, match);
    }

    @Override
    protected void perform(Player owner, Match match) {
        owner.applyEffect(new SpeedBoostEffect("rising_fang", param("duration", 1.2), param("speed", 1.6), false));
        owner.applyEffect(new UnblockableEffect("fang", param("unblockable", 1.8), false));
    }

    @Override
    protected double activeDuration() {
        return param("duration", 1.2);
    }

    @Override
    protected void whileActive(double dt, Player owner, Match match) {
        match.fx().trail("fang", owner.getX(), owner.getY() - 14, 10);
    }

    @Override
    public boolean aiShouldUse(Player owner, Match match) {
        return hasBall(owner, match) && !match.needsClear()
                && match.getCourt().distanceToHoop(owner.getX(), owner.getY()) < 330
                && match.nearestOpponent(owner, 90) != null;
    }
}
