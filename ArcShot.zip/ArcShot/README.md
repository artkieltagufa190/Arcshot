# ArcShot – Basketball 2D (OOP Finals Project)

A Java Swing basketball game with two modes:

* **3x3 Half Court** (new): you plus 2 AI teammates against 3 AI opponents. Three classes (Guard, Forward, Big), Q/E/R abilities, ultimates, perks, a 35-achievement unlock tree, loadouts and cosmetics.
* **Classic Shootout** (the original Messenger-style game): the same game logic as v0.1.10, reskinned with the shared theme and hosted in the new menu.

There's also a **Practice Court** for testing abilities and loadouts.

**v3 upgrade pass (retro + rules).** The 3x3 match now has these changes:
- It renders as **retro pixel art**: 640x360, integer-scaled, from an angled broadcast camera, with a z-axis
  (height) and depth sorting.
- Players are generated **sprites** with recolored team colors.
- One **action at a time** per player, driven by animation frame events.
- **Layups and dunks.**
- **Two referees** and **FIBA 3x3 fouls and free throws**. Free throws use a 2K-style arc-arrow aim.
- **Debug overlay, scenario keys and self-tests.**

The v2 smooth view is still there (Settings → Match graphics). See `CHANGELOG.md` and
`INTEGRATION_GUIDE.md`.

Pure Java + Swing/AWT. No external libraries. The code is compiled at **Java 10** level (`--release 10`), matching the original project. Any JDK from 10 up can build and run it.

---

## 1. Run it

### One command (macOS / Linux / Git Bash)
```sh
./build.sh            # compiles into out/ and runs the game
./build.sh compile    # compile only
./build.sh jar        # builds ArcShot.jar  ->  java -jar ArcShot.jar
./build.sh test       # compile + run the self-tests (rules table + headless matches), prints PASSED/FAILED
./build.sh sprites    # regenerate resources/sprites with tools/SpriteSheetGenerator
```

### One command (Windows)
```bat
build.bat             REM or: build.bat compile / jar / test / sprites
```

### Manually
```sh
javac -encoding UTF-8 -d out @sources.txt      # sources.txt = every .java under src/
cp -R resources/* out/
java -cp out arcshot.App
```

### From an IDE
| IDE | Steps |
|---|---|
| **Eclipse** | File > Import > *Existing Projects into Workspace* and pick this folder. `.project` and `.classpath` are included: `src` and `resources` are source folders, output goes to `bin`. Run `arcshot.App`. |
| **VS Code** (Java Extension Pack) | Open the folder. `.vscode/settings.json` already sets `src` + `resources` as source paths. Run `arcshot.App` with the Run button above `main`. |
| **IntelliJ IDEA** | Open the folder, mark `src` as *Sources Root* and `resources` as *Resources Root*, then run `arcshot.App`. |

**Working directory:** run from this folder (`ArcShot/`) so that live balance tweaking (F5) can find `resources/config/balance.properties`. Everything else also loads from the classpath, so a different working folder still works.

---

## 2. Controls (rebind in Settings)

| Key | Offense | Defense |
|---|---|---|
| W A S D | Move | Move |
| Space (hold, release) | **Context shoot:** jump shot (release in the **green** zone), or a **layup / dunk** when you press it driving at the rim. Free throws: hold until the arrow tip sits on the rim. | Jump to block (near a loose ball: rebound jump) |
| F | Pass (aim with WASD) | Steal |
| Shift | Sprint (uses stamina) | Sprint |
| Q / E | Abilities (cooldown) | Abilities |
| R | Ultimate (only when the meter is full) | Ultimate |
| Tab | Switch controlled player | Switch controlled player |
| Esc | Pause menu | Pause menu |

* With a teammate holding the ball, **F calls for the pass**.
* **Debug:** F1 FPS counter, F3 debug overlay (actions, frames, z, ball state, phase, fouls, hitboxes), F5 reload `balance.properties` live.
  With F3 on, the **scenario keys** set up a situation to test: F6 shooting foul, F7 dunk, F8 block, F9 out of bounds, F10 seventh team foul, F11 free throws.
* **Practice:** C refills every cooldown and ultimate. 1 / 2 / 3 switches to the Guard / Forward / Big. 4 = free-throw drill, 5 = dunk drill. Tips rotate at the top.
* **Classic Shootout:** drag the ball back with the mouse and release to shoot. Esc returns to the menu.

## 3. Rules (FIBA 3x3 style; all values live in `resources/config/balance.properties`, details in `docs/RULES.md`)
* 1 point inside the arc, 2 outside, 1 per free throw. First to 21, or the higher score when the clock runs out (6 minutes by default; Settings → Game length 4/6/8/10).
* A tie at the buzzer goes to **overtime: the first team to score 2 points wins** (`rules.overtimePoints=2`).
* After a made basket or last free throw: the defense takes the ball under the basket and must **clear** it behind the arc.
* After a steal or defensive rebound: **clear the ball** behind the arc before you can shoot. After dead balls and normal fouls: **check ball** at the top of the arc.
* 12-second shot clock. It resets when the ball hits the rim. A violation is a turnover.
* **Fouls:** fouled while shooting inside = 1 FT, outside = 2 FT, made shot = basket + 1 FT. Team fouls 7–9 = 2 FT; 10+ = 2 FT and the ball. Offensive foul = turnover, no FT. Technical = 1 FT, unsportsmanlike = 2 FT (+ ball), counts as 2 team fouls. Settings: **Foul frequency** (Off / Low / Normal / High) and **Strict refs**.
* Abilities are legal ("superpower rule") except the ones listed in `foul.foulableAbilities` (Quake Fist, Bull Rush).
* The ultimate meter fills from scoring, steals, blocks, assists, rebounds, and slowly over time. It carries over between possessions and resets every match.

---

## 4. Project layout and team split

```
ArcShot/
  src/arcshot/
    App.java              entry point
    app/                  AppContext (shared services + navigation), GameMode + 3 modes      [D]
    core/                 GameLoop, Balance (config), GameEventBus/Event/Listener, SoundManager [A]
    court/                Match, Court + CourtGeometry, Ball, Team, ShotAttempt, MatchPhase,  [A]
                          PhaseMachine, Interaction, FreeThrowAim, CourtEntity + fields
    action/               ActionController, ActionType, Action + 8 actions (v3)             [A/B]
    anim/                 AnimationTable/AnimationDef (frames, fps, frame events), Facing (v3)[D]
    rules/                RulesConfig, RuleEngine, FoulDetector, Foul + 5 fouls, FreeThrowSequence (v3) [A]
    referee/              CourtActor, Referee, RefereeAI, RefereeCrew (v3)                  [A]
    ai/                   AIController (state machine), AIStrategy + 3 roles, Difficulty      [A]
    control/              PlayerController interface, Keyboard/Dummy controllers, KeyBindings [A]
    player/               abstract Player, Guard, Forward, Big, PlayerStats                   [B]
    ability/              Ability (template method), ActiveAbility, Ultimate, Registry, Factory [B]
      guard/ forward/ big/  the 24 concrete abilities                                         [B]
    effect/               StatusEffect hierarchy (Slow, Freeze, Barrier, ...)                  [B]
    perk/                 Perk hierarchy + PerkRegistry                                       [C]
    achievement/          Achievement hierarchy, Catalog, Manager, CareerStatsTracker         [C]
    reward/               Reward interface + 4 reward types                                   [C]
    save/                 Profile, Settings, Loadout, SaveManager                             [C]
    cosmetic/             Cosmetic, CosmeticRegistry                                          [C]
    ui/                   Theme, ThemeSkin, UIFactory, Screen, ScreenManager                  [D]
      components/         ThemedButton, RoundedPanel, ValueStepper, GameCanvas, ...           [D]
      screens/            every screen (menu, class select, match, results, ...)              [D]
    render/               MatchView, MatchRenderer (smooth v2), CourtRenderer, PlayerRenderer,[D]
                          HudRenderer, EffectRenderer, ParticleSystem
      retro/              RetroMatchRenderer, Projection, RetroCourtRenderer, RetroHud,      [D]
                          RetroParticles, RetroAbilityIcons, PixelFont (v3)
      sprite/             SpriteLoader, SpriteSheet, Palette, AnimatedSprite (v3)           [D]
    test/                 SelfTests (main-based, no JUnit) (v3)                              [A]
    messenger/            the original Messenger game (package line added, logic unchanged)   [D]
  resources/
    config/balance.properties   every gameplay number
    skins/anime.properties, street.properties
    fonts/                Anton + Fira Sans (SIL Open Font License, see OFL-*.txt)
    images/               original Messenger pixel art
    sounds/               optional .wav files (see sounds/README.md)
    sprites/              generated sprite sheets + manifests (see sprites/README.md)
  tools/SpriteSheetGenerator.java   makes the sprites (puppet rig, mask colors, manifests)
  docs/                   RULES.md, MECHANICS_MATRIX.md, VISUAL_SPEC.md
```

**Member A** owns the engine/rules/AI, **B** the players/abilities/effects, **C** achievements/saves/perks/cosmetics, **D** UI/rendering/Messenger.

The areas only touch each other through these contracts, so the four of you can work in parallel:

| Contract | Between | What it says |
|---|---|---|
| `PlayerController` | A ↔ input/AI | `fillInput(player, match, input, dt)` |
| `Ability` / `ActiveAbility` / `Ultimate` | B ↔ A | `activate()`, `update()`, `aiShouldUse()` |
| `StatusEffect` | B ↔ A | neutral modifier methods (`speedMultiplier()`, ...) |
| `FxSink` | A/B ↔ D | gameplay asks for effects **by key**; rendering decides the look |
| `GameEventBus` + `GameEvent` | A ↔ C, D | gameplay publishes events; achievements, HUD and sound subscribe |
| `Reward` | C | `grant(profile)` |
| `Screen` | D | `onEnter / onResume / onHide / onExit` |

## 5. How the threads work (no UI freezes)
`MatchScreen` starts a `GameLoop` thread with a fixed 60 steps per second. That thread updates the `Match` and draws each frame into an off-screen image (double buffering): 640×360 for the retro view, 1280×720 for the smooth view. Inside one tick the order is fixed: input → AI → effects/cooldowns → actions (frame events) → movement/collision → ball → rules and scoring (in priority order) → clocks → events (see `docs/MECHANICS_MATRIX.md`). The Swing thread only scales and copies the finished image (letterboxed), so it never waits on game logic. Key presses are stored in a thread-safe `KeyboardState`. Pause, restart and debug commands are queued and run on the game thread, so game state is only ever touched by one thread.

---

## 6. How to add a new ability
1. Create a class in `ability/guard|forward|big/` that extends `ActiveAbility` (Q/E) or `Ultimate` (R).
2. Implement `perform(owner, match)`. Optionally override `meetsRequirements`, `activeDuration`, `whileActive`, `onEnd` and `aiShouldUse`.
3. Read every number with `param("cooldown", 10)`, then add matching lines to `balance.properties`:
   `ability.<class>.<name>.cooldown=10`
4. Register it in `AbilityRegistry` with one line:
   `register("guard.my_move", PlayerClass.GUARD, AbilitySlot.Q, false, MyMove::new);`
5. Add its name and description to both skins:
   `ability.guard.my_move.name=...` and `.desc=...` (plus an optional icon color `color.ability.guard.my_move=#RRGGBB`).
6. Make an achievement reward it: `.reward(new AbilityUnlock("guard.my_move"))`.

New effects work the same way: extend `StatusEffect` and override only the modifiers you need. Visuals come from `EffectRenderer` by the effect's id.

## 7. How to add an achievement
Add one entry in `AchievementCatalog.create()`, for example:
```java
list.add(new CounterAchievement("dunk_machine", "Dunk Machine", "Dunk 20 times.", "Get close and shoot.",
        ALL_STAR, SCORING, Filters.user(GameEventType.DUNK), t("dunk_machine", 20))
        .requires("first_bucket")
        .reward(new CosmeticUnlock(null, "jersey.gold")));
```
Pick the type that fits the rule:
* `CounterAchievement`: career totals.
* `SingleMatchAchievement`: X in one match.
* `StreakAchievement`: X in a row; a reset event breaks the streak.
* `ConditionalAchievement`: a condition on the final `MatchSummary`.
* `CompositeAchievement`: needs other achievements.

The tree screen places the new node by its tier and branch automatically.

## 8. Sprites, animations and frame events
* Sprites are generated by `tools/SpriteSheetGenerator.java` (`./build.sh sprites`). The output goes to
  `resources/sprites/<guard|forward|big|ref>/`: `sheet_a.png` and `sheet_b.png` (two hair styles) plus
  `manifest.properties`.
* Team colors are **mask colors** that `SpriteLoader` recolors in code, so one sheet covers every jersey,
  skin and shoe color.
* A sheet is 48x64 frames. Each row is `animation * 3 + facing` (back / front / side, with left = side
  mirrored). Each column is a frame. The manifest stores per-frame anchors (hand = where the ball is drawn,
  number, head).
* **Frame events drive gameplay:**
  - `ball_release`: the shot or pass leaves the hand;
  - `takeoff`: foul check;
  - `contact_start` / `contact_end`: block window;
  - `rim_touch`: the dunk scores;
  - `grab`: rebound;
  - `contact`: steal;
  - `foot_land`.

  They are defined in `anim/AnimationTable.java` and can be re-timed in the manifest
  (`shoot.events=2:takeoff,4:ball_release,6:foot_land`).
* **To add an animation:**
  1. Add its name to `AnimationTable.PLAYER_ANIMS` and give it a `def(...)` there.
  2. Add a `case` with joint angles in `SpriteSheetGenerator.pose(...)`.
  3. Regenerate the sprites.
  4. Return its name from an `Action` (the constructor's animation argument).
* **To change the art:** see the *Art tweak section* in `resources/sprites/README.md`: body-shape constants
  per class, mask colors, and poses. You can also paint over the PNGs, keeping the mask colors.
* If a sprite file is missing, a simple placeholder figure is drawn, so the game never crashes.
* **Before shipping a sprite you found online, check its license and add a credit line to this README.**

## 9. Saves, demo helpers and balance
* **Progress, unlocks, loadouts, cosmetics and settings** are saved to `~/.arcshot/profile.properties` (on Windows, `C:\Users\<you>\.arcshot\`). A missing file starts a fresh profile. A corrupt file is renamed to `profile.corrupt` and a fresh profile is used.
* **Demo helpers for the defense:** open *Settings* and **click the version line at the bottom 5 times**. This reveals *Developer / Demo options*:
  * **Unlock All (Demo Mode)** makes every ability, perk and cosmetic available.
  * **Reset Progress**
  * **Reload balance**
* **Balance:** every cooldown, duration, radius, meter gain, rule and unlock threshold is in `resources/config/balance.properties`. Edit it during a match and press **F5**.

## 10. Credits
* Fonts: **Anton** and **Fira Sans**, SIL Open Font License 1.1 (`resources/fonts/OFL-*.txt`).
* Messenger pixel art: made by the team (v0.1.x).
* Retro match sprites, court and HUD font: generated in code by this project (`tools/SpriteSheetGenerator.java`, `render/retro/`). Teams, sponsors and logos are fictional.
* Rules reference: FIBA 3x3 Official Rules of the Game (Art. 7 Fouls / Free throws).
* Sound files: none bundled. The game runs silently until you add `.wav` files.
