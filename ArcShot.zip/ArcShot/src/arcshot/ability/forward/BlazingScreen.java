package arcshot.ability.forward;

import arcshot.ability.AbilitySlot;
import arcshot.ability.ActiveAbility;
import arcshot.court.Match;
import arcshot.court.PickScreen;
import arcshot.effect.SpeedBoostEffect;
import arcshot.player.Player;

/**
 * Forward E (alternate): plant a burning screen that blocks defenders; your nearest teammate gets a speed burst.
 * OOP pillars: <b>INHERITANCE</b> (extends ActiveAbility / Ultimate) and <b>POLYMORPHISM</b> (overrides perform() and the optional hooks).
 */
public class BlazingScreen extends ActiveAbility {
    public BlazingScreen() {
        super("forward.blazing_screen", AbilitySlot.E, 11);
    }

    @Override
    protected void perform(Player owner, Match match) {
        match.addEntity(new PickScreen(owner, "blazing_screen", owner.getX(), owner.getY(), param("radius", 24),
                param("duration", 3), false, 1.0));
        Player best = null;
        for (Player mate : match.teammatesOf(owner)) {
            if (best == null || mate.distanceTo(owner) < best.distanceTo(owner)) {
                best = mate;
            }
        }
        if (best != null) {
            best.applyEffect(new SpeedBoostEffect("screen_boost", param("boostTime", 2), param("boost", 1.3), false));
        }
        match.fx().ring("blazing_screen", owner.getX(), owner.getY(), 40, 0.4);
    }

    @Override
    public boolean aiShouldUse(Player owner, Match match) {
        Player holder = match.getBall().getHolder();
        return holder != null && holder != owner && holder.getSide() == owner.getSide() && owner.distanceTo(holder) < 150;
    }
}
