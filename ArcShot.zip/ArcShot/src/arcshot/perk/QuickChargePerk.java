package arcshot.perk;

import arcshot.core.Balance;

/**
 * +15% ultimate meter gain.
 * OOP pillars: <b>INHERITANCE</b> (extends Perk) and <b>POLYMORPHISM</b> (overrides one hook).
 */
public class QuickChargePerk extends Perk {
    public QuickChargePerk() {
        super("quick_charge", "Quick Charge", "+15% ultimate meter gain");
    }

    @Override
    public double ultimateGainMultiplier() { return Balance.d("perk.quick_charge.multiplier", 1.15); }
}
