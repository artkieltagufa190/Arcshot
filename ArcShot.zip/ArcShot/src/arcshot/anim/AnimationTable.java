package arcshot.anim;

import java.io.InputStream;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

/**
 * The single list of every animation, its timing and its frame events. Used by:
 * the sprite generator tool (to draw the right number of frames), the gameplay {@code Action}s (durations and
 * events) and the renderer (frame index). A character's {@code manifest.properties} may override fps/events,
 * so artists can retime without touching code.
 * <p>
 * Frame events used by gameplay: {@code takeoff, ball_release, rim_touch, contact_start, contact_end, contact,
 * grab, foot_land, dribble_hit, foot_step}.
 * OOP pillar: <b>ABSTRACTION</b> - callers ask {@code AnimationTable.get("dunk")} and never parse files.
 */
public final class AnimationTable {
    /** Player animations (the order is also the row order in the sprite sheets). */
    public static final String[] PLAYER_ANIMS = {
        "idle", "run", "dribble", "dribble_run", "stance", "shoot", "layup", "dunk", "dunk2", "windmill",
        "block", "steal", "pass", "rebound", "fouled", "celebrate", "cast", "cast_strike"
    };
    /** Referee animations. */
    public static final String[] REF_ANIMS = {
        "idle", "run", "whistle", "signal_foul", "signal_point", "signal_out", "handoff"
    };

    private static final Map<String, AnimationDef> DEFAULTS = new LinkedHashMap<>();
    private static final Map<String, Map<String, AnimationDef>> BY_CHARACTER = new LinkedHashMap<>();

    static {
        def("idle", 4, 5, true, "");
        def("run", 6, 12, true, "1:foot_step,4:foot_step");
        def("dribble", 4, 8, true, "2:dribble_hit");
        def("dribble_run", 6, 12, true, "1:foot_step,3:dribble_hit,4:foot_step");
        def("stance", 4, 6, true, "");
        def("shoot", 7, 14, false, "2:takeoff,4:ball_release,6:foot_land");
        def("layup", 7, 12, false, "2:takeoff,4:ball_release,6:foot_land");
        def("dunk", 8, 12, false, "1:takeoff,4:rim_touch,7:foot_land");
        def("dunk2", 8, 12, false, "1:takeoff,4:rim_touch,7:foot_land");
        def("windmill", 9, 12, false, "1:takeoff,5:rim_touch,8:foot_land");
        def("block", 5, 12, false, "1:contact_start,3:contact_end,4:foot_land");
        def("steal", 3, 12, false, "1:contact");
        def("pass", 3, 14, false, "1:ball_release");
        def("rebound", 5, 12, false, "1:takeoff,2:grab,4:foot_land");
        def("fouled", 4, 10, false, "");
        def("celebrate", 4, 6, true, "");
        def("cast", 4, 12, false, "");
        def("cast_strike", 4, 14, false, "2:contact");
        // referee
        def("whistle", 3, 6, false, "1:whistle");
        def("signal_foul", 3, 6, true, "");
        def("signal_point", 3, 6, true, "");
        def("signal_out", 3, 6, true, "");
        def("handoff", 3, 6, false, "");
    }

    private AnimationTable() { }

    private static void def(String name, int frames, double fps, boolean loop, String events) {
        DEFAULTS.put(name, new AnimationDef(name, frames, fps, loop, events));
    }

    /** Default (code) definition. */
    public static AnimationDef get(String name) {
        AnimationDef d = DEFAULTS.get(name);
        return d != null ? d : DEFAULTS.get("idle");
    }

    /** Definition for a character ("guard", "forward", "big", "ref"), honouring manifest overrides. */
    public static synchronized AnimationDef get(String character, String name) {
        Map<String, AnimationDef> map = BY_CHARACTER.get(character);
        if (map == null) {
            map = load(character);
            BY_CHARACTER.put(character, map);
        }
        AnimationDef d = map.get(name);
        return d != null ? d : get(name);
    }

    public static Map<String, AnimationDef> defaults() {
        return Collections.unmodifiableMap(DEFAULTS);
    }

    private static Map<String, AnimationDef> load(String character) {
        Map<String, AnimationDef> map = new LinkedHashMap<>();
        Properties p = new Properties();
        try (InputStream in = AnimationTable.class.getResourceAsStream("/sprites/" + character + "/manifest.properties")) {
            if (in != null) {
                p.load(in);
            }
        } catch (Exception ex) {
            return map; // missing / broken manifest: defaults are used
        }
        for (AnimationDef d : DEFAULTS.values()) {
            try {
                int frames = Integer.parseInt(p.getProperty(d.getName() + ".frames", String.valueOf(d.getFrames())));
                if (frames != d.getFrames()) {
                    continue; // frame count must match the drawn sheet
                }
                double fps = Double.parseDouble(p.getProperty(d.getName() + ".fps", String.valueOf(d.getFps())));
                boolean loop = Boolean.parseBoolean(p.getProperty(d.getName() + ".loop", String.valueOf(d.isLoop())));
                String ev = p.getProperty(d.getName() + ".events", d.eventSpec());
                map.put(d.getName(), new AnimationDef(d.getName(), frames, fps, loop, ev));
            } catch (NumberFormatException ex) {
                // keep default
            }
        }
        return map;
    }
}
