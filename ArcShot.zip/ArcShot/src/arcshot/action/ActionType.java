package arcshot.action;

/**
 * Every action a player can be in, with its rules. Locomotion types (IDLE ... DEFENSIVE_STANCE) are never
 * "requested": the {@link ActionController} derives them from movement when no other action is running.
 * <p>
 * Columns: priority, interruptible, forces (may cut a non-interruptible action of lower priority),
 * locksMovement, locksShooting, locksPassing, rootMotion.
 * OOP pillar: <b>ENCAPSULATION</b> - each constant keeps its rule data in private fields behind getters.
 */
public enum ActionType {
    IDLE(0, true, false, false, false, false, false),
    WALK(0, true, false, false, false, false, false),
    SPRINT(0, true, false, false, false, false, false),
    DRIBBLE_IDLE(0, true, false, false, false, false, false),
    DRIBBLE_MOVE(0, true, false, false, false, false, false),
    DEFENSIVE_STANCE(0, true, false, false, false, false, false),
    CELEBRATE(1, true, false, false, false, false, false),
    PASS(3, false, false, false, true, true, false),
    STEAL_SWIPE(3, false, false, true, true, true, false),
    CROSSOVER(3, false, false, false, true, true, true),
    ABILITY_CAST(4, false, false, true, true, true, false),
    BLOCK(4, false, false, true, true, true, false),
    REBOUND_JUMP(4, false, false, true, true, true, false),
    JUMP_SHOT(5, false, false, true, true, true, false),
    FREE_THROW(5, false, false, true, true, true, false),
    LAYUP(6, false, false, true, true, true, true),
    DASH(6, false, false, true, false, true, true),
    DUNK(7, false, true, true, true, true, true),
    FOULED(8, false, true, true, true, true, false);

    private final int priority;
    private final boolean interruptible;
    private final boolean forces;
    private final boolean locksMovement;
    private final boolean locksShooting;
    private final boolean locksPassing;
    private final boolean rootMotion;

    ActionType(int priority, boolean interruptible, boolean forces, boolean locksMovement, boolean locksShooting,
               boolean locksPassing, boolean rootMotion) {
        this.priority = priority;
        this.interruptible = interruptible;
        this.forces = forces;
        this.locksMovement = locksMovement;
        this.locksShooting = locksShooting;
        this.locksPassing = locksPassing;
        this.rootMotion = rootMotion;
    }

    public int getPriority() { return priority; }

    public boolean isInterruptible() { return interruptible; }

    public boolean forces() { return forces; }

    public boolean locksMovement() { return locksMovement; }

    public boolean locksShooting() { return locksShooting; }

    public boolean locksPassing() { return locksPassing; }

    public boolean hasRootMotion() { return rootMotion; }

    /** True for the movement-derived types. */
    public boolean isLocomotion() { return priority == 0; }

    /** Whether an action of type {@code next} may replace a running action of this type. */
    public boolean canBeReplacedBy(ActionType next) {
        if (interruptible) {
            return next.priority >= priority;
        }
        return next.forces && next.priority > priority;
    }
}
