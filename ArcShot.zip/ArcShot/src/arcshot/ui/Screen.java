package arcshot.ui;

import arcshot.app.AppContext;
import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.BorderFactory;
import javax.swing.JPanel;

/**
 * Base class of every screen (menu, settings, match, ...). The {@link ScreenManager} calls the lifecycle hooks.
 * <p>
 * OOP pillars: <b>ABSTRACTION</b> + <b>INHERITANCE</b> (all screens share the background, padding and lifecycle) and
 * <b>POLYMORPHISM</b> (the manager calls {@code onEnter()} etc. without knowing the concrete screen).
 */
public abstract class Screen extends JPanel {
    protected final AppContext app;

    protected Screen(AppContext app) {
        super(new BorderLayout());
        this.app = app;
        setOpaque(true);
        setBackground(Theme.BG);
        setBorder(BorderFactory.createEmptyBorder(Theme.S5, Theme.S7, Theme.S5, Theme.S7));
    }

    /** Called when the screen is pushed for the first time. */
    public void onEnter() { }

    /** Called when the screen becomes visible again after the screen above it was closed. */
    public void onResume() { }

    /** Called when another screen is pushed on top of this one. */
    public void onHide() { }

    /** Called when the screen is removed for good. Stop timers and threads here. */
    public void onExit() { }

    @Override
    protected void paintComponent(Graphics g0) {
        Graphics2D g = (Graphics2D) g0.create();
        Theme.quality(g);
        Theme.paintBackground(g, getWidth(), getHeight());
        g.dispose();
    }
}
