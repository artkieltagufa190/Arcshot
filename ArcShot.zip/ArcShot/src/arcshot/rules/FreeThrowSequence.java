package arcshot.rules;

import arcshot.player.Player;
import arcshot.player.TeamSide;

/**
 * State of one free-throw trip: shooter, how many shots, how many taken/made, and the possession that follows.
 * The match runs the FREE_THROW phase and reports each result here.
 * OOP pillar: <b>ENCAPSULATION</b>.
 */
public final class FreeThrowSequence {
    private final Player shooter;
    private final int total;
    private final TeamSide possessionAfter;
    private final String reason;
    private int taken;
    private int made;
    private boolean lastMade;

    public FreeThrowSequence(Player shooter, int total, TeamSide possessionAfter, String reason) {
        this.shooter = shooter;
        this.total = Math.max(1, total);
        this.possessionAfter = possessionAfter;
        this.reason = reason;
    }

    public void record(boolean wasMade) {
        taken++;
        lastMade = wasMade;
        if (wasMade) {
            made++;
        }
    }

    public Player getShooter() { return shooter; }

    public int getTotal() { return total; }

    public int getTaken() { return taken; }

    public int getMade() { return made; }

    public boolean isLastMade() { return lastMade; }

    /** True when the attempt about to be taken is the last one. */
    public boolean isLastAttempt() { return taken == total - 1; }

    public boolean isComplete() { return taken >= total; }

    public TeamSide getPossessionAfter() { return possessionAfter; }

    public String getReason() { return reason; }
}
