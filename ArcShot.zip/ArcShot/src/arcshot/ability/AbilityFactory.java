package arcshot.ability;

import arcshot.player.PlayerClass;

/**
 * Factory pattern: builds fresh ability objects from string ids, falling back to the class default if an id is
 * unknown or for the wrong class/slot (e.g. from an old or edited save file).
 * OOP pillar: <b>ABSTRACTION</b> + <b>POLYMORPHISM</b> - returns base types, callers never use {@code new ShadowStep()}.
 */
public final class AbilityFactory {
    private AbilityFactory() { }

    /** A new instance of the ability with this id, or null if unknown. */
    public static Ability create(String id) {
        AbilityInfo info = AbilityRegistry.get(id);
        return info == null ? null : info.newInstance();
    }

    private static AbilityInfo valid(String id, PlayerClass pc, AbilitySlot slot) {
        AbilityInfo info = AbilityRegistry.get(id);
        if (info == null || info.getPlayerClass() != pc || info.getSlot() != slot) {
            info = AbilityRegistry.get(AbilityRegistry.defaultId(pc, slot));
        }
        return info;
    }

    public static ActiveAbility createActive(String id, PlayerClass pc, AbilitySlot slot) {
        return (ActiveAbility) valid(id, pc, slot).newInstance();
    }

    public static Ultimate createUltimate(String id, PlayerClass pc) {
        return (Ultimate) valid(id, pc, AbilitySlot.R).newInstance();
    }
}
