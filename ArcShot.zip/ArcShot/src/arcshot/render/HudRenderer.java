package arcshot.render;

import arcshot.ability.Ability;
import arcshot.ability.AbilitySlot;
import arcshot.achievement.Achievement;
import arcshot.control.InputAction;
import arcshot.core.Balance;
import arcshot.core.GameEvent;
import arcshot.core.GameEventListener;
import arcshot.core.GameEventType;
import arcshot.court.Ball;
import arcshot.court.Match;
import arcshot.court.Team;
import arcshot.effect.StatusEffect;
import arcshot.player.Player;
import arcshot.player.TeamSide;
import arcshot.ui.Theme;
import arcshot.ui.ThemeSkin;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.geom.Arc2D;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * The in-match HUD: scoreboard and clocks, team cards with stamina and ultimate meters, the Q/E/R ability bar with
 * radial cooldown sweeps, the shot-timing meter, banners, hints and achievement toasts.
 * <p>
 * It subscribes to the {@code GameEventBus} for achievement toasts, so gameplay never calls the HUD directly.
 * OOP pillar: <b>POLYMORPHISM</b> (a {@link GameEventListener}) and <b>ENCAPSULATION</b> (toast queue is private).
 */
public final class HudRenderer implements GameEventListener {
    private static final double TOAST_TIME = 4.0;

    /** A queued achievement toast. */
    private static final class Toast {
        final String title;
        final String sub;
        double age;

        Toast(String title, String sub) {
            this.title = title;
            this.sub = sub;
        }
    }

    private final RenderContext ctx;
    private final ConcurrentLinkedQueue<Toast> incoming = new ConcurrentLinkedQueue<>();
    private final List<Toast> toasts = new ArrayList<>();

    public HudRenderer(RenderContext ctx) {
        this.ctx = ctx;
    }

    @Override
    public void onEvent(GameEvent event) {
        if (event.getType() == GameEventType.ACHIEVEMENT_UNLOCKED && event.getPayload() instanceof Achievement) {
            Achievement a = (Achievement) event.getPayload();
            incoming.add(new Toast(a.getName(), a.getTier().getDisplayName() + " achievement unlocked"));
        }
    }

    public void update(double dt) {
        Toast t;
        while ((t = incoming.poll()) != null) {
            toasts.add(t);
        }
        Iterator<Toast> it = toasts.iterator();
        while (it.hasNext()) {
            Toast toast = it.next();
            toast.age += dt;
            if (toast.age > TOAST_TIME) {
                it.remove();
            }
        }
    }

    public void draw(Graphics2D g, Match m) {
        drawScoreboard(g, m);
        drawTeamPanel(g, m, m.getHome(), 16, true);
        drawTeamPanel(g, m, m.getAway(), 1031, false);
        Player c = m.getControlled();
        if (c != null) {
            drawAbilityBar(g, m, c);
            drawShotMeter(g, m, c);
        }
        drawChips(g, m);
        drawBanner(g, m);
        drawHint(g, m);
        drawToasts(g);
        if (ctx.isShowFps() || ctx.isDebug()) {
            g.setFont(Theme.semi(13));
            g.setColor(Theme.TEXT_MUTED);
            g.drawString(ctx.getFps() + " FPS", 16, 24);
        }
        if (ctx.isDebug()) {
            drawDebug(g, m);
        }
    }

    // ---- scoreboard -----------------------------------------------------------------------------------------

    private void drawScoreboard(Graphics2D g, Match m) {
        int x = 390;
        int y = 10;
        int w = 500;
        int h = 66;
        panel(g, x, y, w, h);
        Team home = m.getHome();
        Team away = m.getAway();
        g.setColor(home.getColor());
        g.fillRoundRect(x, y, 10, h - 4, 8, 8);
        g.setColor(away.getColor());
        g.fillRoundRect(x + w - 10, y, 10, h - 4, 8, 8);
        g.setFont(Theme.semi(14));
        g.setColor(Theme.TEXT_MUTED);
        g.drawString(trim(home.getName(), 16), x + 22, y + 22);
        int aw = g.getFontMetrics().stringWidth(trim(away.getName(), 16));
        g.drawString(trim(away.getName(), 16), x + w - 22 - aw, y + 22);
        g.setFont(Theme.display(40));
        g.setColor(Theme.TEXT);
        g.drawString(String.valueOf(home.getScore()), x + 22, y + 58);
        String as = String.valueOf(away.getScore());
        g.drawString(as, x + w - 22 - g.getFontMetrics().stringWidth(as), y + 58);
        // clock
        int cx = x + w / 2;
        g.setColor(Theme.BG);
        g.fillRoundRect(cx - 70, y + 8, 140, 46, 12, 12);
        g.setFont(Theme.display(28));
        String clock = m.isPractice() ? "PRACTICE" : (m.isOvertime() ? "OT" : m.getClockText());
        g.setColor(m.isOvertime() ? Theme.GOLD : Theme.TEXT);
        if (m.isPractice()) {
            g.setFont(Theme.display(22));
        }
        Theme.drawCentered(g, clock, cx, y + 28);
        if (!m.isPractice()) {
            double sc = m.getShotClock();
            g.setFont(Theme.semi(12));
            g.setColor(sc <= 4 ? Theme.DANGER : Theme.TEXT_MUTED);
            Theme.drawCentered(g, String.format("SHOT %.0f  |  TO %d", Math.ceil(sc), m.targetScore()), cx, y + 46);
        }
        // possession arrow
        boolean homeBall = m.getOffense() == TeamSide.HOME;
        g.setColor(Theme.ACCENT);
        int px = homeBall ? cx - 84 : cx + 78;
        g.fillOval(px, y + 26, 8, 8);
    }

    // ---- team cards -----------------------------------------------------------------------------------------

    private void drawTeamPanel(Graphics2D g, Match m, Team team, int x, boolean user) {
        int y = 96;
        g.setFont(Theme.bold(13));
        g.setColor(Theme.TEXT_MUTED);
        g.drawString(user ? "YOUR SQUAD" : "OPPONENTS", x + 4, y);
        y += 10;
        for (Player p : team.getPlayers()) {
            drawCard(g, m, p, team.getColor(), x, y, user);
            y += user ? 104 : 80;
        }
    }

    private void drawCard(Graphics2D g, Match m, Player p, Color color, int x, int y, boolean user) {
        int w = 233;
        int h = user ? 96 : 72;
        boolean controlled = p == m.getControlled();
        panel(g, x, y, w, h);
        if (controlled) {
            g.setColor(Theme.ACCENT_2);
            g.setStroke(new BasicStroke(2f));
            g.drawRoundRect(x + 1, y + 1, w - 3, h - 6, 14, 14);
        }
        g.setColor(color);
        g.fillOval(x + 12, y + 12, 30, 30);
        g.setFont(Theme.bold(14));
        g.setColor(Color.WHITE);
        Theme.drawCentered(g, String.valueOf(p.getNumber()), x + 27, y + 27);
        g.setFont(Theme.semi(15));
        g.setColor(Theme.TEXT);
        g.drawString(trim(p.getName(), 12), x + 52, y + 25);
        g.setFont(Theme.body(12));
        g.setColor(Theme.TEXT_MUTED);
        g.drawString(p.getPlayerClass().getDisplayName() + " - " + p.getStats().getPoints() + " pts", x + 52, y + 41);
        if (m.getBall().getState() == Ball.State.HELD && m.getBall().getHolder() == p) {
            g.setColor(Theme.ACCENT);
            g.fillOval(x + w - 26, y + 14, 14, 14);
            g.setColor(new Color(60, 30, 10));
            g.drawLine(x + w - 26, y + 21, x + w - 12, y + 21);
        }
        bar(g, x + 12, y + 50, w - 24, 6, p.getStamina() / 100.0, new Color(0x3DDC84), "");
        Color ult = p.isUltimateReady() ? Theme.mix(Theme.GOLD, Color.WHITE, 0.3 + 0.3 * Math.sin(m.getElapsed() * 8)) : Theme.GOLD;
        bar(g, x + 12, y + 60, w - 24, 6, p.getUltimateCharge() / 100.0, ult, "");
        if (user) {
            drawMiniAbilities(g, m, p, x + 12, y + 72);
        }
        drawEffectChips(g, p, x + 12, y + (user ? 2 : 66), w - 24, user);
    }

    private void drawMiniAbilities(Graphics2D g, Match m, Player p, int x, int y) {
        ThemeSkin skin = ctx.getSkin();
        g.setFont(Theme.body(11));
        int cx = x;
        for (AbilitySlot slot : AbilitySlot.values()) {
            Ability a = p.getAbility(slot);
            if (a == null) {
                continue;
            }
            boolean ready = a.getCooldownFraction(p) <= 0;
            g.setColor(ready ? Theme.TEXT : Theme.TEXT_MUTED);
            String txt = slot.name() + " " + trim(skin.abilityName(a.getId()), 9);
            g.drawString(txt, cx, y + 10);
            cx += 72;
        }
    }

    private void drawEffectChips(Graphics2D g, Player p, int x, int y, int w, boolean top) {
        if (p.getEffects().isEmpty()) {
            return;
        }
        g.setFont(Theme.bold(9));
        int cx = x + w;
        int count = 0;
        for (StatusEffect e : p.getEffects()) {
            if (count >= 3 || "screen_boost".equals(e.getId())) {
                continue;
            }
            String label = e.getLabel();
            int lw = g.getFontMetrics().stringWidth(label) + 8;
            cx -= lw + 3;
            g.setColor(e.isDebuff() ? new Color(0xB3263A) : new Color(0x1F7A4D));
            g.fillRoundRect(cx, y, lw, 12, 6, 6);
            g.setColor(Color.WHITE);
            g.drawString(label, cx + 4, y + 9);
            count++;
        }
    }

    // ---- ability bar ----------------------------------------------------------------------------------------

    private void drawAbilityBar(Graphics2D g, Match m, Player p) {
        int cy = 682;
        panel(g, 360, 646, 560, 70);
        g.setFont(Theme.semi(12));
        g.setColor(Theme.TEXT_MUTED);
        g.drawString("STAMINA", 376, 668);
        bar(g, 376, 674, 150, 8, p.getStamina() / 100.0, new Color(0x3DDC84), "");
        g.drawString("ULTIMATE", 376, 696);
        Color ult = p.isUltimateReady() ? Theme.mix(Theme.GOLD, Color.WHITE, 0.3 + 0.3 * Math.sin(m.getElapsed() * 8)) : Theme.GOLD;
        bar(g, 376, 702, 150, 8, p.getUltimateCharge() / 100.0, ult, "");
        int[] xs = {580, 650, 720};
        AbilitySlot[] slots = AbilitySlot.values();
        InputAction[] keys = {InputAction.ABILITY_Q, InputAction.ABILITY_E, InputAction.ULTIMATE};
        for (int i = 0; i < 3; i++) {
            drawAbilityIcon(g, m, p, p.getAbility(slots[i]), xs[i], cy, ctx.getKeys().shortName(keys[i]));
        }
        g.setFont(Theme.semi(14));
        g.setColor(Theme.TEXT);
        g.drawString(trim(p.getName(), 12) + "  #" + p.getNumber(), 768, 672);
        g.setFont(Theme.body(12));
        g.setColor(Theme.TEXT_MUTED);
        g.drawString(p.getPlayerClass().getDisplayName() + " - " + p.getPlayerClass().getRole(), 768, 690);
        g.drawString(ctx.getKeys().shortName(InputAction.SWITCH) + ": switch   "
                + ctx.getKeys().shortName(InputAction.PAUSE) + ": pause", 768, 706);
    }

    private void drawAbilityIcon(Graphics2D g, Match m, Player p, Ability a, int cx, int cy, String key) {
        if (a == null) {
            return;
        }
        int r = 27;
        ThemeSkin skin = ctx.getSkin();
        Color base = skin.color("ability." + a.getId(), classColor(p));
        double frac = a.getCooldownFraction(p);
        boolean ready = frac <= 0.0001;
        boolean ult = a.getSlot() == AbilitySlot.R;
        boolean usable = a.canUse(p, m);
        if (ult && ready) {
            new EffectRenderer(skin).glow(g, cx, cy, r + 16 + Math.sin(m.getElapsed() * 7) * 3, Theme.GOLD, 170);
        }
        g.setColor(Theme.BG);
        g.fillOval(cx - r, cy - r, r * 2, r * 2);
        g.setPaint(new GradientPaint(cx, cy - r, Theme.mix(base, Color.WHITE, 0.2), cx, cy + r, Theme.mix(base, Color.BLACK, 0.3)));
        g.fillOval(cx - r + 3, cy - r + 3, r * 2 - 6, r * 2 - 6);
        if (!ready) {
            g.setColor(new Color(10, 14, 26, 200));
            g.fill(new Arc2D.Double(cx - r + 3, cy - r + 3, r * 2 - 6, r * 2 - 6, 90, 360 * frac, Arc2D.PIE));
        } else if (!usable && !a.isActive()) {
            g.setColor(new Color(10, 14, 26, 90));
            g.fillOval(cx - r + 3, cy - r + 3, r * 2 - 6, r * 2 - 6);
        }
        g.setStroke(new BasicStroke(2.5f));
        g.setColor(a.isActive() ? Color.WHITE : (ready ? (ult ? Theme.GOLD : Theme.mix(base, Color.WHITE, 0.4)) : Theme.BORDER));
        g.drawOval(cx - r, cy - r, r * 2, r * 2);
        g.setColor(Color.WHITE);
        if (ready) {
            g.setFont(Theme.display(17));
            Theme.drawCentered(g, initials(skin.abilityName(a.getId())), cx, cy);
        } else {
            g.setFont(Theme.bold(14));
            Theme.drawCentered(g, a.getStatusText(p), cx, cy);
        }
        // key label
        g.setColor(Theme.ACCENT_2);
        g.fillRoundRect(cx - r - 4, cy - r - 4, 22, 16, 6, 6);
        g.setColor(new Color(8, 16, 30));
        g.setFont(Theme.bold(11));
        Theme.drawCentered(g, key.length() > 2 ? key.substring(0, 1) : key, cx - r + 7, cy - r + 4);
    }

    private Color classColor(Player p) {
        switch (p.getPlayerClass()) {
            case GUARD: return new Color(0x7B5CFF);
            case FORWARD: return new Color(0xFF4D6D);
            default: return new Color(0x3AA0FF);
        }
    }

    // ---- shot meter -----------------------------------------------------------------------------------------

    private void drawShotMeter(Graphics2D g, Match m, Player p) {
        if (m.isFreeThrow()) {
            drawFreeThrowArc(g, m);
            return;
        }
        if (!p.isChargingShot()) {
            return;
        }
        double t = p.getShotHold() / m.getMeterTime(p);
        int x = (int) p.getX() + 30;
        int h = 64;
        int y = (int) p.getY() - 78;
        g.setColor(new Color(0, 0, 0, 170));
        g.fillRoundRect(x - 3, y - 3, 16, h + 6, 8, 8);
        int gy0 = y + h - (int) (h * m.getGreenEnd());
        int gy1 = y + h - (int) (h * m.getGreenStart());
        g.setColor(new Color(0x3DDC84));
        g.fillRect(x, gy0, 10, gy1 - gy0);
        double fill = Math.min(1.2, t);
        boolean inGreen = t >= m.getGreenStart() && t <= m.getGreenEnd() || p.hasGuaranteedGreen();
        g.setColor(inGreen ? Color.WHITE : (t > m.getGreenEnd() ? Theme.DANGER : Theme.ACCENT));
        int fh = (int) (h * Math.min(1, fill));
        g.fillRect(x + 2, y + h - fh, 6, fh);
        g.setColor(Color.WHITE);
        g.setStroke(new BasicStroke(1f));
        g.drawRoundRect(x - 3, y - 3, 16, h + 6, 8, 8);
        if (p.hasGuaranteedGreen()) {
            g.setFont(Theme.bold(10));
            g.drawString("LOCKED", x - 8, y - 8);
        }
    }

    /** Free throws use the 2K-style arc arrow (see FreeThrowAim), not the vertical meter. */
    private void drawFreeThrowArc(Graphics2D g, Match m) {
        Player s = m.getBall().getHolder();
        if (s == null || !s.isHumanControlled()) {
            return;
        }
        arcshot.court.FreeThrowAim aim = m.getFreeThrowAim();
        double sx = s.getX();
        double sy = s.getY() - 70;
        double hx = m.getCourt().getHoopX();
        double hy = m.getCourt().getHoopY() - m.getCourt().getRimHeight() * CourtRenderer.LIFT;
        double power = aim.isAiming() ? Math.min(1.5, aim.getPower()) : 0.25;
        double tipX = hx + aim.getSway() * 60;
        double e = aim.error(1.0);
        Color c = !aim.isAiming() ? new Color(255, 255, 255, 120)
                : (e <= 1 ? new Color(0x3DDC84) : (e <= 2 ? Theme.GOLD : Theme.DANGER));
        g.setStroke(new BasicStroke(9f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        int steps = 24;
        double prevX = sx;
        double prevY = sy;
        for (int i = 1; i <= steps; i++) {
            double t = power * i / steps;
            double x = sx + (tipX - sx) * t;
            double y = sy + (hy - sy) * t - Math.sin(Math.min(1, t) * Math.PI) * 110;
            g.setColor(c);
            g.drawLine((int) prevX, (int) prevY, (int) x, (int) y);
            prevX = x;
            prevY = y;
        }
        g.setStroke(new BasicStroke(1f));
        g.setColor(c);
        g.fillOval((int) prevX - 9, (int) prevY - 9, 18, 18);
    }

    // ---- banners, hints, chips, toasts ----------------------------------------------------------------------

    private void drawChips(Graphics2D g, Match m) {
        if (m.needsClear() && m.isLive()) {
            String txt = m.getOffense() == TeamSide.HOME ? "CLEAR THE BALL  -  take it behind the arc" : "OPPONENT MUST CLEAR";
            chip(g, txt, 640, 92, Theme.GOLD);
        }
    }

    private void chip(Graphics2D g, String txt, int cx, int y, Color c) {
        g.setFont(Theme.bold(13));
        int w = g.getFontMetrics().stringWidth(txt) + 24;
        g.setColor(new Color(0, 0, 0, 180));
        g.fillRoundRect(cx - w / 2, y, w, 24, 12, 12);
        g.setColor(c);
        g.drawRoundRect(cx - w / 2, y, w, 24, 12, 12);
        Theme.drawCentered(g, txt, cx, y + 12);
    }

    private void drawBanner(Graphics2D g, Match m) {
        String b = m.getBanner();
        if (b.isEmpty()) {
            return;
        }
        String sub = m.getBannerSub();
        if ("ULTIMATE".equals(b)) {
            sub = ctx.getSkin().abilityName(sub).toUpperCase();
        }
        double t = m.getBannerTime();
        int alpha = (int) (255 * Math.min(1, t * 3));
        int cy = 300;
        g.setPaint(new GradientPaint(265, 0, Theme.alpha(Theme.BG, 0), 640, 0, Theme.alpha(Theme.BG, (int) (alpha * 0.8)), true));
        g.fillRect(265, cy - 50, 750, sub.isEmpty() ? 80 : 104);
        g.setFont(Theme.display(64));
        g.setColor(Theme.alpha(b.equals("DEFEAT") ? Theme.DANGER : ("ULTIMATE".equals(b) ? Theme.GOLD : Theme.TEXT), alpha));
        Theme.drawCentered(g, "ULTIMATE".equals(b) ? sub : b, 640, cy - 8);
        if (!sub.isEmpty() && !"ULTIMATE".equals(b)) {
            g.setFont(Theme.semi(18));
            g.setColor(Theme.alpha(Theme.TEXT_MUTED, alpha));
            Theme.drawCentered(g, sub, 640, cy + 36);
        }
    }

    private void drawHint(Graphics2D g, Match m) {
        String h = m.getHint();
        if (!h.isEmpty()) {
            chip(g, h, 640, 608, Theme.TEXT);
        }
    }

    private void drawToasts(Graphics2D g) {
        int y = 440;
        for (Toast t : toasts) {
            double slide = Math.min(1, t.age * 4) * Math.min(1, (TOAST_TIME - t.age) * 3);
            int x = 1280 - (int) (250 * slide);
            panel(g, x, y, 236, 58);
            g.setColor(Theme.GOLD);
            g.fillRoundRect(x, y, 6, 54, 6, 6);
            g.setFont(Theme.bold(11));
            g.drawString("ACHIEVEMENT", x + 16, y + 18);
            g.setFont(Theme.semi(15));
            g.setColor(Theme.TEXT);
            g.drawString(trim(t.title, 24), x + 16, y + 36);
            g.setFont(Theme.body(11));
            g.setColor(Theme.TEXT_MUTED);
            g.drawString(trim(t.sub, 34), x + 16, y + 50);
            y += 64;
        }
    }

    private void drawDebug(Graphics2D g, Match m) {
        panel(g, 16, 430, 233, 120);
        g.setFont(Theme.body(12));
        g.setColor(Theme.TEXT);
        int y = 450;
        Player c = m.getControlled();
        String[] lines = {
            "DEBUG (F3)   F5 = reload balance",
            "Balance: " + trim(Balance.loadedFrom(), 26),
            "Phase: " + m.getPhase() + "  Ball: " + m.getBall().getState(),
            c == null ? "" : String.format("Make chance: %.0f%%", m.estimateMakeChance(c) * 100),
            c == null ? "" : String.format("Speed %.0f  Stam %.0f  Ult %.0f", c.getEffectiveSpeed(), c.getStamina(), c.getUltimateCharge()),
            "Entities: " + m.getEntities().size()
        };
        for (String s : lines) {
            g.drawString(s, 26, y);
            y += 17;
        }
    }

    // ---- small helpers --------------------------------------------------------------------------------------

    private static void panel(Graphics2D g, int x, int y, int w, int h) {
        g.setColor(new Color(0, 0, 0, 70));
        g.fillRoundRect(x + 2, y + 4, w, h - 2, 16, 16);
        g.setColor(Theme.alpha(Theme.PANEL, 235));
        g.fillRoundRect(x, y, w, h - 4, 16, 16);
        g.setColor(Theme.alpha(Theme.BORDER, 200));
        g.setStroke(new BasicStroke(1f));
        g.drawRoundRect(x, y, w, h - 4, 16, 16);
    }

    private static void bar(Graphics2D g, int x, int y, int w, int h, double frac, Color c, String label) {
        g.setColor(Theme.BG);
        g.fillRoundRect(x, y, w, h, h, h);
        g.setColor(c);
        g.fillRoundRect(x, y, (int) (w * Math.max(0, Math.min(1, frac))), h, h, h);
    }

    private static String initials(String name) {
        StringBuilder sb = new StringBuilder();
        for (String part : name.split(" ")) {
            if (!part.isEmpty() && sb.length() < 2) {
                sb.append(Character.toUpperCase(part.charAt(0)));
            }
        }
        return sb.toString();
    }

    private static String trim(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max - 1) + ".";
    }
}
