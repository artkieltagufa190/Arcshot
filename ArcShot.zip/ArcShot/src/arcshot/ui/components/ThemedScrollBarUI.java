package arcshot.ui.components;

import arcshot.ui.Theme;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.plaf.basic.BasicScrollBarUI;

/**
 * A thin, rounded scroll bar that matches the theme.
 * OOP pillars: <b>INHERITANCE</b> (extends Swing's BasicScrollBarUI) and <b>POLYMORPHISM</b> (overrides paint hooks).
 */
public class ThemedScrollBarUI extends BasicScrollBarUI {
    @Override
    protected void paintTrack(Graphics g, JComponent c, Rectangle r) {
        g.setColor(Theme.BG);
        g.fillRect(r.x, r.y, r.width, r.height);
    }

    @Override
    protected void paintThumb(Graphics g0, JComponent c, Rectangle r) {
        Graphics2D g = (Graphics2D) g0.create();
        Theme.quality(g);
        g.setColor(isDragging ? Theme.ACCENT : Theme.BORDER);
        g.fillRoundRect(r.x + 3, r.y + 2, r.width - 6, r.height - 4, 8, 8);
        g.dispose();
    }

    @Override
    protected JButton createDecreaseButton(int orientation) {
        return zeroButton();
    }

    @Override
    protected JButton createIncreaseButton(int orientation) {
        return zeroButton();
    }

    private static JButton zeroButton() {
        JButton b = new JButton();
        b.setPreferredSize(new Dimension(0, 0));
        b.setMinimumSize(new Dimension(0, 0));
        b.setMaximumSize(new Dimension(0, 0));
        return b;
    }
}
