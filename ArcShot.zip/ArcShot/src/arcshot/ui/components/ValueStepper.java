package arcshot.ui.components;

import arcshot.ui.Theme;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 * A themed "&lt;  value  &gt;" selector used instead of combo boxes (which are hard to style in Swing).
 * Generic over the option type T.
 * <p>
 * OOP pillar: <b>ENCAPSULATION</b> (the option list and index are private; change only through
 * {@link #setSelected}/arrows) and <b>ABSTRACTION</b> via generics (works for Strings, enums, Integers ...).
 */
public class ValueStepper<T> extends JPanel {
    private final List<T> options = new ArrayList<>();
    private final List<String> labels = new ArrayList<>();
    private final JLabel valueLabel = new JLabel("", SwingConstants.CENTER);
    private final ThemedButton prev = new ThemedButton("<", ThemedButton.Style.SECONDARY);
    private final ThemedButton next = new ThemedButton(">", ThemedButton.Style.SECONDARY);
    private int index;
    private Consumer<T> onChange;

    public ValueStepper() {
        super(new BorderLayout(Theme.S2, 0));
        setOpaque(false);
        valueLabel.setFont(Theme.semi(16));
        valueLabel.setForeground(Theme.TEXT);
        Dimension small = new Dimension(46, 42);
        prev.setPreferredSize(small);
        next.setPreferredSize(small);
        prev.addActionListener(e -> step(-1));
        next.addActionListener(e -> step(1));
        add(prev, BorderLayout.WEST);
        add(valueLabel, BorderLayout.CENTER);
        add(next, BorderLayout.EAST);
    }

    public void addOption(T value, String label) {
        options.add(value);
        labels.add(label);
        refresh();
    }

    public void clearOptions() {
        options.clear();
        labels.clear();
        index = 0;
        refresh();
    }

    public void setOnChange(Consumer<T> onChange) {
        this.onChange = onChange;
    }

    public T getSelected() {
        return options.isEmpty() ? null : options.get(index);
    }

    public void setSelected(T value) {
        int i = options.indexOf(value);
        if (i >= 0) {
            index = i;
            refresh();
        }
    }

    private void step(int delta) {
        if (options.isEmpty()) {
            return;
        }
        index = (index + delta + options.size()) % options.size();
        refresh();
        if (onChange != null) {
            onChange.accept(getSelected());
        }
    }

    private void refresh() {
        valueLabel.setText(options.isEmpty() ? "-" : labels.get(index));
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(280, 44);
    }
}
