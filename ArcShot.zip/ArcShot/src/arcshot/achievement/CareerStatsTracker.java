package arcshot.achievement;

import arcshot.core.GameEvent;
import arcshot.core.GameEventListener;
import arcshot.court.MatchSummary;
import arcshot.save.Profile;

/**
 * Keeps lifetime stats in the profile (Stats screen). Another independent event-bus subscriber.
 * OOP pillar: <b>POLYMORPHISM</b> (one more {@link GameEventListener}).
 */
public final class CareerStatsTracker implements GameEventListener {
    private final Profile profile;

    public CareerStatsTracker(Profile profile) {
        this.profile = profile;
    }

    @Override
    public void onEvent(GameEvent e) {
        if (e.isPractice() || !e.isUserTeam()) {
            return;
        }
        switch (e.getType()) {
            case BASKET_MADE:
                profile.addStat("baskets", 1);
                profile.addStat("points", e.getValue());
                break;
            case THREE_MADE: profile.addStat("outside", 1); break;
            case DUNK: profile.addStat("dunks", 1); break;
            case STEAL: profile.addStat("steals", 1); break;
            case BLOCK: profile.addStat("blocks", 1); break;
            case ASSIST: profile.addStat("assists", 1); break;
            case REBOUND: profile.addStat("rebounds", 1); break;
            case ABILITY_USED: profile.addStat("abilities", 1); break;
            case ULTIMATE_USED: profile.addStat("ultimates", 1); break;
            case MATCH_FINISHED:
                if (e.getPayload() instanceof MatchSummary) {
                    MatchSummary s = (MatchSummary) e.getPayload();
                    profile.addStat("matches", 1);
                    profile.addStat(s.isWon() ? "wins" : "losses", 1);
                    profile.addStat("wins." + s.getMainClass().key(), s.isWon() ? 1 : 0);
                    profile.addStat("seconds", (int) s.getSecondsPlayed());
                    profile.recordBest("best.score", s.getUserScore());
                    profile.recordBest("best.margin", s.getUserScore() - s.getOpponentScore());
                }
                break;
            default:
                break;
        }
    }
}
