package arcshot.ability.guard;

import arcshot.ability.AbilitySlot;
import arcshot.ability.ActiveAbility;
import arcshot.court.Match;
import arcshot.effect.SpeedBoostEffect;
import arcshot.player.Player;

/**
 * Guard Q (alternate): 3 s speed boost with a trail and extra steal resistance.
 * OOP pillars: <b>INHERITANCE</b> (extends ActiveAbility / Ultimate) and <b>POLYMORPHISM</b> (overrides perform() and the optional hooks).
 */
public class Slipstream extends ActiveAbility {
    public Slipstream() {
        super("guard.slipstream", AbilitySlot.Q, 10);
    }

    @Override
    protected void perform(Player owner, Match match) {
        owner.applyEffect(new SpeedBoostEffect("slipstream", param("duration", 3), param("speed", 1.35), true));
    }

    @Override
    protected double activeDuration() {
        return param("duration", 3);
    }

    @Override
    protected void whileActive(double dt, Player owner, Match match) {
        match.fx().trail("slipstream", owner.getX(), owner.getY() - 10, 9);
    }

    @Override
    public boolean aiShouldUse(Player owner, Match match) {
        return hasBall(owner, match) && match.getCourt().distanceToHoop(owner.getX(), owner.getY()) > 260;
    }
}
