package arcshot.court;

import arcshot.ability.Ability;
import arcshot.ability.AbilityFactory;
import arcshot.ability.AbilitySlot;
import arcshot.ability.ActiveAbility;
import arcshot.action.Action;
import arcshot.action.ActionType;
import arcshot.action.CastFamilies;
import arcshot.action.DunkAction;
import arcshot.action.JumpShotAction;
import arcshot.action.LayupAction;
import arcshot.action.PassAction;
import arcshot.action.SimpleAction;
import arcshot.action.StealAction;
import arcshot.ai.AIController;
import arcshot.control.DummyController;
import arcshot.control.KeyboardController;
import arcshot.control.PlayerInput;
import arcshot.core.Balance;
import arcshot.core.GameEvent;
import arcshot.core.GameEventBus;
import arcshot.core.GameEventType;
import arcshot.effect.Reach;
import arcshot.perk.Perk;
import arcshot.perk.PerkRegistry;
import arcshot.player.Player;
import arcshot.player.PlayerClass;
import arcshot.player.PlayerFactory;
import arcshot.player.TeamSide;
import arcshot.referee.RefereeCrew;
import arcshot.rules.Foul;
import arcshot.rules.FoulContext;
import arcshot.rules.FoulDetector;
import arcshot.rules.FoulOutcome;
import arcshot.rules.FreeThrowSequence;
import arcshot.rules.PersonalFoul;
import arcshot.rules.RuleEngine;
import arcshot.rules.RulesConfig;
import arcshot.rules.ShootingFoul;
import arcshot.save.Loadout;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * One 3x3 half-court match: rules, ball, both teams, referees and everything that happens on the court.
 * It never draws and never touches Swing; renderers only read its getters, and other systems learn what happened
 * through {@link GameEventBus} events (flushed once at the end of every tick).
 * <p>
 * <b>Deterministic update order (one tick, see {@link #updatePlay}):</b>
 * 1 input (human) -> 2 AI -> 3 status effects / cooldowns / stamina -> 4 action requests + ActionController
 * (frame events are QUEUED as {@link Interaction}s) -> 5 movement + collision -> 6 ball -> 7 rules: interactions
 * resolved in priority order (whistle &gt; score &gt; block &gt; shot release &gt; steal &gt; rebound &gt; pass), clocks ->
 * 8 scoring outcomes -> 9 event bus flush -> (render happens afterwards on the same thread).
 * <p>
 * OOP pillars: <b>ENCAPSULATION</b> (all state is private; abilities, AI and actions use the public action methods)
 * and <b>POLYMORPHISM</b> (players, controllers, abilities, actions, fouls and court entities are used through their
 * base types).
 */
public final class Match {

    /** Kept so older code compiles: the old 4-value phase. Use {@link #getPhase()} (a {@link MatchPhase}). */
    public enum Phase { CHECK_BALL, LIVE, DEAD_BALL, FINISHED }

    /** What happens when a dead ball ends. */
    private enum Restart { CHECK, CLEAR, GAME_OVER, OVERTIME, NEXT_FREE_THROW }

    /** The 2K-style arc aim used only for free throws (the jump shot keeps its vertical meter). */
    private final FreeThrowAim ftAim = new FreeThrowAim();
    private int lastBounce;
    private final java.util.Map<Player, ActionType> lastSoundType = new java.util.HashMap<>();

    private static final String[] HOME_NAMES = {"Kai", "Rex", "Tank"};
    private static final String[] AWAY_NAMES = {"Jett", "Bruno", "Atlas"};
    private static final String[] AWAY_TEAMS = {"Manila Meteors", "Cebu Comets", "Davao Dragons", "Iloilo Inferno"};

    private final MatchConfig config;
    private final GameEventBus bus;
    private final KeyboardController keyboard;
    private FxSink fx = FxSink.NONE;
    private final Random rng;

    private final CourtGeometry court = new CourtGeometry();
    private final Ball ball = new Ball();
    private final Team home;
    private final Team away;
    private final List<Player> players = new ArrayList<>();
    private final List<CourtEntity> entities = new ArrayList<>();
    private final Map<Player, AIController> aiControllers = new HashMap<>();
    private final Map<Player, double[]> formation = new HashMap<>();
    private final RefereeCrew refs;
    private final RuleEngine rules = new RuleEngine();
    private final FoulDetector fouls;
    private final PhaseMachine phases = new PhaseMachine();
    private final List<Interaction> queue = new ArrayList<>();
    private final List<GameEvent> pendingEvents = new ArrayList<>();
    private final Map<Player, Foul> shootingFouls = new HashMap<>();
    private Player controlled;

    private double phaseTimer;
    private Restart restart = Restart.CHECK;
    private TeamSide restartSide = TeamSide.HOME;
    private TeamSide offense = TeamSide.HOME;
    private boolean needsClear;
    private TeamSide pendingWinner;
    private double clock;
    private double shotClock;
    private boolean overtime;
    private double elapsed;
    private double playTime;
    private int maxDeficit;
    private boolean cooldownWaste;
    private final double[] wasteTimer = new double[2];
    private final List<String> highlights = new ArrayList<>();
    private Player lastPasser;
    private Player lastCatcher;
    private double lastCatchTime = -99;
    private boolean pendingRebound;
    private final Set<Player> interceptRolled = new HashSet<>();
    private final Set<Player> blockRolled = new HashSet<>();
    private MatchSummary summary;
    private double finishedTime;
    private FreeThrowSequence freeThrows;
    private boolean ftBallInAir;
    private FoulOutcome pendingOutcome;
    private Foul calledFoul;
    private Foul deferredFoul;
    private int scoreEvents;
    private int anomalies;

    // presentation state (read by the renderer)
    private String banner = "";
    private String bannerSub = "";
    private double bannerTime;
    private String hint = "";
    private double hintTime;
    private double hitStop;
    private double shake;
    private String flashKey = "";
    private double flashTime;
    private String tintKey = "";
    private double tintTime;
    private double netSwing;
    private double rimBend;

    public Match(MatchConfig config, GameEventBus bus, KeyboardController keyboard) {
        this.config = config;
        this.bus = bus;
        this.keyboard = keyboard;
        this.rng = new Random(config.getSeed());
        this.fouls = new FoulDetector(config.getSeed() * 31 + 7, config.getFoulFrequency(), config.isStrictRefs());
        this.refs = new RefereeCrew(court);
        this.clock = config.getGameSeconds();
        this.shotClock = shotClockLength();
        home = new Team(TeamSide.HOME, config.getPlayerName(), config.getHomeColor());
        away = new Team(TeamSide.AWAY, config.isPractice() ? "Practice Dummies"
                : AWAY_TEAMS[rng.nextInt(AWAY_TEAMS.length)], config.getAwayColor());
        createTeam(home, true);
        createTeam(away, false);
        publish(GameEventType.MATCH_STARTED, null, 0, null);
        setupCheckBall(TeamSide.HOME);
        showBanner(config.isPractice() ? "PRACTICE" : "TIP-OFF",
                config.isPractice() ? "Test your moves freely" : "First to " + targetScore() + " wins");
        flushEvents();
    }

    private void createTeam(Team team, boolean user) {
        int i = 0;
        int[] numbers = {3, 11, 23};
        for (PlayerClass pc : PlayerClass.values()) {
            boolean main = user && pc == config.getMainClass();
            String name = main ? config.getPlayerName() : (user ? HOME_NAMES[i] : AWAY_NAMES[i]);
            int number = main ? config.getJerseyNumber() : numbers[i];
            Player p = PlayerFactory.create(pc, name, number, team.getSide(), user);
            p.attach(this);
            p.setAppearance(Math.abs(name.hashCode()) + i * 7 + (user ? 0 : 3));
            Loadout l = user ? config.getLoadout(pc) : null;
            p.setAbilities(
                    AbilityFactory.createActive(l == null ? null : l.getQ(), pc, AbilitySlot.Q),
                    AbilityFactory.createActive(l == null ? null : l.getE(), pc, AbilitySlot.E),
                    AbilityFactory.createUltimate(l == null ? null : l.getR(), pc));
            if (user) {
                addPerk(p, config.getPerk1());
                addPerk(p, config.getPerk2());
            }
            AIController ai = new AIController(pc, config.getDifficulty());
            aiControllers.put(p, ai);
            if (main) {
                p.setController(keyboard);
                controlled = p;
            } else if (!user && config.isPractice()) {
                p.setController(new DummyController());
            } else {
                p.setController(ai);
            }
            team.addPlayer(p);
            players.add(p);
            i++;
        }
    }

    private static void addPerk(Player p, String id) {
        Perk perk = PerkRegistry.create(id);
        if (perk != null) {
            p.addPerk(perk);
        }
    }

    public void setFx(FxSink fx) {
        this.fx = fx == null ? FxSink.NONE : fx;
    }

    public FxSink fx() {
        return fx;
    }

    // =========================================================================================================
    // main update
    // =========================================================================================================

    /** Advances the match by one fixed step. */
    public void update(double dt) {
        elapsed += dt;
        phases.tick(dt);
        updatePresentation(dt);
        if (phases.get() == MatchPhase.GAME_OVER) {
            finishedTime += dt;
            ball.update(dt, court);
            idlePlayers(dt);
            refs.update(this, dt);
            flushEvents();
            return;
        }
        if (hitStop > 0) {
            hitStop -= dt;
            flushEvents();
            return;
        }
        switch (phases.get()) {
            case CHECK_BALL:
                updateCheckBall(dt);
                break;
            case DEAD_BALL:
                updateDeadBall(dt);
                break;
            case FOUL_CALLED:
                updateFoulCalled(dt);
                break;
            case FREE_THROW:
                updateFreeThrow(dt);
                break;
            case OVERTIME_BREAK:
                updateOvertimeBreak(dt);
                break;
            default:
                updatePlay(dt);
                break;
        }
        refs.update(this, dt);
        fouls.tick(dt);
        flushEvents();
    }

    private void updatePresentation(double dt) {
        bannerTime = Math.max(0, bannerTime - dt);
        hintTime = Math.max(0, hintTime - dt);
        flashTime = Math.max(0, flashTime - dt);
        tintTime = Math.max(0, tintTime - dt);
        shake *= Math.exp(-9 * dt);
        netSwing = Math.max(0, netSwing - dt * 1.6);
        rimBend = Math.max(0, rimBend - dt * 3);
    }

    /** LIVE / SHOT_IN_AIR: the documented tick order. */
    private void updatePlay(double dt) {
        playTime += dt;
        MatchPhase phase = phases.get();
        if (!config.isPractice() && phase.clockRuns()) {
            if (!overtime) {
                clock = Math.max(0, clock - dt);
            }
            if (phase != MatchPhase.SHOT_IN_AIR) {
                shotClock = Math.max(0, shotClock - dt);
            }
        }
        // 1 + 2: input and AI (both are PlayerControllers)
        readInputs(dt);
        Player switchTo = null;
        if (controlled != null && controlled.getInput().isSwitchPressed()) {
            switchTo = nextTeammate(controlled);
        }
        // 3: effects, cooldowns, stamina
        for (Player p : players) {
            p.updateTimers(dt, this);
        }
        // 4: action requests, then every ActionController (frame events -> queue)
        for (Player p : players) {
            handleActions(p, dt);
        }
        for (Player p : players) {
            p.getActions().update(dt, this);
            updateLocomotion(p);
        }
        // 5: movement and collision
        for (Player p : players) {
            p.updateMovement(dt);
        }
        updateEntities(dt);
        resolveCollisions(true);
        for (Player p : players) {
            court.clamp(p);
        }
        // 6: ball
        ball.update(dt, court);
        updateBall();
        soundHooks();
        // 7 + 8: rules and scoring, in priority order
        resolveInteractions();
        if (!phases.get().isPlay()) {
            return; // a whistle or score ended live play this tick
        }
        double passive = Balance.d("meter.passivePerSecond", 0.45) * dt;
        for (Player p : players) {
            p.addUltimateCharge(passive);
        }
        updateClearRule();
        trackCooldownWaste(dt);
        maxDeficit = Math.max(maxDeficit, away.getScore() - home.getScore());
        if (switchTo != null) {
            switchControlTo(switchTo);
        }
        checkClocks();
        syncShotPhase();
    }

    private void readInputs(double dt) {
        boolean allowed = phases.get().allowsInput();
        for (Player p : players) {
            PlayerInput in = p.getInput();
            in.clear();
            if (allowed) {
                p.getController().fillInput(p, this, in, dt);
            }
        }
    }

    private void syncShotPhase() {
        if (phases.get() == MatchPhase.LIVE && ball.getState() == Ball.State.SHOT) {
            goPhase(MatchPhase.SHOT_IN_AIR);
        } else if (phases.get() == MatchPhase.SHOT_IN_AIR && ball.getState() != Ball.State.SHOT) {
            goPhase(MatchPhase.LIVE);
        }
    }

    private void idlePlayers(double dt) {
        for (Player p : players) {
            p.getInput().clear();
            p.updateTimers(dt, this);
            p.getActions().update(dt, this);
            updateLocomotion(p);
            p.updateMovement(dt);
            court.clamp(p);
        }
        resolveCollisions(false);
    }

    private void updateCheckBall(double dt) {
        phaseTimer -= dt;
        for (Player p : players) {
            p.getInput().clear();
            p.updateTimers(dt, this);
            p.getActions().update(dt, this);
            updateLocomotion(p);
            double[] t = formation.get(p);
            if (t != null) {
                double k = Math.min(1, 5.5 * dt);
                p.setPosition(p.getX() + (t[0] - p.getX()) * k, p.getY() + (t[1] - p.getY()) * k);
                p.lockFacing(court.getHoopX(), court.getHoopY());
                p.updateMovement(0);
            }
        }
        ball.update(dt, court);
        if (phaseTimer <= 0) {
            for (Player p : players) {
                double[] t = formation.get(p);
                if (t != null) {
                    p.setPosition(t[0], t[1]);
                }
            }
            goPhase(MatchPhase.LIVE);
            showBanner("CHECK", "");
            bannerTime = 0.5;
        }
    }

    private void updateDeadBall(double dt) {
        phaseTimer -= dt;
        idlePlayers(dt);
        ball.update(dt, court);
        if (phaseTimer > 0) {
            return;
        }
        if (pendingWinner != null) {
            endMatch(pendingWinner);
            return;
        }
        switch (restart) {
            case CLEAR:
                clearUnderBasket(restartSide);
                break;
            case OVERTIME:
                goPhase(MatchPhase.OVERTIME_BREAK);
                phaseTimer = 1.8;
                break;
            case NEXT_FREE_THROW:
                goPhase(MatchPhase.FREE_THROW);
                prepareNextFreeThrow();
                break;
            default:
                setupCheckBall(restartSide);
                break;
        }
    }

    private void updateOvertimeBreak(double dt) {
        phaseTimer -= dt;
        idlePlayers(dt);
        if (phaseTimer <= 0) {
            setupCheckBall(restartSide);
        }
    }

    // =========================================================================================================
    // player actions (input -> action requests)
    // =========================================================================================================

    private void handleActions(Player p, double dt) {
        PlayerInput in = p.getInput();
        if (phases.get().allowsAbilities()) {
            if (in.isQPressed()) {
                tryAbility(p, AbilitySlot.Q);
            }
            if (in.isEPressed()) {
                tryAbility(p, AbilitySlot.E);
            }
            if (in.isRPressed()) {
                tryAbility(p, AbilitySlot.R);
            }
        }
        boolean hasBall = ball.getState() == Ball.State.HELD && ball.getHolder() == p;
        if (hasBall) {
            handleBallHandler(p, in, dt);
        } else {
            p.setShotHold(-1);
            handleOffBall(p, in);
        }
    }

    private void tryAbility(Player p, AbilitySlot slot) {
        Ability a = p.getAbility(slot);
        if (a == null) {
            return;
        }
        ActionType busy = p.getActions().getType();
        if (busy.getPriority() >= ActionType.JUMP_SHOT.getPriority() && busy != ActionType.DASH) {
            if (p.isHumanControlled()) {
                showHint("Busy - finish the move first");
            }
            return; // abilities cannot interrupt a shot, layup, dunk or foul
        }
        if (!a.activate(p, this) && p.isHumanControlled()) {
            showHint(a.getStatusText(p).equals("READY") ? "Can't use that right now" : "Not ready yet");
        }
    }

    private void handleBallHandler(Player p, PlayerInput in, double dt) {
        Action cur = p.getActions().getCurrent();
        if (cur instanceof JumpShotAction && ((JumpShotAction) cur).isCharging()) {
            JumpShotAction shot = (JumpShotAction) cur;
            in.setMove(0, 0);
            in.setSprint(false);
            p.lockFacing(court.getHoopX(), court.getHoopY());
            if (!p.canShoot()) {
                p.setShotHold(-1);
                p.getActions().clear(this);
                return;
            }
            if (in.isShootHeld()) {
                p.setShotHold(Math.max(0, p.getShotHold()) + dt);
                if (shot.isFreeThrow()) {
                    ftAim.update(dt, p.getShotHold(), getFreeThrowMeterTime());
                }
                double limit = shot.isFreeThrow() ? getFreeThrowMeterTime() * 1.5 : getMeterTime(p) * 1.4;
                if (p.getShotHold() > limit) {
                    shot.release(p.getShotHold());
                    p.setShotHold(-1);
                }
            } else {
                shot.release(Math.max(0, p.getShotHold()));
                p.setShotHold(-1);
            }
            return;
        }
        if (p.getActions().locksShooting() || phases.get() == MatchPhase.FREE_THROW && freeThrows == null) {
            return;
        }
        if (in.isShootHeld()) {
            if (phases.get() == MatchPhase.FREE_THROW) {
                if (!ftBallInAir && p.getActions().request(new JumpShotAction(true), this)) {
                    p.setShotHold(0);
                    ftAim.update(0, 0, getFreeThrowMeterTime());
                }
            } else if (needsClear) {
                if (p.isHumanControlled()) {
                    showHint("Clear the ball behind the arc first!");
                }
            } else if (!p.canShoot()) {
                if (p.isHumanControlled()) {
                    showHint("You can't shoot right now");
                }
            } else {
                startShotOrFinish(p);
            }
            return;
        }
        if (in.isPassPressed() && phases.get().isPlay()) {
            passFromInput(p, in);
        }
    }

    /** Context-sensitive shoot: jump shot outside the finishing zone, layup or dunk inside it. */
    private void startShotOrFinish(Player p) {
        double dist = court.distanceToHoop(p.getX(), p.getY());
        if (dist <= court.getFinishRange() && !court.isOutsideArc(p)) {
            double contest = contestPenalty(p);
            double toRimX = court.getHoopX() - p.getX();
            double toRimY = court.getHoopY() - p.getY();
            double driveSpeed = (p.getVx() * toRimX + p.getVy() * toRimY) / Math.max(1, dist);
            boolean towardRim = driveSpeed > Balance.d("finish.dunkMinDriveSpeed", 60) || dist < 50;
            double reach = p.getDunkRange() + Balance.d("finish.dunkExtra", 25);
            boolean guard = p.getPlayerClass() == PlayerClass.GUARD;
            boolean big = p.getPlayerClass() == PlayerClass.BIG;
            boolean dunk = dist <= reach && towardRim
                    && contest < (guard ? Balance.d("finish.guardDunkContest", 0.10) : (big ? 0.5 : 0.22));
            if (dunk) {
                double[] spot = court.dunkSpot(p.getX());
                String variant = contest > 0.15 || p.getPlayerClass() == PlayerClass.BIG ? "dunk2" : "dunk";
                p.getActions().request(new DunkAction(variant, spot[0], spot[1], false, RulesConfig.insidePoints()), this);
            } else {
                double[] spot = court.layupSpot(p.getX(), p.getY());
                boolean bank = Math.abs(p.getX() - court.getHoopX()) > Balance.d("finish.bankAngleX", 40);
                p.getActions().request(new LayupAction(spot[0], spot[1], bank), this);
            }
            return;
        }
        if (p.getActions().request(new JumpShotAction(false), this)) {
            p.setShotHold(0);
            p.lockFacing(court.getHoopX(), court.getHoopY());
        }
    }

    private void handleOffBall(Player p, PlayerInput in) {
        if (!phases.get().isPlay()) {
            return;
        }
        if (in.isShootHeld()) {
            boolean looseNear = ball.getState() == Ball.State.LOOSE
                    && Math.hypot(ball.getX() - p.getX(), ball.getY() - p.getY()) < 110;
            if (looseNear) {
                p.startRebound();
            } else {
                p.startJump();
            }
        }
        if (!in.isPassPressed() || ball.getState() != Ball.State.HELD) {
            return;
        }
        Player holder = ball.getHolder();
        if (holder.getSide() != p.getSide()) {
            if (p.canAttemptSteal()) {
                p.getActions().request(new StealAction(), this);
                p.startStealCooldown(0.5);
            }
        } else if (p.isHumanControlled() && !holder.isHumanControlled()) {
            pass(holder, p, false); // call for the ball
        }
    }

    /** Picks the locomotion state (and the defensive slide facing) when no action runs. */
    private void updateLocomotion(Player p) {
        if (p.getActions().isBusy()) {
            return;
        }
        double speed = Math.hypot(p.getVx(), p.getVy());
        ActionType t;
        if (ball.getState() == Ball.State.HELD && ball.getHolder() == p) {
            t = speed > 30 ? ActionType.DRIBBLE_MOVE : ActionType.DRIBBLE_IDLE;
        } else if (phases.get().isPlay() && ball.getState() == Ball.State.HELD && ball.getHolder().getSide() != p.getSide()
                && (getMatchup(p) == ball.getHolder() || p.distanceTo(ball.getHolder()) < 120)) {
            t = ActionType.DEFENSIVE_STANCE;
            p.lockFacing(ball.getHolder().getX(), ball.getHolder().getY());
        } else if (speed > 30) {
            t = p.isSprinting() ? ActionType.SPRINT : ActionType.WALK;
        } else {
            t = ActionType.IDLE;
        }
        p.getActions().setLocomotion(t);
    }

    /** Seconds for the shot meter to reach 100%. */
    public double getMeterTime(Player p) {
        return Balance.d("shot.meterTime", 0.9);
    }

    /** Seconds of holding for the free-throw arc to reach the rim (power 1.0). */
    public double getFreeThrowMeterTime() { return Balance.d("ft.meterTime", 1.1); }

    /** The free-throw arc aim (read by the HUD). */
    public FreeThrowAim getFreeThrowAim() { return ftAim; }

    public double getGreenStart() { return Balance.d("shot.greenStart", 0.80); }

    public double getGreenEnd() { return Balance.d("shot.greenEnd", 0.93); }

    private ShotAttempt.Timing timingOf(Player p, double hold) {
        double meter = hold / getMeterTime(p);
        double lo = getGreenStart();
        double hi = getGreenEnd();
        if (p.hasGuaranteedGreen() || (meter >= lo && meter <= hi)) {
            return ShotAttempt.Timing.GREEN;
        }
        double off = meter < lo ? lo - meter : meter - hi;
        if (off < Balance.d("shot.goodWindow", 0.10)) {
            return ShotAttempt.Timing.GOOD;
        }
        return meter < lo ? ShotAttempt.Timing.EARLY : ShotAttempt.Timing.LATE;
    }

    private double timingBonus(Player p, double hold, ShotAttempt.Timing timing) {
        double meter = hold / getMeterTime(p);
        switch (timing) {
            case GREEN: return Balance.d("shot.greenBonus", 0.20);
            case GOOD: return Balance.d("shot.goodBonus", 0.02);
            case EARLY: return -0.10 - (getGreenStart() - meter) * 0.45;
            default: return -0.12 - (meter - getGreenEnd()) * 0.6;
        }
    }

    private void releaseJumpShot(Player p, double hold) {
        ShotAttempt.Timing timing = timingOf(p, hold);
        double chance = clamp(estimateMakeChance(p) + timingBonus(p, hold, timing), 0.02, 0.97);
        double dist = court.distanceToHoop(p.getX(), p.getY());
        boolean outside = court.isOutsideArc(p);
        int points = outside ? RulesConfig.outsidePoints() : RulesConfig.insidePoints();
        Foul foul = shootingFouls.remove(p);
        if (foul != null) {
            chance *= Balance.d("foul.shotPenaltyWhenFouled", 0.55);
        }
        boolean made = rng.nextDouble() < chance;
        p.consumeShotEffects();
        ShotAttempt shot = new ShotAttempt(p, 80 + p.getZ(), 0.55 + dist / 1000.0, 50 + dist * 0.28, made, points,
                outside, ShotAttempt.Kind.JUMP_SHOT, false, timing, chance);
        shot.setPendingFoul(foul);
        launchShot(shot);
        fx.text(timing.name(), "timing_" + timing.name().toLowerCase(), p.getX(), p.getY() - 70);
    }

    private void releaseLayup(Player p, LayupAction layup) {
        double dist = court.distanceToHoop(p.getX(), p.getY());
        double chance = Balance.d("finish.layupBase", 0.80) + (p.getShooting() - 70) * 0.004
                + p.rangeModifier(dist, false) + p.getShootingBonus(false, this) + heatBonus(p)
                - contestPenalty(p) * Balance.d("finish.layupContestWeight", 1.1);
        Foul foul = shootingFouls.remove(p);
        if (foul != null) {
            chance -= Balance.d("foul.layupPenaltyWhenFouled", 0.25);
        }
        chance = clamp(chance, 0.05, 0.96);
        boolean made = rng.nextDouble() < chance;
        p.consumeShotEffects();
        ShotAttempt shot = new ShotAttempt(p, 100 + p.getZ(), layup.isBank() ? 0.5 : 0.4, layup.isBank() ? 12 : 22,
                made, RulesConfig.insidePoints(), false, ShotAttempt.Kind.LAYUP, layup.isBank(), ShotAttempt.Timing.GOOD, chance);
        shot.setPendingFoul(foul);
        launchShot(shot);
    }

    private void releaseFreeThrow(Player p, double hold) {
        // graded by the arc aim: power (how long SHOOT was held) and sway (where the tip was when released)
        ftAim.update(0, hold, getFreeThrowMeterTime());
        ftAim.stop();
        double swayWeight = p.isHumanControlled() ? 1.0 : Balance.d("ft.aiSwayWeight", 0.35);
        ShotAttempt.Timing timing = ftAim.grade(swayWeight);
        double chance = RulesConfig.freeThrowPercent(p.getPlayerClass().key())
                + ftAim.bonus(swayWeight) * Balance.d("ft.timingWeight", 1.0);
        chance = clamp(chance, 0.05, 0.98);
        boolean made = rng.nextDouble() < chance;
        ShotAttempt shot = new ShotAttempt(p, 85, 0.8, 72, made, RulesConfig.freeThrowPoints(), false,
                ShotAttempt.Kind.FREE_THROW, false, timing, chance);
        ftBallInAir = true;
        launchShot(shot);
        fx.text(timing.name(), "timing_" + timing.name().toLowerCase(), p.getX(), p.getY() - 70);
    }

    private void launchShot(ShotAttempt shot) {
        ball.startShot(shot);
        blockRolled.clear();
        if (phases.get() == MatchPhase.LIVE) {
            goPhase(MatchPhase.SHOT_IN_AIR);
        }
    }

    /** Make chance before shot-meter timing: rating, distance, class, effects, perks, heat and defenders. */
    public double estimateMakeChance(Player p) {
        double dist = court.distanceToHoop(p.getX(), p.getY());
        boolean outside = court.isOutsideArc(p);
        double chance;
        if (dist <= p.getDunkRange()) {
            chance = Balance.d("shot.dunkBase", 0.88);
        } else {
            chance = p.getShooting() / 100.0 * Balance.d("shot.ratingScale", 0.85);
            chance -= clamp((dist - 70) / 560.0, 0, 1) * Balance.d("shot.distancePenalty", 0.40);
        }
        chance += p.rangeModifier(dist, outside) + p.getShootingBonus(outside, this) + heatBonus(p);
        chance -= contestPenalty(p);
        return clamp(chance, 0.02, 0.97);
    }

    /** "Heat": 3 straight makes = a small built-in bonus (the Hot Hand perk adds more). */
    private static double heatBonus(Player p) {
        return p.getConsecutiveMakes() >= Balance.i("heat.streak", 3) ? Balance.d("heat.bonus", 0.03) : 0;
    }

    /** How much nearby defenders lower the make chance (0 = wide open). */
    public double contestPenalty(Player shooter) {
        double max = 0;
        double contestMax = Balance.d("shot.contestMax", 0.32);
        boolean inPaint = court.isInPaint(shooter.getX(), shooter.getY());
        for (Player o : opponentsOf(shooter)) {
            if (!o.canAct()) {
                continue;
            }
            double d = o.distanceTo(shooter);
            double r = o.getReach(Reach.CONTEST);
            if (d < r) {
                double pen = (1 - d / r) * contestMax * (o.getDefense() / 70.0);
                if (o.isJumping()) {
                    pen *= 1.25;
                }
                max = Math.max(max, pen);
            }
            if (inPaint && o.autoContestsPaint()) {
                max = Math.max(max, contestMax + 0.12);
            }
        }
        return max;
    }

    private void passFromInput(Player p, PlayerInput in) {
        Player best = null;
        double bestScore = -1e9;
        double dx = in.getMoveX();
        double dy = in.getMoveY();
        boolean aimed = Math.hypot(dx, dy) > 0.2;
        for (Player mate : teammatesOf(p)) {
            double mx = mate.getX() - p.getX();
            double my = mate.getY() - p.getY();
            double dist = Math.max(1, Math.hypot(mx, my));
            double score = aimed ? (mx * dx + my * dy) / dist - dist * 0.0004 : openness(mate) - dist * 0.15;
            if (score > bestScore) {
                bestScore = score;
                best = mate;
            }
        }
        if (best != null) {
            pass(p, best, false);
        }
    }

    /** Distance from this player to the closest opponent. */
    public double openness(Player p) {
        double min = 9999;
        for (Player o : opponentsOf(p)) {
            min = Math.min(min, o.distanceTo(p));
        }
        return min;
    }

    // =========================================================================================================
    // interactions: queued by actions, resolved in one fixed priority order
    // =========================================================================================================

    /** Called by actions (frame events) and the ball step. Resolved at the end of the tick in priority order. */
    public void queue(Interaction.Kind kind, Player p, Object data) {
        MatchPhase ph = phases.get();
        if (ph.isPlay() || (ph == MatchPhase.FREE_THROW && freeThrows != null && p == freeThrows.getShooter())) {
            queue.add(new Interaction(kind, p, data, players.indexOf(p)));
        }
        // anything else happens during a dead ball and is ignored on purpose (no stale events later)
    }

    private void resolveInteractions() {
        if (queue.isEmpty()) {
            return;
        }
        List<Interaction> list = new ArrayList<>(queue);
        queue.clear();
        Collections.sort(list);
        MatchPhase startPhase = phases.get();
        for (Interaction it : list) {
            if (phases.get() != startPhase && !(startPhase == MatchPhase.SHOT_IN_AIR && phases.get() == MatchPhase.LIVE)
                    && !(startPhase == MatchPhase.LIVE && phases.get() == MatchPhase.SHOT_IN_AIR)) {
                break; // a whistle or score earlier in this tick changed the phase: ignore the rest
            }
            Player p = it.getPlayer();
            switch (it.getKind()) {
                case FOUL_CHECK:
                    Foul f = fouls.checkShooting(p, String.valueOf(it.getData()), this);
                    if (f != null) {
                        shootingFouls.put(p, f);
                        refs.signal("whistle", p.getX(), p.getY(), 0.8);
                        sound("whistle");
                        fx.text("FOUL!", "block", p.getX(), p.getY() - 90);
                    }
                    break;
                case SCORE:
                    if (it.getData() instanceof DunkAction) {
                        resolveDunk(p, (DunkAction) it.getData());
                    } else if (it.getData() instanceof ShotAttempt) {
                        resolveShot((ShotAttempt) it.getData());
                    }
                    break;
                case BLOCK:
                    resolveBlock(p, (Player) it.getData());
                    break;
                case SHOT_RELEASE:
                    if (ball.getState() == Ball.State.HELD && ball.getHolder() == p) {
                        if (it.getData() instanceof LayupAction) {
                            releaseLayup(p, (LayupAction) it.getData());
                        } else {
                            JumpShotAction a = (JumpShotAction) it.getData();
                            if (a.isFreeThrow()) {
                                releaseFreeThrow(p, a.getHold());
                            } else {
                                releaseJumpShot(p, a.getHold());
                            }
                        }
                    }
                    break;
                case STEAL:
                    resolveSteal(p);
                    break;
                case REBOUND:
                    tryReboundGrab(p);
                    break;
                default:
                    if (it.getData() instanceof PassAction && ball.getState() == Ball.State.HELD && ball.getHolder() == p) {
                        PassAction pa = (PassAction) it.getData();
                        executePass(p, pa.getReceiver(), pa.isSafe());
                    }
                    break;
            }
        }
        queue.clear();
    }

    private void resolveSteal(Player thief) {
        if (ball.getState() != Ball.State.HELD || ball.getHolder().getSide() == thief.getSide()) {
            return;
        }
        Player holder = ball.getHolder();
        boolean stole = attemptSteal(thief);
        Foul foul = fouls.checkStealSwipe(thief, holder, stole, this);
        if (foul != null) {
            callFoul(foul, FoulContext.nonShooting());
        }
    }

    private boolean attemptSteal(Player thief) {
        Player holder = ball.getHolder();
        if (holder.isIntangible()) {
            return false; // can't strip a player mid-dash (Shadow Step, Final Burst...)
        }
        if (thief.distanceTo(holder) > thief.getReach(Reach.STEAL)) {
            return false;
        }
        double chance = Balance.d("steal.baseChance", 0.21) + (thief.getDefense() - 65) * 0.005;
        if (holder.isStealResistant()) {
            chance -= 0.18;
        }
        if (holder.isChargingShot()) {
            chance += 0.08;
        }
        if (!holder.canAct()) {
            chance = 0.95; // frozen or stunned ball handler
        }
        if (rng.nextDouble() < clamp(chance, 0.03, 0.95)) {
            return stealBall(thief);
        }
        thief.startStealCooldown(Balance.d("steal.failCooldown", 0.9));
        fx.burst("whiff", holder.getX(), holder.getY() - 20, 4, 60);
        return false;
    }

    // =========================================================================================================
    // public actions (used by abilities and AI)
    // =========================================================================================================

    /** Takes the ball from the opponent holding it (Tiger Claw, successful steal). */
    public boolean stealBall(Player thief) {
        Player holder = ball.getHolder();
        if (ball.getState() != Ball.State.HELD || holder == null || holder.getSide() == thief.getSide()
                || holder.isIntangible() || !phases.get().isPlay()) {
            return false;
        }
        holder.setShotHold(-1);
        holder.getActions().clear(this);
        holder.getStats().addTurnover();
        thief.getStats().addSteal();
        publish(GameEventType.STEAL, thief, 0, null);
        publish(GameEventType.TURNOVER, holder, 0, null);
        thief.addUltimateCharge(Balance.d("meter.steal", 10));
        fx.burst("steal", holder.getX(), holder.getY() - 20, 14, 180);
        fx.text("STEAL!", "steal", thief.getX(), thief.getY() - 70);
        ball.giveTo(thief, "steal");
        thief.startStealCooldown(0.6);
        onControlGained(thief);
        return true;
    }

    /**
     * Requests a pass from the holder to a teammate (the ball leaves on the pass animation's release frame).
     * {@code safe} = cannot be intercepted (Boulder Toss).
     */
    public boolean pass(Player from, Player to, boolean safe) {
        if (ball.getState() != Ball.State.HELD || ball.getHolder() != from || to == from || !phases.get().isPlay()) {
            return false;
        }
        from.setShotHold(-1);
        return from.getActions().request(new PassAction(to, safe), this);
    }

    private void executePass(Player from, Player to, boolean safe) {
        double speed = Balance.d("pass.speed", 780) * (safe ? 1.25 : 1.0);
        ball.startPass(from, to, speed, safe);
        interceptRolled.clear();
        pendingRebound = false;
    }

    /** A guaranteed, unblockable dunk by {@code p} (Final Burst / Meteor Crash) - the flashiest dunk in the game. */
    public void forceDunk(Player p, int points) {
        if (ball.getState() != Ball.State.HELD || ball.getHolder() != p || !phases.get().isPlay()) {
            return; // no teleporting the ball any more: the dunker must still hold it
        }
        Ability r = p.getAbility(AbilitySlot.R);
        String variant = r != null && r.getId().contains("meteor") ? "dunk2" : "windmill";
        double[] spot = court.dunkSpot(p.getX());
        p.getActions().force(new DunkAction(variant, spot[0], spot[1], true, points), this);
    }

    public void addEntity(CourtEntity e) { entities.add(e); }

    /** Freezes the simulation briefly for impact (blocks, dunks). */
    public void hitStop(double seconds) { hitStop = Math.max(hitStop, seconds); }

    /** Adds screen shake (if enabled in settings, the renderer applies it). */
    public void shake(double amount) { shake = Math.max(shake, amount); }

    /** A short full-screen flash of the skin color for {@code key}. */
    public void flash(String key, double seconds) {
        flashKey = key;
        flashTime = seconds;
    }

    /** A colored full-screen tint (Time Stop). */
    public void tint(String key, double seconds) {
        tintKey = key;
        tintTime = seconds;
    }

    /** Called by {@link Ability#activate} (template method) after an ability fires. */
    public void onAbilityUsed(Player owner, Ability ability) {
        boolean ult = ability.getSlot() == AbilitySlot.R;
        owner.getStats().addAbilityUse(ult);
        publish(ult ? GameEventType.ULTIMATE_USED : GameEventType.ABILITY_USED, owner, 0, ability.getId());
        if (owner == controlled) {
            wasteTimer[0] = 0;
            wasteTimer[1] = 0;
        }
        String cast = CastFamilies.animationFor(ability.getId());
        if (cast != null) {
            owner.getActions().request(SimpleAction.cast(cast), this);
        }
        if (ult) {
            highlights.add(getClockText() + "|" + owner.getName() + "|" + ability.getId() + "|" + owner.getSide());
            showBanner("ULTIMATE", ability.getId());
        }
        Foul foul = fouls.checkAbility(owner, ability.getId(), this);
        if (foul != null) {
            callFoul(foul, FoulContext.nonShooting());
        }
    }

    // =========================================================================================================
    // ball
    // =========================================================================================================

    private void updateBall() {
        switch (ball.getState()) {
            case SHOT:
                checkShotBlocks();
                if (ball.getShot().isFinished()) {
                    queue(Interaction.Kind.SCORE, ball.getShot().getShooter(), ball.getShot());
                }
                break;
            case PASS:
                checkInterceptions();
                if (ball.getState() == Ball.State.PASS) {
                    Player r = ball.getReceiver();
                    if (Math.hypot(r.getX() - ball.getX(), r.getY() - ball.getY()) < 22) {
                        catchPass();
                    }
                }
                break;
            case LOOSE:
                updateLooseBall();
                break;
            case HELD:
                checkFinishBlocks();
                break;
            default:
                break;
        }
        if (ball.consumeBounces() > 0) {
            sound("bounce");
        }
    }

    private void checkShotBlocks() {
        ShotAttempt s = ball.getShot();
        Player shooter = s.getShooter();
        if (s.isFreeThrow() || s.getElapsed() > Balance.d("block.window", 0.32) || shooter.isUnblockable()) {
            return;
        }
        for (Player d : opponentsOf(shooter)) {
            if (!d.isBlockContactActive() || blockRolled.contains(d)) {
                continue;
            }
            double dist = Math.hypot(d.getX() - ball.getX(), d.getY() - ball.getY());
            if (dist > d.getReach(Reach.BLOCK)) {
                continue;
            }
            blockRolled.add(d);
            double chance = Balance.d("block.baseChance", 0.38) + (d.getDefense() - 60) * 0.006;
            if (d.autoContestsPaint() && court.isInPaint(shooter.getX(), shooter.getY())) {
                chance += 0.25;
            }
            if (s.getKind() == ShotAttempt.Kind.LAYUP) {
                chance -= 0.05;
            }
            if (rng.nextDouble() < chance) {
                queue(Interaction.Kind.BLOCK, d, shooter);
                return;
            }
        }
    }

    /** Blocks during a layup / dunk RISE (ball still in the shooter's hands). */
    private void checkFinishBlocks() {
        Player h = ball.getHolder();
        Action a = h.getActions().getCurrent();
        boolean dunkRise = a instanceof DunkAction && ((DunkAction) a).isRising() && !((DunkAction) a).isForced();
        boolean layupRise = a instanceof LayupAction && h.getZ() > 4;
        if ((!dunkRise && !layupRise) || h.isUnblockable()) {
            return;
        }
        for (Player d : opponentsOf(h)) {
            if (!d.isBlockContactActive() || blockRolled.contains(d) || d.distanceTo(h) > d.getReach(Reach.BLOCK) * 0.9) {
                continue;
            }
            blockRolled.add(d);
            double chance = (dunkRise ? Balance.d("block.dunkChance", 0.22) : Balance.d("block.layupChance", 0.34))
                    + (d.getDefense() - 60) * 0.004;
            if (d.isHeavy()) {
                chance += 0.10; // Iron Wall / Colossus stand their ground
            }
            if (rng.nextDouble() < chance) {
                queue(Interaction.Kind.BLOCK, d, h);
                return;
            }
        }
    }

    private void resolveBlock(Player blocker, Player shooter) {
        boolean inFlight = ball.getState() == Ball.State.SHOT && ball.getShot().getShooter() == shooter;
        boolean inHands = ball.getState() == Ball.State.HELD && ball.getHolder() == shooter;
        if (!inFlight && !inHands) {
            return;
        }
        shooter.getStats().addShot(false, 0, false);
        shooter.recordShotResult(false);
        shootingFouls.remove(shooter);
        blocker.getStats().addBlock();
        publish(GameEventType.BLOCK, blocker, 0, null);
        blocker.addUltimateCharge(Balance.d("meter.block", 12));
        hitStop(Balance.d("feel.blockHitStop", 0.08));
        shake(7);
        sound("block");
        double sy = ball.getY();
        fx.burst("block", ball.getX(), sy, 18, 260);
        fx.text("BLOCKED!", "block", blocker.getX(), blocker.getY() - 80);
        Player colossus = colossusOf(blocker.getSide());
        if (colossus != null) {
            if (inFlight) {
                ball.makeLoose(ball.getX(), ball.getY(), ball.getZ(), 0, 0, 0, false, 0);
            }
            ball.giveTo(blocker, "block (colossus)");
            onControlGained(blocker);
            return;
        }
        double dx = ball.getX() - court.getHoopX() + (rng.nextDouble() - 0.5) * 80;
        double dy = Math.abs(ball.getY() - court.getHoopY()) + 60;
        double len = Math.max(1, Math.hypot(dx, dy));
        double speed = 160 + rng.nextDouble() * 120;
        ball.makeLoose(ball.getX(), ball.getY(), Math.max(ball.getZ(), 60), dx / len * speed, dy / len * speed, 120, true, 0.18);
        ball.setLastTouch(blocker);
    }

    private void resolveDunk(Player p, DunkAction dunk) {
        if (ball.getState() != Ball.State.HELD || ball.getHolder() != p) {
            return; // the dunk was blocked or stripped during the rise
        }
        Foul foul = dunk.isForced() ? null : shootingFouls.remove(p);
        boolean made = dunk.isForced() || foul == null || rng.nextDouble() < Balance.d("foul.dunkMakeWhenFouled", 0.7);
        ShotAttempt shot = new ShotAttempt(p, 150, 0.01, 0, made, dunk.getPoints(), false, ShotAttempt.Kind.DUNK,
                false, ShotAttempt.Timing.GREEN, made ? 1 : 0);
        shot.setPendingFoul(foul);
        ball.startShot(shot);
        if (phases.get() == MatchPhase.LIVE) {
            goPhase(MatchPhase.SHOT_IN_AIR);
        }
        rimBend = 1;
        resolveShot(shot);
    }

    private void resolveShot(ShotAttempt s) {
        if (ball.getState() != Ball.State.SHOT || ball.getShot() != s) {
            return; // already resolved (blocked) - never score twice
        }
        Player shooter = s.getShooter();
        if (s.isFreeThrow()) {
            resolveFreeThrow(s);
            return;
        }
        shooter.getStats().addShot(s.isMade(), s.getPoints(), s.isOutside());
        shooter.recordShotResult(s.isMade());
        if (s.isMade()) {
            scoreBasket(s);
        } else {
            missShot(s);
        }
        Foul foul = s.getPendingFoul();
        if (foul == null && deferredFoul != null) {
            foul = deferredFoul;
            deferredFoul = null;
            if (pendingWinner == null) {
                callFoul(foul, FoulContext.nonShooting());
            }
            return;
        }
        if (foul != null && pendingWinner == null) {
            if (s.isMade()) {
                publish(GameEventType.AND_ONE, shooter, 0, foul);
                showBanner("AND ONE!", "");
            }
            callFoul(foul, new FoulContext(s.isMade(), s.isOutside()));
        }
    }

    private void scoreBasket(ShotAttempt s) {
        Player shooter = s.getShooter();
        Team team = teamOf(shooter.getSide());
        team.addPoints(s.getPoints(), overtime);
        scoreEvents++;
        netSwing = 1;
        publish(GameEventType.BASKET_MADE, shooter, s.getPoints(), s);
        if (s.isOutside()) {
            publish(GameEventType.THREE_MADE, shooter, s.getPoints(), s);
        }
        if (s.isDunk()) {
            shooter.getStats().addDunk();
            publish(GameEventType.DUNK, shooter, s.getPoints(), s);
            hitStop(Balance.d("feel.dunkHitStop", 0.06));
            shake(8);
            sound("dunk");
            sound("crowd");
            flash("final_burst", 0.08);
        } else if (s.getKind() == ShotAttempt.Kind.LAYUP) {
            shooter.getStats().addLayup();
            publish(GameEventType.LAYUP, shooter, s.getPoints(), s);
            sound(s.isBank() ? "backboard" : "swish");
        } else {
            sound(s.getTiming() == ShotAttempt.Timing.GREEN ? "swish" : "rim");
            if (s.getTiming() == ShotAttempt.Timing.GREEN) {
                fx.text("SWISH", "score", court.getHoopX(), court.getHoopY() - 110);
            }
        }
        boolean assisted = lastPasser != null && lastCatcher == shooter && lastPasser != shooter
                && lastPasser.getSide() == shooter.getSide()
                && elapsed - lastCatchTime <= Balance.d("rules.assistWindow", 4.0);
        if (assisted) {
            lastPasser.getStats().addAssist();
            publish(GameEventType.ASSIST, lastPasser, 0, null);
            lastPasser.addUltimateCharge(Balance.d("meter.assist", 8));
        }
        shooter.addUltimateCharge(Balance.d("meter.basket", 12) + (s.isOutside() ? Balance.d("meter.outsideBonus", 4) : 0));
        for (Player mate : teammatesOf(shooter)) {
            mate.addUltimateCharge(Balance.d("meter.teamBasket", 3));
        }
        lastPasser = null;
        fx.burst("score", court.getHoopX(), court.getHoopY(), 22, 200);
        fx.text("+" + s.getPoints(), "score", court.getHoopX(), court.getHoopY() - 90);
        boolean rattle = !s.isDunk() && s.getChance() < 0.55 && rng.nextBoolean();
        ball.makeDead(court.getHoopX(), court.getHoopY(), court.getRimHeight(), true, rattle);
        shooter.getActions().request(SimpleAction.celebrate(), this);
        checkWin(team);
        goDeadBall(pendingWinner != null ? 1.6 : Balance.d("rules.deadBallTime", 0.9),
                config.isPractice() ? Restart.CHECK : Restart.CLEAR,
                config.isPractice() ? TeamSide.HOME : shooter.getSide().opposite());
    }

    private void checkWin(Team team) {
        if (config.isPractice()) {
            return;
        }
        if (overtime && team.getOvertimePoints() >= RulesConfig.overtimePoints()) {
            pendingWinner = team.getSide();
        } else if (team.getScore() >= targetScore()) {
            pendingWinner = team.getSide();
        }
    }

    private void missShot(ShotAttempt s) {
        publish(GameEventType.SHOT_MISSED, s.getShooter(), 0, s);
        shotClock = shotClockLength();
        sound(s.isBank() ? "backboard" : "rim");
        ballOffRim(s.getShooter());
    }

    private void ballOffRim(Player shooter) {
        double angle = Math.toRadians(25 + rng.nextDouble() * 130);
        double speed = 90 + rng.nextDouble() * 150;
        ball.makeLoose(court.getHoopX(), court.getHoopY() + 6, court.getRimHeight(),
                Math.cos(angle) * speed, Math.sin(angle) * speed, 160 + rng.nextDouble() * 120, true, 0.22);
        ball.setLastTouch(shooter);
        Player override = null;
        for (Player p : players) {
            if (p.guaranteesRebounds()) {
                override = p;
            }
        }
        ball.setReboundOverride(override);
        fx.burst("rim", court.getHoopX(), court.getHoopY(), 8, 120);
        if (phases.get() == MatchPhase.SHOT_IN_AIR) {
            goPhase(MatchPhase.LIVE);
        }
    }

    private void updateLooseBall() {
        if (!court.isInBounds(ball.getX(), ball.getY(), 6)) {
            outOfBounds();
            return;
        }
        if (!ball.canBeGrabbed()) {
            return;
        }
        Player override = ball.getReboundOverride();
        if (override != null && ball.isFromShot() && override.canAct()) {
            ball.setReboundOverride(null);
            ball.startPass(override, override, 720, true);
            pendingRebound = true;
            fx.text("COLOSSUS!", "colossus", override.getX(), override.getY() - 80);
            return;
        }
        Player best = null;
        double bestScore = -1;
        for (Player p : players) {
            if (!p.canAct() || p.isChargingShot()) {
                continue;
            }
            double d = Math.hypot(p.getX() - ball.getX(), p.getY() - ball.getY());
            if (d <= p.getReach(Reach.REBOUND) && ball.getZ() <= p.getEffectiveGrabHeight()) {
                // deterministic contest: rating + reach + jump + seeded random; ties go to the lower list index
                double score = p.getRebound() + rng.nextDouble() * 45 + p.getReach(Reach.REBOUND) * 0.3 + p.getZ();
                if (score > bestScore) {
                    bestScore = score;
                    best = p;
                }
            }
        }
        if (best != null) {
            grabLoose(best);
        }
    }

    private void tryReboundGrab(Player p) {
        if (ball.getState() != Ball.State.LOOSE || !ball.canBeGrabbed()) {
            return;
        }
        double d = Math.hypot(p.getX() - ball.getX(), p.getY() - ball.getY());
        if (d <= p.getReach(Reach.REBOUND) * 1.3 && ball.getZ() <= p.getEffectiveGrabHeight() + 20) {
            grabLoose(p);
        }
    }

    private void grabLoose(Player p) {
        boolean rebound = ball.isFromShot();
        ball.giveTo(p, rebound ? "rebound" : "loose ball");
        if (rebound) {
            recordRebound(p);
        }
        onControlGained(p);
    }

    private void recordRebound(Player p) {
        p.getStats().addRebound();
        publish(GameEventType.REBOUND, p, p.getSide() == offense ? 1 : 0, null);
        p.addUltimateCharge(Balance.d("meter.rebound", 4));
    }

    private void outOfBounds() {
        Player last = ball.getLastTouch();
        TeamSide gets = last == null ? offense.opposite() : last.getSide().opposite();
        if (last != null) {
            last.getStats().addTurnover();
            publish(GameEventType.TURNOVER, last, 0, null);
        }
        double x = Math.max(court.getLeft(), Math.min(court.getRight(), ball.getX()));
        double y = Math.max(court.getTop(), Math.min(court.getBottom(), ball.getY()));
        fx.text("OUT OF BOUNDS", "whiff", x, y - 30);
        refs.signal("signal_out", x, y, 1.0);
        sound("whistle");
        ball.makeDead(x, y, 0);
        goDeadBall(0.9, Restart.CHECK, config.isPractice() ? TeamSide.HOME : gets);
    }

    private void checkInterceptions() {
        Player passer = ball.getPasser();
        if (ball.isPassSafe() && ball.getPassTime() < Balance.d("pass.safeTime", 1.0)) {
            return;
        }
        for (Player d : opponentsOf(passer)) {
            if (!d.canAct() || interceptRolled.contains(d)) {
                continue;
            }
            double dist = Math.hypot(d.getX() - ball.getX(), d.getY() - ball.getY());
            double r = Balance.d("pass.interceptRadius", 24) * d.getReach(Reach.STEAL) / Balance.d("reach.steal", 46);
            if (dist < r) {
                interceptRolled.add(d);
                double chance = Balance.d("pass.interceptChance", 0.22) * d.getDefense() / 70.0;
                if (rng.nextDouble() < chance) {
                    passer.getStats().addTurnover();
                    d.getStats().addSteal();
                    publish(GameEventType.STEAL, d, 0, null);
                    publish(GameEventType.TURNOVER, passer, 0, null);
                    d.addUltimateCharge(Balance.d("meter.steal", 10));
                    fx.text("PICKED OFF!", "steal", d.getX(), d.getY() - 70);
                    ball.giveTo(d, "interception");
                    onControlGained(d);
                    return;
                }
            }
        }
    }

    private void catchPass() {
        Player receiver = ball.getReceiver();
        Player passer = ball.getPasser();
        ball.giveTo(receiver, pendingRebound ? "colossus rebound" : "catch");
        if (pendingRebound) {
            pendingRebound = false;
            recordRebound(receiver);
        } else {
            lastPasser = passer;
            lastCatcher = receiver;
            lastCatchTime = elapsed;
        }
        onControlGained(receiver);
    }

    /** Called whenever a player secures the ball. Handles possession change and auto-switching. */
    private void onControlGained(Player p) {
        if (p.getSide() != offense) {
            offense = p.getSide();
            needsClear = !court.isOutsideArc(p);
            shotClock = shotClockLength();
            lastPasser = null;
            publish(GameEventType.POSSESSION_CHANGE, p, 0, null);
            if (needsClear && p.isUserTeam()) {
                showHint("Clear the ball: take it behind the arc");
            }
        }
        if (p.isUserTeam() && config.isAutoSwitch() && controlled != p) {
            switchControlTo(p);
        }
    }

    private void updateClearRule() {
        if (needsClear && ball.getState() == Ball.State.HELD && ball.getHolder().getSide() == offense
                && court.isOutsideArc(ball.getHolder())) {
            needsClear = false;
            fx.text("CLEARED", "cleared", ball.getHolder().getX(), ball.getHolder().getY() - 60);
        }
    }

    // =========================================================================================================
    // fouls and free throws
    // =========================================================================================================

    /**
     * Calls a foul: counts it, plays the whistle and signal, and enters FOUL_CALLED. If a shot is in the air the call
     * waits until it lands (the basket can still count).
     */
    public void callFoul(Foul foul, FoulContext ctx) {
        MatchPhase phase = phases.get();
        if (phase == MatchPhase.SHOT_IN_AIR && ctx.getShotMade() == null) {
            deferredFoul = foul;
            return;
        }
        if (!phase.isPlay() && phase != MatchPhase.DEAD_BALL) {
            return;
        }
        FoulOutcome outcome = rules.assess(foul, ctx);
        Player off = foul.getOffender();
        Player vic = foul.getVictim();
        off.getStats().addFoul();
        publish(GameEventType.FOUL_COMMITTED, off, rules.getTeamFouls(off.getSide()), foul);
        publish(GameEventType.FOUL_DRAWN, vic, 0, foul);
        refs.signal(foul.getSignal(), vic.getX(), vic.getY(), 1.6);
        sound("whistle");
        String sub = off.getName() + " - team foul " + rules.getTeamFouls(off.getSide());
        if (outcome.getFreeThrows() > 0) {
            sub += " - " + outcome.getFreeThrows() + " FREE THROW" + (outcome.getFreeThrows() > 1 ? "S" : "");
        }
        showBanner(foul.getName(), sub);
        fx.text("FOUL!", "block", vic.getX(), vic.getY() - 90);
        if (!vic.getActions().isAirborne()) {
            vic.getActions().force(SimpleAction.fouled(), this);
        }
        if (ball.getState() == Ball.State.HELD || ball.getState() == Ball.State.PASS || ball.getState() == Ball.State.LOOSE) {
            ball.makeDead(ball.getX(), ball.getY(), ball.getZ());
        }
        calledFoul = foul;
        pendingOutcome = outcome;
        shootingFouls.clear();
        goPhase(MatchPhase.FOUL_CALLED);
        phaseTimer = Balance.d("foul.callPause", 1.4);
    }

    private void updateFoulCalled(double dt) {
        phaseTimer -= dt;
        idlePlayers(dt);
        ball.update(dt, court);
        if (phaseTimer > 0) {
            return;
        }
        FoulOutcome o = pendingOutcome;
        pendingOutcome = null;
        if (pendingWinner != null) {
            goPhase(MatchPhase.GAME_OVER);
            endMatch(pendingWinner);
            return;
        }
        shotClock = shotClockLength();
        if (o != null && o.getFreeThrows() > 0) {
            startFreeThrows(o.getShooter(), o.getFreeThrows(), o.getPossessionAfter(), calledFoul.getName());
        } else {
            setupCheckBall(o == null ? offense : o.getCheckBallTo());
        }
    }

    /** Starts a free-throw trip: dead ball, lineup, shooter at the line. No abilities, no clock. */
    public void startFreeThrows(Player shooter, int count, TeamSide possessionAfter, String reason) {
        freeThrows = new FreeThrowSequence(shooter, count, possessionAfter, reason);
        goPhase(MatchPhase.FREE_THROW);
        double[] spot = court.freeThrowSpot();
        int slot = 0;
        formation.clear();
        for (Player p : players) {
            p.stop();
            p.setShotHold(-1);
            if (p == shooter) {
                p.setPosition(spot[0], spot[1]);
            } else {
                double[] l = court.freeThrowLineup(slot++);
                p.setPosition(l[0], l[1]);
            }
            p.snapFacing(court.getHoopX() - p.getX(), court.getHoopY() - p.getY());
        }
        if (shooter.isUserTeam()) {
            switchControlTo(shooter);
        }
        prepareNextFreeThrow();
    }

    private void prepareNextFreeThrow() {
        Player s = freeThrows.getShooter();
        double[] spot = court.freeThrowSpot();
        s.setPosition(spot[0], spot[1]);
        s.snapFacing(0, -1);
        ball.giveTo(s, "free throw");
        ftBallInAir = false;
        ftAim.reset(RulesConfig.freeThrowPercent(s.getPlayerClass().key()));
        int n = freeThrows.getTaken() + 1;
        showBanner("FREE THROW " + n + " OF " + freeThrows.getTotal(),
                s.isHumanControlled() ? "Hold SHOOT, release when the arrow tip is on the rim" : s.getName() + " at the line");
    }

    private void updateFreeThrow(double dt) {
        Player s = freeThrows == null ? null : freeThrows.getShooter();
        if (s != null && !ftBallInAir && ball.getState() != Ball.State.HELD && ball.getState() != Ball.State.SHOT) {
            anomalies++; // should never happen: self-heal and count it (self-tests assert 0)
            ball.giveTo(s, "free throw (repair)");
        }
        for (Player p : players) {
            PlayerInput in = p.getInput();
            in.clear();
            if (p == s) {
                p.getController().fillInput(p, this, in, dt);
                in.setMove(0, 0);
                in.setSprint(false);
                in.setPassPressed(false);
                in.setQPressed(false);
                in.setEPressed(false);
                in.setRPressed(false);
            }
            p.updateTimers(dt, this);
        }
        if (s != null && ball.getState() == Ball.State.HELD && ball.getHolder() == s) {
            handleBallHandler(s, s.getInput(), dt);
        }
        for (Player p : players) {
            p.getActions().update(dt, this);
            updateLocomotion(p);
            p.updateMovement(dt);
        }
        ball.update(dt, court);
        if (ball.getState() == Ball.State.SHOT && ball.getShot().isFinished()) {
            queue(Interaction.Kind.SCORE, ball.getShot().getShooter(), ball.getShot());
        }
        resolveInteractions();
    }

    private void resolveFreeThrow(ShotAttempt s) {
        Player shooter = s.getShooter();
        Team team = teamOf(shooter.getSide());
        freeThrows.record(s.isMade());
        shooter.getStats().addFreeThrow(s.isMade(), s.getPoints());
        ftBallInAir = false;
        if (s.isMade()) {
            team.addPoints(s.getPoints(), overtime);
            scoreEvents++;
            netSwing = 1;
            sound("swish");
            publish(GameEventType.FREE_THROW_MADE, shooter, s.getPoints(), s);
            fx.text("+1", "score", court.getHoopX(), court.getHoopY() - 90);
            ball.makeDead(court.getHoopX(), court.getHoopY(), court.getRimHeight(), true, false);
            checkWin(team);
        } else {
            sound("rim");
            publish(GameEventType.FREE_THROW_MISSED, shooter, 0, s);
        }
        if (pendingWinner != null) {
            freeThrows = null;
            goDeadBall(1.6, Restart.GAME_OVER, shooter.getSide());
            return;
        }
        if (!freeThrows.isComplete()) {
            if (!s.isMade()) {
                ball.makeDead(court.getHoopX(), court.getHoopY() + 8, court.getRimHeight());
            }
            goDeadBall(0.9, Restart.NEXT_FREE_THROW, shooter.getSide());
            return;
        }
        TeamSide poss = freeThrows.getPossessionAfter();
        freeThrows = null;
        if (poss != null) {
            if (!s.isMade()) {
                ball.makeDead(court.getHoopX(), court.getHoopY() + 8, court.getRimHeight());
            }
            goDeadBall(0.9, Restart.CHECK, poss);
        } else if (s.isMade()) {
            goDeadBall(0.9, Restart.CLEAR, shooter.getSide().opposite());
        } else {
            // missed last free throw: live rebound (offense may shoot again, defense must clear)
            offense = shooter.getSide();
            needsClear = false;
            goPhase(MatchPhase.LIVE);
            ballOffRim(shooter);
        }
    }

    /** Every phase change goes through here: validated by the PhaseMachine, and stale interactions dropped. */
    private void goPhase(MatchPhase next) {
        MatchPhase prev = phases.get();
        phases.go(next);
        boolean playToPlay = prev.isPlay() && next.isPlay();
        if (!playToPlay) {
            queue.clear();
        }
    }

    private void goDeadBall(double seconds, Restart next, TeamSide side) {
        if (phases.get() != MatchPhase.DEAD_BALL) {
            goPhase(MatchPhase.DEAD_BALL);
        }
        phaseTimer = seconds;
        restart = pendingWinner != null ? Restart.GAME_OVER : next;
        restartSide = side;
    }

    // =========================================================================================================
    // clocks, check ball, clear, overtime, end
    // =========================================================================================================

    private void checkClocks() {
        if (config.isPractice() || !phases.get().isPlay()) {
            return;
        }
        if (shotClockLength() > 0 && shotClock <= 0 && ball.getState() != Ball.State.SHOT) {
            Player last = ball.getHolder() != null ? ball.getHolder() : ball.getLastTouch();
            if (last != null) {
                last.getStats().addTurnover();
                publish(GameEventType.TURNOVER, last, 0, null);
            }
            showBanner("SHOT CLOCK", "Turnover");
            sound("whistle");
            refs.signal("signal_out", ball.getX(), ball.getY(), 1.0);
            ball.makeDead(ball.getX(), ball.getY(), ball.getZ());
            goDeadBall(1.0, Restart.CHECK, offense.opposite());
            return;
        }
        if (!overtime && clock <= 0 && ball.getState() != Ball.State.SHOT) {
            ball.makeDead(ball.getX(), ball.getY(), ball.getZ());
            if (home.getScore() != away.getScore()) {
                pendingWinner = home.getScore() > away.getScore() ? TeamSide.HOME : TeamSide.AWAY;
                goDeadBall(1.2, Restart.GAME_OVER, pendingWinner);
                showBanner("FINAL BUZZER", "");
            } else {
                overtime = true;
                goDeadBall(0.6, Restart.OVERTIME, offense.opposite());
                showBanner("OVERTIME", "First to " + RulesConfig.overtimePoints() + " points wins");
            }
        }
    }

    private void setupCheckBall(TeamSide side) {
        goPhase(MatchPhase.CHECK_BALL);
        phaseTimer = Balance.d("rules.checkBallTime", 1.3);
        offense = side;
        needsClear = false;
        shotClock = shotClockLength();
        lastPasser = null;
        entitiesClearOnReset();
        Team off = teamOf(side);
        Player handler = findClass(off, side == TeamSide.HOME ? config.getMainClass() : PlayerClass.GUARD);
        formation.clear();
        formation.put(handler, new double[] {court.checkX(), court.checkY()});
        for (Player p : off.getPlayers()) {
            if (p != handler) {
                formation.put(p, offenseSpot(p.getPlayerClass(), handler.getPlayerClass()));
            }
        }
        for (Player d : teamOf(side.opposite()).getPlayers()) {
            Player man = findClass(off, d.getPlayerClass());
            double[] t = formation.get(man);
            double hx = court.getHoopX() - t[0];
            double hy = court.getHoopY() - t[1];
            double len = Math.max(1, Math.hypot(hx, hy));
            formation.put(d, new double[] {t[0] + hx / len * 55, t[1] + hy / len * 55});
        }
        for (Player p : players) {
            p.getActions().clear(this);
            p.setShotHold(-1);
        }
        ball.giveTo(handler, "check ball");
        if (side == TeamSide.HOME) {
            switchControlTo(handler);
        } else {
            switchControlTo(findClass(home, config.getMainClass()));
        }
        if (bannerTime <= 0) {
            showBanner("CHECK BALL", teamOf(side).getName() + " ball");
        }
    }

    /** FIBA 3x3: after a made basket / last free throw the defense takes the ball under the hoop and must clear it. */
    private void clearUnderBasket(TeamSide side) {
        Team t = teamOf(side);
        Player taker = findClass(t, PlayerClass.BIG);
        double[] spot = court.underBasketSpot();
        taker.getActions().clear(this);
        taker.setPosition(spot[0], spot[1]);
        for (Player p : players) {
            p.setShotHold(-1);
            if (p != taker && p.distanceTo(taker) < 34) {
                p.setPosition(p.getX() + 40, p.getY() + 30);
            }
        }
        ball.giveTo(taker, "under the basket");
        offense = side;
        needsClear = true;
        shotClock = shotClockLength();
        lastPasser = null;
        goPhase(MatchPhase.LIVE);
        if (taker.isUserTeam()) {
            switchControlTo(taker);
            showHint("Your ball - clear it behind the arc");
        }
    }

    private void entitiesClearOnReset() {
        Iterator<CourtEntity> it = entities.iterator();
        while (it.hasNext()) {
            if (it.next() instanceof PickScreen) {
                it.remove();
            }
        }
    }

    private double[] offenseSpot(PlayerClass pc, PlayerClass handlerClass) {
        switch (pc) {
            case BIG: return court.spot(handlerClass == PlayerClass.FORWARD ? -38 : 38, 120);
            case FORWARD: return court.spot(-58, 300);
            default: return court.spot(handlerClass == PlayerClass.FORWARD ? 58 : -58, 330);
        }
    }

    private void endMatch(TeamSide winner) {
        if (phases.get() != MatchPhase.GAME_OVER) {
            goPhase(MatchPhase.GAME_OVER);
        }
        if (summary != null) {
            return;
        }
        boolean won = winner == TeamSide.HOME;
        summary = new MatchSummary(won, home.getScore(), away.getScore(), maxDeficit, config.getDifficulty(),
                config.getMainClass(), overtime, config.isPractice(), cooldownWaste, playTime,
                home.getPlayers(), away.getPlayers(), highlights);
        showBanner(won ? "VICTORY" : "DEFEAT", home.getScore() + " - " + away.getScore());
        bannerTime = 99;
        for (Player p : teamOf(winner).getPlayers()) {
            p.getActions().force(SimpleAction.celebrate(), this);
        }
        sound(won ? "crowd" : "whistle");
        publish(won ? GameEventType.MATCH_WON : GameEventType.MATCH_LOST, null, 0, summary);
        publish(GameEventType.MATCH_FINISHED, null, 0, summary);
    }

    // =========================================================================================================
    // control switching, entities, collisions
    // =========================================================================================================

    private Player nextTeammate(Player p) {
        List<Player> team = teamOf(p.getSide()).getPlayers();
        int i = team.indexOf(p);
        return team.get((i + 1) % team.size());
    }

    /** Gives keyboard control to {@code p}; the previously controlled player goes back to its AI. */
    public void switchControlTo(Player p) {
        if (p == null || p == controlled || !p.isUserTeam()) {
            return;
        }
        if (controlled != null) {
            controlled.setShotHold(-1);
            controlled.setController(aiControllers.get(controlled));
        }
        p.setController(keyboard);
        controlled = p;
        wasteTimer[0] = 0;
        wasteTimer[1] = 0;
        fx.ring("switch", p.getX(), p.getY(), 34, 0.35);
    }

    private void updateEntities(double dt) {
        Iterator<CourtEntity> it = entities.iterator();
        while (it.hasNext()) {
            CourtEntity e = it.next();
            e.update(dt, this);
            for (Player p : players) {
                if (p.distanceTo(e.getX(), e.getY()) <= e.getRadius()) {
                    e.affect(p, dt, this);
                }
            }
            if (e.isExpired()) {
                it.remove();
            }
        }
    }

    private void resolveCollisions(boolean foulChecks) {
        for (int i = 0; i < players.size(); i++) {
            for (int j = i + 1; j < players.size(); j++) {
                separate(players.get(i), players.get(j), foulChecks);
            }
        }
        for (CourtEntity e : entities) {
            for (Player p : players) {
                if (e.blocks(p) && !p.isIntangible()) {
                    pushOut(p, e.getX(), e.getY(), e.getBlockRadius() + Player.RADIUS);
                }
            }
        }
    }

    /** Soft separation: overlapping players are pushed apart a little each frame (never teleported). */
    private void separate(Player a, Player b, boolean foulChecks) {
        if (a.isIntangible() || b.isIntangible()) {
            return;
        }
        double dx = b.getX() - a.getX();
        double dy = b.getY() - a.getY();
        double d = Math.hypot(dx, dy);
        double min = Player.RADIUS * 2;
        if (d >= min) {
            return;
        }
        if (d < 0.001) {
            dx = (players.indexOf(a) < players.indexOf(b)) ? -1 : 1;
            dy = 0.3;
            d = Math.hypot(dx, dy);
        }
        double overlap = min - d;
        double nx = dx / d;
        double ny = dy / d;
        double ma = a.isHeavy() ? 6 : a.getMass();
        double mb = b.isHeavy() ? 6 : b.getMass();
        double total = ma + mb;
        double push = overlap * Balance.d("collision.softness", 0.6);
        a.setPosition(a.getX() - nx * push * (mb / total), a.getY() - ny * push * (mb / total));
        b.setPosition(b.getX() + nx * push * (ma / total), b.getY() + ny * push * (ma / total));
        if (foulChecks && overlap > 4 && phases.get().isPlay()) {
            Foul f = fouls.checkBodyContact(a, b, this);
            if (f != null) {
                callFoul(f, FoulContext.nonShooting());
            }
        }
    }

    private static void pushOut(Player p, double cx, double cy, double minDist) {
        double dx = p.getX() - cx;
        double dy = p.getY() - cy;
        double d = Math.hypot(dx, dy);
        if (d < minDist) {
            if (d < 0.001) {
                dx = 1;
                d = 1;
                dy = 0;
            }
            p.setPosition(cx + dx / d * minDist, cy + dy / d * minDist);
        }
    }

    private void trackCooldownWaste(double dt) {
        if (controlled == null || config.isPractice()) {
            return;
        }
        AbilitySlot[] slots = {AbilitySlot.Q, AbilitySlot.E};
        for (int i = 0; i < 2; i++) {
            Ability a = controlled.getAbility(slots[i]);
            if (a instanceof ActiveAbility && a.canUse(controlled, this)) {
                wasteTimer[i] += dt;
                if (wasteTimer[i] > Balance.d("achievement.wasteSeconds", 20)) {
                    cooldownWaste = true;
                }
            } else {
                wasteTimer[i] = 0;
            }
        }
    }

    // =========================================================================================================
    // practice and debug scenario helpers (run on the game thread)
    // =========================================================================================================

    /** Practice: refill every cooldown and ultimate meter on your team. */
    public void practiceRefill() {
        for (Player p : home.getPlayers()) {
            p.fillUltimate();
            for (AbilitySlot s : new AbilitySlot[] {AbilitySlot.Q, AbilitySlot.E}) {
                Ability a = p.getAbility(s);
                if (a instanceof ActiveAbility) {
                    ((ActiveAbility) a).resetCooldown();
                }
            }
        }
        showHint("Cooldowns and ultimates refilled");
    }

    /** Practice: control the player of this class. */
    public void controlClass(PlayerClass pc) {
        switchControlTo(findClass(home, pc));
    }

    /** Debug scenarios (F6-F11 with the F3 overlay on). Returns a description or why it could not run. */
    public String debugScenario(String name) {
        if (!phases.get().isPlay()) {
            return "Scenario needs live play";
        }
        Player me = controlled;
        Player opp = getMatchup(me);
        double hx = court.getHoopX();
        double hy = court.getHoopY();
        switch (name) {
            case "shooting_foul":
                takeBall(me);
                me.setPosition(hx + 30, hy + court.getArcRadius() + 20);
                callFoul(new ShootingFoul(opp, me), new FoulContext(false, true));
                return "Shooting foul behind the arc: 2 free throws";
            case "dunk":
                takeBall(me);
                me.setPosition(hx + 40, hy + 80);
                startShotOrFinish(me);
                return "Dunk attempt";
            case "block":
                takeBall(opp);
                opp.setPosition(hx - 20, hy + 150);
                me.setPosition(hx - 20, hy + 128);
                opp.getActions().force(new JumpShotAction(false), this);
                ((JumpShotAction) opp.getActions().getCurrent()).release(getMeterTime(opp) * 0.86);
                me.getActions().force(new arcshot.action.BlockAction(false), this);
                return "Block attempt on a jump shot";
            case "out_of_bounds":
                ball.makeLoose(court.getRight() - 10, hy + 200, 30, 400, 0, 80, false, 5);
                ball.setLastTouch(opp);
                return "Ball out of bounds (last touch: opponent)";
            case "seventh_foul":
                rules.setTeamFouls(opp.getSide(), RulesConfig.bonusFrom() - 1);
                takeBall(me);
                callFoul(new PersonalFoul(opp, me, "REACH-IN"), FoulContext.nonShooting());
                return "7th team foul: 2 free throws";
            case "free_throws":
                takeBall(me);
                goPhase(MatchPhase.DEAD_BALL);
                startFreeThrows(me, 2, null, "debug");
                return "Free-throw sequence (2)";
            default:
                return "Unknown scenario";
        }
    }

    private void takeBall(Player p) {
        if (ball.getState() == Ball.State.SHOT) {
            ball.makeLoose(ball.getX(), ball.getY(), ball.getZ(), 0, 0, 0, false, 0);
        }
        for (Player q : players) {
            q.getActions().clear(this);
            q.setShotHold(-1);
        }
        ball.giveTo(p, "debug");
        offense = p.getSide();
        needsClear = false;
        syncShotPhase();
    }

    // =========================================================================================================
    // queries
    // =========================================================================================================

    public List<Player> opponentsOf(Player p) { return teamOf(p.getSide().opposite()).getPlayers(); }

    public List<Player> teammatesOf(Player p) {
        List<Player> list = new ArrayList<>(teamOf(p.getSide()).getPlayers());
        list.remove(p);
        return list;
    }

    /** Closest opponent within {@code maxDist}, or null. */
    public Player nearestOpponent(Player p, double maxDist) {
        Player best = null;
        double bestD = maxDist;
        for (Player o : opponentsOf(p)) {
            double d = o.distanceTo(p);
            if (d <= bestD) {
                bestD = d;
                best = o;
            }
        }
        return best;
    }

    /** The opponent of the same class (man-to-man assignment). */
    public Player getMatchup(Player p) {
        return findClass(teamOf(p.getSide().opposite()), p.getPlayerClass());
    }

    /** Decoys (Phantom Squad) belonging to this player. */
    public List<CourtEntity> getDecoysOf(Player p) {
        List<CourtEntity> list = new ArrayList<>();
        for (CourtEntity e : entities) {
            if (e instanceof Decoy && e.getOwner() == p) {
                list.add(e);
            }
        }
        return list;
    }

    private Player colossusOf(TeamSide side) {
        for (Player p : teamOf(side).getPlayers()) {
            if (p.guaranteesRebounds()) {
                return p;
            }
        }
        return null;
    }

    private static Player findClass(Team team, PlayerClass pc) {
        for (Player p : team.getPlayers()) {
            if (p.getPlayerClass() == pc) {
                return p;
            }
        }
        return team.getPlayers().get(0);
    }

    public Team teamOf(TeamSide side) { return side == TeamSide.HOME ? home : away; }

    public CourtGeometry getCourt() { return court; }

    public Ball getBall() { return ball; }

    public Team getHome() { return home; }

    public Team getAway() { return away; }

    public List<Player> getPlayers() { return Collections.unmodifiableList(players); }

    public List<CourtEntity> getEntities() { return Collections.unmodifiableList(entities); }

    public RefereeCrew getRefs() { return refs; }

    public RuleEngine getRules() { return rules; }

    public PhaseMachine getPhaseMachine() { return phases; }

    public FreeThrowSequence getFreeThrows() { return freeThrows; }

    public Player getControlled() { return controlled; }

    /** The current phase (see {@link MatchPhase}). */
    public MatchPhase getPhase() { return phases.get(); }

    /** LIVE or SHOT_IN_AIR (abilities use this). */
    public boolean isLive() { return phases.get().isPlay(); }

    public boolean isFreeThrow() { return phases.get() == MatchPhase.FREE_THROW; }

    public boolean isFinished() { return phases.get() == MatchPhase.GAME_OVER; }

    public double getFinishedTime() { return finishedTime; }

    public MatchSummary getSummary() { return summary; }

    public TeamSide getOffense() { return offense; }

    public boolean needsClear() { return needsClear; }

    public boolean isOvertime() { return overtime; }

    public boolean isPractice() { return config.isPractice(); }

    public MatchConfig getConfig() { return config; }

    public double getClockRemaining() { return clock; }

    public double getShotClock() { return Math.max(0, shotClock); }

    public double shotClockLength() { return Balance.d("rules.shotClock", 12); }

    public int targetScore() { return Balance.i("rules.targetScore", 21); }

    /** Number of self-repaired inconsistencies (the self-tests assert this stays 0). */
    public int getAnomalies() { return anomalies + phases.illegalTransitions(); }

    /** Total made baskets + made free throws (self-tests compare it with the score). */
    public int getScoreEvents() { return scoreEvents; }

    public String getClockText() {
        int s = (int) Math.ceil(clock);
        return String.format("%d:%02d", s / 60, s % 60);
    }

    public String getBanner() { return bannerTime > 0 ? banner : ""; }

    public String getBannerSub() { return bannerSub; }

    public double getBannerTime() { return bannerTime; }

    public String getHint() { return hintTime > 0 ? hint : ""; }

    public double getShake() { return shake; }

    public String getFlashKey() { return flashKey; }

    public double getFlashTime() { return flashTime; }

    public String getTintKey() { return tintKey; }

    public double getTintTime() { return tintTime; }

    public double getNetSwing() { return netSwing; }

    /** 0..1 how far the rim is bent down by a dunk. */
    public double getRimBend() { return rimBend; }

    public double getElapsed() { return elapsed; }

    public Random random() { return rng; }

    private void showBanner(String text, String sub) {
        banner = text;
        bannerSub = sub == null ? "" : sub;
        bannerTime = 1.6;
    }

    public void showHint(String text) {
        hint = text;
        hintTime = 1.8;
    }

    /** Footwork sounds: a dribble thud on every bounce, a sneaker squeak when a dash / crossover starts. */
    private void soundHooks() {
        Player h = ball.getState() == Ball.State.HELD ? ball.getHolder() : null;
        if (h != null && ball.isDribbling()) {
            int bounce = (int) (h.getActions().getLocomotionTime() * Ball.dribbleRate(Math.hypot(h.getVx(), h.getVy())));
            if (bounce != lastBounce) {
                sound("dribble");
            }
            lastBounce = bounce;
        }
        for (Player p : players) {
            ActionType t = p.getActions().getType();
            ActionType before = lastSoundType.put(p, t);
            if ((t == ActionType.DASH || t == ActionType.CROSSOVER) && before != t) {
                sound("sneaker");
            }
        }
    }

    private void sound(String name) {
        publish(GameEventType.SOUND, null, 0, name);
    }

    /** Events are buffered and published in order at the end of the tick (step 9 of the update order). */
    private void publish(GameEventType type, Player source, int value, Object payload) {
        boolean user = source == null || source.isUserTeam();
        pendingEvents.add(new GameEvent(type, source, user, config.isPractice(), value, payload));
    }

    private void flushEvents() {
        if (pendingEvents.isEmpty()) {
            return;
        }
        List<GameEvent> list = new ArrayList<>(pendingEvents);
        pendingEvents.clear();
        for (GameEvent e : list) {
            bus.publish(e);
        }
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
