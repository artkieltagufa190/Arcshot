package arcshot.achievement;

import arcshot.core.GameEvent;
import arcshot.reward.Reward;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Base class of all achievements: identity, tier, branch, prerequisites and rewards, plus progress tracking.
 * <p>
 * OOP pillars:
 * <ul>
 *   <li><b>ABSTRACTION</b> - {@link #handle} and {@link #getTarget} are abstract: <i>how</i> progress is counted
 *       is left to subclasses.</li>
 *   <li><b>INHERITANCE</b> - {@link CounterAchievement}, {@link SingleMatchAchievement}, {@link StreakAchievement},
 *       {@link ConditionalAchievement} and {@link CompositeAchievement} share everything else.</li>
 *   <li><b>POLYMORPHISM</b> - the {@link AchievementManager} calls {@code handle(event)} on every achievement
 *       without knowing its type.</li>
 *   <li><b>ENCAPSULATION</b> - all fields are private; the lists are exposed read-only.</li>
 * </ul>
 */
public abstract class Achievement {
    private final String id;
    private final String name;
    private final String description;
    private final String hint;
    private final AchievementTier tier;
    private final AchievementBranch branch;
    private final List<String> prerequisites = new ArrayList<>();
    private final List<Reward> rewards = new ArrayList<>();

    protected Achievement(String id, String name, String description, String hint,
                          AchievementTier tier, AchievementBranch branch) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.hint = hint;
        this.tier = tier;
        this.branch = branch;
    }

    /** Fluent: this achievement can only unlock after these ones. */
    public Achievement requires(String... ids) {
        prerequisites.addAll(Arrays.asList(ids));
        return this;
    }

    /** Fluent: what the player gets. */
    public Achievement reward(Reward... r) {
        rewards.addAll(Arrays.asList(r));
        return this;
    }

    /** The number progress must reach. */
    public abstract int getTarget();

    /** Updates progress for one event. */
    public abstract void handle(GameEvent event, AchievementContext ctx);

    /** Called when a new match starts (single-match achievements reset here). */
    public void onMatchStarted(AchievementContext ctx) { }

    public int getProgress(AchievementContext ctx) {
        return Math.min(getTarget(), ctx.getProgress(id));
    }

    public boolean isComplete(AchievementContext ctx) {
        return getProgress(ctx) >= getTarget();
    }

    public double getFraction(AchievementContext ctx) {
        return getTarget() == 0 ? 1 : getProgress(ctx) / (double) getTarget();
    }

    /** Text like "3 / 5" for progress bars. */
    public String getProgressText(AchievementContext ctx) {
        return getProgress(ctx) + " / " + getTarget();
    }

    public String getId() { return id; }

    public String getName() { return name; }

    public String getDescription() { return description; }

    public String getHint() { return hint; }

    public AchievementTier getTier() { return tier; }

    public AchievementBranch getBranch() { return branch; }

    public List<String> getPrerequisites() { return Collections.unmodifiableList(prerequisites); }

    public List<Reward> getRewards() { return Collections.unmodifiableList(rewards); }
}
