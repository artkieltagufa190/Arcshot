package arcshot.court;

import arcshot.player.Player;

/**
 * Something that happened during this tick and must be resolved by the rules (a shot release, a steal swipe ...).
 * Actions queue interactions; the match resolves them in ONE fixed priority order:
 * FOUL_CHECK (whistle) &gt; SCORE (ball through the hoop / dunk) &gt; BLOCK &gt; SHOT_RELEASE &gt; STEAL &gt; REBOUND &gt; PASS.
 * Ties are broken by player index, so the result is always the same.
 * OOP pillar: <b>ENCAPSULATION</b> (immutable) + implements {@link Comparable} (<b>POLYMORPHISM</b>).
 */
public final class Interaction implements Comparable<Interaction> {

    /** Kinds in priority order (first = resolved first). */
    public enum Kind { FOUL_CHECK, SCORE, BLOCK, SHOT_RELEASE, STEAL, REBOUND, PASS }

    private final Kind kind;
    private final Player player;
    private final Object data;
    private final int order;

    public Interaction(Kind kind, Player player, Object data, int order) {
        this.kind = kind;
        this.player = player;
        this.data = data;
        this.order = order;
    }

    public Kind getKind() { return kind; }

    public Player getPlayer() { return player; }

    public Object getData() { return data; }

    @Override
    public int compareTo(Interaction o) {
        int c = Integer.compare(kind.ordinal(), o.kind.ordinal());
        return c != 0 ? c : Integer.compare(order, o.order);
    }
}
