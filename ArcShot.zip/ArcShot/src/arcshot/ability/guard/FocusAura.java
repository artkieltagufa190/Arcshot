package arcshot.ability.guard;

import arcshot.ability.AbilitySlot;
import arcshot.ability.ActiveAbility;
import arcshot.court.Match;
import arcshot.effect.AccuracyBoostEffect;
import arcshot.player.Player;

/**
 * Guard E (default): 4 s long-range accuracy boost with a yellow aura.
 * OOP pillars: <b>INHERITANCE</b> (extends ActiveAbility / Ultimate) and <b>POLYMORPHISM</b> (overrides perform() and the optional hooks).
 */
public class FocusAura extends ActiveAbility {
    public FocusAura() {
        super("guard.focus_aura", AbilitySlot.E, 12);
    }

    @Override
    protected void perform(Player owner, Match match) {
        owner.applyEffect(new AccuracyBoostEffect("focus", param("duration", 4), param("bonus", 0.18), true));
        match.fx().ring("focus", owner.getX(), owner.getY(), 50, 0.4);
    }

    @Override
    public boolean aiShouldUse(Player owner, Match match) {
        return hasBall(owner, match) && match.getCourt().isOutsideArc(owner);
    }
}
