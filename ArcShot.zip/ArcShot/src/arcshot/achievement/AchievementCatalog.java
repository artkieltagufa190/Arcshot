package arcshot.achievement;

import static arcshot.achievement.AchievementBranch.ABILITY;
import static arcshot.achievement.AchievementBranch.BIG;
import static arcshot.achievement.AchievementBranch.CAREER;
import static arcshot.achievement.AchievementBranch.DEFENSE;
import static arcshot.achievement.AchievementBranch.FORWARD;
import static arcshot.achievement.AchievementBranch.GUARD;
import static arcshot.achievement.AchievementBranch.PLAYMAKING;
import static arcshot.achievement.AchievementBranch.SCORING;
import static arcshot.achievement.AchievementTier.ALL_STAR;
import static arcshot.achievement.AchievementTier.LEGEND;
import static arcshot.achievement.AchievementTier.MVP;
import static arcshot.achievement.AchievementTier.ROOKIE;
import static arcshot.achievement.AchievementTier.STARTER;

import arcshot.ai.Difficulty;
import arcshot.core.Balance;
import arcshot.core.GameEventType;
import arcshot.player.PlayerClass;
import arcshot.reward.AbilityUnlock;
import arcshot.reward.CosmeticUnlock;
import arcshot.reward.PerkUnlock;
import arcshot.reward.TitleUnlock;
import java.util.ArrayList;
import java.util.List;

/**
 * The full achievement tree (35 achievements over 5 tiers; the 5 finishing / free-throw ones came with the upgrade pass). Targets can be tuned in balance.properties
 * ({@code achievement.<id>.target}).
 * <p>
 * <b>To add an achievement:</b> add one {@code list.add(...)} below with an id, texts, tier, branch, the rule and
 * its rewards. Nothing else needs to change.
 * OOP pillar: <b>ABSTRACTION</b> - the rest of the game receives a List&lt;Achievement&gt; and never names a concrete type.
 */
public final class AchievementCatalog {
    private AchievementCatalog() { }

    private static int t(String id, int def) {
        return Balance.i("achievement." + id + ".target", def);
    }

    public static List<Achievement> create() {
        List<Achievement> list = new ArrayList<>();

        // ---------------- ROOKIE ----------------
        list.add(new CounterAchievement("first_bucket", "First Bucket", "Score your first basket.",
                "Just put one in!", ROOKIE, SCORING, Filters.user(GameEventType.BASKET_MADE), 1)
                .reward(new CosmeticUnlock("Street jersey pack", "jersey.teal", "jersey.purple", "jersey.black")));
        list.add(new CounterAchievement("ball_hawk", "Ball Hawk", "Make 5 career steals.",
                "Press F next to the ball handler.", ROOKIE, DEFENSE, Filters.user(GameEventType.STEAL), t("ball_hawk", 5))
                .reward(new AbilityUnlock("guard.crossover_snap")));
        list.add(new CounterAchievement("wall_builder", "Wall Builder", "Block 3 shots (career).",
                "Press Space to jump when a shooter rises.", ROOKIE, DEFENSE, Filters.user(GameEventType.BLOCK), t("wall_builder", 3))
                .reward(new AbilityUnlock("big.bulwark_screen")));
        list.add(new CounterAchievement("dime", "Dime", "Record 3 career assists.",
                "Pass (F) to a teammate who then scores.", ROOKIE, PLAYMAKING, Filters.user(GameEventType.ASSIST), t("dime", 3))
                .reward(new AbilityUnlock("forward.bull_rush")));
        list.add(new CounterAchievement("ability_user", "Ability User", "Use Q or E abilities 10 times.",
                "Abilities recharge - spend them!", ROOKIE, ABILITY, Filters.user(GameEventType.ABILITY_USED), t("ability_user", 10))
                .reward(new TitleUnlock("Spellslinger")));
        list.add(new CounterAchievement("finish_match", "Full Game", "Finish a 3x3 match.",
                "Play until the final buzzer.", ROOKIE, CAREER, Filters.user(GameEventType.MATCH_FINISHED), 1)
                .reward(new TitleUnlock("Rookie")));

        // ---------------- STARTER ----------------
        list.add(new CounterAchievement("sharpshooter", "Sharpshooter", "Make 10 career shots from outside the arc.",
                "Outside-the-arc buckets are worth 2.", STARTER, SCORING, Filters.user(GameEventType.THREE_MADE), t("sharpshooter", 10))
                .reward(new AbilityUnlock("guard.deadeye_mark")));
        list.add(new ConditionalAchievement("clean_sheet", "Clean Sheet", "Win a match allowing 10 points or fewer.",
                "Defense wins championships.", STARTER, DEFENSE,
                s -> s.isWon() && s.getOpponentScore() <= Balance.i("achievement.clean_sheet.max", 10))
                .reward(new AbilityUnlock("big.tremor_stomp")));
        list.add(new CounterAchievement("awakened", "Awakened", "Use your ultimate 3 times.",
                "Fill the meter, then press R.", STARTER, ABILITY, Filters.user(GameEventType.ULTIMATE_USED), t("awakened", 3))
                .requires("ability_user").reward(new PerkUnlock("quick_charge")));
        list.add(new ConditionalAchievement("comeback", "Comeback Kid", "Win after trailing by 6 or more.",
                "Never give up.", STARTER, CAREER,
                s -> s.isWon() && s.getMaxDeficit() >= Balance.i("achievement.comeback.deficit", 6))
                .reward(new PerkUnlock("clutch_gene")));
        list.add(new CounterAchievement("playmaker", "Playmaker", "Record 15 career assists.",
                "Find the open teammate.", STARTER, PLAYMAKING, Filters.user(GameEventType.ASSIST), t("playmaker", 15))
                .requires("dime").reward(new AbilityUnlock("forward.rebound_surge")));
        list.add(new CounterAchievement("glass_cleaner", "Glass Cleaner", "Grab 20 career rebounds.",
                "Stand near the rim when a shot goes up.", STARTER, DEFENSE, Filters.user(GameEventType.REBOUND), t("glass_cleaner", 20))
                .reward(new PerkUnlock("second_wind")));
        list.add(new CounterAchievement("first_win", "First Win", "Win a 3x3 match.",
                "Beat the AI on any difficulty.", STARTER, CAREER, Filters.user(GameEventType.MATCH_WON), 1)
                .reward(new CosmeticUnlock("Elemental aura pack", "aura.fire", "aura.ice", "aura.toxic")));

        // ---------------- ALL-STAR ----------------
        list.add(new StreakAchievement("hot_streak", "Hot Streak", "Make 5 shots in a row in one match.",
                "Time your releases in the green.", ALL_STAR, SCORING, Filters.user(GameEventType.BASKET_MADE),
                Filters.user(GameEventType.SHOT_MISSED), t("hot_streak", 5))
                .reward(new PerkUnlock("hot_hand"), new CosmeticUnlock(null, "court.street")));
        list.add(new SingleMatchAchievement("lockdown", "Lockdown", "Block 5 shots in one match.",
                "Bigs block best. Try Iron Wall.", ALL_STAR, DEFENSE, Filters.user(GameEventType.BLOCK), t("lockdown", 5))
                .reward(new AbilityUnlock("big.boulder_toss")));
        list.add(new CounterAchievement("win_10", "Double Digits", "Win 10 matches.",
                "Keep playing!", ALL_STAR, CAREER, Filters.user(GameEventType.MATCH_WON), t("win_10", 10))
                .requires("first_win").reward(new CosmeticUnlock("Court pack", "court.night", "court.sunset")));
        list.add(new ConditionalAchievement("guard_win", "Guard's Glory", "Win a match playing as the Guard.",
                "Choose Guard on the class screen.", ALL_STAR, GUARD, s -> s.isWon() && s.getMainClass() == PlayerClass.GUARD)
                .reward(new AbilityUnlock("guard.slipstream")));
        list.add(new ConditionalAchievement("forward_win", "Forward March", "Win a match playing as the Forward.",
                "Choose Forward on the class screen.", ALL_STAR, FORWARD, s -> s.isWon() && s.getMainClass() == PlayerClass.FORWARD)
                .reward(new AbilityUnlock("forward.tiger_claw")));
        list.add(new ConditionalAchievement("big_win", "Big Time", "Win a match playing as the Big.",
                "Choose Big on the class screen.", ALL_STAR, BIG, s -> s.isWon() && s.getMainClass() == PlayerClass.BIG)
                .reward(new AbilityUnlock("big.rim_protector")));
        list.add(new CompositeAchievement("triple_threat", "Triple Threat", "Win with each class.",
                "Guard, Forward and Big.", ALL_STAR, CAREER, "guard_win", "forward_win", "big_win")
                .reward(new PerkUnlock("ironclad")));
        list.add(new SingleMatchAchievement("dishing", "Dishing Out", "Record 6 assists in one match.",
                "Pass, pass, pass.", ALL_STAR, PLAYMAKING, Filters.user(GameEventType.ASSIST), t("dishing", 6))
                .reward(new AbilityUnlock("forward.blazing_screen")));
        list.add(new CounterAchievement("ability_master", "Ability Master", "Use Q or E abilities 75 times.",
                "Use them every time they are ready.", ALL_STAR, ABILITY, Filters.user(GameEventType.ABILITY_USED), t("ability_master", 75))
                .requires("ability_user").reward(new AbilityUnlock("guard.pickpocket_reflex")));

        // ---------------- MVP ----------------
        list.add(new ConditionalAchievement("hard_win", "Giant Slayer", "Win a match on Hard difficulty.",
                "Pick Hard on the class screen.", MVP, CAREER, s -> s.isWon() && s.getDifficulty() == Difficulty.HARD)
                .reward(new AbilityUnlock("guard.phantom_squad")));
        list.add(new ConditionalAchievement("deep_range", "Deep Range", "Score 10+ points from outside the arc in one match.",
                "Five long-range makes.", MVP, SCORING,
                s -> s.userOutsidePoints(Balance.i("rules.outsidePoints", 2)) >= Balance.i("achievement.deep_range.points", 10))
                .reward(new AbilityUnlock("forward.meteor_crash")));
        list.add(new CounterAchievement("thief", "Master Thief", "Make 60 career steals.",
                "Pickpocket Reflex helps.", MVP, DEFENSE, Filters.user(GameEventType.STEAL), t("thief", 60))
                .requires("ball_hawk").reward(new AbilityUnlock("big.colossus_rebound")));
        list.add(new SingleMatchAchievement("showtime", "Showtime", "Use 3 ultimates in one match.",
                "Quick Charge fills the meter faster.", MVP, ABILITY, Filters.user(GameEventType.ULTIMATE_USED), t("showtime", 3))
                .reward(new CosmeticUnlock(null, "style.gold"), new TitleUnlock("MVP")));
        list.add(new CounterAchievement("floor_general", "Floor General", "Record 50 career assists.",
                "Make everyone better.", MVP, PLAYMAKING, Filters.user(GameEventType.ASSIST), t("floor_general", 50))
                .requires("playmaker").reward(new CosmeticUnlock("Pro jersey pack", "jersey.gold", "jersey.green", "jersey.pink")));

        // ---------------- LEGEND ----------------
        list.add(new ConditionalAchievement("zero_waste", "Zero Waste", "Win without leaving Q or E ready-but-unused for 20 s.",
                "Use abilities as soon as they come back.", LEGEND, ABILITY, s -> s.isWon() && !s.hadCooldownWaste())
                .reward(new CosmeticUnlock(null, "aura.legend")));
        list.add(new CounterAchievement("hall_of_famer", "Hall of Famer", "Win 25 matches.",
                "A long career.", LEGEND, CAREER, Filters.user(GameEventType.MATCH_WON), t("hall_of_famer", 25))
                .requires("win_10").reward(new TitleUnlock("Legend"), new CosmeticUnlock(null, "style.legend")));
        // ---------------- UPGRADE PASS: finishing, fouls, free throws ----------------
        list.add(new CounterAchievement("layup_line", "Layup Line", "Make 5 career layups.",
                "Press SHOOT while driving into the paint.", ROOKIE, SCORING, Filters.user(GameEventType.LAYUP), t("layup_line", 5))
                .reward(new TitleUnlock("Finisher")));
        list.add(new CounterAchievement("high_flyer", "High Flyer", "Throw down 5 career dunks.",
                "Attack the rim at full speed - Bigs dunk the easiest.", STARTER, SCORING, Filters.user(GameEventType.DUNK), t("high_flyer", 5))
                .requires("layup_line").reward(new TitleUnlock("High Flyer")));
        list.add(new CounterAchievement("charity_stripe", "Charity Stripe", "Make 10 career free throws.",
                "Release when the arrow tip sits on the rim.", STARTER, SCORING, Filters.user(GameEventType.FREE_THROW_MADE), t("charity_stripe", 10))
                .reward(new TitleUnlock("Ice Water")));
        list.add(new CounterAchievement("contact_artist", "Contact Artist", "Draw 5 career fouls.",
                "Drive to the rim and finish through contact.", STARTER, PLAYMAKING, Filters.user(GameEventType.FOUL_DRAWN), t("contact_artist", 5))
                .reward(new TitleUnlock("Contact Artist")));
        list.add(new CounterAchievement("and_one", "And One!", "Score while being fouled.",
                "A made shot through a foul counts + 1 free throw.", ALL_STAR, SCORING, Filters.user(GameEventType.AND_ONE), 1)
                .requires("contact_artist").reward(new TitleUnlock("And-One")));

        List<String> others = new ArrayList<>();
        for (Achievement a : list) {
            others.add(a.getId());
        }
        list.add(new CompositeAchievement("completionist", "Completionist", "Unlock every other achievement.",
                "Complete all branches.", LEGEND, CAREER, others)
                .reward(new CosmeticUnlock("Everything", CosmeticUnlock.ALL), new TitleUnlock("GOAT")));
        return list;
    }
}
