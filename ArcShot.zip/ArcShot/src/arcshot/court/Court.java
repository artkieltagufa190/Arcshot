package arcshot.court;

import arcshot.core.Balance;
import arcshot.player.Player;

/**
 * Half-court geometry in logical pixels (50 px = 1 m, FIBA 3x3 court 15 m x 11 m).
 * Knows where the hoop, arc and paint are and answers questions like "is this point outside the arc?".
 * OOP pillar: <b>ENCAPSULATION</b> - all measurements are private and only exposed through query methods.
 */
public class Court {
    public static final double PX_PER_M = 50;

    private final double left;
    private final double top;
    private final double width;
    private final double height;
    private final double hoopX;
    private final double hoopY;
    private final double arcRadius;
    private final double cornerX;
    private final double paintHalfWidth;
    private final double paintDepth;
    private final double rimHeight;

    public Court() {
        width = 15 * PX_PER_M;
        height = 11 * PX_PER_M;
        left = (1280 - width) / 2;
        top = 92;
        hoopX = left + width / 2;
        hoopY = top + 1.575 * PX_PER_M;
        arcRadius = Balance.d("court.arcRadiusMeters", 6.75) * PX_PER_M;
        cornerX = Math.min(arcRadius - 1, 6.6 * PX_PER_M);
        paintHalfWidth = 4.9 * PX_PER_M / 2;
        paintDepth = 5.8 * PX_PER_M;
        rimHeight = Balance.d("court.rimHeight", 152);
    }

    public double getLeft() { return left; }

    public double getTop() { return top; }

    public double getRight() { return left + width; }

    public double getBottom() { return top + height; }

    public double getWidth() { return width; }

    public double getHeight() { return height; }

    public double getHoopX() { return hoopX; }

    public double getHoopY() { return hoopY; }

    public double getArcRadius() { return arcRadius; }

    public double getCornerX() { return cornerX; }

    public double getPaintHalfWidth() { return paintHalfWidth; }

    public double getPaintDepth() { return paintDepth; }

    /** Rim height in "z" pixels. */
    public double getRimHeight() { return rimHeight; }

    public double distanceToHoop(double x, double y) {
        return Math.hypot(x - hoopX, y - hoopY);
    }

    /** True if a shot from here is worth the long-range value (2 points in 3x3). */
    public boolean isOutsideArc(double x, double y) {
        return Math.abs(x - hoopX) >= cornerX || distanceToHoop(x, y) > arcRadius;
    }

    public boolean isOutsideArc(Player p) {
        return isOutsideArc(p.getX(), p.getY());
    }

    public boolean isInPaint(double x, double y) {
        return Math.abs(x - hoopX) <= paintHalfWidth && y <= top + paintDepth;
    }

    public boolean isInBounds(double x, double y, double margin) {
        return x >= left - margin && x <= left + width + margin && y >= top - margin && y <= top + height + margin;
    }

    /** Keeps a player inside the court lines. */
    public void clamp(Player p) {
        double r = Player.RADIUS;
        double x = Math.max(left + r, Math.min(left + width - r, p.getX()));
        double y = Math.max(top + r, Math.min(top + height - r, p.getY()));
        if (x != p.getX() || y != p.getY()) {
            p.setPosition(x, y);
        }
    }

    /** Where check ball happens: just outside the top of the arc. */
    public double checkX() { return hoopX; }

    public double checkY() { return hoopY + arcRadius + 45; }

    /** A point at angle (degrees, 0 = straight down the middle) and distance from the hoop. */
    public double[] spot(double angleDeg, double distance) {
        double a = Math.toRadians(angleDeg);
        double x = hoopX + Math.sin(a) * distance;
        double y = hoopY + Math.cos(a) * distance;
        x = Math.max(left + 24, Math.min(left + width - 24, x));
        y = Math.max(top + 24, Math.min(top + height - 24, y));
        return new double[] {x, y};
    }

    /** Nearest point just outside the arc, used to "clear" the ball after a turnover. */
    public double[] nearestClearSpot(double x, double y) {
        double dx = x - hoopX;
        double dy = Math.max(10, y - hoopY);
        double len = Math.hypot(dx, dy);
        double d = arcRadius + 40;
        double tx = hoopX + dx / len * d;
        double ty = hoopY + dy / len * d;
        tx = Math.max(left + 24, Math.min(left + width - 24, tx));
        ty = Math.max(top + 24, Math.min(top + height - 24, ty));
        return new double[] {tx, ty};
    }
}
