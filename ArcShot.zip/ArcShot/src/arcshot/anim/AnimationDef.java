package arcshot.anim;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Timing data for one animation: frame count, frames per second, looping, and frame events
 * (e.g. {@code ball_release} on frame 4 of the jump shot). Contains NO images, so gameplay and the headless
 * self-tests can use it.
 * <p>
 * OOP pillar: <b>ENCAPSULATION</b> - immutable; events are exposed read-only.
 */
public final class AnimationDef {
    private final String name;
    private final int frames;
    private final double fps;
    private final boolean loop;
    private final List<String>[] events;

    @SuppressWarnings("unchecked")
    public AnimationDef(String name, int frames, double fps, boolean loop, String eventSpec) {
        this.name = name;
        this.frames = Math.max(1, frames);
        this.fps = Math.max(1, fps);
        this.loop = loop;
        this.events = new List[this.frames];
        for (int i = 0; i < this.frames; i++) {
            events[i] = new ArrayList<>();
        }
        if (eventSpec != null) {
            for (String part : eventSpec.split(",")) {
                String[] kv = part.trim().split(":");
                if (kv.length == 2) {
                    try {
                        int f = Integer.parseInt(kv[0].trim());
                        if (f >= 0 && f < this.frames) {
                            events[f].add(kv[1].trim());
                        }
                    } catch (NumberFormatException ignored) {
                        // a broken event entry is skipped, never fatal
                    }
                }
            }
        }
    }

    public String getName() { return name; }

    public int getFrames() { return frames; }

    public double getFps() { return fps; }

    public boolean isLoop() { return loop; }

    /** Seconds for one full play-through. */
    public double getDuration() { return frames / fps; }

    /** Events fired when this frame starts. */
    public List<String> eventsAt(int frame) {
        return frame < 0 || frame >= frames ? Collections.<String>emptyList() : Collections.unmodifiableList(events[frame]);
    }

    /** First frame that carries the event, or -1. */
    public int frameOf(String event) {
        for (int i = 0; i < frames; i++) {
            if (events[i].contains(event)) {
                return i;
            }
        }
        return -1;
    }

    /** Time (s) at which the event's frame starts, or -1. */
    public double timeOf(String event) {
        int f = frameOf(event);
        return f < 0 ? -1 : f / fps;
    }

    /** Frame index for a time; never faster than designed; holds the last frame when not looping. */
    public int frameAt(double time) {
        int f = (int) Math.floor(Math.max(0, time) * fps);
        return loop ? f % frames : Math.min(frames - 1, f);
    }

    /** Spec string written to manifests, e.g. "2:takeoff,4:ball_release". */
    public String eventSpec() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < frames; i++) {
            for (String e : events[i]) {
                if (sb.length() > 0) {
                    sb.append(',');
                }
                sb.append(i).append(':').append(e);
            }
        }
        return sb.toString();
    }
}
