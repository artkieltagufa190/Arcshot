package arcshot.core;

import arcshot.player.Player;

/**
 * An immutable message describing one thing that happened.
 * <p>
 * OOP pillar: <b>ENCAPSULATION</b>. All fields are private and final; listeners can read but never change an event.
 */
public final class GameEvent {
    private final GameEventType type;
    private final Player source;
    private final boolean userTeam;
    private final boolean practice;
    private final int value;
    private final Object payload;

    public GameEvent(GameEventType type, Player source, boolean userTeam, boolean practice, int value, Object payload) {
        this.type = type;
        this.source = source;
        this.userTeam = userTeam;
        this.practice = practice;
        this.value = value;
        this.payload = payload;
    }

    /** Convenience for events without a player (e.g. MATCH_STARTED). */
    public static GameEvent simple(GameEventType type, boolean practice, Object payload) {
        return new GameEvent(type, null, true, practice, 0, payload);
    }

    public GameEventType getType() { return type; }

    /** The player who caused the event, or {@code null}. */
    public Player getSource() { return source; }

    /** True if the source belongs to the human player's team. */
    public boolean isUserTeam() { return userTeam; }

    /** True while in Practice mode (achievements ignore these). */
    public boolean isPractice() { return practice; }

    /** Extra number, e.g. points for BASKET_MADE. */
    public int getValue() { return value; }

    /** Extra object, e.g. the MatchSummary for MATCH_FINISHED. */
    public Object getPayload() { return payload; }
}
