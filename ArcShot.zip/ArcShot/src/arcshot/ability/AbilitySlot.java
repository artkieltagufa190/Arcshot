package arcshot.ability;

/**
 * The three ability keys. Q and E use cooldowns; R is the ultimate (meter).
 * OOP pillar: <b>ABSTRACTION</b> - a fixed set of named values instead of magic strings or numbers.
 */
public enum AbilitySlot {
    Q, E, R
}
