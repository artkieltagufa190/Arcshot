package arcshot.referee;

import arcshot.core.Balance;
import arcshot.court.CourtGeometry;
import arcshot.court.Match;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The two 3x3 referees. Answers "can a referee see this spot?" for the foul detector, and makes the nearest
 * referee whistle and signal after a call.
 * OOP pillar: <b>ENCAPSULATION</b> - the list is private; callers use {@link #sees} and {@link #signal}.
 */
public final class RefereeCrew {
    private final List<Referee> refs = new ArrayList<>();
    private final RefereeAI ai = new RefereeAI();

    public RefereeCrew(CourtGeometry c) {
        double[] lead = c.leadRefSpot();
        double[] trail = c.trailRefSpot();
        refs.add(new Referee("Lead", Referee.Role.LEAD, lead[0], lead[1]));
        refs.add(new Referee("Trail", Referee.Role.TRAIL, trail[0], trail[1]));
    }

    public void update(Match m, double dt) {
        for (Referee r : refs) {
            ai.update(r, m, dt);
        }
    }

    /** True if a referee is close enough to judge contact at (x, y). */
    public boolean sees(double x, double y) {
        double range = Balance.d("ref.viewRange", 480);
        for (Referee r : refs) {
            if (Math.hypot(r.getX() - x, r.getY() - y) <= range) {
                return true;
            }
        }
        return false;
    }

    public Referee nearest(double x, double y) {
        Referee best = refs.get(0);
        for (Referee r : refs) {
            if (Math.hypot(r.getX() - x, r.getY() - y) < Math.hypot(best.getX() - x, best.getY() - y)) {
                best = r;
            }
        }
        return best;
    }

    /** The nearest referee whistles and shows a signal (animation name) for a while. */
    public void signal(String signalAnim, double x, double y, double seconds) {
        Referee r = nearest(x, y);
        r.face(x - r.getX(), y - r.getY());
        r.call(signalAnim, seconds);
    }

    public List<Referee> getReferees() { return Collections.unmodifiableList(refs); }
}
