package arcshot.court;

import arcshot.player.Player;
import arcshot.player.TeamSide;

/**
 * Something an ability leaves on the court for a while: a field, a screen, a decoy.
 * <p>
 * OOP pillars: <b>ABSTRACTION</b> + <b>INHERITANCE</b> + <b>POLYMORPHISM</b>. The match keeps a
 * {@code List<CourtEntity>} and calls {@link #update} / {@link #affect} on each without knowing the concrete type.
 */
public abstract class CourtEntity {
    private final Player owner;
    private final String visualKey;
    private double x;
    private double y;
    private final double radius;
    private final double duration;
    private double remaining;

    protected CourtEntity(Player owner, String visualKey, double x, double y, double radius, double duration) {
        this.owner = owner;
        this.visualKey = visualKey;
        this.x = x;
        this.y = y;
        this.radius = radius;
        this.duration = duration;
        this.remaining = duration;
    }

    /** Called every step. Subclasses may override to move (decoys) but must call super. */
    public void update(double dt, Match match) {
        remaining -= dt;
    }

    /** Called every step for every player inside {@link #getRadius()}. Default: nothing. */
    public void affect(Player p, double dt, Match match) { }

    /** True if this entity physically blocks the player (screens). */
    public boolean blocks(Player p) { return false; }

    /** Radius used for physical blocking (defaults to the full radius). */
    public double getBlockRadius() { return radius; }

    public boolean isExpired() { return remaining <= 0; }

    public Player getOwner() { return owner; }

    public TeamSide getSide() { return owner.getSide(); }

    public String getVisualKey() { return visualKey; }

    public double getX() { return x; }

    public double getY() { return y; }

    protected void moveTo(double nx, double ny) {
        x = nx;
        y = ny;
    }

    public double getRadius() { return radius; }

    public double getFractionLeft() { return Math.max(0, remaining / duration); }
}
