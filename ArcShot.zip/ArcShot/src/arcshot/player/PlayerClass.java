package arcshot.player;

/**
 * The three playable classes (the five basketball positions merged into three).
 * An enum is used for the <i>type label</i>; the real behaviour lives in the {@link Guard}, {@link Forward}
 * and {@link Big} subclasses of {@link Player}.
 * OOP pillar: <b>ENCAPSULATION</b> - each enum constant keeps its data in private fields behind getters.
 */
public enum PlayerClass {
    GUARD("Guard", "The Speedster", "guard"),
    FORWARD("Forward", "The Fighter", "forward"),
    BIG("Big", "The Guardian", "big");

    private final String displayName;
    private final String role;
    private final String key;

    PlayerClass(String displayName, String role, String key) {
        this.displayName = displayName;
        this.role = role;
        this.key = key;
    }

    public String getDisplayName() { return displayName; }

    public String getRole() { return role; }

    /** Lower-case key used in config files and ability ids, e.g. "guard". */
    public String key() { return key; }

    public static PlayerClass fromKey(String key, PlayerClass fallback) {
        for (PlayerClass pc : values()) {
            if (pc.key.equalsIgnoreCase(key) || pc.name().equalsIgnoreCase(key)) {
                return pc;
            }
        }
        return fallback;
    }
}
