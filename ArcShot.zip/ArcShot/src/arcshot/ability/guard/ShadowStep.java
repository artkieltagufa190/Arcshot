package arcshot.ability.guard;

import arcshot.ability.AbilitySlot;
import arcshot.ability.ActiveAbility;
import arcshot.court.Match;
import arcshot.player.Player;

/**
 * Guard Q (default): a 3-tile dash that passes through defenders, leaving afterimages.
 * OOP pillars: <b>INHERITANCE</b> (extends ActiveAbility / Ultimate) and <b>POLYMORPHISM</b> (overrides perform() and the optional hooks).
 */
public class ShadowStep extends ActiveAbility {
    public ShadowStep() {
        super("guard.shadow_step", AbilitySlot.Q, 8);
    }

    @Override
    protected boolean meetsRequirements(Player owner, Match match) {
        return owner.canMove();
    }

    @Override
    protected void perform(Player owner, Match match) {
        double dx = owner.getInput().getMoveX();
        double dy = owner.getInput().getMoveY();
        if (Math.hypot(dx, dy) < 0.2) {
            dx = owner.getFacingX();
            dy = owner.getFacingY();
        }
        owner.startDash(dx, dy, param("distance", 150), param("dashTime", 0.16), true);
        match.fx().afterimage(owner, "shadow");
    }

    @Override
    protected double activeDuration() {
        return param("dashTime", 0.16);
    }

    @Override
    protected void whileActive(double dt, Player owner, Match match) {
        match.fx().afterimage(owner, "shadow");
    }

    @Override
    public boolean aiShouldUse(Player owner, Match match) {
        return hasBall(owner, match) && !match.needsClear() && match.nearestOpponent(owner, 60) != null
                && match.getCourt().distanceToHoop(owner.getX(), owner.getY()) < 380;
    }
}
