package arcshot.achievement;

import arcshot.core.GameEvent;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Completed when a set of other achievements are all unlocked (e.g. "win with each class").
 * OOP pillars: <b>INHERITANCE</b> (extends Achievement) and <b>POLYMORPHISM</b> (overrides handle() / progress).
 */
public class CompositeAchievement extends Achievement {
    private final List<String> parts;

    public CompositeAchievement(String id, String name, String description, String hint,
                                AchievementTier tier, AchievementBranch branch, String... parts) {
        super(id, name, description, hint, tier, branch);
        this.parts = Arrays.asList(parts);
        requires(parts);
    }

    public CompositeAchievement(String id, String name, String description, String hint,
                                AchievementTier tier, AchievementBranch branch, List<String> parts) {
        this(id, name, description, hint, tier, branch, parts.toArray(new String[0]));
    }

    public List<String> getParts() { return Collections.unmodifiableList(parts); }

    @Override
    public int getTarget() { return parts.size(); }

    @Override
    public void handle(GameEvent event, AchievementContext ctx) {
        // nothing to count: progress is derived from the parts
    }

    @Override
    public int getProgress(AchievementContext ctx) {
        int n = 0;
        for (String id : parts) {
            if (ctx.isUnlocked(id)) {
                n++;
            }
        }
        return n;
    }
}
