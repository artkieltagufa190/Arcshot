package arcshot.player;

import arcshot.core.Balance;
import arcshot.effect.Reach;

/**
 * The Guardian: slowest, heaviest, owns the paint (blocks, rebounds), poor from range.
 * OOP pillar: <b>INHERITANCE</b> + <b>POLYMORPHISM</b>.
 */
public class Big extends Player {
    public Big(String name, int number, TeamSide side, boolean userTeam) {
        super(name, number, side, userTeam, "big", 198, 56, 78, 82);
    }

    @Override
    public PlayerClass getPlayerClass() { return PlayerClass.BIG; }

    @Override
    public double rangeModifier(double distanceToHoop, boolean outsideArc) {
        if (outsideArc) {
            return -Balance.d("big.rangePenalty", 0.10);
        }
        return distanceToHoop < 120 ? Balance.d("big.closeBonus", 0.08) : 0.0;
    }

    @Override
    public double getMass() { return 1.7; }

    @Override
    public double getGrabHeight() { return Balance.d("big.grabHeight", 145); }

    @Override
    public double getDunkRange() { return Balance.d("big.dunkRange", 82); }

    @Override
    protected double classReachFactor(Reach reach) {
        switch (reach) {
            case BLOCK: return 1.3;
            case REBOUND: return 1.3;
            case CONTEST: return 1.15;
            case STEAL: return 0.9;
            default: return 1.0;
        }
    }
}
