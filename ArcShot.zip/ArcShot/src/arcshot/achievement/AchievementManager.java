package arcshot.achievement;

import arcshot.core.GameEvent;
import arcshot.core.GameEventBus;
import arcshot.core.GameEventListener;
import arcshot.core.GameEventType;
import arcshot.reward.Reward;
import arcshot.save.Profile;
import arcshot.save.SaveManager;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Listens to the {@link GameEventBus}, updates achievement progress, unlocks achievements (respecting tiers and
 * prerequisites), grants rewards and announces each unlock with an ACHIEVEMENT_UNLOCKED event (the HUD shows a toast).
 * Gameplay never calls this class: it only publishes events.
 * <p>
 * OOP pillars: <b>POLYMORPHISM</b> (treats every achievement as an {@link Achievement}), <b>ABSTRACTION</b>
 * (implements {@link AchievementContext} so achievements never see the save file) and <b>ENCAPSULATION</b>.
 */
public final class AchievementManager implements GameEventListener, AchievementContext {

    /** How a node looks on the Achievements screen. */
    public enum NodeState { UNLOCKED, IN_PROGRESS, LOCKED }

    private final Map<String, Achievement> achievements = new LinkedHashMap<>();
    private final Profile profile;
    private final SaveManager saves;
    private final GameEventBus bus;
    private final List<Achievement> unlockedThisMatch = new java.util.concurrent.CopyOnWriteArrayList<>();

    public AchievementManager(Profile profile, SaveManager saves, GameEventBus bus) {
        this.profile = profile;
        this.saves = saves;
        this.bus = bus;
        for (Achievement a : AchievementCatalog.create()) {
            achievements.put(a.getId(), a);
        }
    }

    // ---- AchievementContext ---------------------------------------------------------------------------------

    @Override
    public int getProgress(String id) { return profile.getAchievementProgress(id); }

    @Override
    public void setProgress(String id, int value) { profile.setAchievementProgress(id, value); }

    @Override
    public boolean isUnlocked(String id) { return profile.isAchievementUnlocked(id); }

    // ---- events ---------------------------------------------------------------------------------------------

    @Override
    public void onEvent(GameEvent event) {
        if (event.getType() == GameEventType.ACHIEVEMENT_UNLOCKED || event.isPractice()) {
            return;
        }
        if (event.getType() == GameEventType.MATCH_STARTED) {
            unlockedThisMatch.clear();
            for (Achievement a : achievements.values()) {
                a.onMatchStarted(this);
            }
            return;
        }
        for (Achievement a : achievements.values()) {
            if (!isUnlocked(a.getId())) {
                a.handle(event, this);
            }
        }
        checkUnlocks();
        if (event.getType() == GameEventType.MATCH_FINISHED) {
            saves.save(profile);
        }
    }

    /** Unlocks everything that is complete and allowed. Loops because one unlock can open a tier or a composite. */
    public void checkUnlocks() {
        boolean changed = true;
        while (changed) {
            changed = false;
            for (Achievement a : achievements.values()) {
                if (!isUnlocked(a.getId()) && a.isComplete(this) && isTierOpen(a.getTier()) && prerequisitesMet(a)) {
                    unlock(a);
                    changed = true;
                }
            }
        }
    }

    private void unlock(Achievement a) {
        profile.markAchievementUnlocked(a.getId());
        for (Reward r : a.getRewards()) {
            r.grant(profile);
        }
        unlockedThisMatch.add(a);
        bus.publish(new GameEvent(GameEventType.ACHIEVEMENT_UNLOCKED, null, true, false, 0, a));
    }

    // ---- queries used by the UI -----------------------------------------------------------------------------

    public boolean isTierOpen(AchievementTier tier) {
        AchievementTier prev = tier.previous();
        if (prev == null) {
            return true;
        }
        return isTierOpen(prev) && countUnlocked(prev) >= tier.requiredFromPrevious();
    }

    public int countUnlocked(AchievementTier tier) {
        int n = 0;
        for (Achievement a : achievements.values()) {
            if (a.getTier() == tier && isUnlocked(a.getId())) {
                n++;
            }
        }
        return n;
    }

    public boolean prerequisitesMet(Achievement a) {
        for (String id : a.getPrerequisites()) {
            if (!isUnlocked(id)) {
                return false;
            }
        }
        return true;
    }

    public NodeState getState(Achievement a) {
        if (isUnlocked(a.getId())) {
            return NodeState.UNLOCKED;
        }
        return isTierOpen(a.getTier()) && prerequisitesMet(a) ? NodeState.IN_PROGRESS : NodeState.LOCKED;
    }

    /** Which achievement gives this unlock key (for "locked - earn X" labels), or null. */
    public Achievement findSourceOf(String unlockKey) {
        for (Achievement a : achievements.values()) {
            for (Reward r : a.getRewards()) {
                if (r.provides(unlockKey)) {
                    return a;
                }
            }
        }
        return null;
    }

    /** Perk slot 2 opens at the All-Star tier (or in Demo Mode). */
    public boolean isPerkSlot2Unlocked() {
        return profile.getSettings().isUnlockAllDemo() || isTierOpen(AchievementTier.ALL_STAR);
    }

    public Achievement get(String id) { return achievements.get(id); }

    public List<Achievement> all() { return Collections.unmodifiableList(new ArrayList<>(achievements.values())); }

    public List<Achievement> getUnlockedThisMatch() { return new ArrayList<>(unlockedThisMatch); }

    public int countAllUnlocked() { return profile.getUnlockedAchievements().size(); }
}
