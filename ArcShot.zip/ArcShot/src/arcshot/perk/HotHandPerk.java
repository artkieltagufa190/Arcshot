package arcshot.perk;

import arcshot.core.Balance;
import arcshot.court.Match;
import arcshot.player.Player;

/**
 * Three straight makes give a small accuracy bonus.
 * OOP pillars: <b>INHERITANCE</b> (extends Perk) and <b>POLYMORPHISM</b> (overrides one hook).
 */
public class HotHandPerk extends Perk {
    public HotHandPerk() {
        super("hot_hand", "Hot Hand", "3 straight makes = +6% shooting until you miss");
    }

    @Override
    public double shootingBonus(Player player, Match match) {
        return player.getConsecutiveMakes() >= Balance.i("perk.hot_hand.streak", 3) ? Balance.d("perk.hot_hand.bonus", 0.06) : 0.0;
    }
}
