package arcshot.ability.forward;

import arcshot.ability.AbilitySlot;
import arcshot.ability.ActiveAbility;
import arcshot.court.Ball;
import arcshot.court.Match;
import arcshot.effect.Reach;
import arcshot.effect.ReachBoostEffect;
import arcshot.player.Player;

/**
 * Forward E (default): 2 s much bigger rebound and block radius, with a shockwave ring.
 * OOP pillars: <b>INHERITANCE</b> (extends ActiveAbility / Ultimate) and <b>POLYMORPHISM</b> (overrides perform() and the optional hooks).
 */
public class SkyRend extends ActiveAbility {
    public SkyRend() {
        super("forward.sky_rend", AbilitySlot.E, 10);
    }

    @Override
    protected void perform(Player owner, Match match) {
        owner.applyEffect(new ReachBoostEffect("sky_rend", param("duration", 2), param("multiplier", 1.6),
                Reach.BLOCK, Reach.REBOUND, Reach.CONTEST));
        match.fx().ring("shockwave", owner.getX(), owner.getY(), 95, 0.45);
    }

    @Override
    public boolean aiShouldUse(Player owner, Match match) {
        Ball.State s = match.getBall().getState();
        if (s == Ball.State.SHOT || s == Ball.State.LOOSE) {
            return owner.distanceTo(match.getBall().getX(), match.getBall().getY()) < 160;
        }
        return opponentHasBall(owner, match) && match.getBall().getHolder().isChargingShot()
                && owner.distanceTo(match.getBall().getHolder()) < 100;
    }
}
