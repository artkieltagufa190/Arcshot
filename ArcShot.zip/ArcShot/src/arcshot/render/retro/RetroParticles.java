package arcshot.render.retro;

import arcshot.court.FxSink;
import arcshot.player.Player;
import arcshot.render.EffectRenderer;
import java.awt.Color;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Effects in the retro style: square pixel sparks, dithered floor rings, stepped afterimages and pixel-font text pops.
 * Implements the same {@link FxSink} as the smooth particle system, so no ability code changes - abilities still ask
 * for effects by key ("shockwave", "timing_green", ...), and the colors still come from the active theme skin.
 * Positions are court coordinates; they are projected when drawn. Update and draw run on the game thread.
 * OOP pillars: <b>POLYMORPHISM</b> (another FxSink) and <b>ENCAPSULATION</b> (the particle list is private).
 */
public final class RetroParticles implements FxSink {
    private static final int MAX = 600;

    /** One effect particle. kind: 0 spark, 1 ring, 2 afterimage, 3 text, 4 trail. */
    static final class P {
        int kind;
        double x;
        double y;
        double z;
        double vx;
        double vy;
        double vz;
        double life;
        double max;
        double size;
        Color color;
        String text;
        Player player;
        String anim;
        int frame;
    }

    private final List<P> list = new ArrayList<>();
    private final EffectRenderer colors;
    private final Random rng = new Random();

    public RetroParticles(EffectRenderer colors) {
        this.colors = colors;
    }

    private P add(int kind, String key, double x, double y, double life) {
        P p = new P();
        p.kind = kind;
        p.x = x;
        p.y = y;
        p.life = life;
        p.max = life;
        p.color = colors.colorFor(key);
        if (list.size() < MAX) {
            list.add(p);
        }
        return p;
    }

    @Override
    public void burst(String key, double x, double y, int count, double speed) {
        int n = (int) Math.max(2, Math.min(40, count * 0.6 * colors.particleScale()));
        for (int i = 0; i < n; i++) {
            P p = add(0, key, x, y, 0.35 + rng.nextDouble() * 0.45);
            double a = rng.nextDouble() * Math.PI * 2;
            double s = speed * (0.4 + rng.nextDouble() * 0.8);
            p.vx = Math.cos(a) * s;
            p.vy = Math.sin(a) * s * 0.6;
            p.z = 10 + rng.nextDouble() * 30;
            p.vz = 60 + rng.nextDouble() * 160;
            p.size = rng.nextInt(3) == 0 ? 2 : 1;
        }
    }

    @Override
    public void ring(String key, double x, double y, double radius, double duration) {
        P p = add(1, key, x, y, Math.max(0.2, duration));
        p.size = radius;
    }

    @Override
    public void afterimage(Player player, String key) {
        P p = add(2, key, player.getX(), player.getY(), 0.35);
        p.z = player.getZ();
        p.player = player;
        p.anim = player.getActions().getAnimation();
        p.frame = player.getActions().getFrame();
    }

    @Override
    public void trail(String key, double x, double y, double size) {
        P p = add(4, key, x, y, 0.3);
        p.size = size;
    }

    @Override
    public void text(String text, String key, double x, double y) {
        P p = add(3, key, x, y, 1.1);
        p.text = text.replace('_', ' ');
        p.vz = 40;
    }

    public void update(double dt) {
        Iterator<P> it = list.iterator();
        while (it.hasNext()) {
            P p = it.next();
            p.life -= dt;
            if (p.life <= 0) {
                it.remove();
                continue;
            }
            if (p.kind == 0) {
                p.x += p.vx * dt;
                p.y += p.vy * dt;
                p.vz -= 520 * dt;
                p.z = Math.max(0, p.z + p.vz * dt);
            } else if (p.kind == 3) {
                p.z += p.vz * dt;
                p.vz *= 0.92;
            }
        }
    }

    /** Floor effects (rings, trails) - drawn before players. */
    public void drawFloor(Graphics2D g, Projection pr) {
        for (P p : list) {
            double k = p.life / p.max;
            if (p.kind == 1) {
                double r = p.size * (1.15 - k * 0.6);
                ditherEllipse(g, pr, p.x, p.y, r, p.color, k > 0.5);
            } else if (p.kind == 4) {
                if (((int) (p.life * 30)) % 2 == 0) {
                    g.setColor(p.color);
                    int s = Math.max(1, (int) (p.size * pr.scale(p.y) * 0.3 * k));
                    g.fillRect(pr.ix(p.x, p.y) - s / 2, pr.iy(p.x, p.y, 0) - s / 2, s, s);
                }
            }
        }
    }

    /** Sparks, afterimages and text - drawn after players. Afterimages are drawn by the match renderer callback. */
    public void drawAir(Graphics2D g, Projection pr, AfterimagePainter ghosts) {
        for (P p : list) {
            double k = p.life / p.max;
            if (p.kind == 0) {
                g.setColor(p.color);
                int s = (int) p.size;
                g.fillRect(pr.ix(p.x, p.y), pr.iy(p.x, p.y, p.z), s, s);
            } else if (p.kind == 2 && ghosts != null) {
                // stepped fade: visible on alternate 1/20 s ticks, like old hardware flicker
                if (((int) (p.life * 20)) % 2 == 0 || k > 0.6) {
                    ghosts.paint(g, p.player, p.anim, p.frame, p.x, p.y, p.z, p.color);
                }
            } else if (p.kind == 3) {
                int x = pr.ix(p.x, p.y);
                int y = pr.iy(p.x, p.y, p.z) - 10;
                if (k > 0.15 || ((int) (p.life * 30)) % 2 == 0) {
                    PixelFont.drawCentered(g, p.text, x, y, p.color, RetroCourtRenderer.OUTLINE, 1);
                }
            }
        }
    }

    private static void ditherEllipse(Graphics2D g, Projection pr, double cx, double cy, double r, Color c, boolean solid) {
        g.setColor(c);
        int steps = (int) Math.max(16, r / 2);
        for (int i = 0; i < steps; i++) {
            if (!solid && i % 2 == 1) {
                continue;
            }
            double a = Math.PI * 2 * i / steps;
            double wx = cx + Math.cos(a) * r;
            double wy = cy + Math.sin(a) * r;
            g.fillRect(pr.ix(wx, wy), pr.iy(wx, wy, 0), 2, 1);
        }
    }

    /** Callback so afterimages are drawn with the real sprite, tinted. */
    public interface AfterimagePainter {
        void paint(Graphics2D g, Player p, String anim, int frame, double x, double y, double z, Color tint);
    }
}
