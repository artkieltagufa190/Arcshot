package arcshot.core;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;

/**
 * Plays short sound effects with {@code javax.sound}. Files are looked up as
 * {@code resources/sounds/<name>.wav}. Missing files or missing audio hardware are silently skipped,
 * so the game never crashes because of sound.
 * <p>
 * It is also a {@link GameEventListener}: it maps game events to sounds, so gameplay code never plays sounds itself.
 * OOP pillar: <b>POLYMORPHISM</b> (implements the listener interface) and <b>ENCAPSULATION</b> (clip cache is private).
 */
public final class SoundManager implements GameEventListener {
    private final Map<String, Clip> cache = new HashMap<>();
    private final Map<String, Boolean> missing = new HashMap<>();
    private volatile float volume = 0.8f;
    private volatile boolean muted;

    public void setVolume(float volume) {
        this.volume = Math.max(0f, Math.min(1f, volume));
    }

    public void setMuted(boolean muted) {
        this.muted = muted;
    }

    /** Plays a sound by name, e.g. "swish". Does nothing if muted or the file is missing. */
    public synchronized void play(String name) {
        if (muted || volume <= 0.01f || Boolean.TRUE.equals(missing.get(name))) {
            return;
        }
        Clip clip = cache.get(name);
        if (clip == null) {
            clip = load(name);
            if (clip == null) {
                missing.put(name, Boolean.TRUE);
                return;
            }
            cache.put(name, clip);
        }
        try {
            applyVolume(clip);
            clip.stop();
            clip.setFramePosition(0);
            clip.start();
        } catch (RuntimeException ex) {
            missing.put(name, Boolean.TRUE);
        }
    }

    private Clip load(String name) {
        try {
            InputStream raw;
            File file = new File("resources/sounds/" + name + ".wav");
            if (file.isFile()) {
                raw = new java.io.FileInputStream(file);
            } else {
                raw = SoundManager.class.getResourceAsStream("/sounds/" + name + ".wav");
            }
            if (raw == null) {
                return null;
            }
            try (AudioInputStream audio = AudioSystem.getAudioInputStream(new BufferedInputStream(raw))) {
                Clip clip = AudioSystem.getClip();
                clip.open(audio);
                return clip;
            }
        } catch (Exception | LinkageError ex) {
            return null; // no sound card, unsupported format, ... : just stay silent
        }
    }

    private void applyVolume(Clip clip) {
        if (clip.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
            FloatControl gain = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
            float db = (float) (20.0 * Math.log10(Math.max(0.0001, volume)));
            gain.setValue(Math.max(gain.getMinimum(), Math.min(gain.getMaximum(), db)));
        }
    }

    @Override
    public void onEvent(GameEvent event) {
        switch (event.getType()) {
            case BASKET_MADE:
            case DUNK:
            case BLOCK:
                break; // v3: the match sends precise SOUND events (swish / rim / backboard / dunk / block)
            case STEAL:
                play("steal");
                break;
            case ABILITY_USED:
                play("ability");
                break;
            case ULTIMATE_USED:
                play("ultimate");
                break;
            case MATCH_WON:
                play("win");
                break;
            case ACHIEVEMENT_UNLOCKED:
                play("achievement");
                break;
            case SOUND:
                if (event.getPayload() != null) {
                    play(String.valueOf(event.getPayload()));
                }
                break;
            default:
                break;
        }
    }
}
