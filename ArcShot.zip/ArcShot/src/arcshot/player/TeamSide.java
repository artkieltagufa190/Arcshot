package arcshot.player;

/**
 * The two teams. HOME is always the human player's team.
 * OOP pillar: <b>ABSTRACTION</b> - a fixed set of named values instead of magic strings or numbers.
 */
public enum TeamSide {
    HOME, AWAY;

    public TeamSide opposite() {
        return this == HOME ? AWAY : HOME;
    }
}
