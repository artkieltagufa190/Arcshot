package arcshot.rules;

import arcshot.player.Player;

/**
 * Defensive foul not in the act of shooting (reach-in, blocking foul, foulable ability).
 * Team fouls 1-6: no free throws, check ball for the fouled team. 7+ : see {@link Foul#resolve}.
 * OOP pillars: <b>INHERITANCE</b> + <b>POLYMORPHISM</b>.
 */
public class PersonalFoul extends Foul {
    private final String name;

    public PersonalFoul(Player offender, Player victim, String name) {
        super(offender, victim);
        this.name = name;
    }

    @Override
    public String getName() { return name; }

    @Override
    protected int baseFreeThrows(FoulContext ctx) { return 0; }
}
