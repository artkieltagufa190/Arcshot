package arcshot.perk;

import arcshot.court.Match;
import arcshot.player.Player;

/**
 * A passive, class-independent bonus. Players have up to two (slot 2 unlocks at the All-Star tier).
 * <p>
 * OOP pillars: <b>ABSTRACTION</b> + <b>POLYMORPHISM</b>. Every hook has a neutral default; each perk subclass
 * overrides only the hook it changes. The player just asks every perk "what is your speed/meter/shooting bonus?".
 */
public abstract class Perk {
    private final String id;
    private final String name;
    private final String description;

    protected Perk(String id, String name, String description) {
        this.id = id;
        this.name = name;
        this.description = description;
    }

    public final String getId() { return id; }

    public final String getName() { return name; }

    public final String getDescription() { return description; }

    public double ultimateGainMultiplier() { return 1.0; }

    public double staminaRegenMultiplier() { return 1.0; }

    public double shootingBonus(Player player, Match match) { return 0.0; }

    /** Multiplier for the length of harmful effects on you. */
    public double debuffDurationMultiplier() { return 1.0; }
}
