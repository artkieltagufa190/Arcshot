package arcshot.player;

/**
 * Creates the right {@link Player} subclass for a {@link PlayerClass}.
 * OOP pillar: <b>POLYMORPHISM</b> - callers receive a {@code Player} and never need to know the concrete type.
 */
public final class PlayerFactory {
    private PlayerFactory() { }

    public static Player create(PlayerClass pc, String name, int number, TeamSide side, boolean userTeam) {
        switch (pc) {
            case GUARD: return new Guard(name, number, side, userTeam);
            case FORWARD: return new Forward(name, number, side, userTeam);
            default: return new Big(name, number, side, userTeam);
        }
    }
}
