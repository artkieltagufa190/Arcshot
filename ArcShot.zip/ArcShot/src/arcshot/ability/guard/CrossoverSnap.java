package arcshot.ability.guard;

import arcshot.ability.AbilitySlot;
import arcshot.ability.ActiveAbility;
import arcshot.court.Match;
import arcshot.effect.StunEffect;
import arcshot.player.Player;

/**
 * Guard Q (alternate): a quick juke; the nearest defender stumbles for 1 second.
 * OOP pillars: <b>INHERITANCE</b> (extends ActiveAbility / Ultimate) and <b>POLYMORPHISM</b> (overrides perform() and the optional hooks).
 */
public class CrossoverSnap extends ActiveAbility {
    public CrossoverSnap() {
        super("guard.crossover_snap", AbilitySlot.Q, 7);
    }

    @Override
    protected boolean meetsRequirements(Player owner, Match match) {
        return hasBall(owner, match) && match.nearestOpponent(owner, param("range", 130)) != null;
    }

    @Override
    protected void perform(Player owner, Match match) {
        Player defender = match.nearestOpponent(owner, param("range", 130));
        defender.applyEffect(new StunEffect(param("stun", 1.0)));
        owner.startDash(-owner.getFacingY(), owner.getFacingX(), 55, 0.12, false);
        match.fx().burst("snap", defender.getX(), defender.getY() - 30, 10, 140);
        match.fx().text("ANKLES!", "snap", defender.getX(), defender.getY() - 70);
    }

    @Override
    public boolean aiShouldUse(Player owner, Match match) {
        return hasBall(owner, match) && match.nearestOpponent(owner, 70) != null;
    }
}
