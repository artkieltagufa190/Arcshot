package arcshot.ability.big;

import arcshot.ability.Ultimate;
import arcshot.court.Ball;
import arcshot.court.Match;
import arcshot.effect.ColossusEffect;
import arcshot.player.Player;

/**
 * Big R (alternate): for 5 s every missed shot is your rebound, and your team's blocks become possession.
 * OOP pillars: <b>INHERITANCE</b> (extends ActiveAbility / Ultimate) and <b>POLYMORPHISM</b> (overrides perform() and the optional hooks).
 */
public class ColossusRebound extends Ultimate {
    public ColossusRebound() {
        super("big.colossus_rebound");
    }

    @Override
    protected void perform(Player owner, Match match) {
        owner.applyEffect(new ColossusEffect(param("duration", 5)));
        match.flash("colossus", 0.2);
        match.fx().ring("colossus", owner.getX(), owner.getY(), 90, 0.5);
    }

    @Override
    public boolean aiShouldUse(Player owner, Match match) {
        return match.getBall().getState() == Ball.State.SHOT;
    }
}
