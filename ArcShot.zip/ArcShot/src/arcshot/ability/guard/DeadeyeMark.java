package arcshot.ability.guard;

import arcshot.ability.AbilitySlot;
import arcshot.ability.ActiveAbility;
import arcshot.court.Match;
import arcshot.effect.GreenLightEffect;
import arcshot.player.Player;

/**
 * Guard E (alternate): your next shot is a guaranteed perfect ("green") release.
 * OOP pillars: <b>INHERITANCE</b> (extends ActiveAbility / Ultimate) and <b>POLYMORPHISM</b> (overrides perform() and the optional hooks).
 */
public class DeadeyeMark extends ActiveAbility {
    public DeadeyeMark() {
        super("guard.deadeye_mark", AbilitySlot.E, 14);
    }

    @Override
    protected boolean meetsRequirements(Player owner, Match match) {
        return !owner.hasGuaranteedGreen();
    }

    @Override
    protected void perform(Player owner, Match match) {
        owner.applyEffect(new GreenLightEffect(param("duration", 10)));
        match.fx().text("LOCKED IN", "green_light", owner.getX(), owner.getY() - 70);
    }

    @Override
    public boolean aiShouldUse(Player owner, Match match) {
        return hasBall(owner, match) && match.getCourt().isOutsideArc(owner);
    }
}
