package arcshot.rules;

import arcshot.player.TeamSide;

/**
 * Keeps the team-foul count per team and turns a called {@link Foul} into a {@link FoulOutcome}.
 * Pure logic (no Swing, no match), so the self-tests check every foul type with a table.
 * OOP pillars: <b>ENCAPSULATION</b> (foul counts are private) and <b>POLYMORPHISM</b> (works with any Foul).
 */
public final class RuleEngine {
    private final int[] teamFouls = new int[2];

    /** Records the foul for the offender's team and returns its penalty. */
    public FoulOutcome assess(Foul foul, FoulContext ctx) {
        int i = foul.getOffender().getSide().ordinal();
        teamFouls[i] += foul.teamFoulsAdded();
        return foul.resolve(teamFouls[i], ctx);
    }

    public int getTeamFouls(TeamSide side) { return teamFouls[side.ordinal()]; }

    /** True when the NEXT defensive foul by {@code side} gives free throws (the "BONUS" light). */
    public boolean isInPenalty(TeamSide side) { return teamFouls[side.ordinal()] >= RulesConfig.bonusFrom() - 1; }

    /** Test/debug helper (scenario tester). */
    public void setTeamFouls(TeamSide side, int count) { teamFouls[side.ordinal()] = Math.max(0, count); }
}
