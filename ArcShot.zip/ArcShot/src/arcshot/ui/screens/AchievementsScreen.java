package arcshot.ui.screens;

import arcshot.achievement.Achievement;
import arcshot.achievement.AchievementBranch;
import arcshot.achievement.AchievementManager;
import arcshot.achievement.AchievementTier;
import arcshot.app.AppContext;
import arcshot.reward.Reward;
import arcshot.ui.Screen;
import arcshot.ui.Theme;
import arcshot.ui.UIFactory;
import arcshot.ui.components.RoundedPanel;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.CubicCurve2D;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JTextArea;

/**
 * The achievement tree: columns are tiers (Rookie to Legend), rows are branches. Nodes show locked / in progress
 * (with a progress bar) / unlocked, and lines connect prerequisites. Hover a node for details, rewards and a hint.
 * OOP pillars: <b>INHERITANCE</b> (extends Screen) and <b>POLYMORPHISM</b> (the ScreenManager calls its lifecycle hooks).
 */
public class AchievementsScreen extends Screen {
    private static final int LABEL_W = 112;
    private static final int COL_W = 206;
    private static final int NODE_W = 190;
    private static final int NODE_H = 62;
    private static final int HEADER_H = 54;
    private static final int ROW_PAD = 14;

    private final AchievementManager manager;
    private final JLabel detailTitle = UIFactory.heading("Hover an achievement");
    private final JTextArea detailText = UIFactory.paragraph("Columns are tiers, rows are playstyle branches. "
            + "Lines show prerequisites. Locked tiers open when you earn enough achievements in the previous tier.");

    public AchievementsScreen(AppContext app) {
        super(app);
        this.manager = app.achievements();
        manager.checkUnlocks();
        add(UIFactory.header("Achievements", manager.countAllUnlocked() + " of " + manager.all().size()
                + " unlocked" + (app.profile().getSettings().isUnlockAllDemo() ? "   (Demo Mode: all rewards available)" : ""),
                e -> app.back()), BorderLayout.NORTH);
        Tree tree = new Tree();
        add(UIFactory.scrollFree(tree), BorderLayout.CENTER);
        RoundedPanel detail = UIFactory.card(new BorderLayout(0, Theme.S2));
        detail.setPreferredSize(new Dimension(10, 112));
        detail.add(detailTitle, BorderLayout.NORTH);
        detailText.setForeground(Theme.TEXT_MUTED);
        detail.add(detailText, BorderLayout.CENTER);
        add(detail, BorderLayout.SOUTH);
    }

    private void showDetail(Achievement a) {
        if (a == null) {
            return;
        }
        AchievementManager.NodeState st = manager.getState(a);
        detailTitle.setText(a.getName() + "  -  " + a.getTier().getDisplayName() + " / " + a.getBranch().getDisplayName()
                + "  -  " + (st == AchievementManager.NodeState.UNLOCKED ? "UNLOCKED" : a.getProgressText(manager)));
        StringBuilder sb = new StringBuilder(a.getDescription());
        sb.append("\nRewards: ");
        for (Reward r : a.getRewards()) {
            sb.append(r.describe(app.skin())).append(";  ");
        }
        if (st != AchievementManager.NodeState.UNLOCKED) {
            sb.append("\nHint: ").append(a.getHint());
            if (!manager.isTierOpen(a.getTier())) {
                AchievementTier prev = a.getTier().previous();
                sb.append("   (Tier locked: earn ").append(a.getTier().requiredFromPrevious()).append(" ")
                        .append(prev.getDisplayName()).append(" achievements - you have ").append(manager.countUnlocked(prev)).append(")");
            } else if (!manager.prerequisitesMet(a)) {
                sb.append("   (Needs: ");
                for (String id : a.getPrerequisites()) {
                    if (!manager.isUnlocked(id)) {
                        sb.append(manager.get(id).getName()).append(" ");
                    }
                }
                sb.append(")");
            }
        }
        detailText.setText(sb.toString());
    }

    /** The custom-painted tree. Node positions are computed from tier/branch, never hardcoded per node. */
    private final class Tree extends JComponent {
        private final Map<String, Rectangle> bounds = new HashMap<>();
        private final Map<AchievementBranch, Integer> rowY = new EnumMap<>(AchievementBranch.class);
        private String hover;
        private int height;

        Tree() {
            layoutNodes();
            setPreferredSize(new Dimension(LABEL_W + COL_W * 5 + 10, height));
            MouseAdapter mouse = new MouseAdapter() {
                @Override
                public void mouseMoved(MouseEvent e) {
                    String found = null;
                    for (Map.Entry<String, Rectangle> en : bounds.entrySet()) {
                        if (en.getValue().contains(e.getPoint())) {
                            found = en.getKey();
                        }
                    }
                    if (found != null && !found.equals(hover)) {
                        showDetail(manager.get(found));
                    }
                    hover = found;
                    repaint();
                }
            };
            addMouseMotionListener(mouse);
        }

        private void layoutNodes() {
            int y = HEADER_H;
            for (AchievementBranch b : AchievementBranch.values()) {
                int maxInCell = 1;
                for (AchievementTier t : AchievementTier.values()) {
                    maxInCell = Math.max(maxInCell, count(t, b));
                }
                rowY.put(b, y);
                for (AchievementTier t : AchievementTier.values()) {
                    int i = 0;
                    for (Achievement a : manager.all()) {
                        if (a.getTier() == t && a.getBranch() == b) {
                            int x = LABEL_W + t.ordinal() * COL_W + (COL_W - NODE_W) / 2;
                            bounds.put(a.getId(), new Rectangle(x, y + i * (NODE_H + 8), NODE_W, NODE_H));
                            i++;
                        }
                    }
                }
                y += maxInCell * (NODE_H + 8) + ROW_PAD;
            }
            height = y + 10;
        }

        private int count(AchievementTier t, AchievementBranch b) {
            int n = 0;
            for (Achievement a : manager.all()) {
                if (a.getTier() == t && a.getBranch() == b) {
                    n++;
                }
            }
            return n;
        }

        @Override
        protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.quality(g);
            // tier headers
            for (AchievementTier t : AchievementTier.values()) {
                int x = LABEL_W + t.ordinal() * COL_W;
                boolean open = manager.isTierOpen(t);
                g.setColor(open ? Theme.alpha(Theme.PANEL_HI, 160) : Theme.alpha(Theme.PANEL, 120));
                g.fillRoundRect(x + 6, 4, COL_W - 12, HEADER_H - 14, 12, 12);
                g.setFont(Theme.display(20));
                g.setColor(open ? Theme.GOLD : Theme.TEXT_MUTED);
                Theme.drawCentered(g, t.getDisplayName().toUpperCase(), x + COL_W / 2, 18);
                g.setFont(Theme.body(11));
                g.setColor(Theme.TEXT_MUTED);
                String sub = t.previous() == null ? "Open" : (open ? "Open" : "Needs " + t.requiredFromPrevious() + " "
                        + t.previous().getDisplayName() + " (" + manager.countUnlocked(t.previous()) + ")");
                Theme.drawCentered(g, sub, x + COL_W / 2, 34);
            }
            // branch labels and row lines
            for (AchievementBranch b : AchievementBranch.values()) {
                int y = rowY.get(b);
                g.setFont(Theme.bold(13));
                g.setColor(Theme.TEXT_MUTED);
                g.drawString(b.getDisplayName().toUpperCase(), 4, y + NODE_H / 2 + 5);
                g.setColor(Theme.alpha(Theme.BORDER, 70));
                g.drawLine(4, y - ROW_PAD / 2, LABEL_W + COL_W * 5, y - ROW_PAD / 2);
            }
            // prerequisite lines
            g.setStroke(new BasicStroke(2f));
            for (Achievement a : manager.all()) {
                Rectangle to = bounds.get(a.getId());
                for (String pre : a.getPrerequisites()) {
                    Rectangle from = bounds.get(pre);
                    if (from == null || "completionist".equals(a.getId())) {
                        continue;
                    }
                    boolean done = manager.isUnlocked(pre);
                    g.setColor(done ? Theme.alpha(Theme.GOLD, 170) : Theme.alpha(Theme.BORDER, 200));
                    double x1 = from.getMaxX();
                    double y1 = from.getCenterY();
                    double x2 = to.getX();
                    double y2 = to.getCenterY();
                    g.draw(new CubicCurve2D.Double(x1, y1, x1 + 40, y1, x2 - 40, y2, x2, y2));
                }
            }
            for (Achievement a : manager.all()) {
                drawNode(g, a, bounds.get(a.getId()));
            }
            g.dispose();
        }

        private void drawNode(Graphics2D g, Achievement a, Rectangle r) {
            AchievementManager.NodeState st = manager.getState(a);
            boolean hovered = a.getId().equals(hover);
            Color fill;
            Color border;
            switch (st) {
                case UNLOCKED:
                    fill = Theme.mix(Theme.PANEL_HI, Theme.GOLD, 0.18);
                    border = Theme.GOLD;
                    break;
                case IN_PROGRESS:
                    fill = Theme.PANEL_HI;
                    border = Theme.ACCENT_2;
                    break;
                default:
                    fill = Theme.alpha(Theme.PANEL, 200);
                    border = Theme.BORDER;
                    break;
            }
            g.setColor(new Color(0, 0, 0, 60));
            g.fillRoundRect(r.x + 2, r.y + 4, r.width, r.height, 14, 14);
            g.setColor(hovered ? Theme.mix(fill, Color.WHITE, 0.08) : fill);
            g.fillRoundRect(r.x, r.y, r.width, r.height, 14, 14);
            g.setColor(border);
            g.setStroke(new BasicStroke(hovered ? 2.5f : 1.5f));
            g.drawRoundRect(r.x, r.y, r.width, r.height, 14, 14);
            g.setFont(Theme.semi(14));
            g.setColor(st == AchievementManager.NodeState.LOCKED ? Theme.TEXT_MUTED : Theme.TEXT);
            g.drawString(a.getName(), r.x + 12, r.y + 22);
            g.setFont(Theme.body(11));
            g.setColor(Theme.TEXT_MUTED);
            String sub = st == AchievementManager.NodeState.UNLOCKED ? "Unlocked"
                    : (st == AchievementManager.NodeState.LOCKED ? "Locked - " + shorten(a.getHint(), 24) : a.getProgressText(manager));
            g.drawString(sub, r.x + 12, r.y + 38);
            int bw = r.width - 24;
            g.setColor(Theme.BG);
            g.fillRoundRect(r.x + 12, r.y + 46, bw, 6, 6, 6);
            g.setColor(st == AchievementManager.NodeState.UNLOCKED ? Theme.GOLD : Theme.ACCENT_2);
            g.fillRoundRect(r.x + 12, r.y + 46, (int) (bw * a.getFraction(manager)), 6, 6, 6);
            if (st == AchievementManager.NodeState.UNLOCKED) {
                g.setColor(Theme.GOLD);
                g.fillOval(r.x + r.width - 22, r.y + 10, 12, 12);
            }
        }
    }

    private static String shorten(String s, int n) {
        return s.length() <= n ? s : s.substring(0, n - 1) + ".";
    }
}
