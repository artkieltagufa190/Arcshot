package arcshot.action;

import arcshot.core.Balance;
import arcshot.court.Interaction;
import arcshot.court.Match;
import arcshot.player.Player;

/**
 * Jump shot (and free throw). Gather, then HOLD on the dip frame while the shot meter charges; when the shoot key is
 * released the animation continues and the ball leaves the hand on the {@code ball_release} frame event.
 * OOP pillars: <b>INHERITANCE</b> (extends Action) and <b>POLYMORPHISM</b> (overrides onEvent / getZ).
 */
public class JumpShotAction extends Action {
    private final boolean freeThrow;
    private boolean charging = true;
    private double hold = -1;

    public JumpShotAction(boolean freeThrow) {
        super(freeThrow ? ActionType.FREE_THROW : ActionType.JUMP_SHOT, "shoot");
        this.freeThrow = freeThrow;
    }

    public boolean isFreeThrow() { return freeThrow; }

    public boolean isCharging() { return charging; }

    /** Shot-meter seconds captured when the key was released. */
    public double getHold() { return hold; }

    /** Called by the match when the shoot key is released (or auto-release). */
    public void release(double heldSeconds) {
        if (charging) {
            charging = false;
            hold = heldSeconds;
            setHolding(false);
        }
    }

    @Override
    protected void onUpdate(double dt, Player p, Match m) {
        if (charging && getFrame() >= 1) {
            setHolding(true);
        }
    }

    @Override
    protected void onEvent(String event, Player p, Match m) {
        if ("ball_release".equals(event)) {
            m.queue(Interaction.Kind.SHOT_RELEASE, p, this);
        } else if ("takeoff".equals(event) && !freeThrow) {
            m.queue(Interaction.Kind.FOUL_CHECK, p, "jump_shot");
        }
    }

    @Override
    public double getZ() {
        if (freeThrow || charging) {
            return 0;
        }
        double t0 = def().timeOf("takeoff");
        double t1 = def().timeOf("foot_land");
        return arc(getTime(), t0, t1, Balance.d("anim.jumpShotHeight", 26));
    }
}
